# ✅ Direc-Score on Netlify — 100% functional: no database, no accounts, no commands

# ✅ ዴሪክ-ስኮር በNetlify — በ100% ይሰራል፦ ዳታቤዝ የለም፣ መለያ የለም፣ ትዕዛዝ የለም

Every step below is taps in a browser — no terminal, no commands, no sign-ups.
Written for mobile phones and computers alike. Total time: ~5 minutes
(+ ~5 optional minutes for full AI).

ከታች ያሉት ሁሉም ደረጃዎች በብራውዘር ጠቅታ ብቻ ይጠናቀቃሉ — ተርሚናል የለም፣ ትዕዛዝ የለም፣
መለያ የለም። ለስልክና ለኮምፒውተር አንድ አይነት ነው። ግምታዊ ጊᜍ፦ ~5 ደቂቃ
(+ ለሙሉ AI ተጨማሪ ~5 ደቂቃ)።

> **What changed?** The app now stores its data **in the browser itself**
> (IndexedDB + localStorage). When the deployed server cannot persist data
> (Netlify / Vercel serverless), every feature automatically switches to
> browser mode — evaluations, documents, portal, AI and automation all keep
> working and the data survives reloads. **No database, no accounts and no
> commands are needed anywhere.**
>
> **ምን ተቀይሯል?** አፕሊኬሽኑ መረጃውን አሁን **በብራውዘሩ ውስጥ** ያከማቻል (IndexedDB +
> localStorage)። ሰርቨሩ መረጃ ማስቀመጥ ሲታወቅ ሳይችል (Netlify / Vercel serverless)
> ሁሉም አቅም በአውቶማት ወደ ብራውዘር ሁነታ ይቀየራል — ግምገማዎች፣ ሰነዶች፣ ፖርታል፣ AI እና
> አውቶማቲክ ሥራዎች ሁሉ ይቀጥላሉ፤ መረጃው reload ቢደረግም አይጠፋም። **በየትም ቦታ
> ዳታቤዝ፣ መለያ ወይም ትዕዛዝ አያስፈልግም።**

---

## English

### Step 1 — Get the deployment ZIP

1. Open the application (**development preview** / sandbox) → **Settings**
   (PIN **3472**) → **Publish to Netlify**.
2. Tap **"Download deployment package (ZIP)"** — you get one file:
   `direc-score-deploy-YYYY-MM-DD.zip`.
3. **Extract the ZIP** into a folder (phone: Files app → Extract; computer:
   double-click).

### Step 2 — Deploy (~2 minutes)

**Easiest — no account needed:**

1. Open **https://app.netlify.com/drop** in your browser.
2. **Drag the EXTRACTED FOLDER** (not the ZIP file) onto the page.
3. Wait 3–6 minutes → your site is live at
   `https://<random-name>.netlify.app`.

**Or connect GitHub (redeploys automatically on every change):**

1. Create a free repository at **github.com** and upload the files **inside**
   the extracted folder. ⚠️ Do **not** upload `node_modules`, `.next` or the
   `db/` folder — the packaged `.gitignore` already excludes them.
2. On **app.netlify.com**: **Add new site → Import an existing project** →
   pick the repository → **Deploy**. Build settings are already preconfigured
   in `netlify.toml` (Node 20 + `@netlify/plugin-nextjs`, build command
   `npm run db:generate && npx next build`).

No environment variables are required to go live — the site works fully the
moment it opens, with data saved in the browser.

### Step 3 (RECOMMENDED, ~5 minutes) — Shared cloud data on EVERY device

Without any configuration, data is stored **in each browser** — it survives
reloads but is not visible on other devices. To make **all recordings,
edits and updates appear on every device instantly** (and survive refreshes,
restarts and redeploys), connect one free cloud database:

1. Open **https://turso.tech** → sign up free → **Create database**
   (name it e.g. `direcscore`, location closest to you, e.g. `fra` or `jnb`).
2. Copy the **database URL** — it looks like
   `libsql://direcscore-yourname.turso.io`.
3. Create an access token: **turso db tokens create direcscore** (or in the
   web dashboard) and copy the long token.
4. In the **Netlify dashboard**: **Site configuration → Environment
   variables** → add both:

   | Key | Value |
   | --- | --- |
   | `DATABASE_URL` | `libsql://direcscore-yourname.turso.io` |
   | `DATABASE_AUTH_TOKEN` | the long token from step 3 |

5. **Redeploy** the site (Deploys → Trigger deploy).

Done. The app **creates its own tables automatically** on first open — no
commands, no migrations. From then on every device — your phone, the
office computer, a directorate's portal submission — reads and writes the
same database, so everything is shared and can never be lost.

> The free Turso tier is generous (9 GB storage, ~500 databases) — more
> than enough for this application. The database token is a secret: keep it
> in the Netlify environment variables only, never in the code.

### Step 4 (recommended, ~5 minutes) — Enable full AI

Without any key, every AI feature already works using the **built-in offline
analysis engine** — nothing dead-ends. For full language-model quality:

1. On your **deployed site**, open **Settings → AI Provider** (PIN 3472).
2. Pick a free provider — **OpenRouter** is recommended:
   - Create a key at **openrouter.ai/keys** (free account).
   - Base URL: `https://openrouter.ai/api/v1`
   - Model: for example `meta-llama/llama-3.3-70b-instruct:free`
   - Other options: **Groq** (console.groq.com), **Google Gemini**
     (aistudio.google.com/apikey), or **OpenAI** — any OpenAI-compatible
     endpoint works.
3. Paste the key, **Save**, then press **Test** until it turns green.

Done — evaluation, insights, compare, chat, document extraction and the AI
Evaluator now run on your personal model.

### Step 5 (recommended) — Automatic portal delivery

When a directorate submits its report through the public portal **on its own
device**, the submission can be delivered to the supervisor automatically
through Telegram:

1. In Telegram, open **@BotFather** → `/newbot` → copy the **bot token**.
2. In the Netlify dashboard: **Site configuration → Environment variables**
   → add both:

   | Key | Value |
   | --- | --- |
   | `TELEGRAM_BOT_TOKEN` | the token from @BotFather |
   | `TELEGRAM_CHAT_ID` | your chat / user name, e.g. `@feridmhd1` |

3. **Redeploy** the site (Deploys → Trigger deploy).

From then on, portal uploads from the directorates' phones arrive directly
in your Telegram — documents up to ~45 MB — and the portal **always** also
shows one-tap **WhatsApp / Email** hand-off buttons. Without these variables
nothing breaks; the hand-off buttons simply become the delivery method.

### Step 6 — Automation page (send from your own device)

1. Open **Automation** on the deployed site (PIN **3472**).
2. Add your **Telegram bot token** (the same bot from Step 5, or a personal
   one).
3. Score reports, documents and notifications now send **directly from your
   browser** — no server involved.
4. **WhatsApp** and **Email** appear as one-tap hand-off buttons (they open
   with the message already filled in).

### Data & backups (important!)

- **With the cloud database (Step 3)**: all data lives in YOUR Turso
  database — shared across every device, safe from refreshes, restarts and
  redeploys. Backups are still recommended: **Settings → backup → Download
  backup** produces a single JSON file (documents included) that you can
  restore anywhere.
- **Without the cloud database**: data lives **in the browser that entered
  it** — evaluations, documents, settings, everything. It survives reloads
  and restarts, and it is private to that browser profile.
- Make a **weekly backup** a habit: **Settings → backup → Download backup**.
  You get a single JSON file containing ALL data — documents included
  (files are embedded in the backup).
- To move to another device or to recover: open the app on the target device
  → **Settings → backup → Restore** → choose the backup file. After the
  restore everything is back — evaluations, documents, history, settings.
- If the browser data is cleared (cleared browsing data, reinstalled
  browser), the data goes with it — so download backups regularly.

### Honest limits on Netlify (serverless)

1. **Without the cloud database**: data is per-browser — data entered on one
   device does not appear on another. Use **Settings → backup** download
   regularly and restore on the other device when you switch.
   **With the cloud database (Step 3)** this limit disappears: everything is
   shared, including file storage.
2. **Unique file share links** (`/share/report?token=…`,
   `/share/file?token=…`) open on **any device** once the cloud database is
   connected. Without it they open only on the device that stored the
   document; cross-device delivery then goes through **Telegram / WhatsApp /
   Email**.
3. **Upload size on Netlify**: the platform accepts request bodies up to
   ~6 MB, so files larger than ~4 MB should be shared through the
   **Telegram auto-delivery** channel (up to ~45 MB) or by enabling the
   cloud database on a persistent host. All smaller uploads are stored in
   the database and never lost.
4. **Portal auto-delivery** to the supervisor needs the optional
   `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` environment variables; without
   them the portal shows hand-off buttons instead (still fully usable).
5. The **"Download deployment package" button inside the deployed app cannot
   zip itself on serverless** — generate the ZIP from the development project
   before deploying. (The button **does** work in the development preview.)
6. **Google Drive auto-backup** applies to full-server deployments only; on
   Netlify use the manual JSON backup from Settings.

### Alternatives (even more power)

**Shared cloud data without leaving Netlify** — that is exactly what
**Step 3 (Turso)** provides: a persistent cloud database behind the same
serverless deployment. Recommended first.

**Railway / Render / Fly.io / a VPS** additionally give you a persistent
server: Google Drive auto-backup, server-side automation and larger uploads
work there. Deploying needs **no code changes** — the app auto-detects the
persistent server and switches to server mode by itself (same ZIP, same
repository).

---

## አማርኛ

### ደረጃ 1 — የዲፕሎይ ፓኬጁን (ZIP) ያውጡ

1. አፕሊኬሽኑን ይክፈቱ (**development preview**) → **Settings** (PIN **3472**)
   → **Publish to Netlify**።
2. **"Download deployment package (ZIP)"** ይጫኑ — አንድ ፋይል ያገኛሉ፦
   `direc-score-deploy-YYYY-MM-DD.zip`።
3. ZIP ኑን ወደ ፎልደር **ይክፈቱ** (በስልክ፦ Files አፕ → Extract፤ በኮምፒውተር፦
   double-click)።

### ደረጃ 2 — ያሰማሩ (~2 ደቂቃ)

**ቀላሉ መንገድ — መለያ አያስፈልግም፦**

1. **https://app.netlify.com/drop** በብራውዘርዎ ይክፈቱ።
2. **የተከፈተውን ፎልደር** (ZIP ፋይሉን ሳይሆን) ወደ ገጹ ይጎትቱ።
3. ከ3–6 ደቂቃ ይጠብቁ → ጣቢያዎ በ `https://<random-name>.netlify.app`
   ይከፈታል።

**ወይም በGitHub ያገናኙ (በየለውጡ በአውቶማት እንደገና deploy ያደርጋል)፦**

1. በ **github.com** ነጻ repository ይክፈቱ እና የተከፈተው ፎልደር **ውስጥ** ያሉትን
   ፋይሎች ይስቀሉ። ⚠️ `node_modules`፣ `.next` እና `db/` ፎልደሩን **አያስገቡ** —
   የተጠቀለለው `.gitignore` አስቀድሞ ይከላከላቸዋል።
2. በ **app.netlify.com**፦ **Add new site → Import an existing project** →
   repositoryውን ይምረጡ → **Deploy**። የግንባታ ቅንብሮች በ `netlify.toml` ውስጥ
   ተዘጋጅተዋል (Node 20 + `@netlify/plugin-nextjs`፣ build command
   `npm run db:generate && npx next build`)።

ጣቢያውን ለማንቀሳቀስ ምንም environment variable **አያስፈልግም** — ጣቢያው ሲከፈት ሙሉ
አቅሙ ይሰራል፤ መረጃው በብራውዘሩ ውስጥ ይቀመጣል።

### ደረጃ 3 (ይመከራል፣ ~5 ደቂቃ) — የጋራ ደመና መረጃ በሁሉም መሣሪያ

ተለዋዋጭ ካልተቀናጠረ ሁሉ መረጃው **በየብራውዘሩ** ይቀመጣል — reload ቢደረግ አይጠፋም፣
ግን በሌሎች መሣሪያዎች ላይ አይታይም። **ሁሉም መዝገቦች፣ ማስተካከያዎችና ማሻሻያዎች በየትም
መሣሪያ ላይ በቅጽበት እንዲታዩ** (እና refresh፣ restart ወይም redeploy ቢደረግም
እንዳይጠፉ)፣ አንድ ነጻ የደመና ዳታቤዝ ያገናኙ፦

1. **https://turso.tech** ይክፈቱ → በነጻ ይመዝገቡ → **Create database**
   (ስሙን ለምሳሌ `direcscore` ይጻፉ፤ ከእርስዎ ቅርብ የሆነ ቦታ ይምረጡ)።
2. **Database URL**ን ይቅዱ — እንደ ዚህ ይመስላል፦
   `libsql://direcscore-yourname.turso.io`።
3. የመዳረሻ token ይፍጠሩ (**turso db tokens create direcscore** ወይም ከweb
   dashboard) እና የረጅሙን token ይቅዱ።
4. በ **Netlify dashboard**፦ **Site configuration → Environment variables**
   → ሁለቱንም ይጨምሩ፦

   | ቁልፍ | እሴት |
   | --- | --- |
   | `DATABASE_URL` | `libsql://direcscore-yourname.turso.io` |
   | `DATABASE_AUTH_TOKEN` | ከደረጃ 3 ያገኙት token |

5. ጣቢያውን **እንደገና deploy** ይድረግ (Deploys → Trigger deploy)።

ተጠናቋል። አፕሊኬሽኑ **ራሱን ሰንጠረዦችን በአውቶማት ይፈጥራል** — ምንም ትዕዛዝ የለም፣
migration የለም። ከዚያ በኋላ ሁሉም መሣሪያ — ስልክዎ፣ የቢሮ ኮምፒውተሩ፣ የዳይሬክቶሬት
ፖርታል ላኪ — ተመሳሳይ ዳታቤዝ ያነባልና ይጽፋል፤ ስለዚህ ሁሉም ነገር ይጋራል እና ምንም
አይጠፋም።

> የTurso ነጻ እርምጃ ብዙ አቅም አለው (9 GB ማከማቻ) — ለዚህ አፕሊኬሽን በቂ ነው። Token ሚስጥር
> ነው፦ በNetlify environment variables ውስጥ ብቻ ይቀመጥ፣ በኮድ ውስጥ አይጻፍ።

### ደረጃ 4 (ይመከራል፣ ~5 ደቂቃ) — ሙሉ AI ያስተካክሉ

ቁልፍ (key) ሳይኖርም ሁሉም የAI አቅሞች በ **ውስጣዊ offline ትንተና ሞተር** ይሰራሉ —
ምንም አቅም ሳይሰራ አይቀርም። የተሟላ ጥራት ለማግኘት፦

1. በ **የተሰማራው ጣቢያ** ላይ **Settings → AI Provider** ይክፈቱ (PIN 3472)።
2. ነጻ አቅራቢ ይምረጡ — **OpenRouter** ይመከራል፦
   - በ **openrouter.ai/keys** ነጻ መለያ ክፍተው ቁልፍ ይፍጠሩ።
   - Base URL፦ `https://openrouter.ai/api/v1`
   - Model፦ ለምሳሌ `meta-llama/llama-3.3-70b-instruct:free`
   - ሌሎች አማራጮች፦ **Groq** (console.groq.com)፣ **Google Gemini**
     (aistudio.google.com/apikey)፣ ወይም **OpenAI** — ማንኛውም
     OpenAI-compatible endpoint ይሰራል።
3. ቁልፉን ያስገቡ፣ **Save** ይጫኑ፣ ከዚያ **Test** እስኪመረቅ (green) ይጫኑ።

ተጠናቋል — ግምገማ፣ insights፣ ማነጻጸር፣ chat፣ የሰነድ ማውጣት እና AI Evaluator
አሁን በራስዎ ሞዴል ይሰራሉ።

### ደረጃ 5 (ይመከራል) — የፖርታል ራስ-ሰር ልኬት

ዳይሬክቶሬቶች ሪፖርታቸውን በራሳቸው መሣሪያ በፖርታሉ በኩል ሲላኩ በTelegram በአውቶማት
ወደ ሱፐርቫይዘሩ እንዲደርስ፦

1. በTelegram **@BotFather** ይክፈቱ → `/newbot` → የቦቱን **token** ይቅዱ።
2. በNetlify dashboard፦ **Site configuration → Environment variables** →
   ሁለቱንም ይጨምሩ፦

   | ቁልፍ | እሴት |
   | --- | --- |
   | `TELEGRAM_BOT_TOKEN` | ከ@BotFather ያገኙት token |
   | `TELEGRAM_CHAT_ID` | የሱፐርቫይዘሩ chat / ስም፣ ለምሳሌ `@feridmhd1` |

3. ጣቢያውን **እንደገና deploy** ይድረግ (Deploys → Trigger deploy)።

ከዚያ በኋላ የፖርታል ሰነዶች በቀጥታ ወደ Telegramዎ ይደርሳሉ — ሰነዶች እስከ ~45 MB — እና
ፖርታሉ **ሁልጊዜም** የአንድ-ጠቅታ **WhatsApp / Email** አጋዥ አዝራሮችን ያሳያል።
እነዚህ ተለዋዋጮች ከሌሉ ምንም አይበላሽም፤ አጋዥ አዝራሮቹ ብቻ የልኬቱ መንገድ ይሆናሉ።

### ደረጃ 6 — Automation ገጽ (ከራስዎ መሣሪያ መላክ)

1. በተሰማራው ጣቢያ **Automation** ይክፈቱ (PIN **3472**)።
2. የTelegram ቦት tokenዎን ያስገቡ (በደረጃ 5 ያደረጉት ቦት ወይም የግል ቦት)።
3. የውጤት ሪፖርቶች፣ ሰነዶች እና ማሳወቂያዎች በቀጥታ **ከብራውዘርዎ** ይላካሉ — ሰርቨር
   አያስፈልግም።
4. **WhatsApp** እና **Email** እንደ አንድ-ጠቅታ አዝራሮች ይታያሉ (መልእክቱ
   ተጽፎ በዝግጁነት ይከፈታሉ)።

### መረጃ እና መጠባበቂያ (አስፈላጊ!)

- **የደመና ዳታቤዝ (ደረጃ 3) ሲኖር**፦ ሁሉም መረጃ በራስዎ Turso ዳታቤዝ ውስጥ ይኖራል —
  በሁሉም መሣሪያዎች ይጋራል፤ ከrefresh፣ restart እና redeploy ደህንነቱ ተጠብቋል።
  መጠባበቂያ ግን አሁንም ይመከራል፦ **Settings → backup → Download backup**
  ሁሉንም መረጃ በአንድ JSON ፋይል ያወጣል (**ሰነዶቹን ጨምሮ**)፤ በየትም ቦታ Restore
  ማድረግ ይቻላል።
- **የደመና ዳታቤዝ ሳይኖር**፦ መረጃዎ **በገባበት ብራውዘር ውስጥ** ይኖራል — ግምገማዎች፣
  ሰነዶች፣ ቅንብሮች ሁሉ። Reload ወይም restart ቢደረግም አይጠፉም፤ ለዚያ ብራውዘር ብቻ
  የሚታወቅ ነው።
- **በየሳምንቱ መጠባበቂያ** ባህል ይድረግ፦ **Settings → backup → Download backup**።
  ሁሉንም መረጃ በአንድ JSON ፋይል ያወጣል — **ሰነዶቹን ጨምሮ** (ፋይሎቹ በመጠባበቂያው
  ውስጥ ይካተታሉ)።
- ወደ ሌላ መሣሪያ ለመቀየር ወይም ለመመለስ፦ አፕሊኬሽኑን በአዲሱ መሣሪያ ይክፈቱ →
  **Settings → backup → Restore** → የመጠባበቂያ ፋይሉን ይምረጡ። ከተመለሰ
  በኋላ ሁሉም ነገር ይመለሳል — ግምገማዎች፣ ሰነዶች፣ ታሪክ፣ ቅንብሮች።
- የብራውዘሩ መረጃ ሲጠራ (browsing data ሲነጻጥ፣ ብራውዘሩ ሲ reinstall ሲደረግ)
  መረጃውም ይጠፋል — ስለዚህ መጠባበቂያ በተደጋጋሚ ይውሰዱ።

### በNetlify ላይ የሚታወቁ ገደቦች

1. **የደመና ዳታቤዝ ሳለ፦** መረጃ በየብራውዘሩ ነው — በአንድ መሣሪያ የገባ መረጃ በሌላ መሣሪያ
   አይታይም። **Settings → backup** download በየጊዜው ይውሰዱ፤ መሣሪያ ሲቀየሩ በአዲሱ
   መሣሪያ Restore ይድረግ። **የደመና ዳታቤዝ (ደረጃ 3) ሲኖር** ይህ ገደብ ይጠፋል፦
   ሁሉም ነገር — ፋይሎቹን ጨምሮ — ይጋራል።
2. **ልዩ የመጋራት ሊንኮች** (`/share/report?token=…`፣ `/share/file?token=…`)
   የደመና ዳታቤዝ ሲገናኝ በ**ማንኛውም መሣሪያ** ይከፈታሉ። ሳይገናኝ ሰነዱ የተቀመጠበት
   **ተመሳሳይ መሣሪያ** ላይ ብቻ ይከፈታሉ፤ በመሣሪያዎች መካከል መላክ **Telegram / WhatsApp /
   Email** ነው።
3. **የፋይል መጠን በNetlify**፦ መድረኩ የጥያቄ አካል እስከ ~6 MB ብቻ ይቀበላል፤ ስለዚህ
   ከ~4 MB በላይ ፋይሎች **Telegram ራስ-ሰር ልኬት** (እስከ ~45 MB) ወይም በቋሚ
   ሰርቨር ላይ የደመና ዳታቤዝ ይጠቀሙ። ትንሾች ሁሉ በዳታቤዙ ውስጥ ተቀምጠው አይጠፉም።
4. **የፖርታል ራስ-ሰር ልኬት** ወደ ሱፐርቫይዘሩ ተጨማሪ `TELEGRAM_BOT_TOKEN` +
   `TELEGRAM_CHAT_ID` ተለዋዋጮችን ይጠይቃል፤ ከሌሉ ፖርታሉ የአጋዥ አዝራሮችን
   ያሳያል (ሙሉ አቅም አለው)።
5. በተሰማራው አፕሊኬሽን ውስጥ **"Download deployment package"** ቁልፍ በ
   serverless ላይ ራሱን ZIP ማድረግ **አይችልም** — ከመሰማራቱ በፊት ከdevelopment
   ፕሮጀክቱ ZIP ያውጡ። (በdevelopment preview ውስጥ ግን **ይሰራል**።)
6. **Google Drive አውቶማቲክ መጠባበቂያ** ለሙሉ ሰርቨር ዲፕሎይ ብቻ ነው፤ በNetlify
   ላይ ከSettings የሚወጣውን የእጅ JSON መጠባበቂያ ይጠቀሙ።

### አማራጮች (ተጨማሪ አቅም)

**ከNetlify ሳይወጡ የጋራ የደመና መረጃ** — ይህ በቃ የሚለው **ደረጃ 3 (Turso)** ነው፦ ተመሳሳይ
serverless ዲፕሎይ አካባቢ ላይ ቋሚ የደመና ዳታቤዝ። መጀመሪያ ይህን ይምረጡ።

**Railway / Render / Fly.io / VPS** ተጨማሪ ቋሚ ሰርቨር ይሰጣሉ፦ Google Drive
አውቶማቲክ መጠባበቂያ፣ የሰርቨር-ጎን አውቶማቲክ ሥራዎች እና ትልቅ የፋይል መጠን ይሰራሉ። ወደዚህ
ማሰማራት **ምንም የኮድ ለውጥ አያስፈልግም** — አፕሊኬሽኑ ቋሚውን ሰርቨር በራሱ ያሳውቃል እና ወደ
server mode በራሱ ይቀየራል (ተመሳሳይ ZIP፣ ተመሳሳይ repository)።
