"use client";

/**
 * AppShell — single-route client view switcher (?view=...).
 *
 * v3 changes:
 *  - Every view (including the public portal/submit pages) renders inside one
 *    shared page frame: decorative background + <main> + developer-credit footer.
 *  - BackgroundDecor gained dark-mode variants (high-contrast dark palette).
 *  - Added the Settings view (?view=settings).
 *  - BackupScheduler silently runs due weekly Google Drive backups while the
 *    app is open (never on the public portal/submit pages).
 */

import { useEffect, useSyncExternalStore } from "react";
import { useViewNavigation } from "@/hooks/use-view";
import type { UserDTO } from "@/lib/types";
import { LoadingSpinner } from "@/components/shared";
import { toast } from "@/hooks/use-toast";
import { backupApi } from "@/lib/client-api";
import { DashboardView } from "@/components/views/DashboardView";
import { EvaluateView } from "@/components/views/EvaluateView";
import { ReviewView } from "@/components/views/ReviewView";
import { AnalyticsView } from "@/components/views/AnalyticsView";
import { QRCodesView } from "@/components/views/QRCodesView";
import { PortalView } from "@/components/views/PortalView";
import { SubmitView } from "@/components/views/SubmitView";
import { AIStudioView } from "@/components/views/AIStudioView";
import { DocumentHistoryView } from "@/components/views/DocumentHistoryView";
import { CompareView } from "@/components/views/CompareView";
import { AutomationView } from "@/components/views/AutomationView";
import { SettingsView } from "@/components/views/SettingsView";
import { DocumentFilingView } from "@/components/views/FilingView";
import { LinksView } from "@/components/views/LinksView";
import { ContactsView } from "@/components/views/ContactsView";
import { AboutView } from "@/components/views/AboutView";

/**
 * Login has been removed — the app opens directly into the dashboard.
 * A synthetic local user is provided for views that still accept a user prop.
 */
const LOCAL_USER: UserDTO = {
  id: "local-admin",
  email: "admin@harari.gov.et",
  name: "Administrator",
};

/** Decorative fixed background layer (professional gradient blobs + dot grid) */
function BackgroundDecor() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute -top-40 -right-32 h-[28rem] w-[28rem] rounded-full bg-blue-500/10 blur-3xl dark:bg-blue-400/15" />
      <div className="absolute top-1/3 -left-40 h-[24rem] w-[24rem] rounded-full bg-teal-500/10 blur-3xl dark:bg-teal-400/10" />
      <div className="absolute -bottom-40 left-1/3 h-[26rem] w-[26rem] rounded-full bg-primary/10 blur-3xl dark:bg-primary/15" />
      {/* Light-mode dot grid */}
      <div
        className="absolute inset-0 opacity-[0.35] dark:hidden"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(100, 116, 139, 0.14) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
      {/* Dark-mode dot grid (slightly brighter dots on the deep background) */}
      <div
        className="absolute inset-0 hidden opacity-[0.35] dark:block"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(148, 163, 184, 0.10) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
    </div>
  );
}

/**
 * Developer-credit footer — sticks to the bottom of the viewport when content
 * is short, and is pushed down naturally when content overflows (mt-auto).
 */
function AppFooter() {
  return (
    <footer className="glass-card mt-auto border-t border-border/60 pb-[calc(theme(spacing.4)+env(safe-area-inset-bottom))]">
      <div className="mx-auto flex w-full max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
        <p>© {new Date().getFullYear()} Harari Region Health Bureau · Direc-Score</p>
        <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1">
          <span>
            Developed by{" "}
            <span className="font-semibold text-foreground">Mr Ferid Mohammed</span>
          </span>
          <span aria-hidden>·</span>
          <a
            href="tel:+251911133037"
            aria-label="Call the developer at +251 911 133 037"
            className="transition-colors hover:text-foreground"
          >
            📱 +251911133037
          </a>
          <span aria-hidden>·</span>
          <a
            href="mailto:feridmhd3@gmail.com"
            aria-label="Email the developer at feridmhd3@gmail.com"
            className="transition-colors hover:text-foreground"
          >
            📧 feridmhd3@gmail.com
          </a>
        </div>
      </div>
    </footer>
  );
}

/* ---------------- Scheduled Google Drive backup ---------------- */

const BACKUP_ATTEMPT_KEY = "direcscore:lastAutoBackupAttempt";
const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

/** Module-level guard — never let two scheduled backups overlap */
let backupInFlight = false;

async function maybeRunScheduledBackup(): Promise<void> {
  if (backupInFlight) return;
  try {
    const status = await backupApi.status();
    if (
      !status.autoBackupEnabled ||
      !status.driveConfigured ||
      status.lastBackupStatus === "running"
    ) {
      return;
    }
    // Due check — only run once the server-side next-due date has passed
    if (!status.nextBackupDueAt) return;
    if (Date.now() < new Date(status.nextBackupDueAt).getTime()) return;
    // Throttle failed retries — at most one attempt every 6 hours
    const lastAttempt = Number(window.localStorage.getItem(BACKUP_ATTEMPT_KEY) || 0);
    if (lastAttempt && Date.now() - lastAttempt < SIX_HOURS_MS) return;

    backupInFlight = true;
    try {
      const result = await backupApi.run();
      if (result.ok) {
        toast({
          title: "የሳምንት መጠባበቂያ ተጠናቋል / Weekly backup completed",
          description: result.fileName,
        });
      } else {
        window.localStorage.setItem(BACKUP_ATTEMPT_KEY, String(Date.now()));
        toast({
          title: "መጠባበቂያ አልተሳካም / Backup failed",
          description: result.detail || result.fileName,
          variant: "destructive",
        });
      }
      window.dispatchEvent(new CustomEvent("direcscore:backup-done"));
    } finally {
      backupInFlight = false;
    }
  } catch (err) {
    // Fully silent on network / HTTP errors — never disturb the user
    console.warn("[DirecScore] scheduled backup skipped:", err);
  }
}

/**
 * Rendered once for app views. First check 45s after mount, then every 10
 * minutes while the app stays open. Cleanup on unmount.
 */
function BackupScheduler() {
  useEffect(() => {
    let intervalId: ReturnType<typeof setInterval> | null = null;
    const timeoutId = setTimeout(() => {
      void maybeRunScheduledBackup();
      intervalId = setInterval(() => void maybeRunScheduledBackup(), 10 * 60 * 1000);
    }, 45_000);
    return () => {
      clearTimeout(timeoutId);
      if (intervalId) clearInterval(intervalId);
    };
  }, []);
  return null;
}

/** Client-only flag: false during SSR + first hydration render, true after mount */
const emptySubscribe = () => () => {};
function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

export function AppShell() {
  const { view, params, navigate } = useViewNavigation();
  // The active view depends on window.location — wait until mounted so the
  // server-rendered HTML matches the client's first render (no hydration mismatch).
  const mounted = useMounted();

  if (!mounted) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <BackgroundDecor />
        <main className="flex flex-1 items-center justify-center">
          <LoadingSpinner />
        </main>
        <AppFooter />
      </div>
    );
  }

  // Public standalone pages still share the page frame, but the auto-backup
  // scheduler only runs on app views ("runs while the app is open").
  const isPublicView = view === "portal" || view === "submit";

  return (
    <div className="relative flex min-h-screen flex-col">
      <BackgroundDecor />
      <main className="flex flex-1 flex-col">
        {(() => {
          switch (view) {
            // Public views (QR portal + report submission)
            case "portal":
              return (
                <PortalView
                  key={`portal-${params.dir}-${params.quarter}`}
                  directorateKey={params.dir ?? ""}
                  quarter={params.quarter ?? ""}
                />
              );
            case "submit":
              return (
                <SubmitView
                  key={`submit-${params.dir}-${params.quarter}`}
                  directorateKey={params.dir ?? ""}
                  quarter={params.quarter ?? ""}
                  navigate={navigate}
                />
              );
            // App views — no authentication required
            case "evaluate":
              return (
                <EvaluateView
                  key={`eval-${params.directorate}-${params.quarter}`}
                  directorateKey={params.directorate ?? ""}
                  quarter={params.quarter ?? ""}
                  navigate={navigate}
                />
              );
            case "review":
              return <ReviewView navigate={navigate} />;
            case "analytics":
              return <AnalyticsView navigate={navigate} />;
            case "qrcodes":
              return <QRCodesView navigate={navigate} />;
            case "ai-studio":
              return (
                <AIStudioView
                  key={`ai-${params.history ?? ""}`}
                  historyId={params.history ?? ""}
                  navigate={navigate}
                />
              );
            case "document-history":
              return <DocumentHistoryView navigate={navigate} />;
            case "compare":
              return <CompareView ids={params.ids ?? ""} navigate={navigate} />;
            case "automation":
              return <AutomationView navigate={navigate} />;
            case "filing":
              return <DocumentFilingView />;
            case "links":
              return <LinksView navigate={navigate} />;
            case "contacts":
              return <ContactsView navigate={navigate} />;
            case "about":
              return (
                <AboutView
                  navigate={navigate}
                  from={params.from ?? ""}
                  directorateKey={params.dir ?? ""}
                  quarter={params.quarter ?? ""}
                />
              );
            case "settings":
              return <SettingsView navigate={navigate} />;
            default:
              return <DashboardView user={LOCAL_USER} navigate={navigate} />;
          }
        })()}
      </main>
      <AppFooter />
      {!isPublicView && <BackupScheduler />}
    </div>
  );
}
