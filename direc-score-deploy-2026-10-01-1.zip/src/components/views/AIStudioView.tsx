"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import {
  ArrowLeft,
  BarChart3,
  BadgeCheck,
  CheckCircle2,
  FileDown,
  FileText,
  History,
  ImageDown,
  LineChart as LineChartIcon,
  AreaChart as AreaChartIcon,
  Loader2,
  MessageSquare,
  Info,
  PieChart as PieChartIcon,
  RotateCcw,
  Save,
  Send,
  Sparkles,
  Trash2,
  TrendingUp,
  UploadCloud,
  X,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { aiApi, documentsApi, getAIProviderConfig, isLocalMode } from "@/lib/client-api";
import { downloadAnalysisReportPdf } from "@/lib/export-utils";
import { chartContainerToPngDataUrl, downloadChartPng } from "@/lib/chart-export";
import { useLang } from "@/lib/i18n";
import type {
  ChartSpec,
  ColumnStat,
  DataAnalysis,
  DocumentHistoryDTO,
  FinalAnalysisReport,
  GraphicSuggestion,
  Insights,
} from "@/lib/types";
import { LoadingSpinner } from "@/components/shared";
import type { NavigateFn } from "@/hooks/use-view";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Phase = "loading" | "upload" | "extracting" | "analyzing" | "results";

const FILE_ACCEPT =
  ".txt,.md,.csv,.tsv,.json,.html,.htm,.pdf,.docx,.xlsx,.xls,.png,.jpg,.jpeg,.webp,.gif";

const TABLE_MIMES = [
  "text/csv",
  "text/tab-separated-values",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.oasis.opendocument.spreadsheet",
];

const CHART_COLORS = ["#2563eb", "#0d9488", "#f59e0b", "#8b5cf6", "#ef4444"];

const THIN_SCROLLBAR =
  "[scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5";

const sentimentStyles: Record<string, string> = {
  positive: "bg-emerald-100 text-emerald-800 border-emerald-200",
  negative: "bg-red-100 text-red-800 border-red-200",
  neutral: "bg-slate-100 text-slate-700 border-slate-200",
  mixed: "bg-amber-100 text-amber-800 border-amber-200",
};

const statusStyles: Record<string, string> = {
  ready: "bg-emerald-100 text-emerald-800 border-emerald-200",
  processing: "bg-amber-100 text-amber-800 border-amber-200",
  failed: "bg-red-100 text-red-800 border-red-200",
};

interface ChatEntry {
  id: string;
  role: "user" | "assistant";
  content: string;
}

function SentimentBadge({ sentiment }: { sentiment: string }) {
  if (!sentiment) return null;
  const key = sentiment.toLowerCase();
  return (
    <Badge
      variant="outline"
      className={cn("border capitalize", sentimentStyles[key] ?? sentimentStyles.neutral)}
    >
      {sentiment}
    </Badge>
  );
}

function GraphicIcon({ type }: { type: string }) {
  const t = (type || "").toLowerCase();
  if (t.includes("pie")) return <PieChartIcon className="h-5 w-5 text-primary" />;
  if (t.includes("line") || t.includes("trend")) return <LineChartIcon className="h-5 w-5 text-primary" />;
  if (t.includes("progress") || t.includes("radial") || t.includes("gauge"))
    return <TrendingUp className="h-5 w-5 text-primary" />;
  return <BarChart3 className="h-5 w-5 text-primary" />;
}

function normalizeInsights(raw: Record<string, unknown>): Insights {
  const str = (v: unknown): string | undefined => (typeof v === "string" && v.trim() ? v : undefined);
  const strArr = (v: unknown): string[] | undefined =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === "string" && x.trim().length > 0) : undefined;
  return {
    document_type: str(raw.document_type),
    language: str(raw.language),
    sentiment: str(raw.sentiment),
    summary: str(raw.summary),
    key_points: strArr(raw.key_points),
    topics: strArr(raw.topics),
    recommendations: strArr(raw.recommendations),
  };
}

function normalizeGraphics(raw: Array<Record<string, unknown>>): GraphicSuggestion[] {
  return raw.map((g, i) => ({
    id: typeof g.id === "string" ? g.id : `g${i + 1}`,
    title: typeof g.title === "string" && g.title ? g.title : "Visualization",
    type: typeof g.type === "string" && g.type ? g.type : "bar",
    description: typeof g.description === "string" ? g.description : "",
  }));
}

function normalizeAnalysis(raw: Record<string, unknown>): DataAnalysis {
  const str = (v: unknown): string | undefined => (typeof v === "string" && v.trim() ? v : undefined);
  const strArr = (v: unknown): string[] | undefined =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === "string" && x.trim().length > 0) : undefined;
  const num = (v: unknown): number | undefined => {
    if (typeof v === "number" && Number.isFinite(v)) return v;
    if (typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v))) return Number(v);
    return undefined;
  };
  const stats: ColumnStat[] | undefined = Array.isArray(raw.statistics)
    ? raw.statistics
        .filter(
          (s): s is Record<string, unknown> =>
            typeof s === "object" && s !== null && typeof (s as Record<string, unknown>).column === "string"
        )
        .map((s) => {
          const r = s as Record<string, unknown>;
          return {
            column: String(r.column),
            type: typeof r.type === "string" ? r.type : "text",
            min: num(r.min),
            max: num(r.max),
            mean: num(r.mean),
            missing: num(r.missing),
            unique: num(r.unique),
          };
        })
    : undefined;
  return {
    dataset_type: str(raw.dataset_type),
    rows: num(raw.rows),
    columns: num(raw.columns),
    summary: str(raw.summary),
    key_findings: strArr(raw.key_findings),
    statistics: stats && stats.length > 0 ? stats : undefined,
    recommendations: strArr(raw.recommendations),
  };
}

function normalizeCharts(raw: Array<Record<string, unknown>>): ChartSpec[] {
  const out: ChartSpec[] = [];
  raw.forEach((c, i) => {
    if (typeof c !== "object" || c === null) return;
    const title = typeof c.title === "string" && c.title.trim() ? c.title : `Chart ${i + 1}`;
    const type = typeof c.type === "string" ? c.type.toLowerCase() : "bar";
    const xKey = typeof c.xKey === "string" && c.xKey.trim() ? c.xKey : "label";
    const yKeysRaw = Array.isArray(c.yKeys)
      ? c.yKeys.filter((k): k is string => typeof k === "string" && k.trim() !== "")
      : [];
    const yKeys = yKeysRaw.length > 0 ? yKeysRaw : ["value"];
    const rowsRaw = Array.isArray(c.data) ? c.data : [];
    const data: Array<Record<string, string | number>> = [];
    for (const row of rowsRaw) {
      if (typeof row !== "object" || row === null) continue;
      const r = row as Record<string, unknown>;
      const xv = r[xKey];
      const entry: Record<string, string | number> = {
        [xKey]: typeof xv === "string" ? xv : xv !== undefined && xv !== null ? String(xv) : `Item ${data.length + 1}`,
      };
      let hasNumeric = false;
      for (const yk of yKeys) {
        const v = r[yk];
        const n = typeof v === "number" ? v : typeof v === "string" ? Number(v.replace(/,/g, "")) : NaN;
        if (Number.isFinite(n)) {
          entry[yk] = n;
          hasNumeric = true;
        } else if (typeof v === "string" && v.trim() !== "") {
          entry[yk] = v;
        }
      }
      if (hasNumeric) data.push(entry);
      if (data.length >= 12) break;
    }
    if (data.length === 0) return; // drop charts without usable numeric rows
    out.push({
      id: typeof c.id === "string" && c.id ? c.id : `c${i + 1}`,
      title,
      type,
      xKey,
      yKeys,
      data,
      description: typeof c.description === "string" && c.description.trim() ? c.description : undefined,
      unit: typeof c.unit === "string" && c.unit.trim() ? c.unit : undefined,
    });
  });
  return out;
}

/** Rebuild the analysis view-model when a saved document is reopened from history */
function analysisFromHistory(doc: DocumentHistoryDTO): { analysis: DataAnalysis | null; conclusion?: string } {
  const extra = (doc.insights ?? {}) as Record<string, unknown>;
  if (doc.finalReport) {
    const fr = doc.finalReport;
    return {
      analysis: normalizeAnalysis({
        dataset_type: typeof extra.dataset_type === "string" ? extra.dataset_type : "dataset",
        rows: extra.rows,
        columns: extra.columns,
        summary: fr.summary,
        key_findings: fr.key_findings,
        statistics: fr.statistics,
        recommendations: fr.recommendations,
      }),
      conclusion: typeof fr.conclusion === "string" && fr.conclusion.trim() ? fr.conclusion : undefined,
    };
  }
  if (
    (doc.charts?.length ?? 0) > 0 &&
    doc.insights &&
    (doc.insights.summary || (doc.insights.key_points?.length ?? 0) > 0)
  ) {
    return {
      analysis: normalizeAnalysis({
        dataset_type: typeof extra.dataset_type === "string" ? extra.dataset_type : "dataset",
        rows: extra.rows,
        columns: extra.columns,
        summary: doc.insights.summary,
        key_findings: doc.insights.key_points,
        recommendations: doc.insights.recommendations,
      }),
    };
  }
  return { analysis: null };
}

function buildFinalReport(
  fileName: string,
  analysis: DataAnalysis | null,
  conclusion: string | undefined,
  insights?: Insights | null
): FinalAnalysisReport {
  return {
    title: `${fileName} — Final Analysis`,
    generatedAt: new Date().toISOString(),
    summary: analysis?.summary ?? insights?.summary ?? "",
    key_findings: (analysis?.key_findings ?? insights?.key_points ?? []).filter(Boolean),
    recommendations: (analysis?.recommendations ?? insights?.recommendations ?? []).filter(Boolean),
    statistics: analysis?.statistics ?? [],
    conclusion: conclusion || analysis?.summary || insights?.summary || "",
  };
}

/**
 * Build extra graphics straight from the column statistics so the studio can
 * always visualise results — used when the AI did not return its own charts.
 */
function deriveChartsFromStats(stats: ColumnStat[]): ChartSpec[] {
  const numeric = stats.filter(
    (s) => s.type === "number" && (s.mean !== undefined || s.max !== undefined || s.min !== undefined)
  );
  const charts: ChartSpec[] = [];

  if (numeric.length >= 1) {
    charts.push({
      id: "derived-mean",
      title: "Average by Column · በአምድ አማካይ",
      type: "bar",
      xKey: "label",
      yKeys: ["value"],
      data: numeric.map((s) => ({ label: s.column, value: Number((s.mean ?? 0).toFixed(2)) })),
      description: "Mean value of each numeric column",
    });
    charts.push({
      id: "derived-range",
      title: "Min vs Max by Column · አነስተኛ/ከፍተኛ",
      type: "bar",
      xKey: "label",
      yKeys: ["min", "max"],
      data: numeric.map((s) => ({ label: s.column, min: s.min ?? 0, max: s.max ?? 0 })),
      description: "Range of each numeric column",
    });
    charts.push({
      id: "derived-unique",
      title: "Unique Values by Column",
      type: "line",
      xKey: "label",
      yKeys: ["value"],
      data: numeric.map((s) => ({ label: s.column, value: s.unique ?? 0 })),
      description: "Number of distinct values in each numeric column",
    });
  }

  const withMissing = stats.filter((s) => typeof s.missing === "number" && (s.missing ?? 0) > 0);
  if (withMissing.length > 0) {
    charts.push({
      id: "derived-missing",
      title: "Missing Values by Column",
      type: "pie",
      xKey: "label",
      yKeys: ["value"],
      data: withMissing.map((s) => ({ label: s.column, value: s.missing ?? 0 })),
      description: "Share of missing values per column",
    });
  }

  return charts;
}

/**
 * Turn AI visualization suggestions that ship their own data rows into real,
 * renderable charts (best effort — suggestions without usable data are skipped).
 */
function chartsFromGraphics(graphics: GraphicSuggestion[]): ChartSpec[] {
  const out: ChartSpec[] = [];
  graphics.forEach((g, gi) => {
    const raw = g.data as unknown;
    let rows: unknown[] | null = null;
    if (Array.isArray(raw)) rows = raw;
    else if (raw && typeof raw === "object") {
      const obj = raw as Record<string, unknown>;
      if (Array.isArray(obj.rows)) rows = obj.rows;
      else if (Array.isArray(obj.data)) rows = obj.data;
      else if (Array.isArray(obj.items)) rows = obj.items;
    }
    if (!rows || rows.length === 0) return;

    const data: Array<Record<string, string | number>> = [];
    for (const row of rows) {
      if (!row || typeof row !== "object") continue;
      const r = row as Record<string, unknown>;
      const label =
        (typeof r.label === "string" && r.label) ||
        (typeof r.name === "string" && r.name) ||
        (typeof r.key === "string" && r.key) ||
        (typeof r.category === "string" && r.category) ||
        "";
      const valueCandidates = [r.value, r.count, r.amount, r.total, r.y];
      const valueRaw = valueCandidates.find((v) => typeof v === "number" && Number.isFinite(v)) ??
        valueCandidates.find((v) => typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)));
      if (!label && valueRaw === undefined) continue;
      data.push({ label: label || `Item ${data.length + 1}`, value: Number(valueRaw ?? 0) });
    }
    if (data.length < 2) return;

    out.push({
      id: `graphic-${g.id || gi}`,
      title: g.title,
      type: ["bar", "line", "area", "pie"].includes(g.type) ? g.type : "bar",
      xKey: "label",
      yKeys: ["value"],
      data,
      description: g.description,
    });
  });
  return out;
}

/* ------------------------------------------------------------------ */
/* Chart rendering (recharts)                                          */
/* ------------------------------------------------------------------ */

function ChartBody({ chart }: { chart: ChartSpec }) {
  const xKey = chart.xKey ?? "label";
  const yKeys = chart.yKeys && chart.yKeys.length > 0 ? chart.yKeys : ["value"];
  const angled = chart.data.length > 6;
  const xAxis = {
    tick: { fontSize: 11 },
    interval: 0,
    angle: angled ? -30 : 0,
    textAnchor: (angled ? "end" : "middle") as "end" | "middle",
    height: angled ? 52 : 30,
  };
  const margin = { top: 8, right: 16, bottom: 0, left: 0 };

  if (chart.type === "pie") {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={chart.data} dataKey={yKeys[0]} nameKey={xKey} cx="50%" cy="50%" outerRadius={80} label>
            {chart.data.map((_, i) => (
              <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    );
  }
  if (chart.type === "line") {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chart.data} margin={margin}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey={xKey} {...xAxis} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          {yKeys.length > 1 && <Legend />}
          {yKeys.map((k, i) => (
            <Line
              key={k}
              type="monotone"
              dataKey={k}
              stroke={CHART_COLORS[i % CHART_COLORS.length]}
              strokeWidth={2}
              dot={{ r: 3 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    );
  }
  if (chart.type === "area") {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chart.data} margin={margin}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey={xKey} {...xAxis} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          {yKeys.length > 1 && <Legend />}
          {yKeys.map((k, i) => (
            <Area
              key={k}
              type="monotone"
              dataKey={k}
              stroke={CHART_COLORS[i % CHART_COLORS.length]}
              fill={CHART_COLORS[i % CHART_COLORS.length]}
              fillOpacity={0.25}
              strokeWidth={2}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    );
  }
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chart.data} margin={margin}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xKey} {...xAxis} />
        <YAxis tick={{ fontSize: 11 }} />
        <Tooltip />
        {yKeys.length > 1 && <Legend />}
        {yKeys.map((k, i) => (
          <Bar key={k} dataKey={k} fill={CHART_COLORS[i % CHART_COLORS.length]} radius={[6, 6, 0, 0]} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ------------------------------------------------------------------ */
/* Chart card with graphic-type switcher + PNG download                */
/* ------------------------------------------------------------------ */

const CHART_TYPE_OPTIONS: Array<{
  type: ChartSpec["type"];
  icon: typeof BarChart3;
  label: string;
}> = [
  { type: "bar", icon: BarChart3, label: "Bar" },
  { type: "line", icon: LineChartIcon, label: "Line" },
  { type: "area", icon: AreaChartIcon, label: "Area" },
  { type: "pie", icon: PieChartIcon, label: "Pie" },
];

function ChartCard({
  chart,
  registerRef,
  onDownload,
  downloading,
}: {
  chart: ChartSpec;
  registerRef: (id: string, el: HTMLDivElement | null) => void;
  onDownload: (chart: ChartSpec) => void;
  downloading: boolean;
}) {
  const { t } = useLang();
  // Which graphic form the user wants to see — starts with the AI's choice.
  // The parent keys this card by chart.id, so state resets on new charts.
  const [viewType, setViewType] = useState(chart.type);

  const display = useMemo<ChartSpec>(() => ({ ...chart, type: viewType }), [chart, viewType]);

  return (
    <div className="flex flex-col rounded-lg border p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-semibold leading-snug">{chart.title}</p>
        <Badge variant="secondary" className="capitalize">
          {viewType}
        </Badge>
      </div>
      {(chart.description || chart.unit) && (
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
          {chart.description}
          {chart.unit ? ` (${chart.unit})` : ""}
        </p>
      )}
      <div
        ref={(el) => registerRef(chart.id, el)}
        className="mt-3 h-[260px] w-full rounded-lg bg-white p-2"
      >
        <ChartBody chart={display} />
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t pt-3">
        {/* Graphic type switcher — view the same result in different graphics */}
        <div
          role="group"
          aria-label={`Graphic type for ${chart.title}`}
          className="flex items-center gap-1 rounded-lg border p-0.5"
        >
          {CHART_TYPE_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            const active = viewType === opt.type;
            return (
              <button
                key={opt.type}
                type="button"
                aria-pressed={active}
                aria-label={`Show as ${opt.label} chart`}
                title={`${opt.label} chart`}
                onClick={() => setViewType(opt.type)}
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-md transition-colors",
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden />
              </button>
            );
          })}
        </div>
        <Button
          variant="outline"
          size="sm"
          className="h-8"
          disabled={downloading}
          onClick={() => onDownload(chart)}
        >
          {downloading ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
          ) : (
            <ImageDown className="h-4 w-4" aria-hidden />
          )}
          {t("አውርድ PNG", "Download PNG")}
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* AI Analyst Chat panel                                               */
/* ------------------------------------------------------------------ */

function ChatPanel({
  messages,
  pending,
  input,
  onInputChange,
  onSend,
  onClear,
  onClose,
}: {
  messages: ChatEntry[];
  pending: boolean;
  input: string;
  onInputChange: (value: string) => void;
  onSend: (text?: string) => void;
  onClear: () => void;
  onClose: () => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, pending]);

  const suggestions = ["Summarize the key numbers", "What trends do you see?", "Give 3 recommendations"];

  return (
    <div className="glass-card flex h-full min-h-0 flex-col overflow-hidden rounded-xl border shadow-sm">
      {/* Header */}
      <div className="flex items-center gap-2 border-b px-3 py-2.5">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 shadow-sm">
          <MessageSquare className="h-4 w-4 text-white" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold leading-tight">AI Analyst Chat</p>
          <p className="truncate text-xs text-muted-foreground">Grounded in the current document</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 shrink-0"
          onClick={onClear}
          aria-label="Clear chat"
          title="Clear chat"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 shrink-0 lg:hidden"
          onClick={onClose}
          aria-label="Close chat"
          title="Close chat"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className={cn("flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto p-3", THIN_SCROLLBAR)}
      >
        {messages.length === 0 && !pending && (
          <div className="mt-4 space-y-3 px-2">
            <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              Ask the AI analyst about your data
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {suggestions.map((s) => (
                <Button
                  key={s}
                  variant="outline"
                  size="sm"
                  className="h-8 rounded-full text-xs"
                  onClick={() => onSend(s)}
                >
                  {s}
                </Button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m) =>
          m.role === "user" ? (
            <div
              key={m.id}
              className="max-w-[85%] self-end whitespace-pre-wrap rounded-2xl rounded-br-sm bg-primary px-3 py-2 text-sm text-primary-foreground"
            >
              {m.content}
            </div>
          ) : (
            <div
              key={m.id}
              className="max-w-[85%] self-start whitespace-pre-wrap rounded-2xl rounded-bl-sm bg-muted px-3 py-2 text-sm"
            >
              {m.content}
            </div>
          )
        )}
        {pending && (
          <div className="flex max-w-[85%] items-center gap-2 self-start rounded-2xl rounded-bl-sm bg-muted px-3 py-2 text-sm text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            <span className="animate-pulse">thinking…</span>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex items-end gap-2 border-t p-3">
        <Textarea
          value={input}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              onSend();
            }
          }}
          rows={1}
          placeholder="Ask about your data…"
          aria-label="Chat message"
          className="max-h-20 min-h-9 resize-none"
        />
        <Button
          size="icon"
          className="h-9 w-9 shrink-0"
          onClick={() => onSend()}
          disabled={pending || !input.trim()}
          aria-label="Send message"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main view                                                           */
/* ------------------------------------------------------------------ */

export function AIStudioView({ historyId, navigate }: { historyId: string; navigate: NavigateFn }) {
  const { t } = useLang();
  const [phase, setPhase] = useState<Phase>(historyId ? "loading" : "upload");
  const [doc, setDoc] = useState<DocumentHistoryDTO | null>(null);
  const [analysis, setAnalysis] = useState<DataAnalysis | null>(null);
  const [conclusion, setConclusion] = useState<string | undefined>(undefined);
  const [charts, setCharts] = useState<ChartSpec[]>([]);
  const [insights, setInsights] = useState<Insights | null>(null);
  const [graphics, setGraphics] = useState<GraphicSuggestion[]>([]);
  const [kind, setKind] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chartRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadingAll, setDownloadingAll] = useState(false);

  /* Chat state — one session per studio session */
  const [sessionId, setSessionId] = useState<string>(() => crypto.randomUUID());
  const [messages, setMessages] = useState<ChatEntry[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatPending, setChatPending] = useState(false);
  const [unread, setUnread] = useState(0);
  const [chatOpen, setChatOpen] = useState<boolean | null>(null); // null = auto (open on desktop)
  const isMobile = useIsMobile();
  const chatVisible = chatOpen === true || (chatOpen === null && !isMobile);

  /* Local (Netlify) mode without a personal AI key → offline heuristic engine */
  const [offlineNotice, setOfflineNotice] = useState(false);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!(await isLocalMode())) return;
        const cfg = await getAIProviderConfig();
        if (!cancelled && !cfg.apiKey) setOfflineNotice(true);
      } catch {
        /* the notice simply stays hidden */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* Load a previously analyzed document */
  useEffect(() => {
    if (!historyId) return;
    let cancelled = false;
    documentsApi
      .list()
      .then((res) => {
        if (cancelled) return;
        const found = (res.documents ?? []).find((d) => d.id === historyId);
        if (found) {
          const rebuilt = analysisFromHistory(found);
          setDoc(found);
          setAnalysis(rebuilt.analysis);
          setConclusion(rebuilt.conclusion);
          setCharts(
            normalizeCharts(
              Array.isArray(found.charts) ? (found.charts as unknown as Array<Record<string, unknown>>) : []
            )
          );
          setInsights(found.insights ?? null);
          setGraphics(
            normalizeGraphics(
              Array.isArray(found.graphics)
                ? (found.graphics as unknown as Array<Record<string, unknown>>)
                : []
            )
          );
          setKind(rebuilt.analysis ? "dataset" : found.mimeType.startsWith("image/") ? "image" : "document");
          setPhase("results");
        } else {
          toast({
            title: "Document not found",
            description: "The requested document could not be loaded.",
            variant: "destructive",
          });
          setPhase("upload");
        }
      })
      .catch(() => {
        if (cancelled) return;
        toast({ title: "Failed to load document", variant: "destructive" });
        setPhase("upload");
      });
    return () => {
      cancelled = true;
    };
  }, [historyId]);

  /* Load chat history for this session */
  useEffect(() => {
    let cancelled = false;
    aiApi
      .chatHistory(sessionId)
      .then((res) => {
        if (cancelled) return;
        setMessages(
          (res.messages ?? []).map((m) => ({
            id: m.id,
            role: m.role === "user" ? ("user" as const) : ("assistant" as const),
            content: m.content,
          }))
        );
      })
      .catch(() => {
        /* chat history is optional */
      });
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  const analyzeFile = useCallback(
    async (file: File) => {
      setPhase("extracting");
      try {
        /* 1. Extract content from ANY file type */
        const extracted = await aiApi.extractDocument(file);
        const content = extracted.extractedText;
        if (!content.trim()) {
          throw new Error("No text could be extracted from this file.");
        }

        setPhase("analyzing");

        /* 2. Persist the document */
        const created = await documentsApi.create({
          fileName: extracted.fileName,
          content,
          status: "processing",
          mimeType: extracted.mimeType,
        });
        const docId = created.document.id;

        const tabular =
          extracted.kind === "table" ||
          TABLE_MIMES.includes(extracted.mimeType) ||
          /\.(csv|tsv|xlsx|xls)$/i.test(extracted.fileName);

        if (tabular) {
          /* 3a. Full data analysis with renderable charts */
          const result = await aiApi.analyzeData({
            fileName: extracted.fileName,
            content,
            mimeType: extracted.mimeType,
          });
          const rawAnalysis = result.analysis ?? {};
          const analysisData = normalizeAnalysis(rawAnalysis);
          const conclusionData =
            typeof rawAnalysis.conclusion === "string" && rawAnalysis.conclusion.trim()
              ? rawAnalysis.conclusion
              : undefined;
          const chartData = normalizeCharts(Array.isArray(result.charts) ? result.charts : []);
          const insightsData = normalizeInsights(result.insights ?? {});
          const finalReport = buildFinalReport(extracted.fileName, analysisData, conclusionData);

          const updated = await documentsApi.update(docId, {
            charts: chartData.map((c) => ({ ...c })),
            insights: {
              ...insightsData,
              dataset_type: analysisData.dataset_type ?? "dataset",
              rows: analysisData.rows,
              columns: analysisData.columns,
            },
            status: "ready",
            documentType: "dataset",
            mimeType: extracted.mimeType,
            finalReport,
          });

          setDoc(updated.document);
          setAnalysis(analysisData);
          setConclusion(conclusionData);
          setCharts(chartData);
          setInsights(insightsData);
          setKind("dataset");
          setPhase("results");
          navigate("ai-studio", { history: docId }, true);
          return;
        }

        /* 3b. Text/document insights path */
        const raw = await aiApi.documentInsights({ fileName: extracted.fileName, content });
        const insightsData = normalizeInsights(raw.insights ?? {});
        const graphicsData = normalizeGraphics(Array.isArray(raw.graphics) ? raw.graphics : []);

        const updated = await documentsApi.update(docId, {
          insights: { ...insightsData },
          graphics: graphicsData.map((g) => ({ ...g })),
          status: "ready",
          documentType: insightsData.document_type ?? "",
          language: insightsData.language ?? "",
          sentiment: insightsData.sentiment ?? "",
          mimeType: extracted.mimeType,
        });

        setDoc(updated.document);
        setInsights(insightsData);
        setGraphics(graphicsData);
        setAnalysis(null);
        setCharts([]);
        setKind(extracted.kind === "image" ? "image" : "document");
        setPhase("results");
        navigate("ai-studio", { history: docId }, true);
      } catch (err) {
        setPhase("upload");
        toast({
          title: t("ትንታኔ አልተሳካም", "Analysis failed"),
          description:
            err instanceof Error
              ? err.message
              : "Something went wrong while analyzing the document.",
          variant: "destructive",
        });
      }
    },
    [navigate, t]
  );

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) void analyzeFile(file);
    e.target.value = "";
  };

  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) void analyzeFile(file);
  };

  const reset = () => {
    setDoc(null);
    setAnalysis(null);
    setConclusion(undefined);
    setCharts([]);
    setInsights(null);
    setGraphics([]);
    setKind("");
    chartRefs.current = {};
    setMessages([]);
    setUnread(0);
    setSessionId(crypto.randomUUID());
    setPhase("upload");
    navigate("ai-studio", {}, true);
  };

  /* -------- Final analysis actions -------- */

  const saveFinal = async () => {
    if (!doc) return;
    const report = buildFinalReport(doc.fileName, analysis, conclusion, insights);
    try {
      const updated = await documentsApi.update(doc.id, { finalized: true, finalReport: report });
      setDoc(updated.document);
      setConclusion(report.conclusion || undefined);
      toast({ title: t("የመጨረሻ ትንታኔ ተቀምጧል", "Final analysis saved") });
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካም", "Save failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    }
  };

  const downloadFinal = async () => {
    if (!doc) return;
    try {
      const chartImages: Array<{ title: string; dataUrl: string }> = [];
      for (const chart of displayCharts) {
        const el = chartRefs.current[chart.id];
        if (!el) continue;
        try {
          chartImages.push({ title: chart.title, dataUrl: await chartContainerToPngDataUrl(el) });
        } catch {
          /* skip charts that fail to capture */
        }
      }
      const report = doc.finalReport ?? buildFinalReport(doc.fileName, analysis, conclusion, insights);
      downloadAnalysisReportPdf(
        {
          fileName: doc.fileName,
          title: report.title,
          generatedAt: report.generatedAt,
          datasetType: analysis?.dataset_type,
          rows: analysis?.rows,
          columns: analysis?.columns,
          summary: report.summary,
          keyFindings: report.key_findings,
          recommendations: report.recommendations,
          statistics: report.statistics,
          conclusion: report.conclusion,
          chartImages,
        },
        `Final_Analysis_${doc.fileName}.pdf`
      );
      toast({ title: t("የመጨረሻ ሪፖርት አውርዷል", "Final report downloaded") });
    } catch (err) {
      toast({
        title: t("አውርድ አልተሳካም", "Download failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    }
  };

  const handleDownloadPng = async (chart: ChartSpec) => {
    const safeName = chart.title.replace(/[\\/:*?"<>|]+/g, "-").trim() || `chart-${chart.id}`;
    setDownloadingId(chart.id);
    try {
      await downloadChartPng(chartRefs.current[chart.id], `${safeName}.png`);
      toast({ title: t("ግራፍ አውርዷል", "Chart PNG downloaded") });
    } catch (err) {
      toast({
        title: "Could not export chart",
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  /* Download every analytics graphic as a dashboard-ready PNG */
  const downloadAllCharts = async () => {
    if (displayCharts.length === 0 || downloadingAll) return;
    setDownloadingAll(true);
    try {
      let ok = 0;
      for (const chart of displayCharts) {
        const el = chartRefs.current[chart.id];
        if (!el) continue;
        try {
          const safeName = chart.title.replace(/[\\/:*?"<>|]+/g, "-").trim() || `chart-${chart.id}`;
          await downloadChartPng(el, `${safeName}.png`);
          ok += 1;
          // small pause between downloads so the browser handles them all
          await new Promise((r) => setTimeout(r, 350));
        } catch {
          /* skip charts that fail to capture */
        }
      }
      if (ok > 0) {
        toast({ title: t("ግራፎች ወረዱ", `${ok} graphics downloaded`) });
      } else {
        toast({ title: t("አውርድ አልተሳካም", "Download failed"), variant: "destructive" });
      }
    } finally {
      setDownloadingAll(false);
    }
  };

  /* -------- Chat actions -------- */

  const sendMessage = async (text?: string) => {
    const content = (text ?? chatInput).trim();
    if (!content || chatPending) return;
    setChatInput("");
    setMessages((prev) => [
      ...prev,
      { id: `u-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, role: "user", content },
    ]);
    setChatPending(true);
    try {
      const res = await aiApi.chat({ sessionId, message: content, documentId: doc?.id });
      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          role: "assistant",
          content: res.reply ?? "",
        },
      ]);
      if (!chatVisible) setUnread((u) => u + 1);
    } catch (err) {
      toast({
        title: t("ውይይት አልተሳካም", "Chat failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setChatPending(false);
    }
  };

  const handleClearChat = async () => {
    setMessages([]);
    try {
      await aiApi.clearChat(sessionId);
    } catch {
      /* local clear regardless */
    }
  };

  /* -------- Derived values -------- */

  const findings = analysis?.key_findings ?? [];
  const stats = analysis?.statistics ?? [];
  const analysisRecs = analysis?.recommendations ?? [];

  /** AI charts when available, otherwise graphics derived from stats / suggestions */
  const displayCharts = useMemo<ChartSpec[]>(() => {
    if (charts.length > 0) return charts;
    const fromStats = deriveChartsFromStats(stats);
    if (fromStats.length > 0) return fromStats;
    return chartsFromGraphics(graphics);
  }, [charts, stats, graphics]);

  const kindLabel =
    analysis || kind === "table" || kind === "dataset"
      ? "Dataset"
      : kind === "image"
        ? "Image"
        : "Document";

  const sentiment = insights?.sentiment ?? doc?.sentiment ?? "";
  const language = insights?.language ?? doc?.language ?? "";
  const docType = insights?.document_type ?? doc?.documentType ?? "";
  const keyPoints = insights?.key_points ?? [];
  const topics = insights?.topics ?? [];
  const insightRecs = insights?.recommendations ?? [];
  const summaryText = insights?.summary ?? "";

  const canFinalize = Boolean(doc && !doc.finalized && (analysis || insights?.summary));

  return (
    <div className="flex-1">
      <div className="mx-auto max-w-7xl space-y-6 p-4 sm:p-6">
        {/* Header */}
        <header className="flex flex-wrap items-center gap-3">
          <Button variant="outline" size="icon" onClick={() => navigate("home")} aria-label="Back">
            <ArrowLeft />
          </Button>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-md">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-xl font-bold">AI Data Studio</h1>
            <p className="truncate text-sm text-muted-foreground">
              {t("የመረጃ ትንታኔ ስቱዲዮ", "Data Analysis & Analytics")}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate("document-history")}>
            <History className="h-4 w-4" />
            <span className="hidden sm:inline">History</span>
          </Button>
          <div className="relative shrink-0">
            <Button
              variant={chatVisible ? "secondary" : "outline"}
              size="sm"
              onClick={() => {
                setChatOpen(!chatVisible);
                setUnread(0);
              }}
              aria-pressed={chatVisible}
              aria-label="Toggle AI chat"
            >
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">Chat</span>
            </Button>
            {unread > 0 && !chatVisible && (
              <span
                className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white"
                aria-hidden="true"
              >
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </div>
        </header>

        <div className="flex flex-col gap-4 lg:flex-row lg:items-start">
          {/* ---------------- Main analysis column ---------------- */}
          <main className="min-w-0 flex-1 space-y-4">
            {/* Offline engine notice — local mode without a personal AI key */}
            {offlineNotice && (
              <div
                role="status"
                className="flex items-start gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 text-amber-800 dark:text-amber-300"
              >
                <Info className="mt-0.5 h-5 w-5 shrink-0" />
                <p className="min-w-0 text-sm font-medium leading-snug break-words">
                  {t(
                    "ከመስመር ውጭ ትንተና በሥራ ላይ — ሙሉ የAI ብልህነት ለማግኘት በቅንብሮች → AI Provider ውስጥ ነጻ ቁልፍ ያስገቡ።",
                    "Offline analysis is active — add a free AI key in Settings → AI Provider for full intelligence."
                  )}
                </p>
              </div>
            )}

            {/* Loading a saved document */}
            {phase === "loading" && <LoadingSpinner />}

            {/* Upload zone */}
            {phase === "upload" && (
              <Card
                role="button"
                tabIndex={0}
                aria-label="Upload a document for AI data analysis"
                onClick={() => fileInputRef.current?.click()}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={onDrop}
                className={cn(
                  "cursor-pointer border-2 border-dashed transition-colors",
                  dragActive
                    ? "border-primary bg-primary/10"
                    : "glass-card border-slate-300 hover:border-primary/50"
                )}
              >
                <CardContent className="py-14 text-center">
                  <UploadCloud
                    className={cn(
                      "mx-auto h-12 w-12 transition-colors",
                      dragActive ? "text-primary" : "text-slate-400"
                    )}
                  />
                  <p className="mt-4 font-medium">
                    {t("ለAI የመረጃ ትንታኔ ማንኛውም ሰነድ ይስቀሉ", "Upload any document for AI data analysis")}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Documents (PDF, DOCX) · Spreadsheets (XLSX, XLS, CSV) · Text · Images (PNG, JPG)
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Drag &amp; drop or click to browse — max 15MB
                  </p>
                  <Button
                    className="mt-6"
                    onClick={(ev) => {
                      ev.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                  >
                    <UploadCloud className="h-4 w-4" />
                    Choose File
                  </Button>
                </CardContent>
              </Card>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept={FILE_ACCEPT}
              className="hidden"
              onChange={onFileChange}
            />

            {/* Extracting state */}
            {phase === "extracting" && (
              <Card className="glass-card">
                <CardContent className="py-16 text-center">
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-lg">
                    <Loader2 className="h-8 w-8 animate-spin text-white" />
                  </div>
                  <p className="mt-6 text-lg font-medium">Extracting content…</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {t("ይዘት እየተነሳ ነው — PDF · DOCX · XLSX · CSV · Image", "PDF · DOCX · XLSX · CSV · Image")}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Analyzing state */}
            {phase === "analyzing" && (
              <Card className="glass-card">
                <CardContent className="py-16 text-center">
                  <div className="mx-auto flex h-16 w-16 animate-pulse items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-lg">
                    <Sparkles className="h-8 w-8 text-white" />
                  </div>
                  <p className="mt-6 text-lg font-medium">AI is analyzing your data…</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {t(
                      "ዳራ እየተንተነ ነው — building insights, statistics and charts",
                      "building insights, statistics and charts"
                    )}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Results */}
            {phase === "results" && doc && (
              <>
                {/* Document info bar */}
                <Card className="glass-card py-0">
                  <CardContent className="flex flex-wrap items-center gap-3 p-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{doc.fileName}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-2">
                        <Badge variant="secondary">{doc.wordCount} words</Badge>
                        <Badge
                          variant="outline"
                          className={cn(
                            "border capitalize",
                            statusStyles[doc.status] ?? sentimentStyles.neutral
                          )}
                        >
                          {doc.status}
                        </Badge>
                        <Badge variant="outline">{kindLabel}</Badge>
                        {doc.finalized && (
                          <Badge className="border border-emerald-200 bg-emerald-100 text-emerald-800">
                            <BadgeCheck className="h-3 w-3" />
                            Finalized
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {canFinalize && (
                        <Button variant="outline" size="sm" onClick={() => void saveFinal()}>
                          <Save className="h-4 w-4" />
                          <span className="hidden md:inline">{t("አስቀምጥ", "Save Final")}</span>
                          <span className="sr-only">Save as final analysis</span>
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800"
                        onClick={() => void downloadFinal()}
                      >
                        <FileDown className="h-4 w-4" />
                        <span className="hidden md:inline">{t("ሪፖርት አውርድ", "Final Report")}</span>
                        <span className="sr-only">Download final report</span>
                      </Button>
                      <Button variant="outline" size="sm" onClick={reset}>
                        <RotateCcw className="h-4 w-4" />
                        <span className="hidden md:inline">{t("አዲስ", "New Analysis")}</span>
                        <span className="sr-only">Start a new analysis</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {analysis ? (
                  <>
                    {/* Analysis Summary */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">{t("ማጠቃለያ", "Analysis Summary")}</CardTitle>
                        <CardAction className="flex flex-wrap items-center gap-2">
                          {analysis.dataset_type && (
                            <Badge variant="secondary" className="capitalize">
                              {analysis.dataset_type}
                            </Badge>
                          )}
                          {typeof analysis.rows === "number" && (
                            <Badge variant="outline">{analysis.rows} rows</Badge>
                          )}
                          {typeof analysis.columns === "number" && (
                            <Badge variant="outline">{analysis.columns} columns</Badge>
                          )}
                        </CardAction>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm leading-relaxed">
                          {analysis.summary || "No summary is available for this dataset."}
                        </p>
                      </CardContent>
                    </Card>

                    {/* Key Findings */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">{t("ቁልፍ ግኝቶች", "Key Findings")}</CardTitle>
                        {findings.length > 0 && (
                          <CardDescription>{findings.length} findings extracted</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent>
                        {findings.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No key findings were extracted.</p>
                        ) : (
                          <ul
                            className={cn(
                              "max-h-96 space-y-3 overflow-y-auto pr-1",
                              THIN_SCROLLBAR
                            )}
                          >
                            {findings.map((point, i) => (
                              <li key={i} className="flex items-start gap-2.5">
                                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                                <span className="text-sm leading-relaxed">{point}</span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </CardContent>
                    </Card>

                    {/* Statistics */}
                    {stats.length > 0 && (
                      <Card className="glass-card">
                        <CardHeader>
                          <CardTitle className="text-base">{t("ስታቲስቲክስ", "Statistics")}</CardTitle>
                          <CardDescription>Per-column profile of the dataset</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="overflow-x-auto rounded-lg border">
                            <Table>
                              <TableHeader>
                                <TableRow className="bg-muted/50 hover:bg-muted/50">
                                  <TableHead>Column</TableHead>
                                  <TableHead>Type</TableHead>
                                  <TableHead className="text-right">Min</TableHead>
                                  <TableHead className="text-right">Max</TableHead>
                                  <TableHead className="text-right">Mean</TableHead>
                                  <TableHead className="text-right">Missing</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {stats.map((s) => (
                                  <TableRow key={s.column}>
                                    <TableCell className="max-w-[10rem] truncate font-medium">
                                      {s.column}
                                    </TableCell>
                                    <TableCell>
                                      <Badge variant="outline" className="capitalize">
                                        {s.type}
                                      </Badge>
                                    </TableCell>
                                    <TableCell className="text-right tabular-nums">
                                      {s.min ?? "—"}
                                    </TableCell>
                                    <TableCell className="text-right tabular-nums">
                                      {s.max ?? "—"}
                                    </TableCell>
                                    <TableCell className="text-right tabular-nums">
                                      {s.mean ?? "—"}
                                    </TableCell>
                                    <TableCell className="text-right tabular-nums">
                                      {s.missing ?? "—"}
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Recommendations */}
                    {analysisRecs.length > 0 && (
                      <Card className="glass-card">
                        <CardHeader>
                          <CardTitle className="text-base">{t("ምክረ-ሐሳቦች", "Recommendations")}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ol className="space-y-3">
                            {analysisRecs.map((rec, i) => (
                              <li key={i} className="flex items-start gap-3">
                                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                                  {i + 1}
                                </span>
                                <span className="text-sm leading-relaxed">{rec}</span>
                              </li>
                            ))}
                          </ol>
                        </CardContent>
                      </Card>
                    )}

                    {/* Conclusion */}
                    {conclusion && (
                      <Card className="border-primary/20">
                        <CardContent className="p-4">
                          <div className="rounded-lg bg-primary/5 p-4">
                            <p className="text-sm font-semibold text-primary">{t("መደምደሚያ", "Conclusion")}</p>
                            <p className="mt-2 text-sm leading-relaxed">{conclusion}</p>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </>
                ) : (
                  /* ---------- Text document path (original insights UI) ---------- */
                  <>
                    {/* Overview */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">Overview</CardTitle>
                        <CardAction>
                          <div className="flex flex-wrap items-center gap-2">
                            <SentimentBadge sentiment={sentiment} />
                            {language && <Badge variant="outline">{language}</Badge>}
                            {docType && (
                              <Badge variant="secondary" className="capitalize">
                                {docType.replace(/_/g, " ")}
                              </Badge>
                            )}
                          </div>
                        </CardAction>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm leading-relaxed">
                          {summaryText || "No summary is available for this document."}
                        </p>
                      </CardContent>
                    </Card>

                    {/* Key Points */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">Key Points</CardTitle>
                        {keyPoints.length > 0 && (
                          <CardDescription>{keyPoints.length} points extracted</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent>
                        {keyPoints.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No key points were extracted.</p>
                        ) : (
                          <ul
                            className={cn(
                              "max-h-96 space-y-3 overflow-y-auto pr-1",
                              THIN_SCROLLBAR
                            )}
                          >
                            {keyPoints.map((point, i) => (
                              <li key={i} className="flex items-start gap-2.5">
                                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                                <span className="text-sm leading-relaxed">{point}</span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </CardContent>
                    </Card>

                    {/* Topics */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">Topics</CardTitle>
                      </CardHeader>
                      <CardContent className="flex flex-wrap gap-2">
                        {topics.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No topics identified.</p>
                        ) : (
                          topics.map((topic, i) => (
                            <Badge key={i} variant="secondary">
                              {topic}
                            </Badge>
                          ))
                        )}
                      </CardContent>
                    </Card>

                    {/* Recommendations */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">{t("ምክረ-ሐሳቦች", "Recommendations")}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {insightRecs.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No recommendations available.</p>
                        ) : (
                          <ol className="space-y-3">
                            {insightRecs.map((rec, i) => (
                              <li key={i} className="flex items-start gap-3">
                                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                                  {i + 1}
                                </span>
                                <span className="text-sm leading-relaxed">{rec}</span>
                              </li>
                            ))}
                          </ol>
                        )}
                      </CardContent>
                    </Card>

                    {/* Suggested Visualizations */}
                    <Card className="glass-card">
                      <CardHeader>
                        <CardTitle className="text-base">Suggested Visualizations</CardTitle>
                        <CardDescription>AI-proposed charts to present the document data</CardDescription>
                      </CardHeader>
                      <CardContent>
                        {graphics.length === 0 ? (
                          <p className="text-sm text-muted-foreground">
                            No visualization suggestions available.
                          </p>
                        ) : (
                          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                            {graphics.map((g, i) => (
                              <div
                                key={g.id || `g-${i}`}
                                className="space-y-2 rounded-lg border p-4 transition-shadow hover:shadow-sm"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <GraphicIcon type={g.type} />
                                  <Badge variant="secondary" className="capitalize">
                                    {g.type}
                                  </Badge>
                                </div>
                                <p className="text-sm font-medium">{g.title}</p>
                                <p className="text-xs leading-relaxed text-muted-foreground">
                                  {g.description}
                                </p>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </>
                )}

                {/* Analytics Graphics (rendered charts) */}
                {(analysis || charts.length > 0 || displayCharts.length > 0) && (
                  <Card className="glass-card">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-base">
                        <BarChart3 className="h-4 w-4 text-primary" />
                        {t("የመረጃ ግራፎች", "Analytics Graphics")}
                      </CardTitle>
                      <CardDescription>
                        View each result in different graphics (bar / line / area / pie) and download
                        the PNG images for your own dashboard
                      </CardDescription>
                      <CardAction>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8"
                          disabled={downloadingAll || displayCharts.length === 0}
                          onClick={() => void downloadAllCharts()}
                          aria-label="Download all graphics as PNG images"
                        >
                          {downloadingAll ? (
                            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                          ) : (
                            <ImageDown className="h-4 w-4" aria-hidden />
                          )}
                          {t("ሁሉንም አውርድ", "Download All")}
                        </Button>
                      </CardAction>
                    </CardHeader>
                    <CardContent>
                      {displayCharts.length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          No charts were generated for this document.
                        </p>
                      ) : (
                        <>
                          {charts.length === 0 && (
                            <p className="mb-3 text-xs text-muted-foreground">
                              Graphics auto-generated from the analysis results.
                            </p>
                          )}
                          <div className="grid gap-4 sm:grid-cols-2">
                            {displayCharts.map((chart) => (
                              <ChartCard
                                key={chart.id}
                                chart={chart}
                                downloading={downloadingId === chart.id}
                                registerRef={(id, el) => {
                                  chartRefs.current[id] = el;
                                }}
                                onDownload={(c) => void handleDownloadPng(c)}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </main>

          {/* ---------------- AI chat panel ---------------- */}
          {chatVisible && (
            <aside
              className={cn(
                chatOpen === true && isMobile
                  ? "fixed inset-0 z-50 flex flex-col bg-background p-4"
                  : "hidden flex-col lg:sticky lg:top-6 lg:flex lg:h-[calc(100vh-3rem)] lg:w-80 lg:shrink-0"
              )}
              aria-label="AI Analyst Chat"
            >
              <ChatPanel
                messages={messages}
                pending={chatPending}
                input={chatInput}
                onInputChange={setChatInput}
                onSend={(text) => void sendMessage(text)}
                onClear={() => void handleClearChat()}
                onClose={() => setChatOpen(false)}
              />
            </aside>
          )}
        </div>
      </div>
    </div>
  );
}
