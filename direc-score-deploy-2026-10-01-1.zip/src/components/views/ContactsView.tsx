"use client";

/**
 * ContactsView — Directorate delivery contacts (የዳይሬክቶሬት እውቂያዎች).
 *
 * • Insert / edit / delete each directorate's Email, WhatsApp and Telegram
 *   address in one place (management is protected by the Settings password,
 *   default 3472 — same session unlock as the Links page).
 * • "Send it all in one go": quarterly score reports to every evaluated
 *   directorate, or a submit-before-deadline reminder to all of them — each
 *   through its own saved channels. Directorates without saved contacts fall
 *   back to the enabled admin channels (Automation page).
 */

import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeft,
  BellRing,
  Loader2,
  Lock,
  Mail,
  MessageCircle,
  Pencil,
  Phone,
  RefreshCw,
  Save,
  Send,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LoadingSpinner } from "@/components/shared";
import {
  clearSettingsPin,
  contactsApi,
  getSettingsPin,
  setSettingsPin,
  settingsApi,
} from "@/lib/client-api";
import { DEFAULT_QUARTER, DIRECTORATES } from "@/lib/rubric";
import type { ContactDTO, ContactSendResultDTO, DeliveryLogDTO } from "@/lib/types";
import { useLang } from "@/lib/i18n";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const TOUCH_ICON = "h-11 w-11 sm:h-9 sm:w-9";

/* ---------------- Settings PIN gate (same pattern as the Links page) ---------------- */

function ManagePinGate({ onUnlock, onCancel }: { onUnlock: (pin: string) => void; onCancel: () => void }) {
  const { t } = useLang();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const value = pin.trim();
    if (!value || busy) return;
    setBusy(true);
    setError("");
    try {
      await settingsApi.verify(value);
      onUnlock(value);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Verification failed";
      setError(message);
      setPin("");
      toast({ title: t("ስህተት", "Error"), description: message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="glass-card relative mx-auto w-full max-w-md border-amber-300/60 dark:border-amber-500/30">
      <Button
        variant="ghost"
        size="icon"
        className={cn("absolute right-1.5 top-1.5", TOUCH_ICON)}
        onClick={onCancel}
        aria-label={t("ዝጋ", "Dismiss")}
      >
        <X className="h-4 w-4" aria-hidden />
      </Button>
      <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <div>
          <p className="text-sm font-semibold">{t("የተደበቀ አስተዳደር", "Restricted area")}</p>
          <p className="text-xs text-muted-foreground">
            {t(
              "እውቂያዎችን ለማስገባት፣ ለማስተካከል ወይም ለማጥፋት የቅንብሮች ይለፍ ቃል ያስፈልጋል።",
              "Adding, editing or removing contacts requires the settings password."
            )}
          </p>
        </div>
        <form onSubmit={submit} className="flex w-full max-w-xs items-center gap-2">
          <Input
            type="password"
            inputMode="numeric"
            autoComplete="off"
            className="h-9 text-center tracking-[0.4em]"
            placeholder="••••"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            aria-label={t("የቅንብሮች ገጽ የይለፍ ቃል", "Settings password")}
            aria-invalid={Boolean(error)}
            disabled={busy}
          />
          <Button type="submit" className="h-9 shrink-0" disabled={!pin.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Lock className="h-4 w-4" aria-hidden />}
            {t("ክፈት", "Unlock")}
          </Button>
        </form>
        {error && (
          <p className="text-xs font-medium text-destructive" role="alert">
            {error}
          </p>
        )}
        <p className="text-[11px] text-muted-foreground">{t("ነባር የይለፍ ቃል፦ 3472", "Default password: 3472")}</p>
      </CardContent>
    </Card>
  );
}

/* ---------------- Delivery chip ---------------- */

function DeliveryChip({ log }: { log: DeliveryLogDTO }) {
  const { t } = useLang();
  const label =
    log.channelType === "whatsapp"
      ? "WhatsApp"
      : log.channelType === "telegram"
        ? "Telegram"
        : log.channelType === "email"
          ? t("ኢሜይል", "Email")
          : log.channelType;
  const color =
    log.status === "sent"
      ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
      : log.status === "queued"
        ? "border-amber-300/60 bg-amber-500/10 text-amber-700 dark:text-amber-300"
        : "border-red-300/60 bg-red-500/10 text-red-700 dark:text-red-300";
  return (
    <span
      className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium", color)}
      title={log.detail}
    >
      {label}:{" "}
      {log.status === "sent"
        ? t("ተልኳል", "sent")
        : log.status === "queued"
          ? t("ተራ ተይዟል", "queued")
          : t("አልተሳካም", "failed")}
    </span>
  );
}

/* ---------------- Contact row ---------------- */

interface Draft {
  whatsapp: string;
  telegram: string;
  email: string;
}

function ContactRow({
  contact,
  draft,
  manage,
  saving,
  deleting,
  onDraft,
  onSave,
  onDelete,
}: {
  contact: { key: string; short: string; name: string; nameEn: string };
  draft: Draft;
  manage: boolean;
  saving: boolean;
  deleting: boolean;
  onDraft: (patch: Partial<Draft>) => void;
  onSave: () => void;
  onDelete: () => void;
}) {
  const { t } = useLang();
  const saved =
    Boolean(contact.key) &&
    Boolean(draft.whatsapp.trim() || draft.telegram.trim() || draft.email.trim());
  return (
    <div className="rounded-xl border bg-background/60 p-4">
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        <p className="text-sm font-bold">{contact.short}</p>
        <p className="min-w-0 flex-1 truncate text-xs text-muted-foreground">{contact.nameEn || contact.name}</p>
        {manage ? null : saved ? (
          <Badge variant="outline" className="gap-1 text-[10px] text-emerald-600 dark:text-emerald-400">
            <Phone className="h-3 w-3" />
            {t("ተቀምጧል", "saved")}
          </Badge>
        ) : (
          <Badge variant="outline" className="text-[10px] text-muted-foreground">
            {t("እውቂያ የለም", "no contact")}
          </Badge>
        )}
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label htmlFor={`wa-${contact.key}`} className="flex items-center gap-1.5 text-xs">
            <Phone className="h-3.5 w-3.5 text-emerald-600" aria-hidden />
            WhatsApp
          </Label>
          <Input
            id={`wa-${contact.key}`}
            type="tel"
            inputMode="tel"
            className="h-9"
            placeholder="+251900000000"
            value={draft.whatsapp}
            onChange={(e) => onDraft({ whatsapp: e.target.value })}
            disabled={!manage || saving}
            aria-label={`${contact.short} WhatsApp`}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor={`tg-${contact.key}`} className="flex items-center gap-1.5 text-xs">
            <MessageCircle className="h-3.5 w-3.5 text-sky-600" aria-hidden />
            Telegram
          </Label>
          <Input
            id={`tg-${contact.key}`}
            className="h-9"
            placeholder="@username"
            value={draft.telegram}
            onChange={(e) => onDraft({ telegram: e.target.value })}
            disabled={!manage || saving}
            aria-label={`${contact.short} Telegram`}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor={`em-${contact.key}`} className="flex items-center gap-1.5 text-xs">
            <Mail className="h-3.5 w-3.5 text-amber-600" aria-hidden />
            {t("ኢሜይል", "Email")}
          </Label>
          <Input
            id={`em-${contact.key}`}
            type="email"
            inputMode="email"
            className="h-9"
            placeholder="name@hararihealth.gov.et"
            value={draft.email}
            onChange={(e) => onDraft({ email: e.target.value })}
            disabled={!manage || saving}
            aria-label={`${contact.short} email`}
          />
        </div>
      </div>
      {manage && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Button size="sm" className="h-8" onClick={onSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />}
            {t("አስቀምጥ", "Save")}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
            onClick={onDelete}
            disabled={deleting}
          >
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Trash2 className="h-4 w-4" aria-hidden />}
            {t("እውቂያ ሰርዝ", "Delete")}
          </Button>
        </div>
      )}
    </div>
  );
}

/* ---------------- View ---------------- */

export function ContactsView({ navigate }: { navigate?: NavigateFn }) {
  const { t } = useLang();

  /* Data */
  const [contacts, setContacts] = useState<ContactDTO[]>([]);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [loading, setLoading] = useState(true);
  const [busyKey, setBusyKey] = useState<{ key: string; action: "save" | "delete" } | null>(null);

  /* Manage mode + settings-PIN session */
  const [unlocked, setUnlocked] = useState(false);
  const [manageMode, setManageMode] = useState(false);
  const [gateOpen, setGateOpen] = useState(false);

  /* One-go sending */
  const [sendQuarter, setSendQuarter] = useState(DEFAULT_QUARTER);
  const [sendBusy, setSendBusy] = useState<"scores" | "reminder" | null>(null);
  const [sendResults, setSendResults] = useState<ContactSendResultDTO[] | null>(null);
  const [sendMode, setSendMode] = useState<"scores" | "reminder" | null>(null);

  const hydrateDrafts = useCallback((rows: ContactDTO[]) => {
    setDrafts((prev) => {
      const next = { ...prev };
      for (const d of DIRECTORATES) {
        const row = rows.find((r) => r.directorateKey === d.key);
        next[d.key] = {
          whatsapp: row?.whatsapp ?? next[d.key]?.whatsapp ?? "",
          telegram: row?.telegram ?? next[d.key]?.telegram ?? "",
          email: row?.email ?? next[d.key]?.email ?? "",
        };
      }
      return next;
    });
  }, []);

  const loadContacts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await contactsApi.list();
      setContacts(res.contacts);
      hydrateDrafts(res.contacts);
    } catch {
      toast({
        title: t("ስህተት", "Error"),
        description: t("እውቂያዎችን መጫን አልተቻለም።", "Failed to load contacts."),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [hydrateDrafts, t]);

  useEffect(() => {
    void loadContacts();
  }, [loadContacts]);

  /* Restore an unlocked manage session (password verified earlier in this tab) */
  useEffect(() => {
    if (getSettingsPin()) setUnlocked(true);
  }, []);

  const toggleManage = () => {
    if (manageMode) {
      setManageMode(false);
      return;
    }
    if (unlocked) {
      setManageMode(true);
      return;
    }
    setGateOpen((open) => !open);
  };

  const handleUnlock = (pin: string) => {
    setSettingsPin(pin);
    setUnlocked(true);
    setGateOpen(false);
    setManageMode(true);
  };

  const handleLock = () => {
    clearSettingsPin();
    setUnlocked(false);
    setManageMode(false);
    setGateOpen(false);
  };

  /* -------- row actions -------- */

  const patchDraft = (key: string, patch: Partial<Draft>) => {
    setDrafts((prev) => ({ ...prev, [key]: { ...(prev[key] ?? { whatsapp: "", telegram: "", email: "" }), ...patch } }));
  };

  const saveRow = async (key: string) => {
    const draft = drafts[key] ?? { whatsapp: "", telegram: "", email: "" };
    if (!draft.whatsapp.trim() && !draft.telegram.trim() && !draft.email.trim()) {
      toast({
        title: t("ስህተት", "Error"),
        description: t(
          "ቢያንስ አንድ እውቂያ ያስገቡ (WhatsApp፣ Telegram ወይም ኢሜይል)።",
          "Enter at least one contact (WhatsApp, Telegram or email)."
        ),
        variant: "destructive",
      });
      return;
    }
    setBusyKey({ key, action: "save" });
    try {
      await contactsApi.save({
        directorateKey: key,
        whatsapp: draft.whatsapp.trim(),
        telegram: draft.telegram.trim(),
        email: draft.email.trim(),
      });
      toast({
        title: t("እውቂያ ተቀምጧል", "Contact saved"),
        description: DIRECTORATES.find((d) => d.key === key)?.short ?? key,
      });
      await loadContacts();
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካም", "Save failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setBusyKey(null);
    }
  };

  const deleteRow = async (key: string) => {
    const short = DIRECTORATES.find((d) => d.key === key)?.short ?? key;
    const ok = window.confirm(
      t(
        `የ${short} እውቂያዎች ማጥፋት እርግጠኛ ነዎት?`,
        `Delete the saved contacts for ${short}?`
      )
    );
    if (!ok) return;
    setBusyKey({ key, action: "delete" });
    try {
      await contactsApi.remove(key);
      toast({ title: t("እውቂያ ተሰርዟል", "Contact deleted"), description: short });
      await loadContacts();
    } catch (err) {
      toast({
        title: t("መሰረዝ አልተሳካም", "Delete failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setBusyKey(null);
    }
  };

  /* -------- one-go sending -------- */

  const runSendAll = async (mode: "scores" | "reminder") => {
    if (sendBusy) return;
    setSendBusy(mode);
    setSendMode(mode);
    try {
      const res = await contactsApi.sendAll({
        mode,
        quarter: sendQuarter.trim() || undefined,
      });
      setSendResults(res.results);
      const logs = res.results.flatMap((r) => r.logs);
      const sent = logs.filter((l) => l.status === "sent").length;
      const queued = logs.filter((l) => l.status === "queued").length;
      const failed = logs.filter((l) => l.status === "failed").length;
      const withContact = res.results.filter((r) => r.contactSaved).length;
      toast({
        title:
          mode === "scores"
            ? t("ሁሉም ውጤቶች ተልከዋል", "All score reports sent")
            : t("ሁሉም ማስታወሻዎች ተልከዋል", "All reminders sent"),
        description: `${res.results.length} ${t("ዳይሬክቶሬቶች", "directorates")} · ${withContact} ${t(
          "በራስ እውቂያ",
          "own contacts"
        )} · ${sent} sent · ${queued} queued · ${failed} failed`,
      });
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መላክ አልተቻለም", "Could not send"),
        variant: "destructive",
      });
    } finally {
      setSendBusy(null);
    }
  };

  /* -------- render -------- */

  const savedCount = contacts.filter(
    (c) => c.whatsapp.trim() || c.telegram.trim() || c.email.trim()
  ).length;

  const header = (
    <header className="glass-card sticky top-0 z-20 border-b">
      <div className="mx-auto flex w-full max-w-5xl items-center gap-3 px-4 py-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0"
          onClick={() => navigate?.("home")}
          aria-label={t("ተመለስ", "Back")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Users className="h-5 w-5" aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-bold leading-tight">
            {t("የዳይሬክቶሬት እውቂያዎች", "Directorate Contacts")}
          </h1>
          <p className="truncate text-xs text-muted-foreground">
            {t(
              "ኢሜይል፣ WhatsApp እና Telegram ያስቀምጡ — ማሳወቂያዎችን በአንድ ጊዜ ይላኩ",
              "Save email, WhatsApp and Telegram — send reminders & scores in one go"
            )}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <Button
            variant="ghost"
            size="icon"
            className={cn("shrink-0", TOUCH_ICON)}
            onClick={() => void loadContacts()}
            disabled={loading}
            aria-label={t("እድሳት", "Refresh")}
            title={t("እድሳት", "Refresh")}
          >
            <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} aria-hidden />
          </Button>
          <Button
            variant={manageMode ? "default" : "outline"}
            size="sm"
            className="h-9 shrink-0"
            onClick={toggleManage}
            aria-pressed={manageMode || gateOpen}
            aria-label={t("የአስተዳደር ሁነታ", "Manage mode")}
            title={t("የአስተዳደር ሁነታ", "Manage mode")}
          >
            <Pencil className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">{t("አስተዳደር", "Manage")}</span>
          </Button>
          {manageMode && unlocked && (
            <Button
              variant="outline"
              size="sm"
              className="h-9 shrink-0"
              onClick={handleLock}
              aria-label={t("የአስተዳደር ሁነታን ተው", "Lock manage mode")}
              title={t("የአስተዳደር ሁነታን ተው", "Lock manage mode")}
            >
              <Lock className="h-4 w-4" aria-hidden />
              <span className="hidden sm:inline">{t("ተው", "Lock")}</span>
            </Button>
          )}
        </div>
      </div>
    </header>
  );

  return (
    <div className="flex-1">
      {header}

      <main className="mx-auto w-full max-w-5xl space-y-6 p-4 sm:p-6">
        {gateOpen && !manageMode && <ManagePinGate onUnlock={handleUnlock} onCancel={() => setGateOpen(false)} />}

        {/* -------- Send it all in one go -------- */}
        <Card className="glass-card border-primary/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Send className="h-4 w-4 text-primary" aria-hidden />
              {t("በአንድ ጊዜ ላክ", "Send it all in one go")}
            </CardTitle>
            <CardDescription>
              {t(
                "የተቀመጡ እውቂያዎችን ተጠቅመው የሩብ ዓመት ውጤቶችን ወይም ማስታወሻዎችን ለሁሉም ዳይሬክቶሬቶች በአንድ ጊዜ ይላኩ።",
                "Use the saved contacts to send quarterly score reports or reminders to every directorate at once."
              )}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap items-end gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="send-quarter" className="text-xs">
                  {t("ሩብ ዓመት", "Quarter")}
                </Label>
                <Input
                  id="send-quarter"
                  value={sendQuarter}
                  onChange={(e) => setSendQuarter(e.target.value)}
                  className="h-9 w-40"
                  placeholder="Q3-2018EFY"
                  aria-label={t("ሩብ ዓመት", "Quarter")}
                />
              </div>
              <Button
                className="h-9"
                onClick={() => void runSendAll("scores")}
                disabled={sendBusy !== null}
                title={t("ለሁሉም ዳይሬክቶሬቶች የሩብ ዓመት ውጤት ላክ", "Send the quarterly score to every evaluated directorate")}
              >
                {sendBusy === "scores" ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <Send className="h-4 w-4" aria-hidden />
                )}
                {t("ውጤቶች ላክ", "Send score reports")}
              </Button>
              <Button
                variant="outline"
                className="h-9"
                onClick={() => void runSendAll("reminder")}
                disabled={sendBusy !== null}
                title={t("የሪፖርት መጣሪያ ማስታወሻ ላክ", "Send the submit-before-deadline reminder")}
              >
                {sendBusy === "reminder" ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <BellRing className="h-4 w-4" aria-hidden />
                )}
                {t("ማስታወሻ ላክ", "Send reminders")}
              </Button>
              <Badge variant="secondary" className="h-9 px-3 text-xs">
                {savedCount}/{DIRECTORATES.length} {t("እውቂያዎች ተቀምጠዋል", "contacts saved")}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              {t(
                "ማስታወሻ፦ ዳይሬክቶሬት እውቂያ ካልተቀመጠለት መልእክቱ ወደ አስተዳደር መስመሮች (አውቶሜሽን ገጽ) ይላካል።",
                "Note: directorates without saved contacts receive the message through the admin channels (Automation page)."
              )}
            </p>

            {sendResults && sendResults.length > 0 && (
              <div className="space-y-2 rounded-xl border bg-background/60 p-3">
                <p className="text-xs font-semibold">
                  {sendMode === "reminder"
                    ? t("የማስታወሻ ውጤቶች", "Reminder results")
                    : t("የመላኪያ ውጤቶች", "Delivery results")}
                </p>
                <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
                  {sendResults.map((r) => (
                    <div key={r.directorateKey} className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg border p-2">
                      <span className="text-xs font-bold">{r.directorateShort}</span>
                      <span className="min-w-0 flex-1 truncate text-[11px] text-muted-foreground">{r.directorateName}</span>
                      {!r.contactSaved && (
                        <Badge variant="outline" className="text-[10px] text-muted-foreground">
                          {t("የአስተዳደር መስመር", "admin channels")}
                        </Badge>
                      )}
                      <div className="flex flex-wrap gap-1">
                        {r.logs.map((log) => (
                          <DeliveryChip key={log.id} log={log} />
                        ))}
                        {r.logs.length === 0 && (
                          <span className="text-[11px] text-muted-foreground">{t("ምንም መስመር አልተገኘም", "no channel found")}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* -------- Contacts list -------- */}
        {loading && contacts.length === 0 ? (
          <LoadingSpinner />
        ) : (
          <div className="max-h-[36rem] space-y-3 overflow-y-auto pr-1">
            {DIRECTORATES.map((d) => (
              <ContactRow
                key={d.key}
                contact={{ key: d.key, short: d.short, name: d.name, nameEn: d.nameEn }}
                draft={drafts[d.key] ?? { whatsapp: "", telegram: "", email: "" }}
                manage={manageMode}
                saving={busyKey?.key === d.key && busyKey.action === "save"}
                deleting={busyKey?.key === d.key && busyKey.action === "delete"}
                onDraft={(patch) => patchDraft(d.key, patch)}
                onSave={() => void saveRow(d.key)}
                onDelete={() => void deleteRow(d.key)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
