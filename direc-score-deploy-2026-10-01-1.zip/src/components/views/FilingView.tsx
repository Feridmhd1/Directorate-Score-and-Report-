"use client";

/**
 * DocumentFilingView — secure, PIN-protected document filing cabinet.
 *
 * • The room opens only after the correct password (default 3472) is verified
 *   against the server; the PIN stays in tab session storage and is attached
 *   to every filing API request (server-side enforced on each call).
 * • Every upload passes through the server-side file scanner (magic-byte type
 *   detection, executable / macro / active-content checks, SHA-256 checksum).
 *   Executables and EICAR test files are blocked; suspicious files are stored
 *   with a warning verdict.
 * • Each filed document receives a unique public share link that can be
 *   copied or sent via WhatsApp / Telegram / Email.
 */

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import {
  Download,
  File as FileIcon,
  FileImage,
  FileScan,
  FileSpreadsheet,
  FileText,
  FolderLock,
  Link2,
  Loader2,
  Lock,
  LockKeyhole,
  ScanSearch,
  Search,
  Share2,
  ShieldAlert,
  ShieldCheck,
  ShieldX,
  Trash2,
  UploadCloud,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { buildShareLinks, clearFilingPin, filingApi, filingShareUrl, setFilingPin } from "@/lib/client-api";
import type { FiledDocumentDTO, FileScanReport } from "@/lib/types";
import { useLang } from "@/lib/i18n";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const THIN_SCROLLBAR =
  "[scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 dark:[&::-webkit-scrollbar-thumb]:bg-slate-600 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5";

const FILING_CATEGORIES = [
  "General",
  "Reports",
  "Policies & Guidelines",
  "Finance",
  "Human Resources",
  "Correspondence",
  "Certificates",
  "Legal",
] as const;

const MAX_FILE_MB = 10;

function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileIconFor(doc: { fileName: string; mimeType: string }) {
  const name = doc.fileName.toLowerCase();
  if (doc.mimeType.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/.test(name)) {
    return <FileImage className="h-4 w-4" aria-hidden />;
  }
  if (/\.(xlsx|xls|csv|tsv|ods)$/.test(name) || doc.mimeType.includes("spreadsheet") || doc.mimeType.includes("excel")) {
    return <FileSpreadsheet className="h-4 w-4" aria-hidden />;
  }
  if (doc.mimeType.includes("pdf") || /\.(pdf|docx?|txt|md|rtf|odt)$/.test(name)) {
    return <FileText className="h-4 w-4" aria-hidden />;
  }
  return <FileIcon className="h-4 w-4" aria-hidden />;
}

/* ---------------- Scan verdict visuals ---------------- */

function VerdictBadge({ verdict }: { verdict: string }) {
  if (verdict === "clean") {
    return (
      <Badge className="gap-1 border border-emerald-200 bg-emerald-100 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
        <ShieldCheck className="h-3 w-3" aria-hidden />
        <span className="sr-only">Scan verdict: </span>Clean
      </Badge>
    );
  }
  if (verdict === "warning") {
    return (
      <Badge className="gap-1 border border-amber-200 bg-amber-100 text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300">
        <ShieldAlert className="h-3 w-3" aria-hidden />
        <span className="sr-only">Scan verdict: </span>Warning
      </Badge>
    );
  }
  if (verdict === "blocked") {
    return (
      <Badge className="gap-1 border border-red-200 bg-red-100 text-red-800 dark:border-red-800 dark:bg-red-950 dark:text-red-300">
        <ShieldX className="h-3 w-3" aria-hidden />
        Blocked
      </Badge>
    );
  }
  return <Badge variant="outline">{verdict}</Badge>;
}

/* ---------------- Scan report dialog ---------------- */

function ScanReportDialog({
  doc,
  open,
  onOpenChange,
}: {
  doc: FiledDocumentDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useLang();
  const scan: FileScanReport | null = doc?.scanReport ?? null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg" aria-describedby="scan-report-desc">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileScan className="h-4 w-4 text-primary" aria-hidden />
            {t("የፋይል ስካን ውጤት", "File Scan Report")}
          </DialogTitle>
          <DialogDescription id="scan-report-desc" className="truncate">
            {doc?.fileName}
          </DialogDescription>
        </DialogHeader>
        {!scan ? (
          <p className="text-sm text-muted-foreground">No scan report is available for this document.</p>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <VerdictBadge verdict={scan.verdict} />
              <span className="text-xs text-muted-foreground">
                {new Date(scan.scannedAt).toLocaleString()}
              </span>
            </div>
            <dl className="grid grid-cols-[8.5rem_1fr] gap-x-3 gap-y-2 rounded-lg border p-3 text-sm">
              <dt className="text-muted-foreground">Detected type</dt>
              <dd className="break-all font-medium">{scan.detectedType}</dd>
              <dt className="text-muted-foreground">Declared type</dt>
              <dd className="break-all">{scan.declaredMime}</dd>
              <dt className="text-muted-foreground">Type match</dt>
              <dd className={scan.typeMatch ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400"}>
                {scan.typeMatch ? "Yes" : "Mismatch"}
              </dd>
              <dt className="text-muted-foreground">Size</dt>
              <dd>{formatFileSize(scan.sizeBytes)}</dd>
              <dt className="text-muted-foreground">SHA-256</dt>
              <dd className="break-all font-mono text-xs">{scan.checksum}</dd>
            </dl>
            {scan.flags.length > 0 && (
              <div>
                <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Flags
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {scan.flags.map((flag) => (
                    <Badge key={flag} variant="outline" className="font-mono text-xs">
                      {flag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Scanner notes
              </p>
              <ul className="space-y-1.5">
                {scan.details.map((d, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm leading-relaxed">
                    <span aria-hidden className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- PIN gate ---------------- */

function PinGate({ onUnlock }: { onUnlock: (pin: string) => void }) {
  const { t } = useLang();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const submit = async () => {
    const value = pin.trim();
    if (!value || busy) return;
    setBusy(true);
    setError("");
    try {
      await filingApi.verify(value);
      onUnlock(value);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Verification failed");
      setPin("");
      inputRef.current?.focus();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-1 items-center justify-center py-10">
      <Card className="glass-card w-full max-w-sm border-primary/20 shadow-lg">
        <CardHeader className="items-center text-center">
          <div className="mx-auto mb-1 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-teal-500 shadow-md">
            <FolderLock className="h-7 w-7 text-white" aria-hidden />
          </div>
          <CardTitle className="text-lg">{t("የሰነድ ፋይሊንግ ክፍል", "Document Filing")}</CardTitle>
          <CardDescription>
            {t("ይህ ክፍል በይለፍ ቃል ተጠብቋል —", "This room is password protected —")}
            <br />
            {t("ለመግባት የ4-አሃዝ የይለፍ ቃል ያስገቡ።", "enter the 4-digit password to continue.")}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void submit();
            }}
            className="space-y-3"
          >
            <div className="space-y-1.5">
              <Label htmlFor="filing-pin" className="sr-only">
                Filing room password
              </Label>
              <Input
                id="filing-pin"
                ref={inputRef}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                inputMode="numeric"
                autoComplete="off"
                autoFocus
                placeholder="••••"
                aria-label="Enter the 4-digit filing room password"
                aria-invalid={Boolean(error)}
                className={cn(
                  "h-12 text-center text-2xl font-bold tracking-[0.5em]",
                  error && "border-destructive focus-visible:ring-destructive"
                )}
              />
            </div>
            {error && (
              <p role="alert" className="flex items-center justify-center gap-1.5 text-sm text-destructive">
                <ShieldX className="h-4 w-4" aria-hidden />
                {error}
              </p>
            )}
            <Button type="submit" className="w-full" disabled={busy || pin.trim().length === 0}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <LockKeyhole className="h-4 w-4" aria-hidden />}
              {t("ክፈት", "Unlock")}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

/* ---------------- Main view ---------------- */

export function DocumentFilingView() {
  const { t } = useLang();
  const [locked, setLocked] = useState(true);
  const [documents, setDocuments] = useState<FiledDocumentDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>("General");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [scanDoc, setScanDoc] = useState<FiledDocumentDTO | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  /* Unlock with a verified PIN (kept for the tab session) */
  const unlock = useCallback((pin: string) => {
    setFilingPin(pin);
    setLocked(false);
  }, []);

  /* Restore an existing tab session */
  useEffect(() => {
    try {
      const saved = window.sessionStorage.getItem("direcscore:filingPin");
      if (saved) {
        setFilingPin(saved);
        setLocked(false);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await filingApi.list();
      setDocuments(res.documents ?? []);
    } catch (err) {
      // Session PIN may have been invalidated — re-lock
      if (err instanceof Error && /password|401/i.test(err.message)) {
        setLocked(true);
      }
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : "Could not load filed documents",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!locked) void refresh();
  }, [locked, refresh]);

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
    e.target.value = "";
  };

  const upload = async () => {
    if (!file || uploading) return;
    if (file.size > MAX_FILE_MB * 1024 * 1024) {
      toast({
        title: t("ፋይሉ በጣም ትልቅ ነው", "File too large"),
        description: `Documents must be under ${MAX_FILE_MB} MB.`,
        variant: "destructive",
      });
      return;
    }
    setUploading(true);
    try {
      const res = await filingApi.upload(file, {
        title: title.trim() || undefined,
        category,
      });
      const scan = res.scan;
      if (scan?.verdict === "warning") {
        toast({
          title: t("ሰነድ ተቀምጧል — ማስጠንቀቂያ", "Filed with warnings"),
          description: scan.flags.join(", "),
        });
      } else {
        toast({
          title: t("ሰነድ ተቀምጧል", "Document filed"),
          description: t("ስካን ጸድቋል — ምንም ችግር አልተገኘም", "Scanner found no issues."),
        });
      }
      setFile(null);
      setTitle("");
      setCategory("General");
      if (fileInputRef.current) fileInputRef.current.value = "";
      await refresh();
    } catch (err) {
      // Blocked uploads carry the scan report in the error payload — best effort
      toast({
        title: t("ስቀል አልተሳካም", "Upload failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const remove = async (doc: FiledDocumentDTO) => {
    if (!window.confirm(t(`ይህን ሰነድ ሰርዝ? — "${doc.title}"`, `Delete "${doc.title}"?`))) return;
    try {
      await filingApi.remove(doc.id);
      setDocuments((prev) => prev.filter((d) => d.id !== doc.id));
      toast({ title: t("ሰነዱ ተሰርዟል", "Document deleted") });
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    }
  };

  const shareTextFor = (doc: FiledDocumentDTO) =>
    t(`የፋይል ክፍል ሰነድ — ${doc.title}`, `Filed document: "${doc.title}"`);

  const copyLink = async (doc: FiledDocumentDTO) => {
    try {
      await navigator.clipboard.writeText(filingShareUrl(doc.shareToken));
      toast({ title: t("ልዩ አገናኝ ተቀድቷል", "Unique link copied") });
    } catch {
      toast({ title: t("ኮፒ አልተሳካም", "Copy failed"), variant: "destructive" });
    }
  };

  const relock = () => {
    clearFilingPin();
    setDocuments([]);
    setLocked(true);
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return documents.filter((d) => {
      if (categoryFilter !== "all" && d.category !== categoryFilter) return false;
      if (!q) return true;
      return (
        d.title.toLowerCase().includes(q) ||
        d.fileName.toLowerCase().includes(q) ||
        d.note.toLowerCase().includes(q)
      );
    });
  }, [documents, search, categoryFilter]);

  if (locked) {
    return (
      <div className="flex flex-1 flex-col">
        <PinGate onUnlock={unlock} />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl flex-1 space-y-4 px-4 py-6 sm:px-6">
      {/* Header */}
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-teal-500 shadow-md">
            <FolderLock className="h-6 w-6 text-white" aria-hidden />
          </div>
          <div>
            <h1 className="text-xl font-bold sm:text-2xl">{t("የሰነድ ፋይሊንግ", "Document Filing")}</h1>
            <p className="text-sm text-muted-foreground">
              {t(
                "የተጠበቀ የመክፈቢያ ክፍል — እያንዳንዱ ፋይል ይሰረዛል።",
                "Secure cabinet — every file is scanned."
              )}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            <Lock className="h-3 w-3" aria-hidden />
            PIN protected
          </Badge>
          <Button variant="outline" size="sm" onClick={relock} aria-label="Lock the filing room">
            <LockKeyhole className="h-4 w-4" aria-hidden />
            {t("ተዘጋ", "Lock")}
          </Button>
        </div>
      </header>

      {/* Scanner info banner */}
      <Card className="glass-card border-primary/20 py-0">
        <CardContent className="flex flex-wrap items-center gap-3 p-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <ScanSearch className="h-5 w-5 text-primary" aria-hidden />
          </div>
          <p className="min-w-0 flex-1 text-sm leading-relaxed">
            <span className="font-semibold">File scanner active —</span> every upload is checked for
            real file type (magic bytes), executables, Office macros, active HTML/SVG content and
            disguised extensions. Each document also receives a unique shareable link.
          </p>
        </CardContent>
      </Card>

      {/* Upload card */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileScan className="h-4 w-4 text-primary" aria-hidden />
            {t("ሰነድ ስቀል", "File a Document")}
          </CardTitle>
          <CardDescription>
            Any file type up to {MAX_FILE_MB} MB — scanned before it is stored.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="filing-title">{t("ርዕስ", "Title")}</Label>
              <Input
                id="filing-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Q3 Annual Health Report"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="filing-category">{t("ምድብ", "Category")}</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="filing-category" aria-label="Document category">
                  <SelectValue placeholder="Choose a category" />
                </SelectTrigger>
                <SelectContent>
                  {FILING_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="min-w-0 flex-1">
              <Label htmlFor="filing-file" className="sr-only">
                Choose a document to file
              </Label>
              <Input
                id="filing-file"
                ref={fileInputRef}
                type="file"
                onChange={onFileChange}
                className="file:mr-3 file:rounded-md file:border-0 file:bg-primary/10 file:px-3 file:py-1 file:text-sm file:font-medium file:text-primary"
                aria-label="Choose a document to file"
              />
            </div>
            <Button
              onClick={() => void upload()}
              disabled={!file || uploading}
              className="h-9 shrink-0"
              aria-label="Scan and file the selected document"
            >
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <UploadCloud className="h-4 w-4" aria-hidden />
              )}
              {t("ስካን አድርግና ስቀል", "Scan & File")}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search + filter */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative min-w-0 flex-1">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("ፈልግ", "Search filed documents…")}
            aria-label="Search filed documents"
            className="pl-9"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-52" aria-label="Filter by category">
            <SelectValue placeholder="All categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {FILING_CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Badge variant="outline" className="shrink-0 self-start sm:self-center">
          {filtered.length} / {documents.length} {t("ሰነዶች", "documents")}
        </Badge>
      </div>

      {/* Documents list */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base">{t("የተቀምጡ ሰነዶች", "Filed Documents")}</CardTitle>
          {loading && <CardDescription>Loading…</CardDescription>}
        </CardHeader>
        <CardContent>
          {!loading && filtered.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              {documents.length === 0
                ? t("እስካሁን ሰነድ አልተቀመጠም", "No documents filed yet")
                : t("ለፍለጋው የሚስማማ ሰነድ አልተገኘም", "No documents match your search")}
            </p>
          ) : (
            <ul className={cn("max-h-[34rem] space-y-2 overflow-y-auto pr-1", THIN_SCROLLBAR)}>
              {filtered.map((doc) => {
                const links = buildShareLinks(
                  filingShareUrl(doc.shareToken),
                  shareTextFor(doc)
                );
                return (
                  <li
                    key={doc.id}
                    className="flex flex-col gap-3 rounded-lg border p-3 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                      {fileIconFor(doc)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate text-sm font-medium">{doc.title}</p>
                        <VerdictBadge verdict={doc.scanVerdict} />
                      </div>
                      <p className="truncate text-xs text-muted-foreground">{doc.fileName}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        <Badge variant="secondary" className="text-xs">
                          {doc.category}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatFileSize(doc.size)} ·{" "}
                          {new Date(doc.createdAt).toLocaleDateString(undefined, {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </span>
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => setScanDoc(doc)}
                        aria-label={`View scan report for ${doc.title}`}
                        title="Scan report"
                      >
                        <FileScan className="h-4 w-4" aria-hidden />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                        <a
                          href={filingShareUrl(doc.shareToken, true)}
                          download={doc.fileName}
                          aria-label={`Download ${doc.title}`}
                          title="Download"
                        >
                          <Download className="h-4 w-4" aria-hidden />
                        </a>
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            aria-label={`Share ${doc.title}`}
                            title="Share document"
                          >
                            <Share2 className="h-4 w-4" aria-hidden />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onSelect={() => void copyLink(doc)}>
                            <Link2 className="h-4 w-4" aria-hidden />
                            {t("አገናኝ ቅዳ", "Copy link")}
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a
                              href={links.whatsapp}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              WhatsApp
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a
                              href={links.telegram}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              Telegram
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a href={links.email}>Email</a>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => void remove(doc)}
                        aria-label={`Delete ${doc.title}`}
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" aria-hidden />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <ScanReportDialog doc={scanDoc} open={scanDoc !== null} onOpenChange={(o) => !o && setScanDoc(null)} />
    </div>
  );
}
