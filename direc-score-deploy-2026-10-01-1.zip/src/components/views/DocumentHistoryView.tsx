"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  BarChart3,
  BadgeCheck,
  Eye,
  FileText,
  GitCompare,
  History,
  Search,
  Trash2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { documentsApi } from "@/lib/client-api";
import type { DocumentHistoryDTO } from "@/lib/types";
import { LoadingSpinner } from "@/components/shared";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

/** Compact mime-type label, e.g. "application/pdf" → "PDF" */
function mimeLabel(mime: string): string {
  const m = mime.toLowerCase();
  if (!m) return "";
  if (m.includes("pdf")) return "PDF";
  if (m.includes("wordprocessingml")) return "DOCX";
  if (m.includes("spreadsheetml") || m === "application/vnd.ms-excel" || m.includes("opendocument.spreadsheet"))
    return "XLSX";
  if (m === "text/csv") return "CSV";
  if (m.includes("tab-separated")) return "TSV";
  if (m.startsWith("image/")) return m.slice(6).toUpperCase();
  if (m.startsWith("text/")) return m.slice(5).toUpperCase();
  return m.split("/").pop()?.slice(0, 6).toUpperCase() ?? "";
}

/** Tiny relative-time helper, e.g. "5m ago" */
function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const diff = Date.now() - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}

const sentimentStyles: Record<string, string> = {
  positive: "bg-emerald-100 text-emerald-800 border-emerald-200",
  negative: "bg-red-100 text-red-800 border-red-200",
  neutral: "bg-slate-100 text-slate-700 border-slate-200",
  mixed: "bg-amber-100 text-amber-800 border-amber-200",
};

function SentimentBadge({ sentiment }: { sentiment: string }) {
  if (!sentiment) return null;
  const key = sentiment.toLowerCase();
  return (
    <Badge
      variant="outline"
      className={cn("border capitalize", sentimentStyles[key] ?? sentimentStyles.neutral)}
    >
      {sentiment}
    </Badge>
  );
}

export function DocumentHistoryView({ navigate }: { navigate: NavigateFn }) {
  const [docs, setDocs] = useState<DocumentHistoryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [compareMode, setCompareMode] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);

  const refetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await documentsApi.list();
      setDocs(res.documents ?? []);
    } catch (err) {
      toast({
        title: "Failed to load documents",
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return docs;
    return docs.filter(
      (d) =>
        d.fileName.toLowerCase().includes(q) ||
        (d.documentType ?? "").toLowerCase().includes(q)
    );
  }, [docs, query]);

  const toggleSelect = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const handleDelete = async (id: string) => {
    if (!window.confirm("Delete this document?")) return;
    try {
      await documentsApi.remove(id);
      setSelected((prev) => prev.filter((x) => x !== id));
      await refetch();
      toast({ title: "Document deleted" });
    } catch (err) {
      toast({
        title: "Delete failed",
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex-1">
      <div className="mx-auto max-w-3xl space-y-6 p-4 sm:p-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate("ai-studio")}
            aria-label="Back"
          >
            <ArrowLeft />
          </Button>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-md">
            <History className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-xl font-bold">Document History</h1>
            <p className="truncate text-sm text-muted-foreground">Previously analyzed documents</p>
          </div>
        </div>

        {/* Toolbar: search + compare */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[12rem] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search documents…"
              className="bg-white/70 pl-9"
            />
          </div>
          <Button
            variant={compareMode ? "secondary" : "outline"}
            onClick={() => {
              setCompareMode((m) => !m);
              setSelected([]);
            }}
            aria-pressed={compareMode}
          >
            <GitCompare className="h-4 w-4" />
            <span className="hidden sm:inline">Compare</span>
          </Button>
          {compareMode && selected.length >= 2 && (
            <Button
              className="bg-violet-600 text-white hover:bg-violet-700"
              onClick={() => navigate("compare", { ids: selected.join(",") })}
            >
              <GitCompare className="h-4 w-4" />
              Compare Selected ({selected.length})
            </Button>
          )}
        </div>

        {/* List */}
        {loading ? (
          <LoadingSpinner />
        ) : docs.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <History className="mx-auto h-12 w-12 text-slate-400" />
              <p className="mt-4 font-medium">No documents yet</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Upload a document in AI Studio to see it here
              </p>
              <Button className="mt-6" onClick={() => navigate("ai-studio")}>
                Open AI Studio
              </Button>
            </CardContent>
          </Card>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Search className="mx-auto h-10 w-10 text-slate-400" />
              <p className="mt-4 text-sm text-muted-foreground">
                No documents match your search.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {filtered.map((doc) => {
              const isSelected = selected.includes(doc.id);
              return (
                <Card
                  key={doc.id}
                  className={cn(
                    "py-0 shadow-sm",
                    compareMode && isSelected && "border-violet-400 ring-1 ring-violet-200"
                  )}
                >
                  <CardContent className="flex items-center gap-3 p-3">
                    {compareMode && (
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => toggleSelect(doc.id)}
                        aria-label={`Select ${doc.fileName}`}
                        className="shrink-0"
                      />
                    )}
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{doc.fileName}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                        {doc.documentType && (
                          <Badge variant="secondary" className="capitalize">
                            {doc.documentType.replace(/_/g, " ")}
                          </Badge>
                        )}
                        {doc.language && <Badge variant="outline">{doc.language}</Badge>}
                        <SentimentBadge sentiment={doc.sentiment} />
                        {mimeLabel(doc.mimeType) && (
                          <Badge variant="outline">{mimeLabel(doc.mimeType)}</Badge>
                        )}
                        {(doc.charts?.length ?? 0) > 0 && (
                          <Badge variant="secondary">
                            <BarChart3 className="h-3 w-3" />
                            {doc.charts.length} charts
                          </Badge>
                        )}
                        {doc.finalized && (
                          <Badge className="border border-emerald-200 bg-emerald-100 text-emerald-800">
                            <BadgeCheck className="h-3 w-3" />
                            Final
                          </Badge>
                        )}
                        <span>· {doc.wordCount} words</span>
                        {timeAgo(doc.createdAt) && <span>· {timeAgo(doc.createdAt)}</span>}
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Open"
                        aria-label="Open"
                        onClick={() => navigate("ai-studio", { history: doc.id })}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Delete"
                        aria-label="Delete"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(doc.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
