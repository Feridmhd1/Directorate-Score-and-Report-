"use client";

import { useMemo, useState } from "react";
import {
  Check,
  CheckCircle2,
  ClipboardList,
  Download,
  FileText,
  Loader2,
  Plus,
  Sparkles,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import type { NavigateFn } from "@/hooks/use-view";
import {
  ACTION_PLAN_STATUS_LABELS,
  CRITERIA,
  DEFAULT_QUARTER,
  DIRECTORATES,
  TOTAL_MAX_SCORE,
  computeScores,
  getDirectorate,
  scorePercent,
  type ActionPlanItem,
  type Scores,
} from "@/lib/rubric";
import { aiApi, automationApi, evaluationsApi, notificationsApi } from "@/lib/client-api";
import { AiLanguageSelector, BigScore, PerformanceBadge, ScoreBadge, ScoreBar } from "@/components/shared";
import type { AiLanguage } from "@/components/shared";
import { downloadEvaluationPdf } from "@/lib/export-utils";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/i18n";

type YesNo = "yes" | "no";

function normalizeAnswers(raw: Record<string, string> | null | undefined): Record<string, YesNo> {
  const normalized: Record<string, YesNo> = {};
  if (!raw) return normalized;
  Object.entries(raw).forEach(([k, v]) => {
    if (v === "yes" || v === "no") normalized[k] = v;
  });
  return normalized;
}

/* ---------- Structured action plan editor (local to this file) ---------- */

const ACTION_STATUS_KEYS = ["planned", "in_progress", "done"] as const;
type ActionStatusKey = (typeof ACTION_STATUS_KEYS)[number];

const ACTION_STATUS_STYLES: Record<ActionStatusKey, string> = {
  planned: "bg-primary text-primary-foreground border-primary hover:bg-primary/90 hover:text-primary-foreground",
  in_progress: "bg-amber-500 text-white border-amber-500 hover:bg-amber-600 hover:text-white",
  done: "bg-emerald-500 text-white border-emerald-500 hover:bg-emerald-600 hover:text-white",
};

/**
 * Structured "goals & corrective steps" planner: each item carries the step text,
 * an owner, a deadline and a status (planned / in_progress / done).
 */
function ActionPlanEditor({
  items,
  onChange,
}: {
  items: ActionPlanItem[];
  onChange: (items: ActionPlanItem[]) => void;
}) {
  const { t } = useLang();
  const addItem = () =>
    onChange([
      ...items,
      { id: crypto.randomUUID(), text: "", owner: "", deadline: "", status: "planned" },
    ]);
  const patchItem = (id: string, patch: Partial<ActionPlanItem>) =>
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  const removeItem = (id: string) => onChange(items.filter((it) => it.id !== id));

  return (
    <Card className="py-4">
      <CardContent className="px-4 space-y-3">
        <div className="flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-primary shrink-0" />
          <span className="font-semibold text-sm flex-1 min-w-0">{t("የድርጊት እቅድ", "Action Plan")}</span>
          {items.length > 0 && (
            <Badge variant="secondary" className="text-[11px] font-medium">
              {items.length} {t("እርምጃዎች", "actions")}
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {t(
            "በሩብ ዓመት ግምገማዎ ላይ የተለዩ ግቦችን ወይም አስተካካይ እርምጃዎችን ይዘምሩ።",
            "List specific goals or corrective steps identified during your quarterly review."
          )}
        </p>
        <div className="space-y-3">
          {items.map((item) => {
            const rawStatus = item.status ?? (item.done ? "done" : "planned");
            const status: ActionStatusKey = ACTION_STATUS_KEYS.includes(rawStatus as ActionStatusKey)
              ? (rawStatus as ActionStatusKey)
              : "planned";
            return (
              <div key={item.id} className="rounded-lg border p-3 space-y-2">
                {/* Goal / corrective step */}
                <Textarea
                  rows={2}
                  className="text-sm"
                  placeholder={t("ግብ ወይም አስተካካይ እርምጃ ይጻፉ…", "Goal or corrective step…")}
                  value={item.text}
                  onChange={(e) => patchItem(item.id, { text: e.target.value })}
                />
                {/* Owner + deadline */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <Input
                    className="h-9"
                    placeholder={t("ኃላፊ", "Owner…")}
                    value={item.owner ?? ""}
                    onChange={(e) => patchItem(item.id, { owner: e.target.value })}
                  />
                  <Input
                    className="h-9"
                    type="date"
                    aria-label={t("ጊዜ ገደብ", "Deadline")}
                    value={item.deadline ?? ""}
                    onChange={(e) => patchItem(item.id, { deadline: e.target.value })}
                  />
                </div>
                {/* Status + remove */}
                <div className="flex items-center gap-2">
                  <div className="grid flex-1 grid-cols-3 gap-1.5 min-w-0">
                    {ACTION_STATUS_KEYS.map((key) => (
                      <Button
                        key={key}
                        type="button"
                        variant="outline"
                        className={cn(
                          "h-9 px-1 text-[11px] leading-tight whitespace-normal font-medium",
                          status === key ? ACTION_STATUS_STYLES[key] : "text-muted-foreground"
                        )}
                        aria-pressed={status === key}
                        onClick={() =>
                          patchItem(item.id, { status: key, done: key === "done" })
                        }
                      >
                        {ACTION_PLAN_STATUS_LABELS[key]}
                      </Button>
                    ))}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9 shrink-0 text-destructive hover:text-destructive"
                    onClick={() => removeItem(item.id)}
                    aria-label="Remove item"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        {items.length === 0 && (
          <p className="text-xs italic text-muted-foreground">
            {t("እስካሁን ምንም እርምጃ አልታቀደም", "No goals or steps yet.")}
          </p>
        )}
        <Button type="button" variant="outline" className="h-9" onClick={addItem}>
          <Plus className="w-4 h-4 mr-2" />
          {t("እቅድ ጨምር", "Add Goal or Step")}
        </Button>
      </CardContent>
    </Card>
  );
}

interface SubmittedResult {
  dirKey: string;
  quarter: string;
  totalScore: number;
  scores: Scores;
  comments: Record<string, string>;
  feedback: string;
  actionPlan: ActionPlanItem[];
}

export function SubmitView({
  directorateKey,
  quarter,
  navigate,
}: {
  directorateKey: string;
  quarter: string;
  navigate: NavigateFn;
}) {
  const { t } = useLang();
  void navigate;

  const [dirKey, setDirKey] = useState(() =>
    getDirectorate(directorateKey) ? directorateKey : ""
  );
  const [quarterInput, setQuarterInput] = useState(quarter || DEFAULT_QUARTER);
  const [directorName, setDirectorName] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const [content, setContent] = useState("");
  const [wordCount, setWordCount] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const [aiLang, setAiLang] = useState<AiLanguage>("english");
  const [analyzed, setAnalyzed] = useState(false);
  const [answers, setAnswers] = useState<Record<string, YesNo>>({});
  const [comments, setComments] = useState<Record<string, string>>({});
  const [aiComments, setAiComments] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState("");
  const [actionPlan, setActionPlan] = useState<ActionPlanItem[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<SubmittedResult | null>(null);

  const d = getDirectorate(dirKey);
  const { scores, totalScore } = useMemo(() => computeScores(answers), [answers]);
  const pct = scorePercent(totalScore);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      setContent(text);
      setWordCount(text.split(/\s+/).filter(Boolean).length);
    };
    reader.onerror = () => {
      toast({
        title: t("ፋይሉን ማንበብ አልተቻለም", "Could not read the file"),
        description: "Could not read the selected file.",
        variant: "destructive",
      });
    };
    reader.readAsText(file, "UTF-8");
  };

  const analyze = async () => {
    if (!d) {
      toast({ title: t("ዳይሬክቶሬት ይምረጡ", "Select a directorate"), description: "Please select a directorate first." });
      return;
    }
    if (!content.trim()) {
      toast({
        title: t("የሪፖርት ፋይል ያስፈልጋል", "Report file required"),
        description: "Please select your report file first.",
      });
      return;
    }
    setAnalyzing(true);
    try {
      const res = await aiApi.evaluateReport({ directorateName: d.name, quarter: quarterInput, content, language: aiLang });
      setAnswers(normalizeAnswers(res.answers));
      setComments(res.comments ?? {});
      setAiComments(res.comments ?? {});
      setAnalyzed(true);
      toast({ title: t("AI ግምገማ ተጠናቋል!", "AI evaluation completed!"), description: "AI evaluation completed." });
    } catch {
      toast({
        title: t("AI ትንታኔ አልተሳካም። እንደገና ይሞክሩ።", "AI analysis failed. Please try again."),
        variant: "destructive",
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const submit = async () => {
    if (!d) return;
    setSubmitting(true);
    try {
      const computed = computeScores(answers);
      const mergedComments = {
        ...comments,
        ...(feedback.trim() ? { feedback: feedback.trim() } : {}),
      };
      const saved = await evaluationsApi.create({
        directorateKey: d.key,
        directorateName: d.name,
        directorateShort: d.short,
        quarter: quarterInput,
        email: directorName ? "" : undefined,
        scores: computed.scores,
        answers,
        comments: mergedComments,
        totalScore: computed.totalScore,
        status: "completed",
        aiGenerated: true,
        actionPlan,
      });
      await notificationsApi.create({
        type: "report_submitted",
        title: t(`ዳይሬክተር ሪፖርት ቀርቧል — ${d.short}`, `Directorate report submitted — ${d.short}`),
        message: t(
          `${d.name} (${directorName || "ዳይሬክተር"}) የ${quarterInput} ሪፖርት AI ግምገማ ጠቅላላ ውጤት: ${computed.totalScore}/100`,
          `${d.name} (${directorName || "Director"}) AI evaluation of the ${quarterInput} report — total score: ${computed.totalScore}/100`
        ),
        directorateKey: d.key,
        directorateName: d.name,
        quarter: quarterInput,
        totalScore: computed.totalScore,
      });
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));

      /* Fire-and-forget: fan the score out to all enabled delivery channels */
      automationApi
        .autoNotify({ evaluationId: saved.evaluation.id })
        .then((res) => {
          if (res.results.length > 0) {
            toast({
              title: t("ውጤቱ በአውቶማቲክ ለመላክ ተርታል", "Result queued for automatic delivery"),
              description: "Queued for automatic delivery",
            });
          }
        })
        .catch(() => {});

      setResult({
        dirKey: d.key,
        quarter: quarterInput,
        totalScore: computed.totalScore,
        scores: computed.scores,
        comments: mergedComments,
        feedback,
        actionPlan,
      });
    } catch (err) {
      toast({
        title: t("ሪፖርቱ አልተላከም", "Failed to submit report"),
        description: err instanceof Error ? err.message : "Failed to submit report",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  /* ---------- Success screen ---------- */
  if (result) {
    const rd = getDirectorate(result.dirKey);
    const rPct = scorePercent(result.totalScore);
    return (
      <div className="flex-1">
        {/* Header */}
        <div className="bg-primary text-primary-foreground py-4 px-4">
          <div className="max-w-2xl mx-auto flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary-foreground/15 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="font-bold truncate">{t("የሩብ ዓመት ሪፖርት ማቅረቢያ", "Quarterly Report Submission")}</div>
              <div className="text-xs opacity-80 truncate">{t("", "— Harari Health Bureau")}</div>
            </div>
          </div>
        </div>

        <div className="max-w-md mx-auto p-4 py-10">
          <Card className="py-6 text-center">
            <CardContent className="px-6 space-y-3">
              <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
              <div className="text-xl font-bold">{t("ሪፖርቱ ተቀምጧል!", "Report saved!")}</div>
              <div className="text-sm text-muted-foreground">
                {rd ? `${rd.name} — ${result.quarter}` : result.quarter}
              </div>
              <div className="text-sm font-semibold">
                {t("ጠቅላላ ውጤት:", "Total score:")} {result.totalScore}/{TOTAL_MAX_SCORE} ({rPct}%)
              </div>
              <PerformanceBadge percent={rPct} />
              <Button
                className="w-full h-10 mt-2"
                onClick={() =>
                  downloadEvaluationPdf(
                    {
                      directorate: rd
                        ? { short: rd.short, name: rd.name, nameEn: rd.nameEn }
                        : undefined,
                      quarter: result.quarter,
                      totalScore: result.totalScore,
                      scores: result.scores,
                      comments: result.comments,
                      actionPlan: result.actionPlan,
                      feedback: result.feedback,
                    },
                    `report-${rd?.short ?? "directorate"}-${result.quarter}.pdf`
                  )
                }
              >
                <Download className="w-4 h-4 mr-2" />
                {t("ሙሉ ሪፖርት አውርድ", "Download Full Report (PDF)")}
              </Button>
              <p className="text-xs text-muted-foreground pt-1">
                {t("ሪፖርቱ ለቢሮ ግምገማ ቡድን ተልኳል።", "The report has been sent to the bureau evaluation team.")}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  /* ---------- Submission form ---------- */
  return (
    <div className="flex-1">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-4 px-4">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary-foreground/15 flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="font-bold truncate">{t("የሩብ ዓመት ሪፖርት ማቅረቢያ", "Quarterly Report Submission")}</div>
            <div className="text-xs opacity-80 truncate">{t("", "— Harari Health Bureau")}</div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4 pb-16">
        {/* Section 1: Basic information */}
        <Card className="py-4">
          <CardContent className="px-4 space-y-3">
            <div className="font-semibold text-sm">{t("መሠረታዊ መረጃ", "Basic Information")}</div>
            <div className="space-y-1.5">
              <Label>{t("ዳይሬክቶሬት", "Directorate")}</Label>
              <Select value={dirKey} onValueChange={setDirKey}>
                <SelectTrigger className="w-full h-9">
                  <SelectValue placeholder={t("ዳይሬክቶሬት ይምረጡ", "Select a directorate")} />
                </SelectTrigger>
                <SelectContent>
                  {DIRECTORATES.map((dir) => (
                    <SelectItem key={dir.key} value={dir.key}>
                      {dir.short} — {dir.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="submit-quarter">{t("ሩብ ዓመት", "Quarter")}</Label>
                <Input
                  id="submit-quarter"
                  className="h-9"
                  value={quarterInput}
                  onChange={(e) => setQuarterInput(e.target.value)}
                  placeholder={DEFAULT_QUARTER}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="submit-director">{t("የዳይሬክተር ስም", "Director's name")}</Label>
                <Input
                  id="submit-director"
                  className="h-9"
                  value={directorName}
                  onChange={(e) => setDirectorName(e.target.value)}
                  placeholder={t("የዳይሬክተር ስም (አማራጭ)", "Director's name (optional)")}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section 2: Report file */}
        <Card className="py-4">
          <CardContent className="px-4 space-y-3">
            <div className="font-semibold text-sm">{t("ሪፖርት ፋይል", "Report File")}</div>
            <Input
              type="file"
              accept=".txt,.md,.csv,.htm,.html"
              className="h-9 text-xs"
              onChange={handleFile}
            />
            {fileName && (
              <div className="flex items-center gap-2 rounded-md border bg-muted/40 px-2.5 py-1.5">
                <FileText className="w-4 h-4 text-primary shrink-0" />
                <span className="text-xs truncate flex-1">{fileName}</span>
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {wordCount} words
                </span>
              </div>
            )}
            <AiLanguageSelector value={aiLang} onChange={setAiLang} />

            <Button
              className="w-full h-9"
              onClick={analyze}
              disabled={analyzing || !dirKey || !content.trim()}
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t("AI በመገምገም ላይ…", "Analyzing with AI…")}
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  {t("AI በመገምገም ላይ", "Analyze with AI")}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Section 3: Results + editable comments */}
        {analyzed && (
          <>
            <Card className="py-4">
              <CardContent className="px-4 flex flex-col items-center gap-2">
                <BigScore score={totalScore} max={TOTAL_MAX_SCORE} />
                <PerformanceBadge percent={pct} />
              </CardContent>
            </Card>

            <Card className="py-4">
              <CardContent className="px-4 space-y-4">
                <div className="font-semibold text-sm">{t("የምድብ ውጤቶች", "Category Scores")}</div>
                {CRITERIA.map((criterion) => {
                  const scored = scores[criterion.key] ?? 0;
                  return (
                    <div key={criterion.key} className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-medium truncate">
                          <span className="font-bold text-primary">{criterion.key}.</span>{" "}
                          {criterion.name}
                        </span>
                        <ScoreBadge score={scored} max={criterion.maxScore} />
                      </div>
                      <ScoreBar score={scored} max={criterion.maxScore} />
                      {/* yes/no summary */}
                      <div className="flex flex-wrap gap-1.5">
                        {criterion.subQuestions.map((q) => {
                          const isYes = answers[q.id] === "yes";
                          return (
                            <span
                              key={q.id}
                              title={q.labelEn}
                              className={cn(
                                "inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border",
                                isYes
                                  ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
                                  : "bg-red-500/10 text-red-600 border-red-500/30"
                              )}
                            >
                              {isYes ? (
                                <Check className="w-3 h-3" />
                              ) : (
                                <X className="w-3 h-3" />
                              )}
                              {q.id}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card className="py-4">
              <CardContent className="px-4 space-y-4">
                <div className="font-semibold text-sm">{t("አስተያየቶች", "Comments")}</div>
                {CRITERIA.map((criterion) => (
                  <div key={criterion.key} className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">
                      {criterion.key}. {criterion.name} {t("— አስተያየት", "— Comment")}
                    </Label>
                    {aiComments[criterion.key] && (
                      <div className="text-xs italic text-muted-foreground bg-muted/50 rounded-md px-2.5 py-1.5">
                        AI: {aiComments[criterion.key]}
                      </div>
                    )}
                    <Textarea
                      rows={2}
                      className="text-sm"
                      placeholder={t("አስተያየት ይጻፉ…", "Write a comment…")}
                      value={comments[criterion.key] ?? ""}
                      onChange={(e) =>
                        setComments((prev) => ({ ...prev, [criterion.key]: e.target.value }))
                      }
                    />
                  </div>
                ))}
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">
                    {t("ተጨማሪ አስተያየት", "Additional feedback")}
                  </Label>
                  <Textarea
                    rows={3}
                    className="text-sm"
                    placeholder={t("ተጨማሪ አስተያየት ይጻፉ…", "Write additional feedback…")}
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Action plan (structured goals & corrective steps) */}
            <ActionPlanEditor items={actionPlan} onChange={setActionPlan} />

            <Button className="w-full h-10" onClick={submit} disabled={submitting || !dirKey}>
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t("በመላክ ላይ…", "Submitting…")}
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  {t("ሪፖርት አስገባ", "Submit Report")}
                </>
              )}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
