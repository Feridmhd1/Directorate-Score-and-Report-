"use client";

/**
 * LinksView — Link Library (አገናኞች ቤተ-መጻሕፍት).
 *
 * • Public browsing: curated links grouped into three category tabs —
 *   similar applications, learning links and other useful resources.
 *   Each link row opens the URL in a new tab or copies it to the clipboard.
 * • Management (add / edit / delete) is protected by the Settings password
 *   (default 3472): the PIN is verified once via settingsApi.verify, kept for
 *   the tab session (setSettingsPin — sessionStorage) and attached
 *   automatically to every linksApi write by client-api (server-enforced).
 */

import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowLeft,
  Copy,
  ExternalLink,
  GraduationCap,
  Library,
  Link2,
  Loader2,
  Lock,
  Pencil,
  Plus,
  RefreshCw,
  Rocket,
  Save,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/shared";
import { clearSettingsPin, getSettingsPin, linksApi, setSettingsPin, settingsApi } from "@/lib/client-api";
import type { LinkItemDTO } from "@/lib/types";
import { useLang } from "@/lib/i18n";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

/* ---------------- Category metadata (icons/colors static, labels localized in-component) ---------------- */

const CATEGORY_META = [
  {
    key: "app",
    labelAm: "ተመሳሳይ መተግበሪያዎች",
    labelEn: "Similar Applications",
    icon: Rocket,
    chip: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    badge:
      "border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300",
  },
  {
    key: "learning",
    labelAm: "የትምህርት አገናኞች",
    labelEn: "Learning Links",
    icon: GraduationCap,
    chip: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    badge:
      "border-transparent bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-500/15 dark:text-amber-300",
  },
  {
    key: "other",
    labelAm: "ሌሎች አገናኞች",
    labelEn: "Other Links",
    icon: Link2,
    chip: "bg-teal-500/10 text-teal-600 dark:text-teal-400",
    badge:
      "border-transparent bg-teal-100 text-teal-700 hover:bg-teal-100 dark:bg-teal-500/15 dark:text-teal-300",
  },
] as const;

type CategoryKey = (typeof CATEGORY_META)[number]["key"];

function categoryMetaFor(category: string) {
  return CATEGORY_META.find((c) => c.key === category) ?? CATEGORY_META[2];
}

/** 44px touch targets on mobile, compact on larger screens */
const TOUCH_ICON = "h-11 w-11 sm:h-9 sm:w-9";

/* ---------------- Manage PIN gate (inline card, same pattern as the Settings gate) ---------------- */

function ManagePinGate({ onUnlock, onCancel }: { onUnlock: (pin: string) => void; onCancel: () => void }) {
  const { t } = useLang();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const value = pin.trim();
    if (!value || busy) return;
    setBusy(true);
    setError("");
    try {
      await settingsApi.verify(value);
      onUnlock(value);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Verification failed";
      setError(message);
      setPin("");
      toast({ title: t("ስህተት", "Error"), description: message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="glass-card relative mx-auto w-full max-w-md border-amber-300/60 dark:border-amber-500/30">
      <Button
        variant="ghost"
        size="icon"
        className={cn("absolute right-1.5 top-1.5", TOUCH_ICON)}
        onClick={onCancel}
        aria-label={t("ዝጋ", "Dismiss")}
      >
        <X className="h-4 w-4" aria-hidden />
      </Button>
      <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <div>
          <p className="text-sm font-semibold">{t("የተደበቀ አስተዳደር", "Restricted area")}</p>
          <p className="text-xs text-muted-foreground">
            {t(
              "አገናኞችን ለመጨመር፣ ለማስተካከል ወይም ለማጥፋት የቅንብሮች ይለፍ ቃል ያስፈልጋል።",
              "Adding, editing or removing links requires the settings password."
            )}
          </p>
        </div>
        <form onSubmit={submit} className="flex w-full max-w-xs items-center gap-2">
          <Input
            type="password"
            inputMode="numeric"
            autoComplete="off"
            className="h-9 text-center tracking-[0.4em]"
            placeholder="••••"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            aria-label={t("የቅንብሮች ገጽ የይለፍ ቃል", "Settings password")}
            aria-invalid={Boolean(error)}
            disabled={busy}
          />
          <Button type="submit" className="h-9 shrink-0" disabled={!pin.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <ShieldCheck className="h-4 w-4" aria-hidden />}
            {t("ክፈት", "Unlock")}
          </Button>
        </form>
        {error && (
          <p className="text-xs font-medium text-destructive" role="alert">
            {error}
          </p>
        )}
        <p className="text-[11px] text-muted-foreground">{t("ነባር የይለፍ ቃል፦ 3472", "Default password: 3472")}</p>
      </CardContent>
    </Card>
  );
}

/* ---------------- Link row card ---------------- */

function LinkCard({
  link,
  manage,
  onEdit,
  onDelete,
  onCopy,
}: {
  link: LinkItemDTO;
  manage: boolean;
  onEdit: (link: LinkItemDTO) => void;
  onDelete: (link: LinkItemDTO) => void;
  onCopy: (link: LinkItemDTO) => void;
}) {
  const { t } = useLang();
  const meta = categoryMetaFor(link.category);
  const Icon = meta.icon;
  return (
    <div className="flex items-start gap-3 rounded-xl border bg-background/60 p-4 transition-colors hover:border-primary/40">
      <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", meta.chip)}>
        <Icon className="h-5 w-5" aria-hidden />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <p className="min-w-0 font-medium leading-snug">{link.title}</p>
          <Badge className={meta.badge}>{t(meta.labelAm, meta.labelEn)}</Badge>
        </div>
        {link.description && (
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{link.description}</p>
        )}
        <p className="mt-1 truncate text-xs text-muted-foreground/70">{link.url}</p>
      </div>
      <div className="flex shrink-0 items-center gap-0.5 sm:gap-1">
        <Button variant="ghost" size="icon" asChild className={TOUCH_ICON}>
          <a
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${t("ክፈት", "Open")}: ${link.title}`}
            title={t("በአዲስ ትር ክፈት", "Open in new tab")}
          >
            <ExternalLink className="h-4 w-4" aria-hidden />
          </a>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={TOUCH_ICON}
          onClick={() => onCopy(link)}
          aria-label={`${t("አገናኝ ቅዳ", "Copy link")}: ${link.title}`}
          title={t("አገናኝ ቅዳ", "Copy link")}
        >
          <Copy className="h-4 w-4" aria-hidden />
        </Button>
        {manage && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className={TOUCH_ICON}
              onClick={() => onEdit(link)}
              aria-label={`${t("አርትዕ", "Edit")}: ${link.title}`}
              title={t("አርትዕ", "Edit")}
            >
              <Pencil className="h-4 w-4" aria-hidden />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={cn(TOUCH_ICON, "text-destructive hover:text-destructive")}
              onClick={() => onDelete(link)}
              aria-label={`${t("ሰርዝ", "Delete")}: ${link.title}`}
              title={t("ሰርዝ", "Delete")}
            >
              <Trash2 className="h-4 w-4" aria-hidden />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------------- Per-category empty state ---------------- */

function EmptyState({ category, manage }: { category: CategoryKey; manage: boolean }) {
  const { t } = useLang();
  const meta = categoryMetaFor(category);
  const Icon = meta.icon;
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed p-8 text-center">
      <div className={cn("flex h-12 w-12 items-center justify-center rounded-2xl", meta.chip)}>
        <Icon className="h-6 w-6" aria-hidden />
      </div>
      <p className="text-sm font-medium">{t("እስካሁን አገናኝ አልታከለም", "No links added yet")}</p>
      {manage && (
        <p className="text-xs text-muted-foreground">
          {t("ከላይ ባለው ቅጽ የመጀመሪያውን አገናኝ ይጨምሩ።", "Use the form above to add the first link.")}
        </p>
      )}
    </div>
  );
}

/* ---------------- View ---------------- */

export function LinksView({ navigate }: { navigate?: NavigateFn }) {
  const { t } = useLang();

  /* Data */
  const [links, setLinks] = useState<LinkItemDTO[]>([]);
  const [loading, setLoading] = useState(true);

  /* Category tabs */
  const [tab, setTab] = useState<CategoryKey>("app");

  /* Manage mode + settings-PIN session */
  const [unlocked, setUnlocked] = useState(false);
  const [manageMode, setManageMode] = useState(false);
  const [gateOpen, setGateOpen] = useState(false);

  /* Add / edit form */
  const [editing, setEditing] = useState<LinkItemDTO | null>(null);
  const [formTitle, setFormTitle] = useState("");
  const [formUrl, setFormUrl] = useState("");
  const [formCategory, setFormCategory] = useState<string>("app");
  const [formDescription, setFormDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const formCardRef = useRef<HTMLDivElement>(null);

  /* -------- data loading -------- */

  const loadLinks = useCallback(async () => {
    setLoading(true);
    try {
      const res = await linksApi.list();
      setLinks(res.links);
    } catch {
      toast({
        title: t("ስህተት", "Error"),
        description: t("አገናኞችን መጫን አልተቻለም።", "Failed to load links."),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    void loadLinks();
  }, [loadLinks]);

  /* Restore an unlocked manage session (password verified earlier in this tab) */
  useEffect(() => {
    if (getSettingsPin()) setUnlocked(true);
  }, []);

  /* -------- manage mode + form -------- */

  const resetForm = () => {
    setEditing(null);
    setFormTitle("");
    setFormUrl("");
    setFormCategory(tab);
    setFormDescription("");
  };

  /** Manage toggle: active → exit; unlocked → enter; otherwise show the PIN gate */
  const toggleManage = () => {
    if (manageMode) {
      setManageMode(false);
      resetForm();
      return;
    }
    if (unlocked) {
      setManageMode(true);
      return;
    }
    setGateOpen((open) => !open);
  };

  const handleUnlock = (pin: string) => {
    setSettingsPin(pin);
    setUnlocked(true);
    setGateOpen(false);
    setManageMode(true);
  };

  const handleLock = () => {
    clearSettingsPin();
    setUnlocked(false);
    setManageMode(false);
    setGateOpen(false);
    resetForm();
  };

  const openEdit = (link: LinkItemDTO) => {
    setEditing(link);
    setFormTitle(link.title);
    setFormUrl(link.url);
    setFormCategory(link.category);
    setFormDescription(link.description ?? "");
    formCardRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  /* -------- actions -------- */

  const copyLink = async (link: LinkItemDTO) => {
    try {
      await navigator.clipboard.writeText(link.url);
      toast({ title: t("አገናኝ ተቀድቷል", "Link copied"), description: link.title });
    } catch {
      toast({ title: t("መቅዳት አልተሳካም", "Copy failed"), variant: "destructive" });
    }
  };

  const deleteLink = async (link: LinkItemDTO) => {
    const ok = window.confirm(
      `${t("እርግጠኛ ነዎት ይህን አገናኝ ከቤተ-መጻሕፍቱ ማጥፋት ይፈልጋሉ?", "Delete this link from the library?")} — ${link.title}`
    );
    if (!ok) return;
    try {
      await linksApi.remove(link.id);
      toast({ title: t("አገናኙ ተሰርዟል", "Link deleted"), description: link.title });
      if (editing?.id === link.id) resetForm();
      await loadLinks();
    } catch (err) {
      toast({
        title: t("መሰረዝ አልተሳካም", "Delete failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    }
  };

  const submitForm = async (e: FormEvent) => {
    e.preventDefault();
    const title = formTitle.trim();
    const url = formUrl.trim();
    if (!title || !url) {
      toast({
        title: t("ስህተት", "Error"),
        description: t("ርዕስና ሊንክ ያስፈልጋሉ።", "Title and URL are required."),
        variant: "destructive",
      });
      return;
    }
    setSaving(true);
    try {
      const data = { title, url, category: formCategory, description: formDescription.trim() };
      if (editing) {
        await linksApi.update(editing.id, data);
        toast({ title: t("አገናኙ ተዘምኗል", "Link updated"), description: title });
      } else {
        await linksApi.create(data);
        toast({ title: t("አገናኝ ታክሏል", "Link added"), description: title });
      }
      resetForm();
      /* Jump to the tab of the saved category so the change is visible */
      const key = formCategory as CategoryKey;
      if (CATEGORY_META.some((c) => c.key === key)) setTab(key);
      await loadLinks();
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካም", "Save failed"),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  /* -------- render -------- */

  const countFor = (key: CategoryKey) => links.filter((l) => l.category === key).length;

  const header = (
    <header className="glass-card sticky top-0 z-20 border-b">
      <div className="mx-auto flex w-full max-w-5xl items-center gap-3 px-4 py-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0"
          onClick={() => navigate?.("home")}
          aria-label={t("ተመለስ", "Back")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Library className="h-5 w-5" aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-bold leading-tight">{t("አገናኞች ቤተ-መጻሕፍት", "Link Library")}</h1>
          <p className="truncate text-xs text-muted-foreground">
            {t(
              "ተመሳሳይ መተግበሪያዎች፣ የትምህርት አገናኞች እና ሌሎችን ያስቀምጡ",
              "Similar applications, learning links and other useful resources"
            )}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <Button
            variant="ghost"
            size="icon"
            className={cn("shrink-0", TOUCH_ICON)}
            onClick={() => void loadLinks()}
            disabled={loading}
            aria-label={t("እድሳት", "Refresh")}
            title={t("እድሳት", "Refresh")}
          >
            <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} aria-hidden />
          </Button>
          <Button
            variant={manageMode ? "default" : "outline"}
            size="sm"
            className="h-9 shrink-0"
            onClick={toggleManage}
            aria-pressed={manageMode || gateOpen}
            aria-label={t("የአስተዳደር ሁነታ", "Manage mode")}
            title={t("የአስተዳደር ሁነታ", "Manage mode")}
          >
            <Pencil className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">{t("አስተዳደር", "Manage")}</span>
          </Button>
          {manageMode && unlocked && (
            <Button
              variant="outline"
              size="sm"
              className="h-9 shrink-0"
              onClick={handleLock}
              aria-label={t("የአስተዳደር ሁነታን ተው", "Lock manage mode")}
              title={t("የአስተዳደር ሁነታን ተው", "Lock manage mode")}
            >
              <Lock className="h-4 w-4" aria-hidden />
              <span className="hidden sm:inline">{t("ተው", "Lock")}</span>
            </Button>
          )}
        </div>
      </div>
    </header>
  );

  return (
    <div className="flex-1">
      {header}

      <main className="mx-auto w-full max-w-5xl space-y-6 p-4 sm:p-6">
        {gateOpen && !manageMode && <ManagePinGate onUnlock={handleUnlock} onCancel={() => setGateOpen(false)} />}

        {loading && links.length === 0 ? (
          <LoadingSpinner />
        ) : (
          <>
            {manageMode && (
              <Card ref={formCardRef} className="glass-card scroll-mt-20 border-primary/30">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    {editing ? (
                      <Pencil className="h-4 w-4 text-primary" aria-hidden />
                    ) : (
                      <Plus className="h-4 w-4 text-primary" aria-hidden />
                    )}
                    {editing ? t("አገናኝ አርትዕ", "Edit link") : t("አዲስ አገናኝ ያክሉ", "Add a new link")}
                  </CardTitle>
                  <CardDescription>
                    {editing
                      ? t("የአገናኙን መረጃ ያዘምኑ።", "Update the link details.")
                      : t("ለቤተ-መጻሕፍቱ ጠቃሚ አገናኝ ይጨምሩ።", "Add a useful link to the library.")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={submitForm} className="grid gap-4 sm:grid-cols-2" noValidate>
                    <div className="space-y-1.5">
                      <Label htmlFor="link-title">{t("ርዕስ", "Title")} *</Label>
                      <Input
                        id="link-title"
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder={t("ለምሳሌ፦ የጤና ሚኒስቴር", "e.g. Ministry of Health")}
                        required
                        aria-label={t("ርዕስ", "Title")}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="link-url">{t("ሊንክ (URL)", "URL")} *</Label>
                      <Input
                        id="link-url"
                        type="text"
                        inputMode="url"
                        value={formUrl}
                        onChange={(e) => setFormUrl(e.target.value)}
                        placeholder="https://…"
                        required
                        aria-label="URL"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="link-category">{t("ምድብ", "Category")}</Label>
                      <Select value={formCategory} onValueChange={setFormCategory}>
                        <SelectTrigger id="link-category" className="w-full" aria-label={t("ምድብ", "Category")}>
                          <SelectValue placeholder={t("ምድብ ይምረጡ", "Select a category")} />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORY_META.map((c) => (
                            <SelectItem key={c.key} value={c.key}>
                              {t(c.labelAm, c.labelEn)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5 sm:col-span-2">
                      <Label htmlFor="link-description">{t("መግለጫ (አማራጭ)", "Description (optional)")}</Label>
                      <Textarea
                        id="link-description"
                        rows={2}
                        value={formDescription}
                        onChange={(e) => setFormDescription(e.target.value)}
                        placeholder={t("በአጭሩ ምን እንዳለ ይግለጹ…", "Describe what this link offers…")}
                        aria-label={t("መግለጫ", "Description")}
                        className="min-h-[64px] resize-y"
                      />
                    </div>
                    <div className="flex flex-wrap items-center gap-2 sm:col-span-2">
                      <Button type="submit" disabled={saving}>
                        {saving ? (
                          <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                        ) : (
                          <Save className="h-4 w-4" aria-hidden />
                        )}
                        {editing ? t("ለውጦችን አስቀምጥ", "Save changes") : t("አገናኝ አክል", "Add link")}
                      </Button>
                      <Button type="button" variant="outline" onClick={resetForm}>
                        <X className="h-4 w-4" aria-hidden />
                        {t("ሰርዝ", "Cancel")}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Tabs value={tab} onValueChange={(v) => setTab(v as CategoryKey)} className="gap-4">
              <TabsList className="h-auto w-full flex-wrap gap-1">
                {CATEGORY_META.map((c) => (
                  <TabsTrigger key={c.key} value={c.key} className="h-9 flex-1 gap-1.5 px-2.5 sm:flex-none sm:px-3">
                    <c.icon className="h-4 w-4" aria-hidden />
                    <span className="min-w-0 truncate">{t(c.labelAm, c.labelEn)}</span>
                    <span className="text-[11px] font-semibold text-muted-foreground">{countFor(c.key)}</span>
                  </TabsTrigger>
                ))}
              </TabsList>

              {CATEGORY_META.map((c) => {
                const items = links.filter((l) => l.category === c.key);
                return (
                  <TabsContent key={c.key} value={c.key}>
                    {items.length === 0 ? (
                      <EmptyState category={c.key} manage={manageMode} />
                    ) : (
                      <div className="max-h-[36rem] space-y-3 overflow-y-auto pr-1">
                        {items.map((link) => (
                          <LinkCard
                            key={link.id}
                            link={link}
                            manage={manageMode}
                            onEdit={openEdit}
                            onDelete={(l) => void deleteLink(l)}
                            onCopy={(l) => void copyLink(l)}
                          />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </>
        )}
      </main>
    </div>
  );
}
