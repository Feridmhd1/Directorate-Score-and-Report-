"use client";

import { useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  ClipboardList,
  FileSpreadsheet,
  FileText,
  Flag,
  Image as ImageIcon,
  Lightbulb,
  Loader2,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  ThumbsUp,
  Upload,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import type { NavigateFn } from "@/hooks/use-view";
import {
  ACTION_PLAN_STATUS_LABELS,
  CRITERIA,
  DEFAULT_QUARTER,
  DIRECTORATES,
  computeScores,
  scorePercent,
  type ActionPlanItem,
} from "@/lib/rubric";
import { aiApi, automationApi, evaluationsApi, notificationsApi } from "@/lib/client-api";
import { AiLanguageSelector, BigScore, PerformanceBadge, ScoreBadge } from "@/components/shared";
import type { AiLanguage } from "@/components/shared";
import type { EvaluatorAuditReport, EvaluatorDisagreement } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/i18n";

type YesNo = "yes" | "no";

/** A document uploaded to the AI evaluator, after server-side text extraction. */
interface LoadedDoc {
  id: string;
  name: string;
  kind: string; // "text" | "table" | "image"
  wordCount: number;
  meta: Record<string, unknown>;
  text: string;
}

const MAX_DOCS = 6;

/* ---------- AI evaluator audit ("evaluate the AI evaluator") ---------- */

const VERDICT_STYLES: Record<
  string,
  { badge: string; text: string; bar: string; am: string; en: string }
> = {
  reliable: {
    badge: "bg-emerald-100 text-emerald-700",
    text: "text-emerald-600",
    bar: "bg-emerald-500",
    am: "ታምናሚ ነው",
    en: "Reliable",
  },
  review: {
    badge: "bg-amber-100 text-amber-700",
    text: "text-amber-600",
    bar: "bg-amber-500",
    am: "ክለሳ ያስፈልገዋል",
    en: "Needs review",
  },
  unreliable: {
    badge: "bg-red-100 text-red-700",
    text: "text-red-600",
    bar: "bg-red-500",
    am: "እንደገና ይገምገም",
    en: "Unreliable",
  },
};

const SEVERITY_STYLES: Record<string, string> = {
  high: "bg-red-100 text-red-700",
  medium: "bg-amber-100 text-amber-700",
  low: "bg-slate-100 text-slate-600",
};

function normalizeAnswers(raw: Record<string, string> | null | undefined): Record<string, YesNo> {
  const normalized: Record<string, YesNo> = {};
  if (!raw) return normalized;
  Object.entries(raw).forEach(([k, v]) => {
    if (v === "yes" || v === "no") normalized[k] = v;
  });
  return normalized;
}

/* ---------- Structured action plan editor (local to this file) ---------- */

const ACTION_STATUS_KEYS = ["planned", "in_progress", "done"] as const;
type ActionStatusKey = (typeof ACTION_STATUS_KEYS)[number];

const ACTION_STATUS_STYLES: Record<ActionStatusKey, string> = {
  planned: "bg-primary text-primary-foreground border-primary hover:bg-primary/90 hover:text-primary-foreground",
  in_progress: "bg-amber-500 text-white border-amber-500 hover:bg-amber-600 hover:text-white",
  done: "bg-emerald-500 text-white border-emerald-500 hover:bg-emerald-600 hover:text-white",
};

/**
 * Structured "goals & corrective steps" planner: each item carries the step text,
 * an owner, a deadline and a status (planned / in_progress / done).
 */
function ActionPlanEditor({
  items,
  onChange,
}: {
  items: ActionPlanItem[];
  onChange: (items: ActionPlanItem[]) => void;
}) {
  const { t } = useLang();
  const addItem = () =>
    onChange([
      ...items,
      { id: crypto.randomUUID(), text: "", owner: "", deadline: "", status: "planned" },
    ]);
  const patchItem = (id: string, patch: Partial<ActionPlanItem>) =>
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  const removeItem = (id: string) => onChange(items.filter((it) => it.id !== id));

  return (
    <Card className="py-4">
      <CardContent className="px-4 space-y-3">
        <div className="flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-primary shrink-0" />
          <span className="font-semibold text-sm flex-1 min-w-0">{t("የድርጊት እቅድ", "Action Plan")}</span>
          {items.length > 0 && (
            <Badge variant="secondary" className="text-[11px] font-medium">
              {items.length} {t("እርምጃዎች", "actions")}
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {t(
            "በሩብ ዓመት ግምገማዎ ላይ የተለዩ ግቦችን ወይም አስተካካይ እርምጃዎችን ይዘምሩ።",
            "List specific goals or corrective steps identified during your quarterly review."
          )}
        </p>
        <div className="space-y-3">
          {items.map((item) => {
            const rawStatus = item.status ?? (item.done ? "done" : "planned");
            const status: ActionStatusKey = ACTION_STATUS_KEYS.includes(rawStatus as ActionStatusKey)
              ? (rawStatus as ActionStatusKey)
              : "planned";
            return (
              <div key={item.id} className="rounded-lg border p-3 space-y-2">
                {/* Goal / corrective step */}
                <Textarea
                  rows={2}
                  className="text-sm"
                  placeholder={t("ግብ ወይም አስተካካይ እርምጃ ይጻፉ…", "Goal or corrective step…")}
                  value={item.text}
                  onChange={(e) => patchItem(item.id, { text: e.target.value })}
                />
                {/* Owner + deadline */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <Input
                    className="h-9"
                    placeholder={t("ኃላፊ", "Owner…")}
                    value={item.owner ?? ""}
                    onChange={(e) => patchItem(item.id, { owner: e.target.value })}
                  />
                  <Input
                    className="h-9"
                    type="date"
                    aria-label={t("ጊዜ ገደብ", "Deadline")}
                    value={item.deadline ?? ""}
                    onChange={(e) => patchItem(item.id, { deadline: e.target.value })}
                  />
                </div>
                {/* Status + remove */}
                <div className="flex items-center gap-2">
                  <div className="grid flex-1 grid-cols-3 gap-1.5 min-w-0">
                    {ACTION_STATUS_KEYS.map((key) => (
                      <Button
                        key={key}
                        type="button"
                        variant="outline"
                        className={cn(
                          "h-9 px-1 text-[11px] leading-tight whitespace-normal font-medium",
                          status === key ? ACTION_STATUS_STYLES[key] : "text-muted-foreground"
                        )}
                        aria-pressed={status === key}
                        onClick={() =>
                          patchItem(item.id, { status: key, done: key === "done" })
                        }
                      >
                        {ACTION_PLAN_STATUS_LABELS[key]}
                      </Button>
                    ))}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9 shrink-0 text-destructive hover:text-destructive"
                    onClick={() => removeItem(item.id)}
                    aria-label="Remove item"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        {items.length === 0 && (
          <p className="text-xs italic text-muted-foreground">
            {t("እስካሁን ምንም እርምጃ አልታቀደም", "No goals or steps yet.")}
          </p>
        )}
        <Button type="button" variant="outline" className="h-9" onClick={addItem}>
          <Plus className="w-4 h-4 mr-2" />
          {t("እቅድ ጨምር", "Add Goal or Step")}
        </Button>
      </CardContent>
    </Card>
  );
}

export function ReviewView({ navigate }: { navigate: NavigateFn }) {
  const { t } = useLang();
  const [dirKey, setDirKey] = useState("");
  const [quarter, setQuarter] = useState(DEFAULT_QUARTER);
  const [email, setEmail] = useState("");
  const [docs, setDocs] = useState<LoadedDoc[]>([]);
  const [extracting, setExtracting] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [aiLang, setAiLang] = useState<AiLanguage>("english");
  const [analyzed, setAnalyzed] = useState(false);
  const [answers, setAnswers] = useState<Record<string, YesNo>>({});
  const [comments, setComments] = useState<Record<string, string>>({});
  const [aiComments, setAiComments] = useState<Record<string, string>>({});
  const [actionPlan, setActionPlan] = useState<ActionPlanItem[]>([]);
  const [saving, setSaving] = useState(false);
  const resultsRef = useRef<HTMLDivElement | null>(null);

  /* AI evaluator audit (meta-evaluation) */
  const [auditing, setAuditing] = useState(false);
  const [audit, setAudit] = useState<EvaluatorAuditReport | null>(null);
  const [auditedAnswersSnapshot, setAuditedAnswersSnapshot] = useState("");
  const auditRef = useRef<HTMLDivElement | null>(null);

  const d = DIRECTORATES.find((dir) => dir.key === dirKey);
  const { scores, totalScore } = useMemo(() => computeScores(answers), [answers]);
  const pct = scorePercent(totalScore);

  /* Rubric sub-question lookup for audit disagreement cards */
  const questionIndex = useMemo(() => {
    const map: Record<string, { labelEn: string; label: string; points: number }> = {};
    CRITERIA.forEach((c) =>
      c.subQuestions.forEach((q) => {
        map[q.id] = { labelEn: q.labelEn, label: q.label, points: q.points };
      })
    );
    return map;
  }, []);

  /* All extracted documents combined into one report text for the AI. */
  const combinedContent = useMemo(
    () =>
      docs
        .map((doc) => `--- ${doc.name} ---\n${doc.text.trim()}`)
        .join("\n\n")
        .trim(),
    [docs]
  );
  const totalWords = useMemo(() => docs.reduce((sum, doc) => sum + doc.wordCount, 0), [docs]);

  const handleFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files ?? []);
    e.target.value = ""; // allow re-selecting the same file later
    if (selected.length === 0) return;

    const room = MAX_DOCS - docs.length;
    if (room <= 0) {
      toast({
        title: t(`እስከ ${MAX_DOCS} ሰነዶች ብቻ`, `Up to ${MAX_DOCS} documents at a time`),
        description: t(
          "እባክዎ የተጨመሩትን ሰነዶች ይመርምሩ።",
          "Please review or remove the documents already added."
        ),
      });
      return;
    }
    const batch = selected.slice(0, room);
    if (selected.length > batch.length) {
      toast({
        title: t(`እስከ ${MAX_DOCS} ሰነዶች ብቻ`, `Up to ${MAX_DOCS} documents at a time`),
        description: t(
          `${selected.length - batch.length} ፋይሎች አልተጨመሩም።`,
          `${selected.length - batch.length} file(s) were not added.`
        ),
      });
    }

    setExtracting(true);
    try {
      for (const file of batch) {
        try {
          const ex = await aiApi.extractDocument(file);
          if (!ex.extractedText.trim()) {
            throw new Error(
              t("በዚህ ፋይል ውስጥ ጽሑፍ አልተገኘም", "No readable text was found in this file")
            );
          }
          setDocs((prev) => [
            ...prev,
            {
              id: crypto.randomUUID(),
              name: ex.fileName,
              kind: ex.kind,
              wordCount: ex.wordCount,
              meta: ex.meta,
              text: ex.extractedText,
            },
          ]);
        } catch (err) {
          toast({
            title: t(`"${file.name}" ማንበብ አልተቻለም`, `Could not read "${file.name}"`),
            description: err instanceof Error ? err.message : String(err),
            variant: "destructive",
          });
        }
      }
    } finally {
      setExtracting(false);
    }
  };

  const removeDoc = (id: string) => setDocs((prev) => prev.filter((doc) => doc.id !== id));

  const docIconFor = (kind: string) =>
    kind === "image" ? (
      <ImageIcon className="w-4 h-4 text-primary shrink-0" />
    ) : kind === "table" ? (
      <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
    ) : (
      <FileText className="w-4 h-4 text-primary shrink-0" />
    );

  const docBadgeLabel = (doc: LoadedDoc): string => {
    const pages = doc.meta?.pages;
    if (typeof pages === "number" && pages > 0) {
      return `PDF · ${pages} ${t("ገጽ", "pages")}`;
    }
    const rows = doc.meta?.rows;
    if (typeof rows === "number" && rows > 0) {
      return `${t("ሉህ", "Sheet")} · ${rows} ${t("ረድፎች", "rows")}`;
    }
    if (doc.kind === "image") return t("ምስል — AI አንብቦታል", "Image — AI-read");
    if (doc.kind === "table") return t("ሉህ", "Spreadsheet");
    return t("ሰነድ", "Document");
  };

  const analyze = async () => {
    if (!d) {
      toast({ title: t("ዳይሬክቶሬት ይምረጡ", "Select a directorate"), description: "Please select a directorate first." });
      return;
    }
    if (!combinedContent.trim()) {
      toast({
        title: t("የሪፖርት ፋይል ያስፈልጋል", "Report file required"),
        description: t(
          "እባክዎ ቢያንስ አንድ የሪፖርት ሰነድ ይምረጡ።",
          "Please add at least one report document to analyze."
        ),
      });
      return;
    }
    setAnalyzing(true);
    try {
      const res = await aiApi.evaluateReport({ directorateName: d.name, quarter, content: combinedContent, language: aiLang });
      setAnswers(normalizeAnswers(res.answers));
      setComments(res.comments ?? {});
      setAiComments(res.comments ?? {});
      setAnalyzed(true);
      setAudit(null); // a fresh evaluation invalidates any previous audit
      setAuditedAnswersSnapshot("");
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    } catch {
      toast({
        title: t("AI ትንታኔ አልተሳካም። እንደገና ይሞክሩ።", "AI analysis failed. Please try again."),
        variant: "destructive",
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const setAnswer = (id: string, v: YesNo) => setAnswers((prev) => ({ ...prev, [id]: v }));

  /* ---------- Evaluate the AI evaluator (meta-evaluation audit) ---------- */

  const runAudit = async () => {
    if (!d || !analyzed) return;
    setAuditing(true);
    try {
      const computed = computeScores(answers);
      const res = await aiApi.evaluateEvaluator({
        directorateKey: d.key,
        directorateName: d.name,
        quarter,
        language: aiLang,
        answers,
        comments,
        totalScore: computed.totalScore,
        reportContent: combinedContent,
      });
      setAudit(res.report);
      setAuditedAnswersSnapshot(JSON.stringify(answers));
      toast({
        title: t("የAI ግምገማው ኦዲት ተጠናቋል", "AI evaluator audit complete"),
        description: `${t("የታምኝነት ደረጃ", "Reliability grade")}: ${res.report.qualityScore}/100`,
      });
      setTimeout(() => auditRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
    } catch (err) {
      toast({
        title: t("ኦዲቱ አልተሳካም። እንደገና ይሞክሩ።", "Audit failed. Please try again."),
        description: err instanceof Error ? err.message : undefined,
        variant: "destructive",
      });
    } finally {
      setAuditing(false);
    }
  };

  const applySuggestion = (dg: EvaluatorDisagreement) => {
    setAnswer(dg.questionId, dg.suggestedAnswer === "yes" ? "yes" : "no");
    setAudit((prev) =>
      prev ? { ...prev, disagreements: prev.disagreements.filter((x) => x.questionId !== dg.questionId) } : prev
    );
    toast({
      title: t("መልሱ ተስተካክሏል", "Answer corrected"),
      description: `${dg.questionId} → ${dg.suggestedAnswer === "yes" ? t("አዎ", "Yes") : t("አዩ", "No")}`,
    });
  };

  const answersEditedSinceAudit =
    audit !== null && auditedAnswersSnapshot !== "" && auditedAnswersSnapshot !== JSON.stringify(answers);

  const verdictStyle = VERDICT_STYLES[audit?.verdict ?? "review"] ?? VERDICT_STYLES.review;

  const save = async () => {
    if (!d) return;
    setSaving(true);
    try {
      const computed = computeScores(answers);
      const saved = await evaluationsApi.create({
        directorateKey: d.key,
        directorateName: d.name,
        directorateShort: d.short,
        quarter,
        email,
        scores: computed.scores,
        answers,
        comments,
        totalScore: computed.totalScore,
        status: "completed",
        aiGenerated: true,
        actionPlan,
      });
      await notificationsApi.create({
        type: "evaluation_completed",
        title: t(`ግምገማ ተጠናቅቋል — ${d.short}`, `Evaluation completed — ${d.short}`),
        message: t(
          `${d.name} የ${quarter} AI ግምገማ ተጠናቅቋል። ጠቅላላ ውጤት: ${computed.totalScore}/100`,
          `${d.name}'s AI evaluation for ${quarter} is complete. Total score: ${computed.totalScore}/100`
        ),
        directorateKey: d.key,
        directorateName: d.name,
        quarter,
        totalScore: computed.totalScore,
        directorEmail: email,
      });
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));

      /* Fire-and-forget: fan the score out to all enabled delivery channels */
      automationApi
        .autoNotify({ evaluationId: saved.evaluation.id })
        .then((res) => {
          if (res.results.length > 0) {
            toast({
              title: t("ውጤቱ በአውቶማቲክ ለመላክ ተርታል", "Result queued for automatic delivery"),
              description: "Queued for automatic delivery",
            });
          }
        })
        .catch(() => {});

      toast({ title: t("ግምገማው ተቀምጧል!", "Evaluation saved!"), description: "Evaluation saved!" });
      navigate("home");
    } catch (err) {
      toast({
        title: t("ግምገማው አልተቀመጠም", "Failed to save evaluation"),
        description: err instanceof Error ? err.message : "Failed to save evaluation",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex-1">
      {/* Sticky header */}
      <div className="sticky top-0 z-20 bg-card border-b px-4 py-3 shadow-sm">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={() => navigate("home")}
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm sm:text-base truncate">{t("AI ግምገማ", "AI-Assisted Report Evaluation")}</div>
            <div className="text-xs text-muted-foreground truncate">{t("", "")}</div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4 pb-16">
        {/* Upload / analyze form */}
        <Card className="py-4">
          <CardContent className="px-4 space-y-4">
            <div className="space-y-1.5">
              <Label>{t("ዳይሬክቶሬት", "Directorate")}</Label>
              <Select value={dirKey} onValueChange={setDirKey}>
                <SelectTrigger className="w-full h-9">
                  <SelectValue placeholder={t("ዳይሬክቶሬት ይምረጡ", "Select a directorate")} />
                </SelectTrigger>
                <SelectContent>
                  {DIRECTORATES.map((dir) => (
                    <SelectItem key={dir.key} value={dir.key}>
                      {dir.short} — {dir.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="review-quarter">{t("ሩብ ዓመት", "Quarter")}</Label>
                <Input
                  id="review-quarter"
                  className="h-9"
                  value={quarter}
                  onChange={(e) => setQuarter(e.target.value)}
                  placeholder={DEFAULT_QUARTER}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="review-email">{t("የዳይሬክተር ኢሜይል (አማራጭ)", "Director's email (optional)")}</Label>
                <Input
                  id="review-email"
                  type="email"
                  className="h-9"
                  placeholder="director@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="review-file">{t("የሪፖርት ሰነዶች", "Report Documents")}</Label>
              <input
                id="review-file"
                type="file"
                multiple
                className="sr-only"
                onChange={handleFiles}
                disabled={extracting}
              />
              <label
                htmlFor="review-file"
                aria-disabled={extracting}
                className={cn(
                  "flex cursor-pointer flex-col items-center gap-1.5 rounded-lg border border-dashed bg-muted/30 px-4 py-6 text-center transition-colors",
                  extracting ? "opacity-70" : "hover:bg-muted/50"
                )}
              >
                {extracting ? (
                  <Loader2 className="w-5 h-5 text-primary animate-spin" />
                ) : (
                  <Upload className="w-5 h-5 text-primary" />
                )}
                <span className="text-sm font-medium">
                  {extracting
                    ? t("ሰነዶችን በማንበብ ላይ…", "Reading documents…")
                    : t("ሰነዶችን ለመምረጥ ይንኩ", "Tap to choose documents")}
                </span>
                <span className="text-xs text-muted-foreground">
                  {t(
                    "PDF · Word · Excel · ምስሎች · CSV · ጽሑፍ — ማንኛውም ዓይነት ፋይል (እስከ 15MB ለእያንዳንዱ)",
                    "PDF · Word · Excel · images · CSV · text — any file type (up to 15MB each)"
                  )}
                </span>
              </label>
              {docs.length > 0 && (
                <div className="space-y-1.5">
                  {docs.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center gap-2 rounded-md border bg-muted/40 px-2.5 py-1.5"
                    >
                      {docIconFor(doc.kind)}
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium truncate">{doc.name}</div>
                        <div className="text-[11px] text-muted-foreground">
                          {docBadgeLabel(doc)} · {doc.wordCount} {t("ቃላት", "words")}
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive"
                        onClick={() => removeDoc(doc.id)}
                        aria-label={t("ሰነድ አስወግድ", "Remove document")}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  <p className="text-[11px] text-muted-foreground">
                    {t(`${docs.length} ሰነዶች`, `${docs.length} document(s)`)} · {totalWords} {t("ቃላት", "words")}
                  </p>
                </div>
              )}
            </div>

            <AiLanguageSelector value={aiLang} onChange={setAiLang} />

            <Button
              className="w-full h-9"
              onClick={analyze}
              disabled={analyzing || extracting || !dirKey || !combinedContent.trim()}
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t("AI በመተንተን ላይ…", "Analyzing with AI…")}
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  {t("AI ተንተን", "Analyze with AI")}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {analyzed && (
          <div ref={resultsRef} className="space-y-4">
            {/* Total score */}
            <Card className="py-4">
              <CardContent className="px-4 flex flex-col items-center gap-2">
                <BigScore score={totalScore} max={100} />
                <PerformanceBadge percent={pct} />
              </CardContent>
            </Card>

            {/* Evaluate the AI evaluator (meta-evaluation audit) */}
            <div ref={auditRef} className="scroll-mt-20">
              <Card className="py-4 border-primary/25 bg-primary/[0.03]">
                <CardContent className="px-4 space-y-3">
                  <div className="flex items-start gap-2.5">
                    <span className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4 text-primary" />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm leading-tight">
                        {t("የAI ግምገማውን ግምገማ", "Evaluate the AI evaluator")}
                      </div>
                      <div className="text-xs text-muted-foreground leading-snug">
                        {t(
                          "ሁለተኛ አስተያየት — AI ሰጠውን ውሳኔ እያንዳንዱን መልስና አስተያየት እንደገና ያረጋግጣል።",
                          "A second-opinion audit re-checks every answer and comment the AI produced against the report."
                        )}
                      </div>
                    </div>
                  </div>

                  {!audit && (
                    <Button className="w-full h-9" onClick={runAudit} disabled={auditing}>
                      {auditing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          {t("የAI ግምገማው በመገምገም ላይ…", "Auditing the AI evaluator…")}
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="w-4 h-4 mr-2" />
                          {t("የAI ግምገማውን አስገምግም", "Evaluate this AI evaluation")}
                        </>
                      )}
                    </Button>
                  )}

                  {audit && (
                    <div className="space-y-3">
                      {/* Reliability grade + verdict */}
                      <div className="flex items-center gap-3 rounded-lg border bg-background px-3 py-2.5">
                        <div className="flex flex-col items-center shrink-0 w-14">
                          <span className={cn("text-2xl font-extrabold leading-none", verdictStyle.text)}>
                            {audit.qualityScore}
                          </span>
                          <span className="text-[10px] text-muted-foreground">/ 100</span>
                        </div>
                        <div className="flex-1 min-w-0 space-y-1.5">
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div
                              className={cn("h-full rounded-full transition-all", verdictStyle.bar)}
                              style={{ width: `${audit.qualityScore}%` }}
                            />
                          </div>
                          <span
                            className={cn(
                              "inline-block text-[11px] font-semibold px-2 py-0.5 rounded-full",
                              verdictStyle.badge
                            )}
                          >
                            {t(verdictStyle.am, verdictStyle.en)}
                          </span>
                        </div>
                      </div>

                      {audit.summary && (
                        <p className="text-xs leading-relaxed bg-muted/50 rounded-md px-2.5 py-2">
                          {audit.summary}
                        </p>
                      )}

                      {/* Flagged answers with one-tap corrections */}
                      {audit.disagreements.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-1.5 text-xs font-semibold">
                            <Flag className="w-3.5 h-3.5 text-red-500 shrink-0" />
                            {t(
                              `የተጠረጠሩ መልሶች (${audit.disagreements.length})`,
                              `Flagged answers (${audit.disagreements.length})`
                            )}
                          </div>
                          {audit.disagreements.map((dg) => {
                            const q = questionIndex[dg.questionId];
                            return (
                              <div key={dg.questionId} className="rounded-lg border bg-background p-2.5 space-y-1.5">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-muted text-foreground">
                                    {dg.questionId}
                                  </span>
                                  <span
                                    className={cn(
                                      "text-[10px] font-semibold px-1.5 py-0.5 rounded-full capitalize",
                                      SEVERITY_STYLES[dg.severity] ?? SEVERITY_STYLES.low
                                    )}
                                  >
                                    {dg.severity}
                                  </span>
                                  {q && (
                                    <span className="text-[11px] text-muted-foreground min-w-0 truncate">
                                      {q.points} pts · {q.labelEn}
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs leading-relaxed">{dg.reason}</p>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-[11px] text-muted-foreground">
                                    {t("የኦዲተሩ ውሳኔ፦", "Auditor suggests:")}{" "}
                                    <b className="text-foreground">
                                      {dg.suggestedAnswer === "yes" ? t("አዎ", "Yes") : t("አዩ", "No")}
                                    </b>
                                  </span>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    className="h-7 px-2.5 text-[11px]"
                                    onClick={() => applySuggestion(dg)}
                                  >
                                    <Check className="w-3 h-3 mr-1" />
                                    {t("አስተካክል", "Apply fix")}
                                  </Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Strengths & suggestions */}
                      {(audit.strengths.length > 0 || audit.improvements.length > 0) && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {audit.strengths.length > 0 && (
                            <div className="rounded-lg border bg-background p-2.5 space-y-1.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                                <ThumbsUp className="w-3.5 h-3.5 shrink-0" />
                                {t("ጥንካሬዎች", "Strengths")}
                              </div>
                              <ul className="space-y-1">
                                {audit.strengths.map((s, i) => (
                                  <li key={i} className="text-xs leading-relaxed flex gap-1.5">
                                    <span className="text-emerald-500 shrink-0">•</span>
                                    <span className="min-w-0">{s}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {audit.improvements.length > 0 && (
                            <div className="rounded-lg border bg-background p-2.5 space-y-1.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700">
                                <Lightbulb className="w-3.5 h-3.5 shrink-0" />
                                {t("ለማሻሻል ምክሮች", "Suggestions")}
                              </div>
                              <ul className="space-y-1">
                                {audit.improvements.map((s, i) => (
                                  <li key={i} className="text-xs leading-relaxed flex gap-1.5">
                                    <span className="text-amber-500 shrink-0">•</span>
                                    <span className="min-w-0">{s}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}

                      {answersEditedSinceAudit && (
                        <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-2.5 py-1.5">
                          {t(
                            "ኦዲቱ ከተካሄደ በኋላ መልሶችን አስተካክለዋል — እንደገና ማካሄድ ይመከራል።",
                            "Answers were edited after this audit — consider re-running it."
                          )}
                        </p>
                      )}

                      <div className="flex items-center justify-between gap-2 pt-0.5">
                        <span className="text-[11px] text-muted-foreground min-w-0">
                          {t("ኦዲቱ በታሪክ ተቀምጧል", "Audit saved to evaluator history")}
                        </span>
                        <Button
                          type="button"
                          variant="outline"
                          className="h-8 shrink-0"
                          onClick={runAudit}
                          disabled={auditing}
                        >
                          {auditing ? (
                            <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
                          )}
                          {t("እንደገና ኦዲት", "Re-audit")}
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Per-criterion results (editable) */}
            {CRITERIA.map((criterion) => {
              const scored = scores[criterion.key] ?? 0;
              const aiComment = aiComments[criterion.key];
              return (
                <Card key={criterion.key} className="py-4">
                  <CardContent className="px-4 space-y-3">
                    <div className="flex items-center gap-2.5">
                      <span className="w-7 h-7 rounded bg-primary/10 text-primary font-bold flex items-center justify-center text-sm shrink-0">
                        {criterion.key}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm leading-tight">{criterion.name}</div>
                        <div className="text-xs text-muted-foreground truncate">
                          {criterion.nameEn}
                        </div>
                      </div>
                      <ScoreBadge score={scored} max={criterion.maxScore} />
                    </div>

                    {aiComment && (
                      <div className="text-xs italic text-muted-foreground bg-muted/50 rounded-md px-2.5 py-2">
                        AI: {aiComment}
                      </div>
                    )}

                    <div className="space-y-2">
                      {criterion.subQuestions.map((q) => {
                        const isYes = answers[q.id] === "yes";
                        return (
                          <div key={q.id} className="rounded-lg border p-2.5 space-y-2">
                            <div className="flex items-start gap-2">
                              {isYes ? (
                                <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                              ) : (
                                <X className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                              )}
                              <div className="min-w-0 flex-1">
                                <div className="text-sm font-medium leading-snug">{q.label}</div>
                                <div className="text-xs text-muted-foreground">
                                  {q.labelEn} • {q.points} pts
                                </div>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                type="button"
                                variant="outline"
                                className={cn(
                                  "h-9 flex-1 text-xs font-medium",
                                  isYes &&
                                    "bg-emerald-500 hover:bg-emerald-600 text-white hover:text-white border-emerald-500"
                                )}
                                onClick={() => setAnswer(q.id, "yes")}
                              >
                                {t("አዎ", "Yes")}
                              </Button>
                              <Button
                                type="button"
                                variant="outline"
                                className={cn(
                                  "h-9 flex-1 text-xs font-medium",
                                  !isYes &&
                                    "bg-red-500 hover:bg-red-600 text-white hover:text-white border-red-500"
                                )}
                                onClick={() => setAnswer(q.id, "no")}
                              >
                                {t("አዩ", "No")}
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">{t("አስተያየት", "Comment")}</Label>
                      <Textarea
                        rows={2}
                        className="text-sm"
                        placeholder={t("አስተያየት ይጻፉ…", "Write a comment…")}
                        value={comments[criterion.key] ?? ""}
                        onChange={(e) =>
                          setComments((prev) => ({ ...prev, [criterion.key]: e.target.value }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {/* Action plan (structured goals & corrective steps) */}
            <ActionPlanEditor items={actionPlan} onChange={setActionPlan} />

            {/* Save */}
            <Button className="w-full h-10" onClick={save} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t("በመቀምጠት ላይ…", "Saving…")}
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  {t("ግምገማ አስቀምጥ", "Save Evaluation")}
                </>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
