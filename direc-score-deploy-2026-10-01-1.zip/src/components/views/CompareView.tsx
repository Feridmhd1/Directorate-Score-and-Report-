"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  FileText,
  GitCompare,
  Layers,
  Lightbulb,
  Loader2,
  RotateCcw,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { aiApi, documentsApi } from "@/lib/client-api";
import type { AICompareResult, DocumentHistoryDTO } from "@/lib/types";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

function LoadingSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-8 w-64 rounded-md" />
      <Skeleton className="h-32 w-full rounded-xl" />
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-40 w-full rounded-xl" />
    </div>
  );
}

function similarityTone(score: number): { text: string; bar: string } {
  if (score >= 75) return { text: "text-emerald-600", bar: "bg-emerald-500" };
  if (score >= 50) return { text: "text-amber-500", bar: "bg-amber-500" };
  return { text: "text-red-500", bar: "bg-red-500" };
}

export function CompareView({ ids, navigate }: { ids: string; navigate: NavigateFn }) {
  const idList = useMemo(
    () => ids.split(",").map((s) => s.trim()).filter(Boolean),
    [ids]
  );
  const [docs, setDocs] = useState<DocumentHistoryDTO[] | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [comparing, setComparing] = useState(false);
  const [result, setResult] = useState<AICompareResult | null>(null);

  /* Load the selected documents (order preserved) */
  useEffect(() => {
    if (idList.length < 2) return;
    let cancelled = false;
    setDocs(null);
    setLoadError(false);
    setResult(null);
    Promise.all(
      idList.map(async (id) => {
        const data = await documentsApi.getById(id); // works in server AND local mode
        return data.document;
      })
    )
      .then((loaded) => {
        if (!cancelled) setDocs(loaded);
      })
      .catch((err) => {
        if (cancelled) return;
        setLoadError(true);
        toast({
          title: "Failed to load documents",
          description: err instanceof Error ? err.message : undefined,
          variant: "destructive",
        });
      });
    return () => {
      cancelled = true;
    };
  }, [idList]);

  const runCompare = async () => {
    if (!docs || docs.length < 2) return;
    setComparing(true);
    try {
      const res = await aiApi.compareDocuments({
        documents: docs.map((d) => ({ fileName: d.fileName, content: d.content })),
      });
      setResult(res);
    } catch (err) {
      toast({
        title: "Comparison failed",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setComparing(false);
    }
  };

  /* Fewer than two documents selected */
  if (idList.length < 2) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="py-12 text-center">
            <GitCompare className="mx-auto h-12 w-12 text-slate-400" />
            <p className="mt-4 font-medium">Select at least two documents to compare</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Pick documents from your history to run an AI comparison.
            </p>
            <Button className="mt-6" onClick={() => navigate("document-history")}>
              <ArrowLeft className="h-4 w-4" />
              Back to History
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const sim = result ? Math.max(0, Math.min(100, Math.round(result.similarity_score || 0))) : 0;
  const tone = similarityTone(sim);
  const themes = result && Array.isArray(result.common_themes) ? result.common_themes : [];
  const conflicts = result && Array.isArray(result.conflicts) ? result.conflicts : [];
  const uniqueInsights =
    result && Array.isArray(result.unique_insights) ? result.unique_insights : [];

  return (
    <div className="flex-1">
      <div className="mx-auto max-w-4xl space-y-6 p-4 sm:p-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate("document-history")}
            aria-label="Back"
          >
            <ArrowLeft />
          </Button>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 shadow-md">
            <GitCompare className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-xl font-bold">Compare Documents</h1>
            <p className="truncate text-sm text-muted-foreground">
              AI-powered comparative analysis
            </p>
          </div>
        </div>

        {loadError ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="font-medium">Documents could not be loaded</p>
              <p className="mt-1 text-sm text-muted-foreground">
                One or more selected documents are no longer available.
              </p>
              <Button className="mt-6" variant="outline" onClick={() => navigate("document-history")}>
                <ArrowLeft className="h-4 w-4" />
                Back to History
              </Button>
            </CardContent>
          </Card>
        ) : !docs ? (
          <LoadingSkeleton />
        ) : (
          <>
            {/* Selected document chips */}
            <div className="flex flex-wrap gap-2">
              {docs.map((d) => (
                <span
                  key={d.id}
                  className="inline-flex max-w-full items-center gap-1.5 rounded-full border bg-white/70 px-3 py-1 text-xs font-medium"
                >
                  <FileText className="h-3.5 w-3.5 shrink-0 text-primary" />
                  <span className="max-w-[16rem] truncate">{d.fileName}</span>
                </span>
              ))}
            </div>

            {!result ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <GitCompare className="mx-auto h-10 w-10 text-slate-400" />
                  <p className="mt-4 font-medium">Compare {docs.length} documents</p>
                  <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
                    AI will identify shared themes, conflicts and unique insights, then produce a
                    consolidated summary.
                  </p>
                  <Button className="mt-6" size="lg" onClick={runCompare} disabled={comparing}>
                    {comparing ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <GitCompare className="h-4 w-4" />
                    )}
                    {comparing ? "AI is comparing documents…" : "Run AI Comparison"}
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="mx-auto max-w-4xl space-y-4">
                {/* 1. Overview + similarity gauge */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Comparison Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-6 sm:flex-row sm:items-center">
                    <p className="flex-1 text-sm leading-relaxed">{result.overview}</p>
                    <div className="w-full shrink-0 text-center sm:w-48 sm:text-left">
                      <p className={cn("text-4xl font-extrabold", tone.text)}>{sim}%</p>
                      <p className="mb-2 text-xs text-muted-foreground">Similarity score</p>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className={cn("h-full rounded-full transition-all", tone.bar)}
                          style={{ width: `${sim}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 2. Common Themes */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Common Themes</CardTitle>
                    <CardDescription>Themes shared across the documents</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {themes.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No common themes identified.</p>
                    ) : (
                      <ul className="space-y-2.5">
                        {themes.map((theme, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            <Layers className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            <span className="text-sm leading-relaxed">{theme}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </CardContent>
                </Card>

                {/* 3. Conflicts */}
                {conflicts.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Conflicts</CardTitle>
                      <CardDescription>Points where the documents disagree</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {conflicts.map((conflict, i) => (
                        <div key={i} className="space-y-3 rounded-lg border p-4">
                          <p className="text-sm font-semibold">{conflict.topic}</p>
                          <div className="grid gap-3 sm:grid-cols-2">
                            <div className="rounded-md bg-slate-50 p-3">
                              <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Document view
                              </p>
                              <p className="text-sm leading-relaxed">{conflict.doc1_view}</p>
                            </div>
                            <div className="rounded-md bg-slate-50 p-3">
                              <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Document view
                              </p>
                              <p className="text-sm leading-relaxed">{conflict.doc2_view}</p>
                            </div>
                          </div>
                          <p className="text-sm leading-relaxed text-muted-foreground">
                            {conflict.explanation}
                          </p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                {/* 4. Unique Insights */}
                {uniqueInsights.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Unique Insights</CardTitle>
                      <CardDescription>Notable points found in individual documents</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2.5">
                      {uniqueInsights.map((item, i) => (
                        <div key={i} className="flex items-start gap-2.5">
                          <Badge variant="secondary" className="mt-0.5 max-w-[12rem] shrink-0 truncate">
                            {item.document_name}
                          </Badge>
                          <span className="text-sm leading-relaxed">{item.insight}</span>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                {/* 5. Consolidated Summary */}
                <Card className="border-primary/20 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="text-base">Consolidated Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed">{result.consolidated_summary}</p>
                  </CardContent>
                </Card>

                {/* 6. Recommendation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Lightbulb className="h-4 w-4 text-amber-500" />
                      Recommendation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed">{result.recommendation}</p>
                  </CardContent>
                </Card>

                <div className="flex justify-center pb-4">
                  <Button variant="outline" onClick={runCompare} disabled={comparing}>
                    {comparing ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <RotateCcw className="h-4 w-4" />
                    )}
                    Run Comparison Again
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
