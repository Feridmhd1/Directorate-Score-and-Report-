"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";
import {
  BarChart3,
  BellOff,
  Bot,
  Brain,
  Building2,
  CalendarClock,
  Check,
  CheckCircle2,
  CheckSquare,
  ClipboardCheck,
  Copy,
  Download,
  ExternalLink,
  FileText,
  FileUp,
  FolderLock,
  Info,
  Layers,
  LayoutGrid,
  Lightbulb,
  Link2,
  Loader2,
  Mail,
  MessageCircle,
  MessageSquare,
  MessagesSquare,
  Pencil,
  Phone,
  QrCode,
  RefreshCw,
  Send,
  Settings2,
  Sparkles,
  Table as TableIcon,
  Trash2,
  Users,
  X,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LoadingSpinner, ScoreBadge, ScoreBar } from "@/components/shared";
import { NotificationsBell } from "@/components/NotificationsBell";
import { buildAbsoluteUrl, type NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import {
  automationApi,
  contactsApi,
  deadlineApi,
  evaluationsApi,
  feedbackApi,
  notificationsApi,
  qualityApi,
  reportShareUrl,
} from "@/lib/client-api";
import { getLogoDataUrl } from "@/lib/branding";
import { useLang } from "@/lib/i18n";
import type { DocumentUploadedEvent } from "@/lib/events";
import { formatDistanceToNowStrict } from "date-fns";
import {
  CRITERIA,
  DEFAULT_QUARTER,
  DIRECTORATES,
  TOTAL_MAX_SCORE,
  performanceLabel,
  scorePercent,
  type Directorate,
} from "@/lib/rubric";
import type { DeadlineStateDTO, EvaluationDTO, FeedbackDTO, QualityReportDTO, UserDTO } from "@/lib/types";
import {
  downloadCombinedPdf,
  downloadEvaluationPdf,
  downloadSummaryCsv,
  downloadSummaryPdf,
} from "@/lib/export-utils";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Result text helpers                                                 */
/* ------------------------------------------------------------------ */

/** One result line: "HPDP: 82/100 (A: 10 | B: 6 | ...)" */
function resultLine(e: EvaluationDTO): string {
  const parts = CRITERIA.map((c) => `${c.key}: ${e.scores?.[c.key] ?? 0}`).join(" | ");
  return `${e.directorateShort}: ${e.totalScore}/100 (${parts})`;
}

/** Individual result text (quarter-prefixed) */
function fullResultText(e: EvaluationDTO, quarter: string): string {
  return `${quarter} ${resultLine(e)}`;
}

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function scoreColorClass(pct: number): string {
  return pct >= 75 ? "text-emerald-600" : pct >= 50 ? "text-amber-500" : "text-red-500";
}

/** Tiny relative-time label, e.g. "5 minutes ago" */
function timeAgoLabel(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  try {
    return formatDistanceToNowStrict(new Date(iso), { addSuffix: true });
  } catch {
    return "";
  }
}

/** "HPDP — Health Promotion..." for a feedback row (falls back to stored name/key) */
function feedbackDirectorateLabel(f: FeedbackDTO): string {
  const short = DIRECTORATES.find((d) => d.key === f.directorateKey)?.short;
  const name = f.directorateName || f.directorateKey;
  return short ? `${short} — ${name}` : name;
}

/** Human-readable file size for the live uploads list */
function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

/* ------------------------------------------------------------------ */
/* SendResultsDialog (local component)                                 */
/* ------------------------------------------------------------------ */

interface SendResultsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  evaluations: EvaluationDTO[];
  quarter: string;
  onSent: () => void;
}

function SendResultsDialog({ open, onOpenChange, evaluations, quarter, onSent }: SendResultsDialogProps) {
  const { t } = useLang();
  const [emails, setEmails] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (open) {
      const initial: Record<string, string> = {};
      evaluations.forEach((ev) => {
        initial[ev.id] = ev.email ?? "";
      });
      setEmails(initial);
    }
  }, [open, evaluations]);

  const handleSend = async () => {
    if (evaluations.length === 0) return;
    setSending(true);
    try {
      for (const ev of evaluations) {
        const email = (emails[ev.id] ?? ev.email ?? "").trim();
        // Sending is a mailto-style alternative: the formatted result text goes to the clipboard.
        await copyText(fullResultText(ev, quarter));
        await notificationsApi.create({
          type: "results_sent",
          title: `${t("ውጤት ተልኩ", "Score sent")} — ${ev.directorateShort}`,
          message: t(
            `${ev.directorateName} የ${quarter} ውጤት: ${ev.totalScore}/100`,
            `${ev.directorateName} ${quarter} score: ${ev.totalScore}/100`
          ),
          directorateKey: ev.directorateKey,
          directorateName: ev.directorateName,
          quarter,
          totalScore: ev.totalScore,
          directorEmail: email,
        });
        await evaluationsApi.update(ev.id, { status: "sent" });
      }
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));
      toast({ title: t("ውጤቶች ተልከዋል", "Results sent"), description: "Results sent and copied to clipboard!" });
      onOpenChange(false);
      onSent();
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("ውጤቱን መላክ አልተቻለም", "Could not send the results"),
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{t("ውጤት ላክ", "Send Results")}</DialogTitle>
          <DialogDescription>
            {t(
              "የተመረጡ ዳይሬክቶሬቶች ውጤቶች ወደ ዳይሬክተሩ ኢሜይል ይላካሉ።",
              "Selected directorate scores will be sent to each director's email."
            )}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          {evaluations.length === 0 ? (
            <p className="py-2 text-sm text-muted-foreground">{t("ምንም ዳይሬክቶሬት አልተመረጠም።", "No directorates selected.")}</p>
          ) : (
            evaluations.map((ev) => {
              const pct = scorePercent(ev.totalScore);
              return (
                <div key={ev.id} className="space-y-1.5 rounded-md border p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold">
                      {ev.directorateShort} — {ev.directorateName}
                    </span>
                    <span className={cn("text-sm font-extrabold", scoreColorClass(pct))}>
                      {ev.totalScore}/{TOTAL_MAX_SCORE}
                    </span>
                  </div>
                  <Input
                    type="email"
                    value={emails[ev.id] ?? ""}
                    onChange={(e) => setEmails((prev) => ({ ...prev, [ev.id]: e.target.value }))}
                    placeholder="director@hararihealth.gov.et"
                  />
                </div>
              );
            })
          )}
          <p className="text-xs text-muted-foreground">
            {t(
              "ማስታወሻ፦ መላክ የውጤት ጽሑፉን ወደ ክሊፕቦርድ ይቀዳል — ከዚያ በኢሜይል መተግበሪያዎ (mailto አማራጭ) መላክ ይችላሉ።",
              "Note: sending copies the result text to your clipboard (email/mailto alternative)."
            )}
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sending}>
            {t("ሰርዝ", "Cancel")}
          </Button>
          <Button onClick={handleSend} disabled={sending || evaluations.length === 0}>
            <Send /> {sending ? t("በመላክ ላይ…", "Sending…") : t("ላክ", "Send")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* Directorate card (grid tab)                                         */
/* ------------------------------------------------------------------ */

/**
 * Stray-click guard: after a Radix dropdown menu item is selected the menu
 * unmounts and the browser may dispatch a stray click on the element now
 * under the pointer (the score card) — which would navigate to the evaluate
 * view. Menu selections set this timestamp; the card ignores navigation for
 * a short window afterwards.
 */
let suppressCardNavUntil = 0;
function markMenuSelection(): void {
  suppressCardNavUntil = Date.now() + 700;
}

interface DirectorateCardProps {
  directorate: Directorate;
  evaluation: EvaluationDTO | undefined;
  quarter: string;
  selectMode: boolean;
  selected: boolean;
  qualityCount: number;
  onToggleSelect: (key: string) => void;
  onDownload: (ev: EvaluationDTO) => void;
  onDelete: (ev: EvaluationDTO) => void;
  onOpen: (key: string) => void;
}

/* ------------------------------------------------------------------ */
/* Score send menu — per-directorate score sharing (Send, not Copy)    */
/* ------------------------------------------------------------------ */

/**
 * "Send" menu for one directorate score: deliver it through the enabled
 * automation channels (WhatsApp / Telegram / Email) or open a share compose
 * window. Replaces the old copy-to-clipboard action on the score card.
 */
function ScoreSendMenu({
  ev,
  quarter,
  variant = "ghost",
  size = "icon",
  label,
}: {
  ev: EvaluationDTO;
  quarter: string;
  variant?: "ghost" | "outline" | "secondary";
  size?: "icon" | "sm";
  label?: string;
}) {
  const { t } = useLang();
  const [sending, setSending] = useState(false);

  const text = fullResultText(ev, quarter);
  const portalUrl = buildAbsoluteUrl("portal", { dir: ev.directorateKey, quarter });
  const message = `${text}\n🔗 ${portalUrl}`;
  const compose = {
    whatsapp: `https://wa.me/?text=${encodeURIComponent(message)}`,
    telegram: `https://t.me/share/url?url=${encodeURIComponent(portalUrl)}&text=${encodeURIComponent(text)}`,
    email: `mailto:?subject=${encodeURIComponent(
      `${t("ውጤት", "Score")} — ${ev.directorateShort} ${quarter}`
    )}&body=${encodeURIComponent(message)}`,
  };

  const openCompose = (url: string) => {
    markMenuSelection();
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const sendViaChannels = async () => {
    if (sending) return;
    markMenuSelection();
    setSending(true);
    try {
      const { results } = await automationApi.sendScores({ evaluationIds: [ev.id] });
      if (results.length === 0) {
        toast({
          title: t("ንቁ መስመር የለም", "No enabled channels"),
          description: t(
            "አውቶሜሽን ገጽ ላይ WhatsApp / Telegram / ኢሜይል ያንቁቱ",
            "Enable WhatsApp / Telegram / Email channels in the Automation page."
          ),
        });
      } else {
        const sent = results.filter((r) => r.status === "sent").length;
        const queued = results.filter((r) => r.status === "queued").length;
        const failed = results.filter((r) => r.status === "failed").length;
        toast({
          title: t("ውጤቱ ተልኳል", "Score sent"),
          description: `${sent} sent · ${queued} queued · ${failed} failed — ${t(
            "ዝርዝር በአውቶሜሽን መለያ",
            "details in the Automation page"
          )}`,
        });
        window.dispatchEvent(new Event("direcscore:refresh-notifications"));
      }
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መላክ አልተቻለም", "Could not send"),
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  const iconClass = size === "icon" ? "size-3.5" : "size-4";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant={variant}
          size={size}
          className={size === "icon" ? "h-7 w-7" : undefined}
          disabled={sending}
          aria-label={t("ውጤት ላክ", "Send result")}
          title={t("ውጤት ላክ", "Send result")}
          onClick={(e) => e.stopPropagation()}
        >
          {sending ? (
            <Loader2 className={cn(iconClass, "animate-spin")} />
          ) : (
            <Send className={iconClass} />
          )}
          {label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuItem
          onClick={() => {
            markMenuSelection();
            void sendViaChannels();
          }}
        >
          <Bot className="size-4" />
          {t("በአውቶማቲክ ላክ", "Send via channels")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => openCompose(compose.whatsapp)}>
          <MessageCircle className="size-4 text-emerald-600" />
          {t("በWhatsApp ላክ", "Share to WhatsApp")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => openCompose(compose.telegram)}>
          <Send className="size-4 text-sky-600" />
          {t("በTelegram ላክ", "Share to Telegram")}
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href={compose.email} onClick={() => markMenuSelection()}>
            <Mail className="size-4 text-amber-600" />
            {t("በኢሜይል ላክ", "Share via Email")}
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function DirectorateCard({
  directorate: d,
  evaluation: ev,
  quarter,
  selectMode,
  selected,
  qualityCount,
  onToggleSelect,
  onDownload,
  onDelete,
  onOpen,
}: DirectorateCardProps) {
  const { t } = useLang();
  const pct = ev ? scorePercent(ev.totalScore) : 0;
  const planCount = ev?.actionPlan?.length ?? 0;

  return (
    <Card
      className={cn(
        "glass-card relative cursor-pointer gap-2 p-4 transition-shadow hover:shadow-md",
        !ev && "border-dashed",
        selected && "border-primary ring-1 ring-primary"
      )}
      onClick={() => {
        if (Date.now() < suppressCardNavUntil) return;
        if (selectMode) {
          if (ev) onToggleSelect(d.key);
          return;
        }
        onOpen(d.key);
      }}
    >
      {selectMode && (
        <div
          className={cn(
            "absolute top-2 right-2 flex h-5 w-5 items-center justify-center rounded-full border",
            selected ? "border-primary bg-primary text-primary-foreground" : "bg-background"
          )}
        >
          {selected && <Check className="size-3" />}
        </div>
      )}

      <div className={cn("space-y-0.5", selectMode && "pr-14")}>
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-bold">{d.short}</span>
          {qualityCount > 0 && (
            <Badge
              variant="outline"
              className="gap-1 px-1.5 py-0 text-[10px] font-medium text-muted-foreground"
              title={t("የጥራት ሪፖርት ሰነዶች", "Quality report documents")}
            >
              <FileText className="h-3 w-3" />
              {qualityCount}
            </Badge>
          )}
          {ev?.status === "sent" && <ClipboardCheck className="size-3.5 text-primary" />}
        </div>
        <div className="truncate text-xs text-muted-foreground">{d.nameEn}</div>
        <div className="text-[10px] text-muted-foreground">{quarter}</div>
      </div>

      {ev ? (
        <>
          <div className="flex items-end justify-between">
            <div className={cn("text-2xl leading-none font-extrabold", scoreColorClass(pct))}>
              {ev.totalScore}
              <span className="text-xs font-medium text-muted-foreground">/{TOTAL_MAX_SCORE}</span>
            </div>
            <div className="flex items-center gap-1">
              {planCount > 0 && (
                <Badge
                  variant="outline"
                  className="border-primary/30 bg-primary/5 px-1.5 py-0 text-[10px] text-primary"
                  title={t("የተግባር እቅድ", "Action plan items")}
                >
                  {t("እቅድ", "Plan")}: {planCount}
                </Badge>
              )}
              {ev.status === "sent" ? (
                <Badge variant="secondary">sent</Badge>
              ) : (
                <Badge variant="outline">{ev.status}</Badge>
              )}
            </div>
          </div>
          <div className="max-h-40 space-y-1.5 overflow-y-auto pr-1">
            {CRITERIA.map((c) => (
              <div key={c.key} className="flex items-center gap-2">
                <span className="w-3 shrink-0 text-[10px] font-semibold text-muted-foreground">{c.key}</span>
                <ScoreBar score={ev.scores?.[c.key] ?? 0} max={c.maxScore} className="flex-1" />
                <ScoreBadge score={ev.scores?.[c.key] ?? 0} max={c.maxScore} />
              </div>
            ))}
          </div>
          {!selectMode && (
            <div className="flex items-center justify-end gap-1 border-t pt-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                aria-label={t("አርትዕ", "Edit evaluation")}
                onClick={(e) => {
                  e.stopPropagation();
                  onOpen(d.key);
                }}
              >
                <Pencil className="size-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                aria-label={t("PDF አውርድ", "Download PDF")}
                onClick={(e) => {
                  e.stopPropagation();
                  onDownload(ev);
                }}
              >
                <Download className="size-3.5" />
              </Button>
              <ScoreSendMenu ev={ev} quarter={quarter} />
              {(ev.status === "completed" || ev.status === "sent") && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  aria-label="Portal"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(buildAbsoluteUrl("portal", { dir: d.key, quarter }), "_blank", "noopener,noreferrer");
                  }}
                >
                  <ExternalLink className="size-3.5" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                aria-label={t("ሰርዝ", "Delete evaluation")}
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(ev);
                }}
              >
                <Trash2 className="size-3.5" />
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="flex h-24 items-center justify-center rounded-md border border-dashed bg-muted/30 px-2 text-center text-xs text-muted-foreground">
          {t("ግምገማ አልተደረገም", "Not evaluated")}
        </div>
      )}
    </Card>
  );
}

/* ------------------------------------------------------------------ */
/* DashboardView                                                       */
/* ------------------------------------------------------------------ */

export function DashboardView({ user, navigate }: { user: UserDTO; navigate: NavigateFn }) {
  void user; // reserved for future personalization; auth is handled by AppShell

  const { lang, setLang, t } = useLang();

  const [quarter, setQuarter] = useState(DEFAULT_QUARTER);
  const [reportDate, setReportDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [evaluations, setEvaluations] = useState<EvaluationDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [combinedProgress, setCombinedProgress] = useState<string | null>(null);
  const [downloadAllProgress, setDownloadAllProgress] = useState<string | null>(null);
  const [sendOpen, setSendOpen] = useState(false);
  const [sendAllBusy, setSendAllBusy] = useState(false);
  const [deleteTargets, setDeleteTargets] = useState<EvaluationDTO[] | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [logo, setLogo] = useState("");
  const [qualityCounts, setQualityCounts] = useState<Record<string, number>>({});
  const [recentUploads, setRecentUploads] = useState<QualityReportDTO[]>([]);
  const [liveConnected, setLiveConnected] = useState(false);
  const [feedback, setFeedback] = useState<FeedbackDTO[]>([]);
  const [feedbackUnread, setFeedbackUnread] = useState(0);
  /* Quarterly report submission deadline — public read only (sending lives in Settings) */
  const [deadline, setDeadline] = useState<DeadlineStateDTO | null>(null);
  const knownUploadIds = useRef<Set<string>>(new Set());
  const knownFeedbackIds = useRef<Set<string>>(new Set());
  /** Late-bound fetchFeedback ref — the socket effect runs before it is defined */
  const feedbackRefreshRef = useRef<() => void>(() => {});

  const fetchEvaluations = useCallback(async (q: string) => {
    setLoading(true);
    try {
      const res = await evaluationsApi.list({ quarter: q });
      setEvaluations(res.evaluations);
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("ግምገማዎችን መጫን አልተቻለም", "Could not load evaluations"),
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEvaluations(quarter);
  }, [quarter, fetchEvaluations]);

  /* Bureau logo (cached branding helper) — hidden gracefully when empty */
  useEffect(() => {
    let cancelled = false;
    getLogoDataUrl()
      .then((url) => {
        if (!cancelled) setLogo(url);
      })
      .catch(() => {
        /* keep placeholder icon */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /* Report deadline banner state — best-effort public read, silent on failure */
  useEffect(() => {
    let cancelled = false;
    deadlineApi
      .get()
      .then((res) => {
        if (!cancelled) setDeadline(res);
      })
      .catch(() => {
        /* banner simply stays hidden */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /* Directorate uploads: counts per directorate + newest list for the live feed.
     Refreshed on mount, every 30s (fallback) and on real-time events. */
  const loadUploads = useCallback(async () => {
    try {
      const res = await qualityApi.list();
      const counts: Record<string, number> = {};
      res.reports.forEach((r) => {
        counts[r.directorateKey] = (counts[r.directorateKey] ?? 0) + 1;
      });
      setQualityCounts(counts);
      setRecentUploads(res.reports.slice(0, 15));
      res.reports.slice(0, 15).forEach((r) => knownUploadIds.current.add(r.id));
    } catch {
      /* informational only — silently ignore */
    }
  }, []);

  useEffect(() => {
    void loadUploads();
    const interval = setInterval(() => void loadUploads(), 30_000);
    return () => clearInterval(interval);
  }, [loadUploads]);

  /* Real-time: instantly show uploads made from a directorate's shareable link
     (or the admin Evaluate page) through the events service. */
  useEffect(() => {
    const socket = io("/?XTransformPort=3010", {
      path: "/",
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
      timeout: 10000,
    });

    const onDocumentUploaded = (payload: DocumentUploadedEvent) => {
      if (!payload?.id) return;
      setRecentUploads((prev) => {
        if (prev.some((r) => r.id === payload.id)) return prev;
        const row: QualityReportDTO = {
          id: payload.id,
          directorateKey: payload.directorateKey,
          quarter: payload.quarter ?? "",
          title: payload.title ?? payload.fileName,
          fileName: payload.fileName,
          mimeType: payload.mimeType ?? "application/octet-stream",
          size: payload.size ?? 0,
          note: payload.note ?? "",
          shareToken: payload.shareToken ?? "",
          createdAt: payload.createdAt ?? new Date().toISOString(),
        };
        return [row, ...prev].slice(0, 15);
      });
      if (!knownUploadIds.current.has(payload.id)) {
        knownUploadIds.current.add(payload.id);
        toast({
          title:
            lang === "en"
              ? `New report from ${payload.directorateShort || payload.directorateKey}`
              : `አዲስ ሪፖርት ከ${payload.directorateShort || payload.directorateKey}`,
          description:
            lang === "en"
              ? `"${payload.title || payload.fileName}" (${payload.quarter || "—"}) — visible below now.`
              : `"${payload.title || payload.fileName}" (${payload.quarter || "—"}) — ከታች በቅጽበት ተቀምጧል።`,
        });
        window.dispatchEvent(new Event("direcscore:refresh-notifications"));
        void loadUploads();
      }
    };

    const onFeedbackShared = (
      payload: {
        id?: string;
        directorateKey?: string;
        directorateName?: string;
        kind?: string;
        message?: string;
      } | null
    ) => {
      if (!payload?.id || knownFeedbackIds.current.has(payload.id)) return;
      knownFeedbackIds.current.add(payload.id);
      const who = payload.directorateName || payload.directorateKey || "—";
      toast({
        title:
          lang === "en"
            ? `New ${payload.kind === "suggestion" ? "suggestion" : "comment"} from ${who}`
            : `አዲስ ${payload.kind === "suggestion" ? "ጥቆማ" : "አስተያየት"} ከ${who}`,
        description: (payload.message ?? "").slice(0, 140),
      });
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));
      feedbackRefreshRef.current?.();
    };

    socket.on("connect", () => setLiveConnected(true));
    socket.on("disconnect", () => setLiveConnected(false));
    socket.on("connect_error", () => setLiveConnected(false));
    socket.on("document_uploaded", onDocumentUploaded);
    socket.on("feedback_shared", onFeedbackShared);

    return () => {
      socket.off("connect");
      socket.off("disconnect");
      socket.off("connect_error");
      socket.off("document_uploaded", onDocumentUploaded);
      socket.off("feedback_shared", onFeedbackShared);
      socket.disconnect();
    };
  }, [lang, loadUploads]);

  const fetchFeedback = useCallback(async () => {
    try {
      const res = await feedbackApi.list();
      setFeedback(res.feedback);
      setFeedbackUnread(res.unreadCount);
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("አስተያየቶችን መጫን አልተቻለም", "Could not load feedback"),
        variant: "destructive",
      });
    }
  }, []);

  useEffect(() => {
    void fetchFeedback();
  }, [fetchFeedback]);

  /* Late-bind the realtime handler to the latest fetchFeedback */
  useEffect(() => {
    feedbackRefreshRef.current = () => void fetchFeedback();
  }, [fetchFeedback]);

  const markFeedbackRead = async (id: string) => {
    try {
      await feedbackApi.markRead(id);
      setFeedback((prev) => prev.map((f) => (f.id === id ? { ...f, isRead: true } : f)));
      setFeedbackUnread((prev) => Math.max(0, prev - 1));
      toast({ title: t("እንደተነበበ ተለይቷል", "Marked as read"), description: "Marked as read" });
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("ማስለያ አልተቻለም", "Could not mark read"),
        variant: "destructive",
      });
    }
  };

  const byDir = useMemo(() => {
    const map: Record<string, EvaluationDTO> = {};
    evaluations.forEach((e) => {
      map[e.directorateKey] = e;
    });
    return map;
  }, [evaluations]);

  const orderedEvaluations = useMemo(
    () => DIRECTORATES.map((d) => byDir[d.key]).filter((e): e is EvaluationDTO => Boolean(e)),
    [byDir]
  );

  const completed = useMemo(
    () =>
      DIRECTORATES.map((d) => byDir[d.key]).filter(
        (e): e is EvaluationDTO =>
          Boolean(e) && (e!.status === "completed" || e!.status === "sent")
      ),
    [byDir]
  );

  const evaluatedKeys = useMemo(() => orderedEvaluations.map((e) => e.directorateKey), [orderedEvaluations]);

  const selectedEvaluations = useMemo(
    () => orderedEvaluations.filter((e) => selectedKeys.includes(e.directorateKey)),
    [orderedEvaluations, selectedKeys]
  );

  const allSelected = evaluatedKeys.length > 0 && selectedKeys.length === evaluatedKeys.length;

  const toggleSelect = useCallback((key: string) => {
    setSelectedKeys((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }, []);

  const exitSelectMode = () => {
    setSelectMode(false);
    setSelectedKeys([]);
  };

  const toggleSelectAll = () => {
    setSelectedKeys(allSelected ? [] : evaluatedKeys);
  };

  /* ---------------- actions ---------------- */

  /**
   * "Send it all" — every evaluated directorate of the quarter receives its
   * own score summary through its saved WhatsApp / Telegram / Email contacts
   * (directorates without saved contacts fall back to the admin channels).
   */
  const sendAllResults = async () => {
    if (orderedEvaluations.length === 0 || sendAllBusy) return;
    setSendAllBusy(true);
    try {
      const res = await contactsApi.sendAll({
        mode: "scores",
        quarter,
        directorateKeys: orderedEvaluations.map((e) => e.directorateKey),
      });
      const logs = res.results.flatMap((r) => r.logs);
      const sent = logs.filter((l) => l.status === "sent").length;
      const queued = logs.filter((l) => l.status === "queued").length;
      const failed = logs.filter((l) => l.status === "failed").length;
      toast({
        title: t("ሁሉም ውጤቶች ተልከዋል", "All results sent"),
        description: `${res.results.length} ${t("ዳይሬክቶሬቶች", "directorates")} · ${sent} sent · ${queued} queued · ${failed} failed — ${t(
          "ዝርዝር በአውቶሜሽን መለያ",
          "details in the Automation page"
        )}`,
      });
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));
      await fetchEvaluations(quarter);
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መላክ አልተቻለም", "Could not send"),
        variant: "destructive",
      });
    } finally {
      setSendAllBusy(false);
    }
  };

  const handleExportCsv = () => {
    downloadSummaryCsv(evaluations, quarter, reportDate || undefined);
  };

  const handleExportPdf = () => {
    downloadSummaryPdf(evaluations, quarter, reportDate || undefined);
  };

  const handleCombinedPdf = async () => {
    if (selectedEvaluations.length === 0) return;
    setCombinedProgress(`0/${selectedEvaluations.length}`);
    try {
      await downloadCombinedPdf(selectedEvaluations, quarter, (current, total) =>
        setCombinedProgress(`${current}/${total}`)
      );
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : "PDF generation failed",
      });
    } finally {
      setCombinedProgress(null);
    }
  };

  const downloadSingle = (ev: EvaluationDTO) => {
    const d = DIRECTORATES.find((x) => x.key === ev.directorateKey);
    const short = d?.short ?? ev.directorateShort;
    try {
      downloadEvaluationPdf(
        {
          directorate: {
            short,
            name: d?.name ?? ev.directorateName,
            nameEn: d?.nameEn ?? ev.directorateShort,
          },
          quarter: ev.quarter,
          totalScore: ev.totalScore,
          scores: ev.scores,
          comments: ev.comments,
          actionPlan: ev.actionPlan,
        },
        `Evaluation_${short}_${ev.quarter}.pdf`
      );
      toast({ title: t("PDF ተወርዷል", "PDF downloaded"), description: `${short} — ${ev.quarter}` });
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : "PDF generation failed",
      });
    }
  };

  const handleDownloadAll = async () => {
    const list = selectedEvaluations;
    if (list.length === 0) return;
    setDownloadAllProgress(`0/${list.length}`);
    try {
      for (let i = 0; i < list.length; i++) {
        downloadSingle(list[i]);
        setDownloadAllProgress(`${i + 1}/${list.length}`);
        if (i < list.length - 1) await new Promise((resolve) => setTimeout(resolve, 150));
      }
      toast({ title: t("ውጤቶች ተወርደዋል", "Results downloaded"), description: `${list.length} evaluation PDFs downloaded.` });
    } finally {
      setDownloadAllProgress(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTargets || deleteTargets.length === 0) return;
    const targets = deleteTargets;
    setDeleting(true);
    try {
      for (const ev of targets) {
        await evaluationsApi.remove(ev.id);
      }
      toast({
        title:
          targets.length === 1
            ? t("ግምገማው ተሰርዟል", "Evaluation deleted")
            : t(`${targets.length} ግምገማዎች ተሰረዙ`, `${targets.length} evaluations deleted`),
        description: targets.length === 1 ? "Evaluation deleted!" : `${targets.length} evaluations deleted!`,
      });
      setDeleteTargets(null);
      setSelectedKeys([]);
      await fetchEvaluations(quarter);
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መሰረዝ አልተቻለም", "Could not delete"),
      });
    } finally {
      setDeleting(false);
    }
  };

  const handleSent = useCallback(() => {
    setSendOpen(false);
    setSelectMode(false);
    setSelectedKeys([]);
    fetchEvaluations(quarter);
  }, [fetchEvaluations, quarter]);

  /* ---------------- render ---------------- */

  /* Deadline banner derived state (deadline exists + days left + missing list) */
  const deadlineInfo = deadline?.deadline ?? null;
  const deadlineDaysLeft = deadline?.daysLeft ?? null;
  const deadlineMissing = deadline?.missing ?? [];
  const deadlinePending =
    Boolean(deadlineInfo) && deadlineDaysLeft !== null && deadlineDaysLeft >= 0 && deadlineMissing.length > 0;
  const deadlineAllDone = Boolean(deadlineInfo) && deadlineMissing.length === 0;

  return (
    <div className="flex-1">
      {/* Header */}
      <div className="glass-card border-b shadow-sm">
        <div className="mx-auto max-w-7xl space-y-3 px-4 py-4">
          <div className="flex items-center gap-3">
            {/* Bureau logo (left of the title) with a graceful icon fallback */}
            <div className="flex min-w-0 flex-1 items-center gap-3">
              {logo ? (
                <img
                  src={logo}
                  alt="Harari Regional Health Bureau logo"
                  className="h-11 w-11 shrink-0 rounded-lg border bg-white object-contain p-0.5 shadow-sm"
                />
              ) : (
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary">
                  <Building2 className="size-5 text-primary-foreground" />
                </div>
              )}
              <div className="min-w-0">
                <h1 className="text-lg leading-tight font-bold">{t("የሀረሪ ክልል ጤና ቢሮ", "Harari Region Health Bureau")}</h1>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {t("የዳይሬክቶሬት ዳይሬክተሮች ሪፖርት ግምገማ", "Directorate Directors' Report Evaluation")}
                </p>
              </div>
            </div>
            <div className="group ml-auto flex items-center gap-2">
              {/* App language — አማርኛ / English (instant, persisted) */}
              <div
                className="flex overflow-hidden rounded-lg border bg-background/60"
                role="group"
                aria-label={t("ቋንቋ", "Language")}
              >
                <button
                  type="button"
                  onClick={() => setLang("am")}
                  aria-pressed={lang === "am"}
                  className={cn(
                    "h-8 min-w-9 px-2 text-xs font-semibold transition-colors",
                    lang === "am"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  አማ
                </button>
                <button
                  type="button"
                  onClick={() => setLang("en")}
                  aria-pressed={lang === "en"}
                  className={cn(
                    "h-8 min-w-9 border-l px-2 text-xs font-semibold transition-colors",
                    lang === "en"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  EN
                </button>
              </div>
              <NotificationsBell />
            </div>
          </div>

          {/* Controls row */}
          <div className="flex flex-wrap items-center gap-2">
            <Input
              value={quarter}
              onChange={(e) => setQuarter(e.target.value)}
              className="w-40"
              placeholder="Q3-2018EFY"
              aria-label={t("ሩብ ዓመት", "Quarter")}
            />
            <Input
              type="date"
              value={reportDate}
              onChange={(e) => setReportDate(e.target.value)}
              className="w-40"
              aria-label={t("ቀን", "Date")}
            />
            <Button variant="outline" size="sm" onClick={() => navigate("review")}>
              <Sparkles /> {t("AI ግምገማ", "AI Evaluation")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("qrcodes")}>
              <QrCode /> QR Codes
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("analytics")}>
              <BarChart3 /> {t("ዳሽቦርድ", "Dashboard")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("ai-studio")}>
              <Brain /> AI Studio
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("automation")}>
              <Bot /> {t("አውቶሜሽን", "Automation")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("filing")}>
              <FolderLock /> {t("ፋይሊንግ", "Filing")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("links")}>
              <Link2 /> {t("አገናኞች", "Links")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("contacts")}>
              <Users /> {t("እውቂያዎች", "Contacts")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("about")}>
              <Info /> {t("ስለ አፕሊኬሽኑ", "About")}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-muted-foreground hover:text-foreground"
              aria-label={t("ቅንብሮች", "Settings")}
              title={t("ቅንብሮች", "Settings")}
              onClick={() => navigate("settings")}
            >
              <Settings2 className="size-4" />
            </Button>
            <Button variant="outline" size="sm" disabled={evaluations.length === 0} onClick={handleExportCsv}>
              <Download /> {t("CSV አውርድ", "Download CSV")}
            </Button>
            <Button variant="outline" size="sm" disabled={evaluations.length === 0} onClick={handleExportPdf}>
              <FileText /> {t("PDF አውርድ", "Download PDF")}
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={evaluations.length === 0 || sendAllBusy}
              onClick={sendAllResults}
              title={t(
                "ውጤቶችን በተቀመጡ እውቂያዎች በአንድ ጊዜ ላክ",
                "Send every result through the saved contacts in one go"
              )}
            >
              {sendAllBusy ? <Loader2 className="animate-spin" /> : <Send />} {t("ሁሉንም ላክ", "Send all")}
            </Button>
            {selectMode ? (
              <Button variant="secondary" size="sm" onClick={exitSelectMode}>
                <X /> {t("ምርጫ አጥፋ", "Clear selection")} ({selectedKeys.length})
              </Button>
            ) : (
              <Button variant="outline" size="sm" onClick={() => setSelectMode(true)}>
                <CheckSquare /> {t("በርካታ ምረጥ", "Select multiple")}
              </Button>
            )}
            {selectMode && (
              <>
                <Button
                  size="sm"
                  onClick={handleCombinedPdf}
                  disabled={selectedEvaluations.length === 0 || combinedProgress !== null}
                >
                  <Layers /> {t("የተዋሀደ PDF", "Combined PDF")}{combinedProgress ? ` (${combinedProgress})` : ""}
                </Button>
                <Button
                  size="sm"
                  onClick={() => setSendOpen(true)}
                  disabled={selectedEvaluations.length === 0}
                >
                  <Send /> {t("ውጤት ላክ", "Send Results")}
                </Button>
                <Button
                  size="sm"
                  onClick={handleDownloadAll}
                  disabled={selectedEvaluations.length === 0 || downloadAllProgress !== null}
                >
                  <Download /> {t("ውጤቶች አውርድ", "Download results")}{downloadAllProgress ? ` (${downloadAllProgress})` : ""}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={() => setDeleteTargets(selectedEvaluations)}
                  disabled={selectedEvaluations.length === 0}
                >
                  <Trash2 /> {t("ሁሉንም ሰርዝ", "Delete all")}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-primary"
                  onClick={toggleSelectAll}
                  disabled={evaluatedKeys.length === 0}
                >
                  {allSelected ? t("ሁሉንም አጥፋ", "Deselect all") : t("ሁሉንም ምረጥ", "Select all")}
                </Button>
              </>
            )}
            <Badge variant="secondary">
              {completed.length}/{DIRECTORATES.length} {t("ተጠናቅቋል", "completed")}
            </Badge>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-7xl px-4 py-6">
        {loading ? (
          <LoadingSpinner />
        ) : (
          <Tabs defaultValue="grid" className="gap-4">
            <TabsList>
              <TabsTrigger value="grid">
                <LayoutGrid /> {t("ዳይሬክቶሬቶች", "Directorates")}
              </TabsTrigger>
              <TabsTrigger value="summary">
                <TableIcon /> {t("ማጠቃለያ", "Summary")}
              </TabsTrigger>
              <TabsTrigger value="comments">
                <MessageSquare /> {t("አስተያየቶች", "Comments")}
              </TabsTrigger>
            </TabsList>

            {/* Grid tab */}
            <TabsContent value="grid" className="space-y-6">
              {/* Quarterly report deadline — status banner (sending lives in Settings) */}
              {deadlinePending && deadlineInfo ? (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 dark:border-amber-500/40 dark:bg-amber-500/10">
                  <CalendarClock className="size-4 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden />
                  <span className="min-w-0 break-words text-sm font-semibold text-amber-900 dark:text-amber-200">
                    {t(
                      `⏰ የ${deadlineInfo.quarter} ሪፖርት መጣሪያ: ${deadlineInfo.date}`,
                      `⏰ ${deadlineInfo.quarter} report deadline: ${deadlineInfo.date}`
                    )}
                  </span>
                  {deadlineDaysLeft !== null && (
                    <Badge
                      variant="outline"
                      className={
                        deadlineDaysLeft <= 7
                          ? "border-amber-300 bg-amber-100 text-amber-800 dark:border-amber-500/40 dark:bg-amber-500/20 dark:text-amber-200"
                          : undefined
                      }
                    >
                      {deadlineDaysLeft === 1
                        ? t("1 ቀን ቀርቷል", "1 day left")
                        : t(`${deadlineDaysLeft} ቀናት ቀርተዋል`, `${deadlineDaysLeft} days left`)}
                    </Badge>
                  )}
                  <span className="text-xs font-medium text-amber-800 dark:text-amber-300">
                    {t(
                      `${deadlineMissing.length} ዳይሬክቶሬቶች አልገቡም`,
                      `${deadlineMissing.length} directorates pending`
                    )}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="ml-auto h-7 shrink-0 border-amber-400/60 bg-white/70 text-amber-900 hover:bg-amber-100 hover:text-amber-900 dark:border-amber-500/40 dark:bg-transparent dark:text-amber-200 dark:hover:bg-amber-500/20 dark:hover:text-amber-100"
                    onClick={() => navigate("settings")}
                  >
                    <Send className="size-3.5" aria-hidden />
                    {t("አስታዋሻ ላክ", "Send reminder")}
                  </Button>
                </div>
              ) : deadlineAllDone && deadlineInfo ? (
                <div className="flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-3 py-2.5 dark:border-emerald-500/40 dark:bg-emerald-500/10">
                  <CheckCircle2 className="size-4 shrink-0 text-emerald-600 dark:text-emerald-400" aria-hidden />
                  <span className="min-w-0 break-words text-sm font-medium text-emerald-800 dark:text-emerald-200">
                    {t(
                      `ሁሉም ዳይሬክቶሬቶች ለ${deadlineInfo.quarter} ሪፖርት አግብተዋል`,
                      `All directorates submitted for ${deadlineInfo.quarter}`
                    )}
                  </span>
                </div>
              ) : null}

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {DIRECTORATES.map((d) => (
                  <DirectorateCard
                    key={d.key}
                    directorate={d}
                    evaluation={byDir[d.key]}
                    quarter={quarter}
                    selectMode={selectMode}
                    selected={selectedKeys.includes(d.key)}
                    qualityCount={qualityCounts[d.key] ?? 0}
                    onToggleSelect={toggleSelect}
                    onDownload={downloadSingle}
                    onDelete={(ev) => setDeleteTargets([ev])}
                    onOpen={(key) => navigate("evaluate", { directorate: key, quarter })}
                  />
                ))}
              </div>

              {/* Live directorate uploads — instantly visible via real-time events */}
              <Card className="glass-card space-y-4 p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10">
                    <FileUp className="size-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm leading-tight font-bold sm:text-base">
                      {t("የተሰቀሉ የዳይሬክቶሬት ሪፖርቶች — በቅጽበት", "Directorate report uploads — live")}
                      <span className="hidden sm:inline">{t(" · Directorate report uploads", "")}</span>
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {t(
                        "ዳይሬክቶሬት ከራሱ ሊንክ ሪፖርት ሲሰቀል ወዲያውኑ እዚህ ይታያል።",
                        "The moment a directorate uploads a quarterly report from its own link it appears here instantly."
                      )}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold",
                      liveConnected
                        ? "border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300"
                        : "border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
                    )}
                  >
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        liveConnected ? "animate-pulse bg-emerald-500" : "bg-amber-500"
                      )}
                      aria-hidden
                    />
                    {liveConnected ? t("በቀጥታ · Live", "Live") : "30s · Auto"}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    aria-label={t("እድሳት", "Refresh uploads")}
                    title={t("እድሳት", "Refresh")}
                    onClick={() => void loadUploads()}
                  >
                    <RefreshCw className="size-4" />
                  </Button>
                </div>

                {recentUploads.length === 0 ? (
                  <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed p-8 text-center">
                    <FileUp className="size-6 text-muted-foreground/60" />
                    <p className="text-sm text-muted-foreground">
                      {t(
                        "እስካሁን ሪፖርት አልተሰቀለም",
                        "No report documents uploaded yet — directorates upload from their own QR link"
                      )}
                    </p>
                  </div>
                ) : (
                  <div className="max-h-96 space-y-2 overflow-y-auto pr-1 [scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5">
                    {recentUploads.map((r) => {
                      const d = DIRECTORATES.find((x) => x.key === r.directorateKey);
                      const when = timeAgoLabel(r.createdAt);
                      return (
                        <div key={r.id} className="rounded-lg border p-3">
                          <div className="flex items-start gap-2.5">
                            <span
                              className="flex h-7 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-[11px] font-bold text-primary"
                              aria-hidden
                            >
                              {d?.short || r.directorateKey.slice(0, 4)}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1">
                                <span className="min-w-0 truncate text-sm font-medium" title={r.title}>
                                  {r.title}
                                </span>
                                {r.quarter && (
                                  <Badge variant="outline" className="px-1.5 py-0 text-[10px]">
                                    {r.quarter}
                                  </Badge>
                                )}
                                {when && (
                                  <span className="ml-auto shrink-0 text-[10px] whitespace-nowrap text-muted-foreground">
                                    {when}
                                  </span>
                                )}
                              </div>
                              <p className="mt-0.5 truncate text-xs text-muted-foreground" title={r.fileName}>
                                {r.fileName}
                                {r.size > 0 ? ` · ${formatBytes(r.size)}` : ""}
                              </p>
                            </div>
                            <div className="flex shrink-0 items-center gap-0.5">
                              {r.shareToken && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-muted-foreground hover:text-primary"
                                  aria-label={t("ልዩ ሊንክ ኮፒ አድርግ", "Copy unique link")}
                                  title={t("ልዩ ሊንክ ኮፒ", "Copy unique link")}
                                  onClick={async () => {
                                    const ok = await copyText(reportShareUrl(r.shareToken));
                                    if (ok) {
                                      toast({
                                        title: t("ልዩ ሊንክ ተቀድቷል", "Unique link copied"),
                                        description: r.fileName,
                                      });
                                    }
                                  }}
                                >
                                  <Link2 className="size-3.5" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-muted-foreground hover:text-foreground"
                                aria-label={t("ሰነድ አውርድ", "Download document")}
                                title={t("ሰነድ አውርድ", "Download document")}
                                onClick={() =>
                                  window.open(qualityApi.fileUrl(r.id), "_blank", "noopener,noreferrer")
                                }
                              >
                                <Download className="size-3.5" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>

              {/* Directorate feedback (comments & suggestions from their portal) */}
              <Card className="glass-card space-y-4 p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                    <MessagesSquare className="size-5 text-primary" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm leading-tight font-bold sm:text-base">
                      {t("የዳይሬክቶሬቶች አስተያየቶች እና ጥቆማዎች", "Directorate Comments & Suggestions")}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {t("Directorate Comments & Suggestions", "")}
                    </p>
                  </div>
                  {feedbackUnread > 0 && (
                    <Badge variant="destructive" className="shrink-0">
                      {feedbackUnread} {t("አዲስ · new", "new")}
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    aria-label={t("እድሳት", "Refresh feedback")}
                    title={t("እድሳት", "Refresh")}
                    onClick={() => void fetchFeedback()}
                  >
                    <RefreshCw className="size-4" />
                  </Button>
                </div>

                {feedback.length === 0 ? (
                  <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed p-8 text-center">
                    <BellOff className="size-6 text-muted-foreground/60" />
                    <p className="text-sm text-muted-foreground">
                      {t(
                        "እስካሁን አስተያየት አልተሰበሰበም",
                        "No feedback collected yet — directorates can share from their portal"
                      )}
                    </p>
                  </div>
                ) : (
                  <div className="max-h-96 space-y-2 overflow-y-auto pr-1 [scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5">
                    {feedback.map((f) => {
                      const isSuggestion = f.kind === "suggestion";
                      const when = timeAgoLabel(f.createdAt);
                      return (
                        <div
                          key={f.id}
                          className={cn(
                            "rounded-lg border p-3",
                            !f.isRead && "border-primary/30 bg-primary/5"
                          )}
                        >
                          <div className="flex items-start gap-2.5">
                            <span
                              className={cn(
                                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                                isSuggestion
                                  ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                                  : "bg-sky-500/10 text-sky-600 dark:text-sky-400"
                              )}
                              aria-hidden
                            >
                              {isSuggestion ? (
                                <Lightbulb className="size-3.5" />
                              ) : (
                                <MessageCircle className="size-3.5" />
                              )}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1">
                                <span className="min-w-0 truncate text-sm font-medium">
                                  {feedbackDirectorateLabel(f)}
                                </span>
                                {f.quarter && (
                                  <Badge variant="outline" className="px-1.5 py-0 text-[10px]">
                                    {f.quarter}
                                  </Badge>
                                )}
                                {!f.isRead && (
                                  <Badge variant="destructive" className="px-1.5 py-0 text-[10px]">
                                    {t("አዲስ · new", "new")}
                                  </Badge>
                                )}
                                {when && (
                                  <span className="ml-auto shrink-0 text-[10px] whitespace-nowrap text-muted-foreground">
                                    {when}
                                  </span>
                                )}
                              </div>
                              <p
                                className="mt-1 line-clamp-2 text-sm text-muted-foreground"
                                title={f.message}
                              >
                                {f.message}
                              </p>
                              <div className="mt-1.5 flex items-center justify-between gap-2">
                                {f.contact ? (
                                  <span className="flex min-w-0 items-center gap-1 text-xs text-muted-foreground">
                                    {f.contact.includes("@") ? (
                                      <Mail className="size-3 shrink-0" />
                                    ) : (
                                      <Phone className="size-3 shrink-0" />
                                    )}
                                    <span className="truncate">{f.contact}</span>
                                  </span>
                                ) : (
                                  <span />
                                )}
                                {!f.isRead && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7 shrink-0 text-muted-foreground hover:text-primary"
                                    aria-label={t("ተነብቧል", "Mark read")}
                                    title={t("ተነብቧል", "Mark read")}
                                    onClick={() => void markFeedbackRead(f.id)}
                                  >
                                    <Check className="size-3.5" />
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            </TabsContent>

            {/* Summary tab */}
            <TabsContent value="summary" className="space-y-6">
              <Card className="glass-card overflow-x-auto p-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("ዳይሬክቶሬት", "Directorate")}</TableHead>
                      {CRITERIA.map((c) => (
                        <TableHead key={c.key} className="text-center" title={c.nameEn}>
                          {c.key}
                        </TableHead>
                      ))}
                      <TableHead className="text-center">{t("ጠቅላላ", "Total")}</TableHead>
                      <TableHead className="text-center">%</TableHead>
                      <TableHead>{t("ሁኔታ", "Status")}</TableHead>
                      <TableHead className="text-center">{t("እርምጃ", "Actions")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DIRECTORATES.map((d) => {
                      const ev = byDir[d.key];
                      const pct = ev ? scorePercent(ev.totalScore) : 0;
                      return (
                        <TableRow key={d.key}>
                          <TableCell>
                            <div className="text-sm font-medium">{d.name}</div>
                            <div className="text-xs text-muted-foreground">{d.nameEn}</div>
                          </TableCell>
                          {CRITERIA.map((c) => (
                            <TableCell key={c.key} className="text-center text-sm">
                              {ev ? (ev.scores?.[c.key] ?? 0) : "—"}
                            </TableCell>
                          ))}
                          <TableCell className="text-center font-bold">
                            {ev ? (
                              <span className={scoreColorClass(pct)}>{ev.totalScore}</span>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {ev ? (
                              <span
                                className={cn(
                                  "inline-block rounded-full px-2 py-0.5 text-xs font-semibold",
                                  performanceLabel(pct).className
                                )}
                              >
                                {pct}%
                              </span>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                          <TableCell>
                            {ev ? (
                              <Badge variant={ev.status === "sent" ? "secondary" : "outline"}>
                                {ev.status}
                              </Badge>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {ev ? (
                              <div className="flex items-center justify-center gap-0.5">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  aria-label={t("አርትዕ", "Edit")}
                                  onClick={() => navigate("evaluate", { directorate: d.key, quarter })}
                                >
                                  <Pencil className="size-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  aria-label={t("PDF አውርድ", "Download PDF")}
                                  onClick={() => downloadSingle(ev)}
                                >
                                  <Download className="size-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                                  aria-label={t("ሰርዝ", "Delete")}
                                  onClick={() => setDeleteTargets([ev])}
                                >
                                  <Trash2 className="size-3.5" />
                                </Button>
                              </div>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </Card>

              <div>
                <h3 className="text-sm font-bold">{t("ውጤት ላክ", "Send Individual Results")}</h3>
                <p className="mb-3 mt-1 text-xs text-muted-foreground">
                  {t(
                    "የተጠናቀቁ ውጤቶች በWhatsApp፣ Telegram ወይም ኢሜይል ይላካሉ።",
                    "Send completed scores via WhatsApp, Telegram or Email."
                  )}
                </p>
                {completed.length === 0 ? (
                  <p className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
                    {t("የተጠናቀቁ ግምገማዎች የሉም።", "No completed evaluations yet.")}
                  </p>
                ) : (
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {completed.map((ev) => (
                      <Card key={ev.id} className="glass-card flex-row items-center justify-between gap-2 p-3">
                        <div className="min-w-0">
                          <div className="text-sm font-bold">{ev.directorateShort}</div>
                          <div className="truncate text-xs text-muted-foreground">{ev.email || "—"}</div>
                        </div>
                        <ScoreSendMenu ev={ev} quarter={quarter} variant="outline" size="sm" label={t("ላክ", "Send")} />
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Comments tab */}
            <TabsContent value="comments" className="space-y-4">
              {orderedEvaluations.length === 0 ? (
                <div className="rounded-lg border border-dashed p-10 text-center text-sm text-muted-foreground">
                  {t("ገና ግምገማ አልተደረገም።", "No evaluations yet.")}
                </div>
              ) : (
                orderedEvaluations.map((ev) => {
                  const commented = CRITERIA.filter((c) => (ev.comments?.[c.key] ?? "").trim().length > 0);
                  return (
                    <Card key={ev.id} className="glass-card gap-3 p-4">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-sm font-bold">{ev.directorateName}</div>
                          <div className="text-xs text-muted-foreground">
                            {ev.directorateShort} · {ev.quarter}
                          </div>
                        </div>
                        <Badge variant={ev.status === "sent" ? "secondary" : "outline"}>{ev.status}</Badge>
                      </div>
                      {commented.length === 0 ? (
                        <p className="text-xs text-muted-foreground">{t("አስተያየት የለም።", "No comments.")}</p>
                      ) : (
                        <div className="space-y-2">
                          {commented.map((c) => (
                            <div key={c.key} className="flex items-start gap-2">
                              <Badge variant="outline" className="mt-0.5 shrink-0">
                                {c.key}
                              </Badge>
                              <div className="min-w-0">
                                <div className="text-xs font-semibold">{c.nameEn}</div>
                                <p className="text-sm whitespace-pre-wrap text-muted-foreground">
                                  {ev.comments[c.key]}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </Card>
                  );
                })
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>

      <SendResultsDialog
        open={sendOpen}
        onOpenChange={setSendOpen}
        evaluations={selectedEvaluations}
        quarter={quarter}
        onSent={handleSent}
      />

      {/* Delete confirmation (single or bulk) */}
      <AlertDialog
        open={deleteTargets !== null}
        onOpenChange={(open) => {
          if (!open && !deleting) setDeleteTargets(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("ግምገማን ሰርዝ", "Delete Evaluation")}</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTargets && deleteTargets.length === 1
                ? t(
                    `የ${deleteTargets[0].directorateName} (${deleteTargets[0].directorateShort}) የ${deleteTargets[0].quarter} ግምገማ በቋሚነት ይሰረዛል።`,
                    `The ${deleteTargets[0].quarter} evaluation for ${deleteTargets[0].directorateName} (${deleteTargets[0].directorateShort}) will be permanently deleted.`
                  )
                : t(
                    `${deleteTargets?.length ?? 0} የተመረጡ ግምገማዎች በቋሚነት ይሰረዛሉ።`,
                    `${deleteTargets?.length ?? 0} selected evaluations will be permanently deleted.`
                  )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>{t("አትሰርዝ", "Cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                void confirmDelete();
              }}
            >
              {deleting ? <Loader2 className="animate-spin" /> : <Trash2 />}
              {deleting ? t("በመሰረዝ ላይ…", "Deleting…") : t("አዎ፣ ሰርዝ", "Yes, delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
