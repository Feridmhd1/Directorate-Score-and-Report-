"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ClipboardList,
  Copy,
  Download,
  File,
  FileImage,
  FileSpreadsheet,
  FileStack,
  FileText,
  Loader2,
  Mail,
  MessageCircle,
  Paperclip,
  Plus,
  Save,
  Send,
  Share2,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import type { NavigateFn } from "@/hooks/use-view";
import {
  ACTION_PLAN_STATUS_LABELS,
  CRITERIA,
  TOTAL_MAX_SCORE,
  computeScores,
  getDirectorate,
  scorePercent,
  type ActionPlanItem,
} from "@/lib/rubric";
import {
  automationApi,
  buildShareLinks,
  evaluationsApi,
  notificationsApi,
  qualityApi,
  reportShareUrl,
} from "@/lib/client-api";
import { PerformanceBadge, ScoreBadge, ScoreBar } from "@/components/shared";
import type { QualityReportDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/i18n";

type YesNo = "yes" | "no";

/* ---------- Quality report documents (upload / download / share / delete) ---------- */

function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

function reportFileIcon(r: QualityReportDTO) {
  const mime = (r.mimeType || "").toLowerCase();
  const ext = (r.fileName || "").toLowerCase().split(".").pop() ?? "";
  if (mime.startsWith("image/") || ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"].includes(ext)) {
    return FileImage;
  }
  if (
    mime.includes("spreadsheet") ||
    mime.includes("excel") ||
    mime === "text/csv" ||
    ["xlsx", "xls", "csv"].includes(ext)
  ) {
    return FileSpreadsheet;
  }
  if (
    mime.includes("pdf") ||
    mime.includes("word") ||
    mime.includes("text") ||
    ["pdf", "doc", "docx", "txt", "md", "rtf"].includes(ext)
  ) {
    return FileText;
  }
  return File;
}

function shareTextFor(r: QualityReportDTO): string {
  const displayTitle = r.title || r.fileName;
  return `የጥራት ሪፖርት — ${displayTitle} / Quality report "${displayTitle}"`;
}

/**
 * Upload quality report documents for the current directorate, then download,
 * share (unique link via WhatsApp/Telegram/Email) or delete them.
 */
function QualityReportsSection({ directorateKey, quarter }: { directorateKey: string; quarter: string }) {
  const { t } = useLang();
  const [reports, setReports] = useState<QualityReportDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchReports = async () => {
    try {
      const res = await qualityApi.list(directorateKey);
      setReports(res.reports);
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("ሰነዶችን መጫን አልተቻለም", "Could not load documents"),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    qualityApi
      .list(directorateKey)
      .then((res) => {
        if (!cancelled) setReports(res.reports);
      })
      .catch(() => {
        /* keep the empty list — refresh button retries */
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [directorateKey]);

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    try {
      const { deliveries } = await qualityApi.upload(file, {
        directorateKey,
        quarter: quarter || undefined,
        title: title.trim() || undefined,
      });
      // The server immediately automated the unique link to the delivery
      // channels (WhatsApp / Telegram / Email) — summarize the attempts.
      const sent = deliveries.filter((d) => d.status === "sent").length;
      const queued = deliveries.filter((d) => d.status === "queued").length;
      const failed = deliveries.filter((d) => d.status === "failed").length;
      toast({
        title: t("ሰነድ ተስቀልቷል — ልዩ አገናኝ ተፈጥሯል", "Document uploaded — unique link created"),
        description:
          deliveries.length === 0
            ? "Document uploaded · link automation has no enabled channel"
            : t(
                `አገናኙ ወደ WhatsApp / Telegram / ኢሜይል ተልኳል — ${sent} ተላክ · ${queued} ተራ · ${failed} አልተሳካም`,
                `Link sent to WhatsApp / Telegram / Email — ${sent} sent · ${queued} queued · ${failed} failed`
              ),
      });
      setFile(null);
      setTitle("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      await fetchReports();
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መስቀል አልተቻለም", "Upload failed"),
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const copyShareLink = async (r: QualityReportDTO) => {
    try {
      await navigator.clipboard.writeText(reportShareUrl(r.shareToken));
      toast({ title: t("ልዩ አገናኝ ተቀድቷል", "Unique link copied"), description: "Unique link copied" });
    } catch {
      toast({
        title: t("ኮፒ አልተሳካም", "Copy failed"),
        description: "Could not copy the link to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (r: QualityReportDTO) => {
    if (!window.confirm(t("ይህን ሰነድ ሰርዝ?", "Delete this document?"))) return;
    try {
      await qualityApi.remove(r.id);
      toast({ title: t("ሰነዱ ተሰርዟል", "Document deleted"), description: "Document deleted" });
      await fetchReports();
    } catch (err) {
      toast({
        title: t("ስህተት", "Error"),
        description: err instanceof Error ? err.message : t("መሰረዝ አልተቻለም", "Could not delete"),
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="py-4">
      <CardContent className="px-4 space-y-3">
        {/* Header */}
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-teal-500 text-white shadow-sm">
            <FileStack className="size-5" aria-hidden />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">{t("የጥራት ሪፖርት ሰነዶች", "Quality Report Documents")}</span>
              <span className="text-xs text-muted-foreground">{t("", "")}</span>
              {reports.length > 0 && (
                <Badge variant="secondary" className="text-[11px] font-medium">
                  {reports.length} {t("ሰነዶች", "documents")}
                </Badge>
              )}
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {t(
                "ለዚህ ዳይሬክቶሬት ማንኛውም ሰነድ ይስቀሉ — PDF፣ Word፣ Excel፣ PowerPoint፣ ምስሎች (ፎቶ) እና ሌላ ማናቸውም ፋይሎች። ከመስቀል በኋላ ልዩ አገናኙ በአውቶማቲክ ይላካል።",
                "Upload any document for this directorate — PDF, Word, Excel, PowerPoint, photos and any other file type (max 10 MB). The unique link is sent automatically after upload."
              )}
            </p>
          </div>
        </div>

        {/* Upload row */}
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            ref={fileInputRef}
            type="file"
            className="h-9 text-xs sm:max-w-xs"
            aria-label={t("ፋይል ምረጥ", "Choose file")}
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
          <Input
            className="h-9"
            placeholder={t("ርዕስ", "Title…")}
            aria-label={t("ርዕስ", "Title")}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <Button
            type="button"
            className="h-9 shrink-0"
            disabled={!file || uploading}
            onClick={() => void handleUpload()}
          >
            {uploading ? <Loader2 className="size-4 animate-spin" /> : <UploadCloud className="size-4" />}
            {t("ስቀል", "Upload")}
          </Button>
        </div>

        {/* Documents list */}
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> {t("በመጫን ላይ…", "Loading…")}
          </div>
        ) : reports.length === 0 ? (
          <p className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
            {t("እስካሁን ሰነድ አልተስቀለም", "No documents uploaded yet")}
          </p>
        ) : (
          <div className="max-h-96 space-y-2 overflow-y-auto pr-1 [scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5">
            {reports.map((r) => {
              const Icon = reportFileIcon(r);
              const size = formatFileSize(r.size);
              const links = buildShareLinks(reportShareUrl(r.shareToken), shareTextFor(r));
              return (
                <div key={r.id} className="flex items-start gap-2.5 rounded-lg border p-2.5">
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground"
                    aria-hidden
                  >
                    <Icon className="size-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1">
                      <span className="min-w-0 flex-1 truncate text-sm font-medium" title={r.title || r.fileName}>
                        {r.title || r.fileName}
                      </span>
                      {r.quarter && (
                        <Badge variant="outline" className="px-1.5 py-0 text-[10px]">
                          {r.quarter}
                        </Badge>
                      )}
                    </div>
                    <div className="truncate text-xs text-muted-foreground" title={r.fileName}>
                      {r.fileName}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[10px] text-muted-foreground">
                      {size && <span>{size}</span>}
                      {r.createdAt && (
                        <span>
                          {t("ተሰቀለ ·", "uploaded ·")} {new Date(r.createdAt).toLocaleDateString("en-GB")}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-0.5">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      asChild
                      aria-label={t("አውርድ", "Download")}
                      title={t("አውርድ", "Download")}
                    >
                      <a href={qualityApi.fileUrl(r.id)} download={r.fileName}>
                        <Download className="size-4" />
                      </a>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          aria-label={t("አጋራ", "Share document")}
                          title={t("አጋራ", "Share")}
                        >
                          <Share2 className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        <DropdownMenuItem onClick={() => void copyShareLink(r)}>
                          <Copy className="size-4" /> {t("አገናኝ ቅዳ", "Copy link")}
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <a href={links.whatsapp} target="_blank" rel="noopener noreferrer">
                            <MessageCircle className="size-4 text-emerald-600" /> WhatsApp
                          </a>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <a href={links.telegram} target="_blank" rel="noopener noreferrer">
                            <Send className="size-4 text-sky-600" /> Telegram
                          </a>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <a href={links.email}>
                            <Mail className="size-4 text-amber-600" /> Email
                          </a>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      aria-label={t("ሰርዝ", "Delete document")}
                      title={t("ሰርዝ", "Delete")}
                      onClick={() => void handleDelete(r)}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <p className="text-[11px] text-muted-foreground">
          {t(
            "እያንዳንዱ ሰነድ በWhatsApp፣ Telegram ወይም ኢሜይል ለመላክ የሚያገለግል ልዩ አገናኝ አለው።",
            "Every document gets a unique shareable link for WhatsApp, Telegram or Email"
          )}
        </p>
      </CardContent>
    </Card>
  );
}

/** Yes/No toggle pair used for every sub-question */
function YesNoButtons({
  value,
  onChange,
}: {
  value: YesNo | undefined;
  onChange: (v: YesNo) => void;
}) {
  const { t } = useLang();
  return (
    <div className="flex gap-2">
      <Button
        type="button"
        variant="outline"
        className={cn(
          "h-9 flex-1 text-xs font-medium",
          value === "yes" &&
            "bg-emerald-500 hover:bg-emerald-600 text-white hover:text-white border-emerald-500"
        )}
        onClick={() => onChange("yes")}
      >
        {t("አዎ", "Yes")}
      </Button>
      <Button
        type="button"
        variant="outline"
        className={cn(
          "h-9 flex-1 text-xs font-medium",
          value === "no" &&
            "bg-red-500 hover:bg-red-600 text-white hover:text-white border-red-500"
        )}
        onClick={() => onChange("no")}
      >
        {t("አዩ", "No")}
      </Button>
    </div>
  );
}

function normalizeAnswers(raw: Record<string, string> | null | undefined): Record<string, YesNo> {
  const normalized: Record<string, YesNo> = {};
  if (!raw) return normalized;
  Object.entries(raw).forEach(([k, v]) => {
    if (v === "yes" || v === "no") normalized[k] = v;
  });
  return normalized;
}

/* ---------- Structured action plan editor (local to this file) ---------- */

const ACTION_STATUS_KEYS = ["planned", "in_progress", "done"] as const;
type ActionStatusKey = (typeof ACTION_STATUS_KEYS)[number];

const ACTION_STATUS_STYLES: Record<ActionStatusKey, string> = {
  planned: "bg-primary text-primary-foreground border-primary hover:bg-primary/90 hover:text-primary-foreground",
  in_progress: "bg-amber-500 text-white border-amber-500 hover:bg-amber-600 hover:text-white",
  done: "bg-emerald-500 text-white border-emerald-500 hover:bg-emerald-600 hover:text-white",
};

/**
 * Structured "goals & corrective steps" planner: each item carries the step text,
 * an owner, a deadline and a status (planned / in_progress / done).
 */
function ActionPlanEditor({
  items,
  onChange,
}: {
  items: ActionPlanItem[];
  onChange: (items: ActionPlanItem[]) => void;
}) {
  const { t } = useLang();
  const addItem = () =>
    onChange([
      ...items,
      { id: crypto.randomUUID(), text: "", owner: "", deadline: "", status: "planned" },
    ]);
  const patchItem = (id: string, patch: Partial<ActionPlanItem>) =>
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  const removeItem = (id: string) => onChange(items.filter((it) => it.id !== id));

  return (
    <Card className="py-4">
      <CardContent className="px-4 space-y-3">
        <div className="flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-primary shrink-0" />
          <span className="font-semibold text-sm flex-1 min-w-0">{t("የድርጊት እቅድ", "Action Plan")}</span>
          {items.length > 0 && (
            <Badge variant="secondary" className="text-[11px] font-medium">
              {items.length} {t("እርምጃዎች", "actions")}
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {t(
            "በሩብ ዓመት ግምገማዎ ላይ የተለዩ ግቦችን ወይም አስተካካይ እርምጃዎችን ይዘምሩ።",
            "List specific goals or corrective steps identified during your quarterly review."
          )}
        </p>
        <div className="space-y-3">
          {items.map((item) => {
            const rawStatus = item.status ?? (item.done ? "done" : "planned");
            const status: ActionStatusKey = ACTION_STATUS_KEYS.includes(rawStatus as ActionStatusKey)
              ? (rawStatus as ActionStatusKey)
              : "planned";
            return (
              <div key={item.id} className="rounded-lg border p-3 space-y-2">
                {/* Goal / corrective step */}
                <Textarea
                  rows={2}
                  className="text-sm"
                  placeholder={t("ግብ ወይም አስተካካይ እርምጃ ይጻፉ…", "Goal or corrective step…")}
                  value={item.text}
                  onChange={(e) => patchItem(item.id, { text: e.target.value })}
                />
                {/* Owner + deadline */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <Input
                    className="h-9"
                    placeholder={t("ኃላፊ", "Owner…")}
                    value={item.owner ?? ""}
                    onChange={(e) => patchItem(item.id, { owner: e.target.value })}
                  />
                  <Input
                    className="h-9"
                    type="date"
                    aria-label={t("ጊዜ ገደብ", "Deadline")}
                    value={item.deadline ?? ""}
                    onChange={(e) => patchItem(item.id, { deadline: e.target.value })}
                  />
                </div>
                {/* Status + remove */}
                <div className="flex items-center gap-2">
                  <div className="grid flex-1 grid-cols-3 gap-1.5 min-w-0">
                    {ACTION_STATUS_KEYS.map((key) => (
                      <Button
                        key={key}
                        type="button"
                        variant="outline"
                        className={cn(
                          "h-9 px-1 text-[11px] leading-tight whitespace-normal font-medium",
                          status === key ? ACTION_STATUS_STYLES[key] : "text-muted-foreground"
                        )}
                        aria-pressed={status === key}
                        onClick={() =>
                          patchItem(item.id, { status: key, done: key === "done" })
                        }
                      >
                        {ACTION_PLAN_STATUS_LABELS[key]}
                      </Button>
                    ))}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9 shrink-0 text-destructive hover:text-destructive"
                    onClick={() => removeItem(item.id)}
                    aria-label="Remove item"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        {items.length === 0 && (
          <p className="text-xs italic text-muted-foreground">
            {t("እስካሁን ምንም እርምጃ አልታቀደም", "No goals or steps yet.")}
          </p>
        )}
        <Button type="button" variant="outline" className="h-9" onClick={addItem}>
          <Plus className="w-4 h-4 mr-2" />
          {t("እቅድ ጨምር", "Add Goal or Step")}
        </Button>
      </CardContent>
    </Card>
  );
}

export function EvaluateView({
  directorateKey,
  quarter,
  navigate,
}: {
  directorateKey: string;
  quarter: string;
  navigate: NavigateFn;
}) {
  const { t } = useLang();
  const d = getDirectorate(directorateKey);

  const [email, setEmail] = useState("");
  const [answers, setAnswers] = useState<Record<string, YesNo>>({});
  const [comments, setComments] = useState<Record<string, string>>({});
  const [attachments, setAttachments] = useState<string[]>([]);
  const [actionPlan, setActionPlan] = useState<ActionPlanItem[]>([]);
  const [existingId, setExistingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  /* Load an existing evaluation for this directorate+quarter (if any) */
  useEffect(() => {
    let cancelled = false;
    if (!getDirectorate(directorateKey)) return;
    evaluationsApi
      .list({ directorateKey, quarter })
      .then((res) => {
        if (cancelled) return;
        const existing = res.evaluations[0];
        if (!existing) return;
        setExistingId(existing.id);
        if (existing.email) setEmail(existing.email);
        setAnswers(normalizeAnswers(existing.answers));
        setComments(existing.comments ?? {});
        setAttachments(existing.attachments ?? []);
        setActionPlan(existing.actionPlan ?? []);
      })
      .catch(() => {
        /* keep a blank form on failure */
      });
    return () => {
      cancelled = true;
    };
  }, [directorateKey, quarter]);

  const { scores, totalScore } = useMemo(() => computeScores(answers), [answers]);
  const pct = scorePercent(totalScore);

  const setAnswer = (id: string, v: YesNo) => setAnswers((prev) => ({ ...prev, [id]: v }));

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const names = Array.from(files).map((f) => f.name);
    setAttachments((prev) => [...prev, ...names.filter((n) => !prev.includes(n))]);
    e.target.value = "";
  };
  const removeAttachment = (idx: number) =>
    setAttachments((prev) => prev.filter((_, i) => i !== idx));

  const handleSave = async () => {
    if (!d) return;
    setSaving(true);
    try {
      const computed = computeScores(answers);
      const payload = {
        directorateKey: d.key,
        directorateName: d.name,
        directorateShort: d.short,
        quarter,
        email,
        scores: computed.scores,
        answers,
        comments,
        totalScore: computed.totalScore,
        status: "completed",
        attachments,
        actionPlan,
      };
      const saved = existingId
        ? await evaluationsApi.update(existingId, payload)
        : await evaluationsApi.create(payload);
      const evaluationId = existingId ?? saved.evaluation.id;

      await notificationsApi.create({
        type: "evaluation_completed",
        title: t(`ግምገማ ተጠናቅቋል — ${d.short}`, `Evaluation completed — ${d.short}`),
        message: t(
          `${d.name} የ${quarter} ሩብ ዓመት ግምገማ ተጠናቅቋል። ጠቅላላ ውጤት: ${computed.totalScore}/100`,
          `${d.name}'s ${quarter} quarterly evaluation is complete. Total score: ${computed.totalScore}/100`
        ),
        directorateKey: d.key,
        directorateName: d.name,
        quarter,
        totalScore: computed.totalScore,
        directorEmail: email,
      });
      window.dispatchEvent(new Event("direcscore:refresh-notifications"));

      /* Fire-and-forget: fan the score out to all enabled delivery channels */
      automationApi
        .autoNotify({ evaluationId })
        .then((res) => {
          if (res.results.length > 0) {
            toast({
              title: t("ውጤቱ በአውቶማቲክ ለመላክ ተርታል", "Result queued for automatic delivery"),
              description: "Queued for automatic delivery",
            });
          }
        })
        .catch(() => {});

      toast({ title: t("ግምገማው ተቀምጧል!", "Evaluation saved!"), description: "Evaluation saved!" });
      navigate("home");
    } catch (err) {
      toast({
        title: t("ግምገማው አልተቀመጠም", "Failed to save evaluation"),
        description: err instanceof Error ? err.message : "Failed to save evaluation",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  /* ---------- Directorate not found ---------- */
  if (!d) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center p-4">
        <Card className="w-full max-w-sm py-4">
          <CardContent className="px-4 py-2 space-y-3 text-center">
            <AlertCircle className="w-10 h-10 text-muted-foreground mx-auto" />
            <div>
              <div className="font-bold">{t("ዳይሬክቶሬት አልተገኘም", "Directorate not found")}</div>
              <p className="text-sm text-muted-foreground mt-1">
                Directorate &quot;{directorateKey}&quot; was not found. Please go back and select a
                directorate.
              </p>
            </div>
            <Button className="w-full h-9" onClick={() => navigate("home")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {t("ወደ መነሻ ተመለስ", "Back to home")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1">
      {/* Sticky header */}
      <div className="sticky top-0 z-20 bg-card border-b px-4 py-3 shadow-sm">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={() => navigate("home")}
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm sm:text-base truncate">
              {d.short} - {d.name}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {d.nameEn} • {quarter}
            </div>
          </div>
          <Button onClick={handleSave} disabled={saving} className="h-9 shrink-0">
            {saving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            {t("አስቀምጥ", "Save")}
          </Button>
        </div>
      </div>

      {/* Body */}
      <div className="max-w-3xl mx-auto p-4 space-y-4 pb-28">
        {/* 1. Director email */}
        <Card className="py-4">
          <CardContent className="px-4 space-y-2">
            <Label htmlFor="director-email" className="text-sm font-medium">
              {t("የዳይሬክተር ኢሜይል", "Director Email")}
            </Label>
            <Input
              id="director-email"
              type="email"
              className="h-9"
              placeholder="director@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </CardContent>
        </Card>

        {/* 3. Live total score bar (sticky bottom) */}
        <div className="sticky bottom-4 z-10">
          <Card className="py-3 shadow-lg border-primary/30 bg-card/95 backdrop-blur">
            <CardContent className="px-4 space-y-2">
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm font-bold">
                  {t("ጠቅላላ:", "Total:")} {totalScore}/{TOTAL_MAX_SCORE} ({pct}%)
                </span>
                <PerformanceBadge percent={pct} />
              </div>
              <ScoreBar score={totalScore} max={TOTAL_MAX_SCORE} className="h-2.5" />
            </CardContent>
          </Card>
        </div>

        {/* 2. Scoring form */}
        {CRITERIA.map((criterion) => {
          const scored = scores[criterion.key] ?? 0;
          return (
            <Card key={criterion.key} className="py-4">
              <CardContent className="px-4 space-y-3">
                {/* Criterion header */}
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded bg-primary/10 text-primary font-bold flex items-center justify-center text-sm shrink-0">
                    {criterion.key}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm leading-tight">{criterion.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{criterion.nameEn}</div>
                  </div>
                  <ScoreBadge score={scored} max={criterion.maxScore} />
                </div>

                {/* Sub-questions */}
                <div className="space-y-2">
                  {criterion.subQuestions.map((q) => (
                    <div key={q.id} className="rounded-lg border p-2.5 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-sm font-medium leading-snug">{q.label}</div>
                          <div className="text-xs text-muted-foreground">{q.labelEn}</div>
                        </div>
                        <span className="text-xs text-muted-foreground whitespace-nowrap mt-0.5">
                          {q.points} pts
                        </span>
                      </div>
                      <YesNoButtons value={answers[q.id]} onChange={(v) => setAnswer(q.id, v)} />
                    </div>
                  ))}
                </div>

                {/* 4. Per-criterion comment */}
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">{t("አስተያየት", "Comment")}</Label>
                  <Textarea
                    rows={2}
                    className="text-sm"
                    placeholder={t("አስተያየት ይጻፉ…", "Write a comment…")}
                    value={comments[criterion.key] ?? ""}
                    onChange={(e) =>
                      setComments((prev) => ({ ...prev, [criterion.key]: e.target.value }))
                    }
                  />
                </div>
              </CardContent>
            </Card>
          );
        })}

        {/* 5. Action plan (structured goals & corrective steps) */}
        <ActionPlanEditor items={actionPlan} onChange={setActionPlan} />

        {/* 6. Supporting documents */}
        <Card className="py-4">
          <CardContent className="px-4 space-y-3">
            <div className="flex items-center gap-2">
              <Paperclip className="w-4 h-4 text-primary" />
              <span className="font-semibold text-sm">{t("ደጋፊ ፋይሎች", "Supporting Documents")}</span>
            </div>
            <Input
              type="file"
              multiple
              className="h-9 text-xs"
              aria-label={t("ደጋፊ ፋይሎች ምረጥ", "Choose supporting files (any type)")}
              onChange={handleFiles}
            />
            {attachments.length > 0 && (
              <ul className="space-y-1.5">
                {attachments.map((name, idx) => (
                  <li
                    key={`${name}-${idx}`}
                    className="flex items-center justify-between gap-2 rounded-md border px-2.5 py-1.5"
                  >
                    <span className="text-xs truncate">{name}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => removeAttachment(idx)}
                      aria-label={`Remove ${name}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* 7. Quality report documents (upload / share / download / delete) */}
        <QualityReportsSection directorateKey={d.key} quarter={quarter} />
      </div>
    </div>
  );
}
