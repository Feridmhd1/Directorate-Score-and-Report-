"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  Calendar,
  ClipboardList,
  Download,
  History,
  Minus,
  Target,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { LoadingSpinner } from "@/components/shared";
import { CRITERIA, DIRECTORATES, TOTAL_MAX_SCORE, getDirectorate, scorePercent } from "@/lib/rubric";
import { evaluationsApi } from "@/lib/client-api";
import { downloadHistoryCsv, downloadResultsCsv } from "@/lib/export-utils";
import { useLang } from "@/lib/i18n";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { EvaluationDTO } from "@/lib/types";

const LINE_PALETTE = [
  "#2563eb", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#84cc16",
  "#f97316", "#ec4899", "#14b8a6", "#a855f7", "#3b82f6", "#eab308", "#64748b",
];

const MAX_CATEGORY_SCORE = 15;

function barColor(percent: number): string {
  if (percent >= 75) return "#10b981";
  if (percent >= 50) return "#f59e0b";
  return "#ef4444";
}

function TrendCell({ current, previous }: { current: number; previous?: EvaluationDTO }) {
  if (!previous) return <span className="text-muted-foreground text-xs">—</span>;
  const diff = current - previous.totalScore;
  if (diff > 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
        <TrendingUp className="w-3.5 h-3.5" />
        +{diff}
      </span>
    );
  }
  if (diff < 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-red-600">
        <TrendingDown className="w-3.5 h-3.5" />
        {diff}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground">
      <Minus className="w-3.5 h-3.5" />
      0
    </span>
  );
}

export function AnalyticsView({ navigate }: { navigate: NavigateFn }) {
  const { t } = useLang();
  const [loading, setLoading] = useState(true);
  const [allEvaluations, setAllEvaluations] = useState<EvaluationDTO[]>([]);
  const [quarter, setQuarter] = useState("all");
  const [selectedDirs, setSelectedDirs] = useState<string[]>([]);

  useEffect(() => {
    let cancelled = false;
    evaluationsApi
      .listAll()
      .then(({ evaluations }) => {
        if (cancelled) return;
        setAllEvaluations(evaluations);
        const keysWithData = DIRECTORATES.filter((d) =>
          evaluations.some((e) => e.directorateKey === d.key)
        ).map((d) => d.key);
        setSelectedDirs(keysWithData.slice(0, 5));
      })
      .catch(() => {
        if (!cancelled) {
          toast({
            title: t("ስህተት", "Error"),
            description: t("መረጃውን ማምጣት አልተቻለም", "Failed to load evaluations"),
          });
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const quarters = useMemo(
    () => Array.from(new Set(allEvaluations.map((e) => e.quarter))).sort(),
    [allEvaluations]
  );

  const filteredEvaluations = useMemo(
    () => (quarter === "all" ? allEvaluations : allEvaluations.filter((e) => e.quarter === quarter)),
    [allEvaluations, quarter]
  );

  const uniqueDirectorates = useMemo(
    () => new Set(filteredEvaluations.map((e) => e.directorateKey)).size,
    [filteredEvaluations]
  );

  /** Latest evaluation per directorate within the selected filter */
  const latestByDir = useMemo(() => {
    const byDir: Record<string, EvaluationDTO> = {};
    filteredEvaluations.forEach((e) => {
      const cur = byDir[e.directorateKey];
      if (!cur || new Date(e.createdAt).getTime() > new Date(cur.createdAt).getTime()) {
        byDir[e.directorateKey] = e;
      }
    });
    return byDir;
  }, [filteredEvaluations]);

  const scoreRows = useMemo(
    () =>
      DIRECTORATES.filter((d) => latestByDir[d.key]).map((d) => {
        const e = latestByDir[d.key];
        return {
          key: d.key,
          short: d.short,
          score: e.totalScore,
          percent: scorePercent(e.totalScore, TOTAL_MAX_SCORE),
        };
      }),
    [latestByDir]
  );

  const ranking = useMemo(() => [...scoreRows].sort((a, b) => b.score - a.score), [scoreRows]);

  /** Latest previous-quarter evaluation per directorate (for trend arrows) */
  const prevByKey = useMemo(() => {
    const map: Record<string, EvaluationDTO | undefined> = {};
    Object.entries(latestByDir).forEach(([key, cur]) => {
      const curTime = new Date(cur.createdAt).getTime();
      const earlier = allEvaluations
        .filter(
          (e) =>
            e.directorateKey === key && new Date(e.createdAt).getTime() < curTime
        )
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      map[key] = earlier[0];
    });
    return map;
  }, [allEvaluations, latestByDir]);

  const avgScore = useMemo(() => {
    if (filteredEvaluations.length === 0) return 0;
    const sum = filteredEvaluations.reduce((acc, e) => acc + e.totalScore, 0);
    return Math.round(sum / filteredEvaluations.length);
  }, [filteredEvaluations]);

  const top = useMemo(
    () => [...scoreRows].sort((a, b) => b.score - a.score)[0],
    [scoreRows]
  );

  const needsImprovement = useMemo(
    () => scoreRows.filter((r) => r.percent < 50).length,
    [scoreRows]
  );

  const categoryData = useMemo(
    () =>
      CRITERIA.map((c) => {
        const vals = filteredEvaluations.map((e) => e.scores?.[c.key] ?? 0);
        const avg = vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
        return { key: c.key, avg: Math.round(avg * 10) / 10, max: c.maxScore };
      }),
    [filteredEvaluations]
  );

  const dirsWithData = useMemo(
    () => DIRECTORATES.filter((d) => allEvaluations.some((e) => e.directorateKey === d.key)),
    [allEvaluations]
  );

  /** Distinct quarters ordered by earliest evaluation date */
  const historyQuarters = useMemo(() => {
    const byQuarter = new Map<string, number>();
    allEvaluations.forEach((e) => {
      const t = new Date(e.createdAt).getTime();
      const cur = byQuarter.get(e.quarter);
      if (cur === undefined || t < cur) byQuarter.set(e.quarter, t);
    });
    return [...byQuarter.entries()].sort((a, b) => a[1] - b[1]).map(([q]) => q);
  }, [allEvaluations]);

  const historyData = useMemo(() => {
    return historyQuarters.map((q) => {
      const row: Record<string, string | number> = { quarter: q };
      selectedDirs.forEach((key) => {
        const evs = allEvaluations.filter((e) => e.directorateKey === key && e.quarter === q);
        if (evs.length > 0) {
          const latest = evs.reduce((a, b) =>
            new Date(a.createdAt).getTime() > new Date(b.createdAt).getTime() ? a : b
          );
          row[getDirectorate(key)?.short ?? key] = latest.totalScore;
        }
      });
      return row;
    });
  }, [allEvaluations, historyQuarters, selectedDirs]);

  const toggleDir = (key: string) => {
    setSelectedDirs((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-background">
      {/* Sticky header */}
      <header className="bg-card border-b sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3 flex-wrap">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("home")}
            aria-label={t("ተመለስ", "Back")}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div className="mr-auto min-w-0">
            <h1 className="text-base md:text-lg font-bold leading-tight truncate">
              {t("የአፈጻጸም ዳሽቦርድ", "Performance Analytics Dashboard")}
            </h1>
            <p className="text-xs text-muted-foreground">Performance Analytics Dashboard</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => downloadResultsCsv(filteredEvaluations, quarter === "all" ? "All" : quarter)}
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">{t("ውጤት አውርድ", "Download Results")}</span>
          </Button>
          <Button variant="outline" size="sm" onClick={() => downloadHistoryCsv(allEvaluations)}>
            <History className="w-4 h-4" />
            <span className="hidden sm:inline">{t("ታሪክ አውርድ", "Download History")}</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
        {allEvaluations.length === 0 ? (
          <Card className="p-10 text-center">
            <BarChart3 className="w-10 h-10 mx-auto text-muted-foreground/50" />
            <p className="mt-3 text-sm font-medium">{t("ምንም ውጤት አልተገኘም", "No result found")}</p>
            <p className="text-xs text-muted-foreground">No evaluation data available yet</p>
          </Card>
        ) : (
          <>
            {/* Quarter filter */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <Select value={quarter} onValueChange={setQuarter}>
                  <SelectTrigger className="w-[210px]" aria-label={t("ሩብ ዓመት", "Quarter")}>
                    <SelectValue placeholder={t("ሩብ ዓመት", "Quarter")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("ሁሉም", "All Quarters")}</SelectItem>
                    {quarters.map((q) => (
                      <SelectItem key={q} value={q}>
                        {q}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Badge variant="secondary">{t(`${uniqueDirectorates} ዳይሬክቶሬቶች`, `${uniqueDirectorates} directorates`)}</Badge>
            </div>

            {filteredEvaluations.length === 0 ? (
              <Card className="p-10 text-center">
                <ClipboardList className="w-10 h-10 mx-auto text-muted-foreground/50" />
                <p className="mt-3 text-sm font-medium">
                  {t("ለተመረጠው ሩብ ዓመት ውጤት አልተገኘም", "No results for the selected quarter")}
                </p>
                <p className="text-xs text-muted-foreground">No results for the selected quarter</p>
              </Card>
            ) : (
              <>
                {/* KPI cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                        <ClipboardList className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-2xl font-bold leading-none">{filteredEvaluations.length}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {t("ጠቅላላ ግምገማዎች", "Total Evaluations")}
                        </div>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                        <Target className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-2xl font-bold leading-none">
                          {avgScore}
                          <span className="text-sm font-normal text-muted-foreground">/100</span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {t("አማካይ ውጤት", "Average Score")}
                        </div>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 shrink-0 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <TrendingUp className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-2xl font-bold leading-none truncate">
                          {top ? top.short : "—"}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {top ? `${top.score}/100 · ` : ""}
                          {t("ከፍተኛ አፈጻጸም", "Highest Performer")}
                        </div>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 shrink-0 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-2xl font-bold leading-none">{needsImprovement}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {t("ማሻሻል የሚያስፈልጋቸው", "Needs Improvement (<50%)")}
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Charts */}
                <div className="grid gap-4 lg:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("የዳይሬክቶሬት ውጤቶች", "Scores by Directorate")}</CardTitle>
                      <CardDescription>Scores by Directorate</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={scoreRows} margin={{ top: 5, right: 8, bottom: 0, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis
                            dataKey="short"
                            angle={-35}
                            textAnchor="end"
                            height={60}
                            interval={0}
                            tick={{ fontSize: 12 }}
                          />
                          <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} width={36} />
                          <Tooltip />
                          <Bar dataKey="score" fill="#2563eb" radius={[6, 6, 0, 0]}>
                            {scoreRows.map((row) => (
                              <Cell key={row.key} fill={barColor(row.percent)} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>{t("የምድብ አማካይ", "Category Averages")}</CardTitle>
                      <CardDescription>Category Averages</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart
                          data={categoryData}
                          layout="vertical"
                          margin={{ top: 5, right: 16, bottom: 0, left: 0 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                          <XAxis
                            type="number"
                            domain={[0, MAX_CATEGORY_SCORE]}
                            allowDecimals={false}
                            tick={{ fontSize: 12 }}
                          />
                          <YAxis type="category" dataKey="key" width={30} tick={{ fontSize: 12 }} />
                          <Tooltip />
                          <Bar dataKey="avg" fill="#2563eb" radius={[0, 6, 6, 0]} barSize={16} />
                        </BarChart>
                      </ResponsiveContainer>
                      <p className="text-xs text-muted-foreground mt-2">
                        {t(
                          "ማሳሰቢያ፡ ከፍተኛ ነጥብ በምድብ ይለያያል (6–15)",
                          "Note: maximum points vary by category (6–15)"
                        )}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Performance history */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("የአፈጻጸም ታሪክ", "Performance History")}</CardTitle>
                    <CardDescription>Performance History Archive</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {historyQuarters.length > 1 ? (
                      <>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {dirsWithData.map((d) => (
                            <Button
                              key={d.key}
                              type="button"
                              variant={selectedDirs.includes(d.key) ? "default" : "outline"}
                              size="sm"
                              className="h-8 text-xs"
                              onClick={() => toggleDir(d.key)}
                            >
                              {d.short}
                            </Button>
                          ))}
                        </div>
                        {selectedDirs.length === 0 ? (
                          <p className="text-sm text-muted-foreground text-center py-10">
                            {t("ለማነጻጸር ዳይሬክቶሬት ይምረጡ", "Select directorates to compare")}
                          </p>
                        ) : (
                          <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={historyData} margin={{ top: 5, right: 16, bottom: 5, left: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="quarter" tick={{ fontSize: 12 }} />
                              <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} width={36} />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 12 }} />
                              {selectedDirs.map((key, i) => {
                                const d = getDirectorate(key);
                                return (
                                  <Line
                                    key={key}
                                    type="monotone"
                                    dataKey={d?.short ?? key}
                                    name={d?.short ?? key}
                                    stroke={LINE_PALETTE[i % LINE_PALETTE.length]}
                                    strokeWidth={2}
                                    dot={{ r: 3 }}
                                    connectNulls
                                  />
                                );
                              })}
                            </LineChart>
                          </ResponsiveContainer>
                        )}
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-10">
                        {t("ቢያንስ 2 ሩብ ዓመት ውጤት ያስፈልጋል", "Need at least 2 quarters of data")}
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Directorate ranking */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("የዳይሬክቶሬቶች ደረጃ", "Directorate Ranking")}</CardTitle>
                    <CardDescription>Directorate Ranking</CardDescription>
                  </CardHeader>
                  <CardContent className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">#</TableHead>
                          <TableHead>{t("ዳይሬክቶሬት", "Directorate")}</TableHead>
                          <TableHead className="hidden md:table-cell">Directorate</TableHead>
                          <TableHead className="text-right">{t("ጠቅላላ", "Total")}</TableHead>
                          <TableHead className="text-right">%</TableHead>
                          <TableHead className="text-right">{t("አዝማሚያ", "Trend")}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {ranking.map((row, idx) => {
                          const dir = getDirectorate(row.key);
                          return (
                            <TableRow key={row.key}>
                              <TableCell className="font-semibold text-muted-foreground">{idx + 1}</TableCell>
                              <TableCell>
                                <span className="font-bold">{row.short}</span>
                                <span className="md:hidden text-xs text-muted-foreground block">
                                  {dir?.nameEn ?? ""}
                                </span>
                              </TableCell>
                              <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                                {dir?.nameEn ?? ""}
                              </TableCell>
                              <TableCell className="text-right font-bold">{row.score}</TableCell>
                              <TableCell
                                className={cn(
                                  "text-right font-semibold",
                                  row.percent >= 75
                                    ? "text-emerald-600"
                                    : row.percent >= 50
                                      ? "text-amber-600"
                                      : "text-red-600"
                                )}
                              >
                                {row.percent}%
                              </TableCell>
                              <TableCell className="text-right">
                                <TrendCell
                                  current={row.score}
                                  previous={prevByKey[row.key]}
                                />
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}
