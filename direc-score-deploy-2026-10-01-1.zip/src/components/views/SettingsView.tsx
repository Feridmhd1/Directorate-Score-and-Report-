"use client";

/**
 * Settings — application preferences (PASSWORD-PROTECTED page):
 *  0. Password gate (default 3472, server-enforced on every change)
 *  1. Appearance (high-contrast dark mode toggle)
 *  2. Language (አማርኛ / English)
 *  3. Bureau logo (custom upload / reset to built-in)
 *  4. Google Drive JSON backup (status, schedule, credentials, run now, local export)
 *  5. Organization name
 *  6. Security passwords (settings page + filing room + automation edit)
 *  7. About (developer credit + version)
 *  8. Report deadline (quarterly submission deadline + reminder fan-out)
 *  9. AI Provider (personal OpenAI-compatible key — browser-stored) +
 *     backup restore + data-storage status (browser vs server)
 */

import { useCallback, useEffect, useRef, useState } from "react";
import type { ChangeEvent } from "react";
import { useTheme } from "next-themes";
import {
  ArrowLeft,
  CalendarClock,
  CheckCircle2,
  Clock,
  CloudUpload,
  Download,
  Globe,
  HardDrive,
  ImagePlus,
  KeyRound,
  Languages,
  Loader2,
  Lock,
  Mail,
  Moon,
  RefreshCw,
  RotateCcw,
  Save,
  Send,
  Settings2,
  ShieldCheck,
  Smartphone,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { LoadingSpinner } from "@/components/shared";
import {
  aiApi,
  backupApi,
  clearSettingsPin,
  deadlineApi,
  getAIProviderConfig,
  getSettingsPin,
  isLocalMode,
  setAIProviderConfig,
  setSettingsPin,
  settingsApi,
} from "@/lib/client-api";
import type { SettingsInput } from "@/lib/client-api";
import { useLang } from "@/lib/i18n";
import type {
  AppSettingsDTO,
  BackupResultDTO,
  BackupStatusDTO,
  DeadlineStateDTO,
  DeliveryLogDTO,
} from "@/lib/types";
import { DEFAULT_QUARTER } from "@/lib/rubric";
import { DEFAULT_ORG_NAME, refreshLogoCache } from "@/lib/branding";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type BackupRunResult = BackupResultDTO & { counts?: Record<string, number> };

/**
 * One-tap presets for the personal AI provider (OpenAI-compatible).
 * Each fills Base URL + Model; the user only pastes their own key.
 */
const AI_PROVIDER_PRESETS: Array<{ name: string; baseUrl: string; model: string }> = [
  {
    name: "OpenRouter",
    baseUrl: "https://openrouter.ai/api/v1",
    model: "meta-llama/llama-3.3-70b-instruct:free",
  },
  {
    name: "Groq",
    baseUrl: "https://api.groq.com/openai/v1",
    model: "llama-3.3-70b-versatile",
  },
  {
    name: "Gemini",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    model: "gemini-2.0-flash",
  },
  {
    name: "OpenAI",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
  },
];

/* ---------------- Small helpers ---------------- */

function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatSize(bytes: number | undefined): string {
  if (!bytes || bytes <= 0) return "";
  const kb = Math.round(bytes / 1024);
  if (kb < 1024) return `${kb} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

/** Status badge for the last backup outcome (theme-token + dark variants) */
function BackupStatusBadge({ status }: { status: string }) {
  const { t } = useLang();
  if (status === "success") {
    return (
      <Badge className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300">
        {t("ተሳክቷል", "Success")}
      </Badge>
    );
  }
  if (status === "failed") {
    return <Badge variant="destructive">{t("አልተሳካም", "Failed")}</Badge>;
  }
  if (status === "running") {
    return (
      <Badge
        variant="outline"
        className="border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
      >
        {t("በሂደት ላይ", "Running")}
      </Badge>
    );
  }
  return <Badge variant="outline">{t("ገና አልተጀመረም", "Idle")}</Badge>;
}

/**
 * Small per-channel result chip for the deadline reminder fan-out
 * (WhatsApp / Telegram / Email) — sent=emerald, failed=red, queued=amber.
 */
function DeadlineDeliveryChip({ log }: { log: DeliveryLogDTO }) {
  const { t } = useLang();
  const channel =
    log.channelType === "whatsapp"
      ? "WhatsApp"
      : log.channelType === "telegram"
        ? "Telegram"
        : log.channelType === "email"
          ? "Email"
          : log.channelType;
  const statusText =
    log.status === "sent"
      ? t("ተልኳል", "Sent")
      : log.status === "failed"
        ? t("አልተላከም", "Failed")
        : log.status === "queued"
          ? t("በመራገብ ላይ", "Queued")
          : log.status;
  if (log.status === "failed") {
    return (
      <Badge variant="destructive" title={`${log.target}${log.detail ? ` — ${log.detail}` : ""}`}>
        {channel} · {statusText}
      </Badge>
    );
  }
  if (log.status === "queued") {
    return (
      <Badge
        variant="outline"
        className="border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
        title={log.target}
      >
        {channel} · {statusText}
      </Badge>
    );
  }
  return (
    <Badge
      className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300"
      title={log.target}
    >
      {channel} · {statusText}
    </Badge>
  );
}

/** Mini stat box (same chip style as the AutomationView KPI grid) */
function StatBox({
  icon: Icon,
  label,
  children,
}: {
  icon: LucideIcon;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border bg-background/60 p-3">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3.5 w-3.5" aria-hidden />
        <span className="text-[11px] font-medium uppercase tracking-wide">{label}</span>
      </div>
      <div className="mt-1.5 text-sm font-semibold leading-snug">{children}</div>
    </div>
  );
}

/* ---------------- Settings password gate ---------------- */

/**
 * The whole Settings page is password-protected (server-enforced on every
 * settings/logo change). Same UX as the automation edit gate.
 */
function SettingsPinGate({ onUnlock }: { onUnlock: (pin: string) => void }) {
  const { t } = useLang();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const value = pin.trim();
    if (!value || busy) return;
    setBusy(true);
    setError("");
    try {
      await settingsApi.verify(value);
      onUnlock(value);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Verification failed");
      setPin("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="glass-card mx-auto max-w-md">
      <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <div>
          <p className="text-sm font-semibold">{t("ቅንብሮች ተቆልፈዋል", "Settings locked")}</p>
          <p className="text-xs text-muted-foreground">
            {t(
              "ይህ ገጽ በይለፍ ቃል ተጠብቋል — ለመቀጠል ይለፍ ቃሉን ያስገቡ።",
              "This page is protected by a password — enter it to continue."
            )}
          </p>
        </div>
        <form onSubmit={submit} className="flex w-full max-w-xs items-center gap-2">
          <Input
            type="password"
            inputMode="numeric"
            autoComplete="off"
            className="h-9 text-center tracking-[0.4em]"
            placeholder="••••"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            aria-label={t("የቅንብሮች ገጽ የይለፍ ቃል", "Settings password")}
            disabled={busy}
          />
          <Button type="submit" className="h-9 shrink-0" disabled={!pin.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <ShieldCheck className="h-4 w-4" aria-hidden />}
            {t("ክፈት", "Unlock")}
          </Button>
        </form>
        {error && (
          <p className="text-xs font-medium text-destructive" role="alert">
            {error}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------------- View ---------------- */

export function SettingsView({ navigate }: { navigate: NavigateFn }) {
  /* Data */
  const [settings, setSettings] = useState<AppSettingsDTO | null>(null);
  const [status, setStatus] = useState<BackupStatusDTO | null>(null);
  const [logoDataUrl, setLogoDataUrl] = useState<string>("");
  const [logoCustom, setLogoCustom] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  /* Dark mode — local state synced from next-themes after mount (no hydration mismatch) */
  const [themeMounted, setThemeMounted] = useState(false);
  const [isDark, setIsDark] = useState(false);

  /* Forms */
  const [orgName, setOrgName] = useState(DEFAULT_ORG_NAME);
  const [orgSaving, setOrgSaving] = useState(false);
  const [driveClientId, setDriveClientId] = useState("");
  const [driveClientSecret, setDriveClientSecret] = useState("");
  const [driveRefreshToken, setDriveRefreshToken] = useState("");
  const [driveFolderId, setDriveFolderId] = useState("");
  const [driveSaving, setDriveSaving] = useState(false);
  const [clearingDrive, setClearingDrive] = useState(false);

  /* Actions */
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [resettingLogo, setResettingLogo] = useState(false);
  const [backupRunning, setBackupRunning] = useState(false);
  const [backupResult, setBackupResult] = useState<BackupRunResult | null>(null);
  const [filingPinInput, setFilingPinInput] = useState("");
  const [automationPinInput, setAutomationPinInput] = useState("");
  const [settingsPinInput, setSettingsPinInput] = useState("");
  const [pinSaving, setPinSaving] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  /* Report deadline (public read; mutations are Settings-PIN protected) */
  const [deadlineState, setDeadlineState] = useState<DeadlineStateDTO | null>(null);
  const [dlQuarter, setDlQuarter] = useState(DEFAULT_QUARTER);
  const [dlDate, setDlDate] = useState("");
  const [dlSaving, setDlSaving] = useState(false);
  const [dlClearing, setDlClearing] = useState(false);
  const [dlSending, setDlSending] = useState(false);
  const [dlDeliveries, setDlDeliveries] = useState<DeliveryLogDTO[] | null>(null);

  /* AI Provider — personal OpenAI-compatible key (full AI intelligence everywhere) */
  const [aiBaseUrl, setAiBaseUrl] = useState("");
  const [aiApiKey, setAiApiKey] = useState("");
  const [aiModel, setAiModel] = useState("");
  const [aiSaving, setAiSaving] = useState(false);
  const [aiTesting, setAiTesting] = useState(false);

  /* Where the data lives (null = still checking) — Netlify keeps it in this browser */
  const [localMode, setLocalMode] = useState<boolean | null>(null);

  /* Restore from a previously downloaded JSON backup */
  const [restoring, setRestoring] = useState(false);
  const restoreInputRef = useRef<HTMLInputElement>(null);

  const { theme, setTheme } = useTheme();
  const { lang, setLang, t } = useLang();

  /* -------- data loading -------- */

  const loadAll = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    try {
      const [settingsRes, logoRes, statusRes] = await Promise.all([
        settingsApi.get(),
        settingsApi.getLogo(),
        backupApi.status(),
      ]);
      setSettings(settingsRes.settings);
      setOrgName(settingsRes.settings.organizationName || DEFAULT_ORG_NAME);
      setLogoDataUrl(logoRes.logoDataUrl);
      setLogoCustom(logoRes.custom);
      setStatus(statusRes);
    } catch {
      setLoadError(true);
      toast({
        title: t("ስህተት", "Error"),
        description: t("ቅንብሮችን መጫን አልተቻለም", "Failed to load settings"),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  /* Restore an unlocked tab session (password already verified earlier) */
  useEffect(() => {
    if (getSettingsPin()) setUnlocked(true);
  }, []);

  /* Detect where the data lives (browser IndexedDB on Netlify vs server DB) */
  useEffect(() => {
    let cancelled = false;
    isLocalMode()
      .then((v) => {
        if (!cancelled) setLocalMode(v);
      })
      .catch(() => {
        if (!cancelled) setLocalMode(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /* Load the personal AI provider config whenever the settings page unlocks */
  useEffect(() => {
    if (!unlocked) return;
    let cancelled = false;
    getAIProviderConfig()
      .then((cfg) => {
        if (cancelled) return;
        setAiBaseUrl(cfg.baseUrl || "");
        setAiApiKey(cfg.apiKey || "");
        setAiModel(cfg.model || "");
      })
      .catch(() => {
        /* keep the empty form */
      });
    return () => {
      cancelled = true;
    };
  }, [unlocked]);

  const unlock = useCallback((pin: string) => {
    setSettingsPin(pin);
    setUnlocked(true);
  }, []);

  const lock = useCallback(() => {
    clearSettingsPin();
    setUnlocked(false);
  }, []);

  /* Dark-mode state syncs from next-themes after mount (theme is undefined
     during SSR) and whenever the theme changes elsewhere */
  useEffect(() => {
    setThemeMounted(true);
    setIsDark(theme === "dark");
  }, [theme]);

  /* Deadline state — public GET; hydrates the form with the saved deadline */
  const loadDeadline = useCallback(async () => {
    try {
      const res = await deadlineApi.get();
      setDeadlineState(res);
      setDlQuarter(res.deadline?.quarter || DEFAULT_QUARTER);
      setDlDate(res.deadline?.date || "");
      setDlDeliveries(null);
    } catch {
      /* silent — the card simply shows the empty form */
    }
  }, []);

  useEffect(() => {
    void loadDeadline();
  }, [loadDeadline]);

  /* Refetch backup status whenever a scheduled backup finishes */
  useEffect(() => {
    const onBackupDone = () => {
      void (async () => {
        try {
          const [settingsRes, statusRes] = await Promise.all([
            settingsApi.get(),
            backupApi.status(),
          ]);
          setSettings(settingsRes.settings);
          setStatus(statusRes);
        } catch {
          /* silent */
        }
      })();
    };
    window.addEventListener("direcscore:backup-done", onBackupDone);
    return () => window.removeEventListener("direcscore:backup-done", onBackupDone);
  }, []);

  /* -------- helpers -------- */

  const refreshBackupStatus = useCallback(async () => {
    try {
      const [settingsRes, statusRes] = await Promise.all([
        settingsApi.get(),
        backupApi.status(),
      ]);
      setSettings(settingsRes.settings);
      setStatus(statusRes);
    } catch {
      /* silent */
    }
  }, []);

  const clearDriveInputs = () => {
    setDriveClientId("");
    setDriveClientSecret("");
    setDriveRefreshToken("");
    setDriveFolderId("");
  };

  /* -------- logo handlers -------- */

  const onLogoFilePicked = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file || uploadingLogo) return;
    setUploadingLogo(true);
    try {
      const res = await settingsApi.uploadLogo(file);
      refreshLogoCache();
      setLogoDataUrl(res.logoDataUrl);
      setLogoCustom(res.custom);
      setSettings((prev) => (prev ? { ...prev, customLogo: res.custom } : prev));
      window.dispatchEvent(new CustomEvent("direcscore:logo-changed"));
      toast({ title: t("ሎጎ ተሻሽሏል", "Logo updated"), description: file.name });
    } catch (err) {
      toast({
        title: t("ሎጎ መስቀል አልተቻለም", "Logo upload failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setUploadingLogo(false);
    }
  };

  const resetLogo = async () => {
    if (resettingLogo) return;
    setResettingLogo(true);
    try {
      const res = await settingsApi.removeLogo();
      refreshLogoCache();
      setLogoDataUrl(res.logoDataUrl);
      setLogoCustom(res.custom);
      setSettings((prev) => (prev ? { ...prev, customLogo: res.custom } : prev));
      window.dispatchEvent(new CustomEvent("direcscore:logo-changed"));
      toast({ title: t("ወደ መነሻ ሎጎ ተመልሷል", "Reset to built-in logo") });
    } catch (err) {
      toast({
        title: t("መመለስ አልተቻለም", "Reset failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setResettingLogo(false);
    }
  };

  /* -------- backup handlers -------- */

  const toggleAutoBackup = async (v: boolean) => {
    if (!settings) return;
    const prev = settings.autoBackupEnabled;
    setSettings({ ...settings, autoBackupEnabled: v }); // optimistic
    try {
      const res = await settingsApi.update({ autoBackupEnabled: v });
      setSettings(res.settings);
      await refreshBackupStatus();
      toast({
        title: v
          ? t("አውቶማቲክ መጠባበቂያ በርቷል", "Automatic backup enabled")
          : t("አውቶማቲክ መጠባበቂያ ጠፍቷል", "Automatic backup disabled"),
      });
    } catch (err) {
      setSettings((s) => (s ? { ...s, autoBackupEnabled: prev } : s)); // revert
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    }
  };

  const changeFrequency = async (v: string) => {
    if (!settings) return;
    const next = v === "daily" ? "daily" : "weekly";
    const prev = settings.backupFrequency;
    setSettings({ ...settings, backupFrequency: next }); // optimistic
    try {
      const res = await settingsApi.update({ backupFrequency: next });
      setSettings(res.settings);
      await refreshBackupStatus();
    } catch (err) {
      setSettings((s) => (s ? { ...s, backupFrequency: prev } : s)); // revert
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    }
  };

  const saveDriveConfig = async () => {
    if (driveSaving) return;
    const payload: SettingsInput = {};
    if (driveClientId.trim()) payload.driveClientId = driveClientId.trim();
    if (driveClientSecret.trim()) payload.driveClientSecret = driveClientSecret.trim();
    if (driveRefreshToken.trim()) payload.driveRefreshToken = driveRefreshToken.trim();
    if (driveFolderId.trim()) payload.driveFolderId = driveFolderId.trim();
    if (Object.keys(payload).length === 0) {
      toast({
        title: t("ምንም ለመቀምጠት አልተሞላም", "Nothing to save"),
        description: t(
          "ቢያንስ አንድ መስክ ይሙሉ",
          "Fill at least one field — blank fields keep the saved values"
        ),
      });
      return;
    }
    setDriveSaving(true);
    try {
      const res = await settingsApi.update(payload);
      setSettings(res.settings);
      clearDriveInputs(); // secrets are write-only — never echoed back
      await refreshBackupStatus();
      toast({ title: t("የDrive ቅንብሮች ተቀምጧል", "Drive configuration saved") });
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setDriveSaving(false);
    }
  };

  const clearDriveConfig = async () => {
    if (clearingDrive) return;
    if (
      !window.confirm(
        t(
          "የተቀመጡ የGoogle Drive ቅንብሮችን ማጽዳት እርግጠኛ ነዎት?",
          "Clear the saved Google Drive configuration?"
        )
      )
    ) {
      return;
    }
    setClearingDrive(true);
    try {
      const res = await settingsApi.update({ clearDriveConfig: true });
      setSettings(res.settings);
      clearDriveInputs();
      await refreshBackupStatus();
      toast({ title: t("የDrive ቅንብሮች ተጽድተዋል", "Drive configuration cleared") });
    } catch (err) {
      toast({
        title: t("ማጽዳት አልተቻለም", "Clear failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setClearingDrive(false);
    }
  };

  const runBackupNow = async () => {
    if (backupRunning) return;
    setBackupRunning(true);
    setBackupResult(null);
    try {
      const res = await backupApi.run();
      setBackupResult(res);
      if (res.ok) {
        toast({
          title: t("መጠባበቂያ ተጠናቋል", "Backup completed"),
          description: `${res.fileName}${res.sizeBytes ? ` · ${formatSize(res.sizeBytes)}` : ""}`,
        });
      } else {
        toast({
          title: t("መጠባበቂያ አልተሳካም", "Backup failed"),
          description: res.detail || "Please check the Drive configuration",
          variant: "destructive",
        });
      }
      await refreshBackupStatus();
    } catch (err) {
      toast({
        title: t("መጠባበቂያ አልተሳካም", "Backup failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
      await refreshBackupStatus();
    } finally {
      setBackupRunning(false);
    }
  };

  /* -------- AI provider (personal key) + backup restore -------- */

  const applyAiPreset = (preset: (typeof AI_PROVIDER_PRESETS)[number]) => {
    setAiBaseUrl(preset.baseUrl);
    setAiModel(preset.model);
    toast({
      title: `${preset.name} — ${t("ቅድመ-ቅንብር ተሞልቷል", "preset filled")}`,
      description: t(
        "የAPI ቁልፍዎን አስገብተው አስቀምጡ።",
        "Now paste your API key and save."
      ),
    });
  };

  const saveAiProvider = async () => {
    if (aiSaving) return;
    setAiSaving(true);
    try {
      await setAIProviderConfig({
        baseUrl: aiBaseUrl.trim(),
        apiKey: aiApiKey.trim(),
        model: aiModel.trim(),
      });
      toast({
        title: t("AI አገልጋይ ተቀምጧል", "AI provider saved"),
        description: t(
          "ከእንግዲህ ሁሉም AI ተግባራት በራስዎ አገልጋይ ይሠራሉ።",
          "All AI features now run through your personal provider."
        ),
      });
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : t("እባክዎ እንደገና ይሞክሩ።", "Please try again"),
        variant: "destructive",
      });
    } finally {
      setAiSaving(false);
    }
  };

  const testAiProvider = async () => {
    if (aiTesting) return;
    setAiTesting(true);
    try {
      const res = await aiApi.testProvider();
      if (res.ok) {
        toast({
          title: t("ተሳክቷል — AI አገልጋዩ ይሠራል", "Success — the AI provider works"),
          description: [res.model, res.reply].filter(Boolean).join(" · ") || undefined,
        });
      } else {
        toast({
          title: t("ሙከራ አልተሳካም", "Test failed"),
          description: res.error || t("ምክንያት አልተሰጠም።", "No reason was returned."),
          variant: "destructive",
        });
      }
    } finally {
      setAiTesting(false);
    }
  };

  const clearAiProvider = async () => {
    setAiBaseUrl("");
    setAiApiKey("");
    setAiModel("");
    try {
      await setAIProviderConfig({ baseUrl: "", apiKey: "", model: "" });
      toast({
        title: t("AI አገልጋይ ተጽድቷል", "AI provider cleared"),
        description: t(
          "እስኪ አዲስ ቁልፍ ስታስገባ ከመስመር ውጭ ትንተና ይጠቀማል።",
          "Until a new key is added, offline analysis is used."
        ),
      });
    } catch (err) {
      toast({
        title: t("ማጽዳት አልተቻለም", "Clear failed"),
        description: err instanceof Error ? err.message : t("እባክዎ እንደገና ይሞክሩ።", "Please try again"),
        variant: "destructive",
      });
    }
  };

  const onRestoreFilePicked = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file || restoring) return;
    setRestoring(true);
    try {
      const res = await backupApi.restore(file);
      toast({
        title: t("መልስ አስገባ ተጠናቋል", "Restore completed"),
        description: t(
          `${res.collections} የመረጃ ስብስቦች እና ${res.files} ፋይሎች ተመልሰዋል።`,
          `${res.collections} collections and ${res.files} files restored.`
        ),
      });
      await refreshBackupStatus();
    } catch (err) {
      toast({
        title: t("መልስ አስገባ አልተሳካል", "Restore failed"),
        description:
          err instanceof Error ? err.message : t("ትክክለኛ የJSON መጠባበቂያ ፋይል ይምረጡ።", "Pick a valid JSON backup file."),
        variant: "destructive",
      });
    } finally {
      setRestoring(false);
    }
  };

  /* -------- report submission deadline -------- */

  const saveDeadline = async () => {
    if (dlSaving) return;
    const quarter = dlQuarter.trim();
    const date = dlDate.trim();
    if (!quarter || !date) {
      toast({
        title: t("መረጃ ያስፈልጋል", "Missing information"),
        description: t("ሩብ ዓመት እና መጣሪያ ቀን ያስገቡ", "Enter both the quarter and the deadline date"),
        variant: "destructive",
      });
      return;
    }
    setDlSaving(true);
    try {
      await deadlineApi.set(quarter, date);
      toast({ title: t("መጣሪያ ቀን ተቀምጧል", "Deadline saved") });
      await loadDeadline();
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setDlSaving(false);
    }
  };

  const clearDeadline = async () => {
    if (dlClearing) return;
    if (!window.confirm(t("የሪፖርት መጣሪያ ቀን ማጽዳት እርግጠኛ ነዎት?", "Clear the report deadline?"))) return;
    setDlClearing(true);
    try {
      await deadlineApi.clear();
      toast({ title: t("መጣሪያ ቀን ተጽድቷል", "Deadline cleared") });
      await loadDeadline();
    } catch (err) {
      toast({
        title: t("ማጽዳት አልተቻለም", "Clear failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setDlClearing(false);
    }
  };

  const sendDeadlineReminder = async () => {
    if (dlSending) return;
    setDlSending(true);
    setDlDeliveries(null);
    try {
      const res = await deadlineApi.remindNow();
      setDlDeliveries(res.deliveries);
      toast({ title: t("አስታዋሻ ተልኳል", "Reminder sent") });
    } catch (err) {
      toast({
        title: t("አስታዋሻ መላክ አልተቻለም", "Could not send the reminder"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setDlSending(false);
    }
  };

  /* -------- organization name -------- */

  const saveOrgName = async () => {
    if (orgSaving) return;
    const name = orgName.trim();
    if (!name) {
      toast({
        title: t("ስም ያስፈልጋል", "Name required"),
        description: t("የድርጅቱ ስም ባዶ መሆን የለበትም", "Organization name cannot be empty"),
      });
      return;
    }
    setOrgSaving(true);
    try {
      const res = await settingsApi.update({ organizationName: name });
      setSettings(res.settings);
      setOrgName(res.settings.organizationName);
      toast({ title: t("የድርጅቱ ስም ተቀምጧል", "Organization name saved") });
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setOrgSaving(false);
    }
  };

  /* -------- security PINs (settings page + filing room + automation edit) -------- */

  const savePins = async () => {
    if (pinSaving) return;
    const filing = filingPinInput.trim();
    const automation = automationPinInput.trim();
    const settings = settingsPinInput.trim();
    if (!filing && !automation && !settings) {
      toast({
        title: t("ምንም ለመቀምጠት አልተሞላም", "Nothing to save"),
        description: t(
          "ቢያንስ አንድ መስክ ይሙሉ",
          "Fill at least one PIN — blank fields keep the saved values"
        ),
      });
      return;
    }
    if ((filing && filing.length < 4) || (automation && automation.length < 4) || (settings && settings.length < 4)) {
      toast({
        title: t("የይለፍ ቃል አጭር ነው", "Password too short"),
        description: t("ቢያንስ 4 ቁምፊዎችን ይጠቀሙ", "Use at least 4 characters"),
        variant: "destructive",
      });
      return;
    }
    setPinSaving(true);
    try {
      const payload: SettingsInput = {};
      if (filing) payload.filingPin = filing;
      if (automation) payload.automationPin = automation;
      if (settings) payload.settingsPin = settings;
      await settingsApi.update(payload);
      setFilingPinInput("");
      setAutomationPinInput("");
      setSettingsPinInput("");
      if (settings) setSettingsPin(settings); // keep this tab unlocked with the new password
      toast({
        title: t("የደህንነት ይለፍ ቃሎች ተቀይረዋል", "Security passwords updated"),
        description:
          "Use the new password next time you unlock settings, the filing room or automation editing.",
      });
    } catch (err) {
      toast({
        title: t("ማስቀመጥ አልተሳካል", "Save failed"),
        description: err instanceof Error ? err.message : "Please try again",
        variant: "destructive",
      });
    } finally {
      setPinSaving(false);
    }
  };

  /* -------- render -------- */

  const header = (
    <header className="glass-card sticky top-0 z-20 border-b">
      <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0"
          onClick={() => navigate("home")}
          aria-label={t("ተመለስ", "Back to dashboard")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-sm">
          <Settings2 className="h-5 w-5" aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-bold leading-tight">{t("ቅንብሮች", "Settings")}</h1>
          <p className="truncate text-xs text-muted-foreground">
            {t("የመተግበሪያ ማስተካከያዎች", "Application preferences")}
          </p>
        </div>
        {unlocked && (
          <Button
            variant="outline"
            size="sm"
            className="h-9 shrink-0"
            onClick={lock}
            aria-label={t("ቅንብሮችን ተው", "Lock settings")}
            title={t("ቅንብሮችን ተው", "Lock settings")}
          >
            <Lock className="h-4 w-4" aria-hidden />
            {t("ተው", "Lock")}
          </Button>
        )}
      </div>
    </header>
  );

  if (!unlocked) {
    return (
      <div className="flex-1">
        {header}
        <div className="mx-auto w-full max-w-3xl p-4 sm:p-6">
          <SettingsPinGate onUnlock={unlock} />
          <p className="mx-auto mt-4 max-w-md text-center text-[11px] text-muted-foreground">
            {t(
              "ቅንብሮቹ ገጽ በይለፍ ቃል ተጠብቋል። ነባሩ ይለፍ ቃል 3472 ነው።",
              "The Settings page is protected by a password. The default password is 3472."
            )}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1">
      {header}

      {loading ? (
        <div className="flex justify-center py-24" role="status" aria-live="polite">
          <LoadingSpinner />
        </div>
      ) : loadError || !settings ? (
        <div className="mx-auto max-w-3xl p-4 sm:p-6">
          <Card className="glass-card">
            <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
              <p className="text-sm font-medium">{t("ቅንብሮችን መጫን አልተቻለም", "Failed to load settings")}</p>
              <Button onClick={() => void loadAll()} variant="outline" className="h-9">
                <RefreshCw className="h-4 w-4" aria-hidden />
                {t("እንደገና ሞክር", "Retry")}
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="mx-auto w-full max-w-3xl space-y-6 p-4 sm:p-6">
          {/* ---------- 1. Appearance ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t("መልክ", "Appearance")}</CardTitle>
              <CardDescription className="text-xs">
                {t("የማሳያ ሁነታ ምርጫ", "Display mode preference")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between gap-4">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted">
                    <Moon className="h-5 w-5" aria-hidden />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{t("ጨለማ ሁነታ", "Dark mode")}</p>
                    <p className="text-xs text-muted-foreground">
                      {t(
                        "በሁሉም ገጾች ላይ ከፍተኛ ንፅፅር ያለው ጨለማ ትርኢት",
                        "High-contrast dark theme across all pages"
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <Badge variant="outline">{isDark ? t("🌙 ጨለማ", "🌙 Dark") : t("☀ ቀላል", "☀ Light")}</Badge>
                  {themeMounted ? (
                    <Switch
                      checked={isDark}
                      onCheckedChange={(v) => {
                        setIsDark(v);
                        setTheme(v ? "dark" : "light");
                      }}
                      aria-label={t("ጨለማ ሁነታ", "Toggle dark mode")}
                    />
                  ) : (
                    <div className="h-6 w-11 animate-pulse rounded-full bg-muted" aria-hidden />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ---------- 2. Language (አማርኛ / English) ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t("ቋንቋ", "Language")}</CardTitle>
              <CardDescription className="text-xs">
                {t("የማሳያ ቋንቋ ምርጫ", "Interface language preference")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between gap-4">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted">
                    <Languages className="h-5 w-5" aria-hidden />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium">አማርኛ / English</p>
                    <p className="text-xs text-muted-foreground">
                      {t("በሙሉ መተግበሪያው የሚያሳየው ቋንቋ", "Language used across the application")}
                    </p>
                  </div>
                </div>
                <div
                  className="flex shrink-0 gap-1.5"
                  role="group"
                  aria-label={t("ቋንቋ", "Language")}
                >
                  <Button
                    type="button"
                    size="sm"
                    variant={lang === "am" ? "default" : "outline"}
                    aria-pressed={lang === "am"}
                    className="h-9 px-3 text-xs font-semibold"
                    onClick={() => setLang("am")}
                  >
                    አማርኛ
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={lang === "en" ? "default" : "outline"}
                    aria-pressed={lang === "en"}
                    className="h-9 px-3 text-xs font-semibold"
                    onClick={() => setLang("en")}
                  >
                    English
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ---------- 3. Bureau logo ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t("የቢሮ ሎጎ", "Bureau Logo")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                {logoDataUrl ? (
                  <img
                    src={logoDataUrl}
                    alt="Bureau logo"
                    className="h-20 w-20 shrink-0 rounded-lg border bg-white object-contain p-1"
                  />
                ) : (
                  <div
                    className="flex h-20 w-20 shrink-0 items-center justify-center rounded-lg border bg-white text-muted-foreground"
                    aria-hidden
                  >
                    <ImagePlus className="h-6 w-6" />
                  </div>
                )}
                <div className="min-w-0 flex-1 space-y-3">
                  <div className="flex items-center gap-2">
                    {logoCustom ? (
                      <Badge className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300">
                        {t("የተሰቀል", "Custom")}
                      </Badge>
                    ) : (
                      <Badge variant="outline">{t("ነባሪ", "Default")}</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {t(
                      "ሎጎው በራስጌዎች፣ በይፋዊ ፖርታሎች እና በሁሉም PDF ሪፖርቶች ላይ ይታያል",
                      "The logo appears in headers, public portals and all PDF exports"
                    )}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => void onLogoFilePicked(e)}
                      aria-label={t("የሎጎ ፋይል ምረጥ", "Choose logo file")}
                    />
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingLogo}
                      className="h-9"
                    >
                      {uploadingLogo ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <ImagePlus className="h-4 w-4" aria-hidden />
                      )}
                      {t("ሎጎ ስቀል", "Upload logo")}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => void resetLogo()}
                      disabled={resettingLogo || !logoCustom}
                      className="h-9"
                    >
                      {resettingLogo ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <RotateCcw className="h-4 w-4" aria-hidden />
                      )}
                      {t("መነሻ ሎጎ", "Reset to built-in")}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ---------- Report deadline ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <CalendarClock className="h-4 w-4 text-amber-600 dark:text-amber-400" aria-hidden />
                {t("የሪፖርት መጣሪያ ቀን", "Report Deadline")}
              </CardTitle>
              <CardDescription className="text-xs">
                {t(
                  "ዳይሬክቶሬቶች ሪፖርት ከመጣሪያ ቀን በፊት እንዲያስገቡ አስታውስ",
                  "Remind directorates to submit quarterly reports before the deadline"
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Quarter + date + save */}
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div className="space-y-1.5 sm:w-44 sm:shrink-0">
                  <Label htmlFor="deadline-quarter">{t("ሩብ ዓመት", "Quarter")}</Label>
                  <Input
                    id="deadline-quarter"
                    value={dlQuarter}
                    onChange={(e) => setDlQuarter(e.target.value)}
                    placeholder="Q3-2018 EFY"
                    aria-label={t("የሪፖርት ሩብ ዓመት", "Report quarter")}
                    maxLength={24}
                    className="h-9"
                  />
                </div>
                <div className="space-y-1.5 sm:w-44 sm:shrink-0">
                  <Label htmlFor="deadline-date">{t("መጣሪያ ቀን", "Deadline date")}</Label>
                  <Input
                    id="deadline-date"
                    type="date"
                    value={dlDate}
                    onChange={(e) => setDlDate(e.target.value)}
                    aria-label={t("የሪፖርት መጣሪያ ቀን", "Report deadline date")}
                    className="h-9"
                  />
                </div>
                <Button onClick={() => void saveDeadline()} disabled={dlSaving} className="h-9 shrink-0">
                  {dlSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Save className="h-4 w-4" aria-hidden />
                  )}
                  {t("አስቀምጥ", "Save")}
                </Button>
              </div>

              {/* Current deadline status */}
              {deadlineState?.deadline && (
                <div className="space-y-2.5 rounded-xl border bg-background/60 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline">{deadlineState.deadline.quarter}</Badge>
                    <span className="text-sm font-semibold">{deadlineState.deadline.date}</span>
                    {deadlineState.daysLeft !== null && (
                      <Badge
                        variant="outline"
                        className={
                          deadlineState.daysLeft <= 7
                            ? "border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
                            : "border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300"
                        }
                      >
                        {deadlineState.daysLeft < 0
                          ? t("ጊዜው አልፏል", "Past due")
                          : deadlineState.daysLeft === 1
                            ? t("1 ቀን ቀርቷል", "1 day left")
                            : t(
                                `${deadlineState.daysLeft} ቀናት ቀርተዋል`,
                                `${deadlineState.daysLeft} days left`
                              )}
                      </Badge>
                    )}
                  </div>
                  {deadlineState.missing.length > 0 ? (
                    <div className="space-y-1.5">
                      <p className="text-xs font-medium text-muted-foreground">
                        {t(
                          `${deadlineState.missing.length} ዳይሬክቶሬቶች ሪፖርት አልገቡም`,
                          `${deadlineState.missing.length} directorates have not submitted`
                        )}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {deadlineState.missing.map((m) => (
                          <Badge
                            key={m.key}
                            variant="outline"
                            className="px-1.5 py-0 text-[10px]"
                            title={m.name}
                          >
                            {m.short}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-300">
                      <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                      {t("ሁሉም ዳይሬክቶሬቶች ሪፖርት አግብተዋል", "All directorates have submitted")}
                    </p>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => void clearDeadline()}
                    disabled={dlClearing}
                    className="h-8 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    {dlClearing ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      <Trash2 className="h-4 w-4" aria-hidden />
                    )}
                    {t("መጣሪያ ቀን አጽዳ", "Clear deadline")}
                  </Button>
                </div>
              )}

              {/* Reminder now + built-in automation note */}
              <div className="space-y-2 rounded-xl border bg-background/60 p-3">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <Button
                    onClick={() => void sendDeadlineReminder()}
                    disabled={dlSending}
                    className="h-9 shrink-0"
                  >
                    {dlSending ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      <Send className="h-4 w-4" aria-hidden />
                    )}
                    {t("አስታዋሻ አሁን ላክ", "Send reminder now")}
                  </Button>
                  <p className="min-w-0 text-xs text-muted-foreground">
                    {t(
                      "በራስ-ሰር እለታዊ አስታዋሻ በ7 ቀናት ውስጥ ይላካል።",
                      "An automatic daily reminder is sent within the last 7 days."
                    )}
                  </p>
                </div>
                {dlDeliveries && dlDeliveries.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {dlDeliveries.map((log) => (
                      <DeadlineDeliveryChip key={log.id} log={log} />
                    ))}
                  </div>
                )}
                {dlDeliveries && dlDeliveries.length === 0 && (
                  <p className="text-xs text-muted-foreground">
                    {t("ንቁ የአስተላለፍ መስመር የለም", "No enabled delivery channels")}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* ---------- 3. Google Drive JSON backup ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">
                {t("የGoogle Drive መጠባበቂያ", "Google Drive JSON Backup")}
              </CardTitle>
              <CardDescription className="text-xs">
                {t(
                  "ሁሉንም መረጃ በJSON ወደ Google Drive ያስቀምጡ",
                  "Store a full JSON snapshot of the app in Google Drive"
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Data storage status — where the data actually lives in this session */}
              <div className="flex items-start gap-2.5 rounded-lg border bg-muted/30 p-3 text-xs">
                <HardDrive className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                {localMode === null ? (
                  <span className="text-muted-foreground">
                    {t("የውሂብ ማከማቻ በመፈተሽ ላይ…", "Checking data storage…")}
                  </span>
                ) : localMode ? (
                  <span className="min-w-0">
                    <span className="font-semibold">
                      {t("ውሂብ: ይህ ብራውዘር (Netlify mode)", "Data: this browser (Netlify mode)")}
                    </span>{" — "}
                    {t(
                      "መጠባበቂያ በየጊዜው ያውርዱ።",
                      "download backups regularly."
                    )}
                  </span>
                ) : (
                  <span className="min-w-0">
                    <span className="font-semibold">
                      {t("ውሂብ: የሰርቨር ዳታቤዝ", "Data: server database")}
                    </span>
                  </span>
                )}
              </div>

              {/* Status grid */}
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                <StatBox icon={RefreshCw} label={t("አውቶ መጠባበቂያ", "Auto")}>
                  <span
                    className={cn(
                      status?.autoBackupEnabled
                        ? "text-emerald-600 dark:text-emerald-300"
                        : "text-muted-foreground"
                    )}
                  >
                    {status?.autoBackupEnabled ? t("በርቷል", "On") : t("ጠፍቷል", "Off")}
                  </span>
                </StatBox>
                <StatBox icon={HardDrive} label="Google Drive">
                  {status?.driveConfigured ? (
                    <Badge className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300">
                      ✓ {t("ተዋቅሯል", "Configured")}
                    </Badge>
                  ) : (
                    <Badge
                      variant="outline"
                      className="border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
                    >
                      ⚠ {t("አልተዋቀረም", "Not configured")}
                    </Badge>
                  )}
                </StatBox>
                <StatBox icon={Clock} label={t("የመጨረሻ", "Last backup")}>
                  <div className="space-y-1">
                    <span>{formatDateTime(status?.lastBackupAt)}</span>
                    <div>
                      <BackupStatusBadge status={status?.lastBackupStatus ?? "idle"} />
                    </div>
                    {status?.lastBackupDetail ? (
                      <p
                        className="truncate text-[11px] font-normal text-muted-foreground"
                        title={status.lastBackupDetail}
                      >
                        {status.lastBackupDetail}
                      </p>
                    ) : null}
                  </div>
                </StatBox>
                <StatBox icon={CalendarClock} label={t("ቀጣይ ቀን", "Next due")}>
                  <span>{formatDateTime(status?.nextBackupDueAt)}</span>
                </StatBox>
              </div>

              {/* Schedule controls */}
              <div className="flex flex-col gap-4 rounded-xl border bg-background/60 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <Label className="text-sm font-medium">
                    {t("ለሳምንት በሳምንት አውቶማቲክ መጠባበቂያ", "Automatic weekly backup")}
                  </Label>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t("መተግበሪያው በሚከፈትበት ጊዜ ይሰራል", "Runs while the app is open")}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-3">
                  <Select
                    value={settings.backupFrequency === "daily" ? "daily" : "weekly"}
                    onValueChange={(v) => void changeFrequency(v)}
                  >
                    <SelectTrigger className="h-9 w-[150px]" aria-label={t("ድግግሞሽ", "Backup frequency")}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">{t("ሳምንታዊ", "Weekly")}</SelectItem>
                      <SelectItem value="daily">{t("ዕለታዊ", "Daily")}</SelectItem>
                    </SelectContent>
                  </Select>
                  <Switch
                    checked={settings.autoBackupEnabled}
                    onCheckedChange={(v) => void toggleAutoBackup(v)}
                    aria-label={t("አውቶማቲክ መጠባበቂያ", "Toggle automatic backup")}
                  />
                </div>
              </div>

              {/* Drive credentials */}
              <div className="space-y-3 rounded-xl border bg-background/60 p-4">
                <p className="text-sm font-medium">{t("የDrive ቅንብሮች", "Drive configuration")}</p>
                <p className="text-xs text-muted-foreground">
                  {t(
                    "Google Cloud OAuth Desktop app credentials + refresh token. ቦዝኖ ካለ የተቀመጠው ይቀራል",
                    "Google Cloud OAuth Desktop app credentials + refresh token. Saved values are kept when left blank"
                  )}
                </p>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="drive-client-id">Client ID</Label>
                    <Input
                      id="drive-client-id"
                      type="password"
                      autoComplete="off"
                      placeholder="…apps.googleusercontent.com"
                      value={driveClientId}
                      onChange={(e) => setDriveClientId(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="drive-client-secret">Client Secret</Label>
                    <Input
                      id="drive-client-secret"
                      type="password"
                      autoComplete="off"
                      placeholder="GOCSPX-…"
                      value={driveClientSecret}
                      onChange={(e) => setDriveClientSecret(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="drive-refresh-token">Refresh Token</Label>
                    <Input
                      id="drive-refresh-token"
                      type="password"
                      autoComplete="off"
                      placeholder="1//0g…"
                      value={driveRefreshToken}
                      onChange={(e) => setDriveRefreshToken(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="drive-folder-id">
                      Folder ID ({t("አማራጭ", "optional")})
                    </Label>
                    <Input
                      id="drive-folder-id"
                      type="password"
                      autoComplete="off"
                      placeholder="1AbC…"
                      value={driveFolderId}
                      onChange={(e) => setDriveFolderId(e.target.value)}
                    />
                  </div>
                </div>
                <Button onClick={() => void saveDriveConfig()} disabled={driveSaving} className="h-9">
                  {driveSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Save className="h-4 w-4" aria-hidden />
                  )}
                  {t("አስቀምጥ", "Save")}
                </Button>
              </div>

              {/* Action row */}
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  onClick={() => void runBackupNow()}
                  disabled={backupRunning}
                  className="h-9"
                >
                  {backupRunning ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <CloudUpload className="h-4 w-4" aria-hidden />
                  )}
                  {t("አሁን መጠባበቂያ", "Back up now")}
                </Button>
                <Button variant="outline" asChild className="h-9">
                  <a href={backupApi.exportUrl} download aria-label={t("JSON መጠባበቂያ አውርድ", "Download JSON backup")}>
                    <Download className="h-4 w-4" aria-hidden />
                    {t("ወደ መሣሪያ አውርድ", "Download JSON backup")}
                  </a>
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => void clearDriveConfig()}
                  disabled={clearingDrive}
                  className="h-9 text-destructive hover:bg-destructive/10 hover:text-destructive"
                >
                  {clearingDrive ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Trash2 className="h-4 w-4" aria-hidden />
                  )}
                  {t("የDrive ቅንብሮችን አጽዳ", "Clear Drive config")}
                </Button>
              </div>

              {/* Restore from a previously downloaded backup (imports browser data) */}
              <div className="space-y-2 rounded-xl border border-dashed p-4">
                <p className="text-sm font-medium">{t("መልስ አስገባ", "Restore from backup")}</p>
                <input
                  ref={restoreInputRef}
                  type="file"
                  accept="application/json,.json"
                  className="hidden"
                  aria-label={t("የJSON መጠባበቂያ ፋይል ይምረጡ", "Choose a JSON backup file")}
                  onChange={(e) => void onRestoreFilePicked(e)}
                />
                <div>
                  <Button
                    variant="outline"
                    onClick={() => restoreInputRef.current?.click()}
                    disabled={restoring}
                    className="h-9"
                  >
                    {restoring ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      <Upload className="h-4 w-4" aria-hidden />
                    )}
                    {t("መልስ አስገባ", "Restore from backup")}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  {t(
                    "ከዚህ ቀደም ካወረዱት የJSON መጠባበቂያ ፋይል ሁሉንም መረጃ ወደዚህ ብራውዘር ይመልሳል።",
                    "Imports everything from a previously downloaded JSON backup into this browser."
                  )}
                </p>
              </div>

              {/* Dismissible inline result (Drive web view link is clickable here) */}
              {backupResult && (
                <div className="flex items-start justify-between gap-3 rounded-lg border bg-background/60 p-3 text-xs">
                  <div className="min-w-0 space-y-0.5">
                    <p className={cn("font-medium", backupResult.ok ? "text-emerald-600 dark:text-emerald-300" : "text-destructive")}>
                      {backupResult.ok
                        ? `✓ ${backupResult.fileName}${backupResult.sizeBytes ? ` · ${formatSize(backupResult.sizeBytes)}` : ""}`
                        : `✗ ${t("መጠባበቂያ አልተሳካም", "Backup failed")}`}
                    </p>
                    {backupResult.ok && backupResult.webViewLink ? (
                      <a
                        href={backupResult.webViewLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-primary underline underline-offset-2"
                      >
                        {t("በGoogle Drive ይመልከቱ", "View in Google Drive ↗")}
                      </a>
                    ) : null}
                    {!backupResult.ok && backupResult.detail ? (
                      <p className="text-muted-foreground" title={backupResult.detail}>
                        {backupResult.detail}
                      </p>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    onClick={() => setBackupResult(null)}
                    aria-label={t("ዝጋ", "Dismiss backup result")}
                    className="rounded p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                  >
                    <X className="h-4 w-4" aria-hidden />
                  </button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* ---------- 4. Organization name ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t("የድርጅቱ ስም", "Organization name")}</CardTitle>
              <CardDescription className="text-xs">
                {t("በራስጌዎች እና በPDF ሪፖርቶች ላይ የሚታይ ስም", "Shown in headers and PDF exports")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <Input
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  placeholder={DEFAULT_ORG_NAME}
                  aria-label={t("የድርጅቱ ስም", "Organization name")}
                  maxLength={120}
                  className="h-9 sm:flex-1"
                />
                <Button onClick={() => void saveOrgName()} disabled={orgSaving} className="h-9">
                  {orgSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Save className="h-4 w-4" aria-hidden />
                  )}
                  {t("አስቀምጥ", "Save")}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* ---------- 6. Security passwords ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t("ደህንነት", "Security passwords")}</CardTitle>
              <CardDescription className="text-xs">
                {t(
                  "የቅንብሮች ገጽ፣ የሰነድ ፋይሊንግ ክፍል እና የአውቶማሽን ማስተካከያ የይለፍ ቃሎች — ባዶ ከተተወ የተቀመጠው ይቀራል።",
                  "Protect the settings page, document filing room and automation editing — blank keeps the saved value."
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label htmlFor="settings-pin-input">
                    {t("የቅንብሮች ገጽ የይለፍ ቃል", "Settings page password")}
                  </Label>
                  <Input
                    id="settings-pin-input"
                    type="password"
                    autoComplete="new-password"
                    className="h-9"
                    placeholder="Default 3472"
                    value={settingsPinInput}
                    onChange={(e) => setSettingsPinInput(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="filing-pin-input">{t("የፋይሊንግ ክፍል የይለፍ ቃል", "Filing room password")}</Label>
                  <Input
                    id="filing-pin-input"
                    type="password"
                    autoComplete="new-password"
                    className="h-9"
                    placeholder="Default 3472"
                    value={filingPinInput}
                    onChange={(e) => setFilingPinInput(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="automation-pin-input">
                    {t("የአውቶማሽን ማስተካከያ የይለፍ ቃል", "Automation edit password")}
                  </Label>
                  <Input
                    id="automation-pin-input"
                    type="password"
                    autoComplete="new-password"
                    className="h-9"
                    placeholder="Default 3472"
                    value={automationPinInput}
                    onChange={(e) => setAutomationPinInput(e.target.value)}
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                The settings password protects this page (every change is verified server-side). The
                automation password protects every WhatsApp / Telegram / Email delivery-channel
                change. Passwords are stored server-side and never shown again.
              </p>
              <Button onClick={() => void savePins()} disabled={pinSaving} className="h-9">
                {pinSaving ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <Save className="h-4 w-4" aria-hidden />
                )}
                {t("አስቀምጥ", "Save passwords")}
              </Button>
            </CardContent>
          </Card>

          {/* ---------- AI Provider (personal key — full intelligence everywhere) ---------- */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <KeyRound className="h-4 w-4 text-primary" aria-hidden />
                {t("AI አገልጋይ", "AI Provider")}
              </CardTitle>
              <CardDescription className="text-xs">
                {t(
                  "አፕሊኬሽኑ በNetlify ላይ ያለ ሰርቨር AI ይሠራል (ከመስመር ውጭ ትንተና)። ነጻ የሆነ የራስዎን AI ቁልፍ በማከል ሙሉ የAI ብልህነት በየቦታው ይገኛል።",
                  "The app works on Netlify without any server AI (offline analysis). Adding a free personal AI key enables full intelligence everywhere."
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Free provider options + base URLs */}
              <div className="space-y-1.5 rounded-xl border bg-background/60 p-3 text-xs">
                <p className="text-sm font-medium">{t("ነጻ አማራጮች", "Free options")}</p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>
                    <span className="font-semibold text-foreground">OpenRouter</span>{" "}
                    <a
                      href="https://openrouter.ai/keys"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-2"
                    >
                      openrouter.ai/keys
                    </a>{" "}
                    · {t("ነጻ ሞዴሎች", "free models")} · <code className="text-[10px]">https://openrouter.ai/api/v1</code>
                  </li>
                  <li>
                    <span className="font-semibold text-foreground">Groq</span>{" "}
                    <a
                      href="https://console.groq.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-2"
                    >
                      console.groq.com
                    </a>{" "}
                    · <code className="text-[10px]">https://api.groq.com/openai/v1</code>
                  </li>
                  <li>
                    <span className="font-semibold text-foreground">Google Gemini</span>{" "}
                    <a
                      href="https://aistudio.google.com/apikey"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-2"
                    >
                      aistudio.google.com/apikey
                    </a>{" "}
                    · <code className="text-[10px]">https://generativelanguage.googleapis.com/v1beta/openai</code>
                  </li>
                  <li>
                    <span className="font-semibold text-foreground">OpenAI</span>{" "}
                    <a
                      href="https://platform.openai.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-2"
                    >
                      platform.openai.com
                    </a>{" "}
                    · <code className="text-[10px]">https://api.openai.com/v1</code>
                  </li>
                </ul>
              </div>

              {/* Presets — fill Base URL + Model in one tap */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-medium text-muted-foreground">
                  {t("ቅድመ-ቅንብሮች፦", "Presets:")}
                </span>
                {AI_PROVIDER_PRESETS.map((preset) => (
                  <Button
                    key={preset.name}
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => applyAiPreset(preset)}
                  >
                    {preset.name}
                  </Button>
                ))}
              </div>

              {/* Provider inputs */}
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="ai-base-url">Base URL</Label>
                  <Input
                    id="ai-base-url"
                    inputMode="url"
                    autoComplete="off"
                    className="h-9"
                    placeholder="https://openrouter.ai/api/v1"
                    value={aiBaseUrl}
                    onChange={(e) => setAiBaseUrl(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ai-api-key">API Key</Label>
                  <Input
                    id="ai-api-key"
                    type="password"
                    autoComplete="off"
                    className="h-9"
                    placeholder="sk-…"
                    value={aiApiKey}
                    onChange={(e) => setAiApiKey(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ai-model">{t("ሞዴል", "Model")}</Label>
                  <Input
                    id="ai-model"
                    autoComplete="off"
                    className="h-9"
                    placeholder="meta-llama/llama-3.3-70b-instruct:free"
                    value={aiModel}
                    onChange={(e) => setAiModel(e.target.value)}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center gap-2">
                <Button onClick={() => void saveAiProvider()} disabled={aiSaving} className="h-9">
                  {aiSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <Save className="h-4 w-4" aria-hidden />
                  )}
                  {t("አስቀምጥ", "Save")}
                </Button>
                <Button variant="outline" onClick={() => void testAiProvider()} disabled={aiTesting} className="h-9">
                  {aiTesting ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  ) : (
                    <ShieldCheck className="h-4 w-4" aria-hidden />
                  )}
                  {t("ልክ", "Test")}
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => void clearAiProvider()}
                  className="h-9 text-destructive hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" aria-hidden />
                  {t("አጥፋ", "Clear")}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                {t(
                  "ቁልፉ በብራውዘርዎ ብቻ ይቀመጣል — በሰርቨር አይቀመጥም። ባዶ ከተተወ ከመስመር ውጭ ትንተና ይጠቀማል።",
                  "The key is stored only in this browser — never on a server. Left empty, the app uses offline analysis."
                )}
              </p>
            </CardContent>
          </Card>

          {/* ---------- Publish to Netlify (mobile-friendly steps) ---------- */}
          <Card className="glass-card border-emerald-300/50 dark:border-emerald-500/25">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Globe className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden />
                {t("ወደ Netlify ማትሪያል", "Publish to Netlify")}
              </CardTitle>
              <CardDescription>
                {t(
                  "አፕሊኬሽኑን በስልክዎ ወደ netlify.com ይለጥፉ — ሁሉም ደረጃዎች በብራውዘር ይጠናቀቃሉ።",
                  "Publish this application to netlify.com from your mobile device — every step works in a phone browser."
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Download the ready-to-deploy ZIP */}
              <div className="space-y-1.5">
                <a href="/api/publish/download" download aria-label={t("የዲፕሎይ ፓኬጁን አውርድ", "Download deployment package")}>
                  <Button className="w-full h-10">
                    <Download className="w-4 h-4 mr-2" aria-hidden />
                    {t("የዲፕሎይ ፓኬጁን አውርድ (ZIP)", "Download deployment package (ZIP)")}
                  </Button>
                </a>
                <p className="text-xs text-muted-foreground">
                  {t(
                    "ፓኬጁው ውስጥ ማሰማራት የሚያስፈልግ ሁሉ አለ — ምንጭ ኮድ፣ ዳታቤዝ ስኪማ፣ netlify.toml እና መመሪያ። ፋይሎቹን ብቻ ወደ GitHub ይስቀሉ (ZIP ራሱን አይደለም)።",
                    "The package contains everything needed to deploy — source code, database schema, netlify.toml and the guide. Upload the files inside it to GitHub (not the ZIP itself)."
                  )}
                </p>
              </div>

              <ol className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                    1
                  </span>
                  <span>
                    {t(
                      "ከታች ያለውን የዲፕሎይ ፓኬጅ (ZIP) አውርደው ውስጣዊ ፋይሎቹን ወደ GitHub መጽሐፍተው ያስቀምጡ (github.com → New repository)።",
                      "Download the deployment package (ZIP) below, then upload the files inside it to a GitHub repository (github.com → New repository)."
                    )}
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                    2
                  </span>
                  <span>
                    {t(
                      "app.netlify.com ግቡ → Add new site → Import an existing project → GitHub → መጽሐፍተውን ይምረጡ።",
                      "Sign in at app.netlify.com → Add new site → Import an existing project → GitHub → pick the repository."
                    )}
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                    3
                  </span>
                  <span>
                    {t("ቅንብሮች ሲጠየቁ Build command: ", "When asked for Build command use: ")}
                    <code className="rounded bg-muted px-1.5 py-0.5 text-[11px]">npm run db:generate && npx next build</code>
                    {t(" እና Publish directory: ", " and Publish directory: ")}
                    <code className="rounded bg-muted px-1.5 py-0.5 text-[11px]">.next</code>
                    {t(
                      " (netlify.toml በኮዱ ውስጥ ስለሚገኝ ብዙ ጊዜ በቀጥታ Deploy መጫን በቂ ነው)።",
                      " (netlify.toml ships with the code, so usually tapping Deploy is enough)."
                    )}
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                    4
                  </span>
                  <span>
                    {t(
                      "Environment variables ውስጥ DATABASE_URL = ",
                      "Add the environment variable DATABASE_URL = "
                    )}
                    <code className="rounded bg-muted px-1.5 py-0.5 text-[11px]">file:/tmp/data.db</code>
                    {t(" ይጨምሩ እና Deploy ይጫኑ።", " and tap Deploy.")}
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                    5
                  </span>
                  <span>
                    {t(
                      "ከ3–6 ደቂቃ በኋላ ጣቢያዎ https://<site>.netlify.app ላይ ይከፈታል።",
                      "After 3–6 minutes your site is live at https://<site>.netlify.app."
                    )}
                  </span>
                </li>
              </ol>
              <p className="rounded-lg border border-amber-300/50 bg-amber-500/10 p-2.5 text-xs text-amber-700 dark:text-amber-300">
                {t(
                  "ማሳሰቢያ፦ በNetlify ላይ ዳታቤዙ ጊዜያዊ ነው — በየጊዜው የJSON መጠባበቂያ ይውሰዱ፤ ዝርዝር መመሪያ DEPLOY-NETLIFY.md ውስጥ አለ።",
                  "Note: the database is ephemeral on Netlify — take the JSON backup below regularly. Full guide: DEPLOY-NETLIFY.md."
                )}
              </p>
              <div className="rounded-lg border bg-muted/40 p-2.5 text-xs text-muted-foreground">
                <div className="font-semibold text-foreground mb-1">
                  {t("ሌሎች ማስተናገጃ አማራጮች", "Other hosting options")}
                </div>
                <p>
                  {t(
                    "Vercel — እንደ Netlify (ተመሳሳይ ጊዜያዊ ዳታቤዝ)። Railway / Render / Fly.io — ቋሚ ሰርቨርና ዳታቤዝ ስለሚሰጡ ለቋሚ መረጃ ይመከራሉ (ከGitHub በስልክ ማሰማራት ይቻላል)።",
                    "Vercel — same as Netlify (also an ephemeral database). Railway / Render / Fly.io — persistent server + database, recommended for permanent data (can also be deployed from GitHub on a phone)."
                  )}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* ---------- 6. About ---------- */}
          <Card className="glass-card">
            <CardContent className="flex flex-col items-center p-6 text-center">
              {logoDataUrl ? (
                <img
                  src={logoDataUrl}
                  alt="Bureau logo"
                  className="mx-auto h-16 rounded-lg border bg-white object-contain p-1"
                />
              ) : (
                <div
                  className="mx-auto flex h-16 w-16 items-center justify-center rounded-lg border bg-white text-muted-foreground"
                  aria-hidden
                >
                  <ImagePlus className="h-5 w-5" />
                </div>
              )}
              <p className="mt-3 text-lg font-bold">Direc-Score</p>
              <p className="text-xs text-muted-foreground">
                {t(
                  "የዳይሬክቶሬት የሩብ ዓመት ግምገማ ስርዓት",
                  "Directorate Quarterly Evaluation System"
                )}
              </p>
              <Badge variant="secondary" className="mt-2 max-w-full truncate">
                {settings.organizationName || DEFAULT_ORG_NAME}
              </Badge>
              <Separator className="my-4 w-24" />
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Developed by
              </p>
              <p className="font-semibold">Mr Ferid Mohammed</p>
              <div className="mt-2 flex flex-col items-center gap-1 text-xs">
                <a
                  href="tel:+251911133037"
                  className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground"
                  aria-label="Call Mr Ferid Mohammed at +251 911 133 037"
                >
                  <Smartphone className="h-3.5 w-3.5" aria-hidden />
                  +251911133037
                </a>
                <a
                  href="mailto:feridmhd3@gmail.com"
                  className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground"
                  aria-label="Email Mr Ferid Mohammed at feridmhd3@gmail.com"
                >
                  <Mail className="h-3.5 w-3.5" aria-hidden />
                  feridmhd3@gmail.com
                </a>
              </div>
              <Badge variant="outline" className="mt-4">
                v3.0
              </Badge>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
