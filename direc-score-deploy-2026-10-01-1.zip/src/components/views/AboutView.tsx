"use client";

/**
 * AboutView — ስለ አፕሊኬሽኑ / About the application.
 *
 * A detailed, bilingual description of Direc-Score: what it is, what it is
 * for, its features and how it works. It lives in the main app navigation AND
 * is reachable from every directorate's shareable portal (the back button
 * returns to the portal when `from === "portal"`).
 */

import { useEffect, useState } from "react";
import {
  ArrowLeft,
  BarChart3,
  BellRing,
  Brain,
  Building2,
  CheckCircle2,
  FolderLock,
  Globe,
  Info,
  Link2,
  Mail,
  MessageCircle,
  Phone,
  QrCode,
  Send,
  Sparkles,
  Upload,
  Users,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLogoDataUrl } from "@/lib/branding";
import { useLang } from "@/lib/i18n";
import type { NavigateFn } from "@/hooks/use-view";
import { cn } from "@/lib/utils";

export function AboutView({
  navigate,
  from,
  directorateKey,
  quarter,
}: {
  navigate?: NavigateFn;
  from?: string;
  directorateKey?: string;
  quarter?: string;
}) {
  const { t } = useLang();
  const [logo, setLogo] = useState("");

  useEffect(() => {
    let cancelled = false;
    getLogoDataUrl()
      .then((url) => {
        if (!cancelled && url) setLogo(url);
      })
      .catch(() => {
        /* icon fallback stays */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const goBack = () => {
    if (from === "portal" && directorateKey) {
      navigate?.("portal", { dir: directorateKey, ...(quarter ? { quarter } : {}) });
    } else {
      navigate?.("home");
    }
  };

  const backLabel =
    from === "portal" && directorateKey
      ? t("ወደ ዳይሬክቶሬት ገጽ ተመለስ", "Back to the directorate portal")
      : t("ተመለስ", "Back");

  const purposes: Array<{ am: string; en: string }> = [
    {
      am: "የዳይሬክቶሬቶችን የሩብ ዓመት አፈጻጸም በአንድ የተወሰነ ነጥብ (100) መለኪያ በትክክል ማስመዝገብ እና ማጠቃለያ።",
      en: "Record and summarise every directorate's quarterly performance against one standard 100-point rubric.",
    },
    {
      am: "የግምገማ ሂደቱን ግልጽ፣ ፈጣን እና በመረጃ ላይ የተመሠረተ ማድረግ።",
      en: "Make the evaluation process transparent, fast and data-driven.",
    },
    {
      am: "እያንዳንዱ ዳይሬክቶሬት በራሱ ሊንክ/QR ውጤቱን መመልከት፣ ሪፖርት መላክ እና አስተያየት መስጠት።",
      en: "Give each directorate its own QR/link to view its score, upload reports and share feedback.",
    },
    {
      am: "ውጤቶችን፣ ሰነዶችን እና ማስታወሻዎችን በአውቶማት በWhatsApp፣ Telegram እና ኢሜይል ማድረስ።",
      en: "Automatically deliver scores, documents and reminders through WhatsApp, Telegram and Email.",
    },
    {
      am: "የሪፖርት መጣሪያ ጊዜን መቆጣጠር እና ከመጣሪያ በፊት ማሳወቂያ መላክ።",
      en: "Track the quarterly submission deadline and remind directorates before it passes.",
    },
    {
      am: "በAI ድጋፍ ትክክለኛ ትንተናና ግራፍ ታያሽ ሪፖርቶችን ማዘጋጀት።",
      en: "Produce AI-assisted analysis and downloadable graphics for executive review.",
    },
  ];

  const features: Array<{ icon: typeof BarChart3; am: string; en: string; descAm: string; descEn: string }> = [
    {
      icon: CheckCircle2,
      am: "የሩብ ዓመት ግምገማ",
      en: "Quarterly evaluations",
      descAm: "10 መስፈርቶች (A–J) ፣ 100 ነጥብ ፣ የእርምጃ እቅድ እና የግምገማ አስተያየቶች።",
      descEn: "10 criteria (A–J), a 100-point total, action plans and evaluator comments.",
    },
    {
      icon: QrCode,
      am: "የዳይሬክቶሬት ፖርታል",
      en: "Directorate portals",
      descAm: "ለእያንዳንዱ ዳይሬክቶሬት ልዩ QR እና ሊንክ — ውጤት መመልከት፣ ሰነድ መላክ፣ አስተያየት መስጠት።",
      descEn: "A unique QR + link per directorate — view scores, upload reports and share feedback.",
    },
    {
      icon: Upload,
      am: "የሰነድ መላክ",
      en: "Any-file uploads",
      descAm: "PDF፣ Word፣ Excel፣ PowerPoint፣ ምስል እና ሌሎችን መላክ — ለእያንዳንዱ ሰነድ ልዩ ሊንክ።",
      descEn: "PDF, Word, Excel, PowerPoint, images and more — each upload gets a unique share link.",
    },
    {
      icon: Send,
      am: "አውቶማቲክ መላክ",
      en: "Automated delivery",
      descAm: "ውጤቶች እና አዲስ ሰነዶች በአውቶማት ወደ WhatsApp፣ Telegram እና ኢሜይል ይሄዳሉ።",
      descEn: "Scores and new documents flow out automatically via WhatsApp, Telegram and Email.",
    },
    {
      icon: Users,
      am: "የእውቂያ አደረጃጀት",
      en: "Contact book",
      descAm: "የእያንዳንዱ ዳይሬክቶሬት ኢሜይል፣ WhatsApp እና Telegram ተቀምጦ ማንኛውንም ነገር በአንድ ጊዜ መላክ።",
      descEn: "Save each directorate's email, WhatsApp and Telegram — send everything in one go.",
    },
    {
      icon: BellRing,
      am: "የመጣሪያ ጊዜ ማስታወሻ",
      en: "Deadline reminders",
      descAm: "የሪፖርት መጣሪያ ቀን ማስቀመጥ እና ከመጣሪያ በፊት በአውቶማት ማሳወቂያ መላክ።",
      descEn: "Set the quarterly deadline and send automatic reminders before it passes.",
    },
    {
      icon: Brain,
      am: "AI ግምገማ እና ትንተና",
      en: "AI evaluator & analysis",
      descAm: "በAI ሰነድ መተንተን፣ መልሶችን ሙላት እና ትንተና ማዘጋጀት — በአማርኛም በእንግሊዝኛም።",
      descEn: "Analyse documents, draft answers and insights with AI — in Amharic and English.",
    },
    {
      icon: BarChart3,
      am: "ታያሽ መረጃ",
      en: "Analytics & dashboards",
      descAm: "ናሙና ግራፎች፣ ማወዳደር እና ለዳሽቦርድ ሊወርዱ ምስሎች።",
      descEn: "Charts, comparisons and downloadable graphics for your own dashboard.",
    },
    {
      icon: FolderLock,
      am: "የሰነድ ማረሚያ",
      en: "Secure filing room",
      descAm: "በይለፍ ቃል የተጠበቀ የሰነድ ካቢኔ እና የፋይል ስካነር።",
      descEn: "A PIN-protected document cabinet with a built-in file scanner.",
    },
    {
      icon: Link2,
      am: "የአገናኞች ቤተ-መጻሕፍት",
      en: "Link library",
      descAm: "ተመሳሳይ መተግበሪያዎች፣ የትምህርት አገናኞች እና ሌሎች ጠቃሚ አገናኞች።",
      descEn: "Similar applications, learning links and other useful resources in one place.",
    },
    {
      icon: Globe,
      am: "ባለሁለት ቋንቋ",
      en: "Bilingual app",
      descAm: "ሙሉ የአማርኛ / እንግሊዝኛ ቋንቋ መለወጫ፣ ጨለማ ሁነታ እና የሳምንት መጠባበቂያ።",
      descEn: "Full Amharic / English switcher, dark mode and weekly Google Drive backup.",
    },
  ];

  const steps: Array<{ am: string; en: string; descAm: string; descEn: string }> = [
    {
      am: "1ኛ — QR ያስንበቡ",
      en: "1 — Scan the QR",
      descAm: "እያንዳንዱ ዳይሬክቶሬት የራሱ ልዩ QR/ሊንክ ይይዛል።",
      descEn: "Each directorate holds its own unique QR code / link.",
    },
    {
      am: "2ኛ — ሪፖርት ያስገቡ",
      en: "2 — Submit the report",
      descAm: "በፖርታሉ ላይ ማንኛውንም ሰነድ ያስገቡ፤ ልዩ ሊንክ በአውቶማት ይፈጠራል።",
      descEn: "Upload any report document from the portal; a unique link is created instantly.",
    },
    {
      am: "3ኛ — ግምገማ",
      en: "3 — Evaluation",
      descAm: "ቢሮው በ100 ነጥብ መለኪያ ውጤቱን ያስመዘግባል (በAI ድጋፍ መጠቀም ይቻላል)።",
      descEn: "The bureau records the score on the 100-point rubric (AI-assisted when wanted).",
    },
    {
      am: "4ኛ — ውጤት ይደርሳል",
      en: "4 — Score delivered",
      descAm: "ውጤቱ በአውቶማት ወደ ዳይሬክቶሬቱ WhatsApp፣ Telegram እና ኢሜይል ይሄዳል።",
      descEn: "The score is delivered automatically to the directorate's WhatsApp, Telegram and Email.",
    },
  ];

  return (
    <div className="flex-1">
      <header className="glass-card sticky top-0 z-20 border-b">
        <div className="mx-auto flex w-full max-w-4xl items-center gap-3 px-4 py-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={goBack}
            aria-label={backLabel}
            title={backLabel}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Info className="h-5 w-5" aria-hidden />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-bold leading-tight">
              {t("ስለ አፕሊኬሽኑ", "About the Application")}
            </h1>
            <p className="truncate text-xs text-muted-foreground">
              {t("Direc-Score — የዳይሬክቶሬት ውጤት ሪፖርት", "Direc-Score — Directorate Score Report")}
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl space-y-6 p-4 sm:p-6">
        {/* Hero */}
        <Card className="glass-card overflow-hidden">
          <CardContent className="flex flex-col items-center gap-4 p-6 text-center sm:flex-row sm:text-left">
            {logo ? (
              <img
                src={logo}
                alt="Harari Regional Health Bureau logo"
                className="h-20 w-20 shrink-0 rounded-2xl border bg-white object-contain p-1 shadow-sm"
              />
            ) : (
              <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                <Building2 className="h-9 w-9" aria-hidden />
              </div>
            )}
            <div className="min-w-0">
              <h2 className="text-xl font-extrabold leading-tight">
                {t("Direc-Score — የዳይሬክቶሬት ውጤት ሪፖርት ሲስተም", "Direc-Score — Directorate Score Report System")}
              </h2>
              <p className="mt-1 text-sm font-medium text-primary">
                {t("የሀረሪ ክልል ጤና ቢሮ", "Harari Region Health Bureau")}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                {t(
                  "የሀረሪ ክልል ጤና ቢሮ በስር ያሉ የተለያዩ ዳይሬክቶሬቶች የሩብ ዓመት አፈጻጸምን በአንድ ደረጃ መለኪያ የሚመዘግብ፣ የሚገመግም እና ውጤቶችን በአውቶማት የሚያደርስ ዘመናዊ የድር አፕሊኬሽን ነው።",
                  "A modern web application for Harari Region Health Bureau that records, evaluates and automatically delivers the quarterly performance of every directorate under the bureau on one standard rubric."
                )}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Purpose */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-4 w-4 text-primary" aria-hidden />
              {t("የአፕሊኬሽኑ ዓላማ", "Purpose of the application")}
            </CardTitle>
            <CardDescription>
              {t("ይህ አፕሊኬሽን ምን እንዲፈጸም ተዘጋጅቷል?", "What is this application built to achieve?")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5">
              {purposes.map((p, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" aria-hidden />
                  <span className="text-sm leading-relaxed">{t(p.am, p.en)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Features */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base">{t("ዋና ዋና አቅሞች", "Key features")}</CardTitle>
            <CardDescription>
              {t("አፕሊኬሽኑ የሚያቀርባቸው አቅሞች።", "Everything the application offers.")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {features.map((f, i) => {
                const Icon = f.icon;
                return (
                  <div key={i} className="flex items-start gap-3 rounded-xl border bg-background/60 p-3.5">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <Icon className="h-4.5 w-4.5" aria-hidden />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold leading-snug">{t(f.am, f.en)}</p>
                      <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{t(f.descAm, f.descEn)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* How it works */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base">{t("እንዴት ይሰራል?", "How it works")}</CardTitle>
            <CardDescription>
              {t("አራት ቀላል ደረጃዎች።", "Four simple steps.")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="grid gap-3 sm:grid-cols-2">
              {steps.map((s, i) => (
                <li key={i} className="rounded-xl border bg-background/60 p-3.5">
                  <p className="text-sm font-bold">{t(s.am, s.en)}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{t(s.descAm, s.descEn)}</p>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>

        {/* Developer contact */}
        <Card className="glass-card border-primary/30">
          <CardHeader>
            <CardTitle className="text-base">{t("ገንቢ እና አግኝት", "Developer & contact")}</CardTitle>
            <CardDescription>
              {t(
                "ስለ አፕሊኬሽኑ ጥያቄ፣ ማስተካከያ ወይም ማሻሻያ ካለብዎ ያግኙን።",
                "For questions, support or improvements to this application, reach out."
              )}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="bg-primary/10 text-primary hover:bg-primary/10">
                {t("ገንቢ", "Developed by")}: Mr Ferid Mohammed
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="h-9" asChild>
                <a href="tel:+251911133037" aria-label="Call +251 911 133 037">
                  <Phone className="h-4 w-4 text-emerald-600" aria-hidden />
                  +251911133037
                </a>
              </Button>
              <Button variant="outline" size="sm" className="h-9" asChild>
                <a href="mailto:feridmhd3@gmail.com" aria-label="Email feridmhd3@gmail.com">
                  <Mail className="h-4 w-4 text-amber-600" aria-hidden />
                  feridmhd3@gmail.com
                </a>
              </Button>
              <Button variant="outline" size="sm" className="h-9" asChild>
                <a
                  href="https://t.me/feridmhd1"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Telegram @feridmhd1"
                >
                  <MessageCircle className="h-4 w-4 text-sky-600" aria-hidden />
                  @feridmhd1
                </a>
              </Button>
            </div>
            <p className={cn("text-xs text-muted-foreground")}>
              {t(
                "© " + new Date().getFullYear() + " የሀረሪ ክልል ጤና ቢሮ — Direc-Score። መብቱ በህግ የተጠበቀ ነው።",
                "© " + new Date().getFullYear() + " Harari Region Health Bureau — Direc-Score. All rights reserved."
              )}
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
