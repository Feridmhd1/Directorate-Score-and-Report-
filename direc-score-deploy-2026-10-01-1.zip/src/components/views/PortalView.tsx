"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlarmClock,
  AlertCircle,
  CheckCircle2,
  Clock,
  Copy,
  Download,
  ExternalLink,
  File as FileIcon,
  FileSpreadsheet,
  FileText,
  FileUp,
  FolderOpen,
  HeartPulse,
  Image as ImageIcon,
  Info,
  Languages,
  Lightbulb,
  Link2,
  Loader2,
  Lock,
  Mail,
  MessageCircle,
  Send,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  BigScore,
  LoadingSpinner,
  PerformanceBadge,
  ScoreBadge,
  ScoreBar,
} from "@/components/shared";
import { CRITERIA, DEFAULT_QUARTER, DIRECTORATES, TOTAL_MAX_SCORE, scorePercent } from "@/lib/rubric";
import {
  buildShareLinks,
  deadlineApi,
  evaluationsApi,
  feedbackApi,
  linksApi,
  portalApi,
  reportShareUrl,
} from "@/lib/client-api";
import { getLogoDataUrl } from "@/lib/branding";
import { useLang } from "@/lib/i18n";
import { toast } from "@/hooks/use-toast";
import type {
  DeadlineStateDTO,
  DeliveryLogDTO,
  EvaluationDTO,
  LinkItemDTO,
  QualityReportDTO,
} from "@/lib/types";

function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

function docIconFor(mimeType: string): typeof FileIcon {
  if (mimeType.startsWith("image/")) return ImageIcon;
  if (/spreadsheet|excel|csv/.test(mimeType)) return FileSpreadsheet;
  if (/pdf|word|document|text|presentation|powerpoint/.test(mimeType)) return FileText;
  return FileIcon;
}

type FeedbackKind = "comment" | "suggestion";

/**
 * Public directorate hub — opened through each directorate's unique shareable
 * link / QR code. Scope (per requirement): view own score, upload quarterly
 * report documents (any file type → unique link + automatic WhatsApp/Telegram
 * delivery), and share comments & suggestions. The AI evaluator is NOT part of
 * this page.
 */
export function PortalView({
  directorateKey,
  quarter,
}: {
  directorateKey: string;
  quarter: string;
}) {
  const { lang, setLang, t } = useLang();
  const [loading, setLoading] = useState(Boolean(directorateKey));
  const [evaluation, setEvaluation] = useState<EvaluationDTO | null>(null);

  /* Bureau logo (custom upload or built-in Harari logo) — graceful when empty */
  const [logoDataUrl, setLogoDataUrl] = useState("");
  useEffect(() => {
    let cancelled = false;
    getLogoDataUrl()
      .then((url) => {
        if (!cancelled && url) setLogoDataUrl(url);
      })
      .catch(() => {
        /* keep the default icon fallback */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /* Comments & suggestions form state */
  const [fbKind, setFbKind] = useState<FeedbackKind>("comment");
  const [fbMessage, setFbMessage] = useState("");
  const [fbContact, setFbContact] = useState("");
  const [fbSending, setFbSending] = useState(false);
  const [fbSent, setFbSent] = useState(false);
  /* Per-channel WhatsApp/Telegram/Email delivery rows created on submit */
  const [fbDeliveries, setFbDeliveries] = useState<DeliveryLogDTO[]>([]);

  /* Quarterly report document upload (ANY file type via this shareable link) */
  const [upTitle, setUpTitle] = useState("");
  const [upNote, setUpNote] = useState("");
  const [upQuarter, setUpQuarter] = useState(quarter || DEFAULT_QUARTER);
  const [upFile, setUpFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [lastUpload, setLastUpload] = useState<{
    report: QualityReportDTO;
    shareUrl: string;
    deliveries: DeliveryLogDTO[];
    /** One-tap wa.me / mailto hand-offs (local / Netlify mode only) */
    handoffs?: Array<{ channelType: string; label: string; url: string; detail: string }>;
  } | null>(null);

  /* This directorate's own uploaded documents (with unique links) */
  const [docs, setDocs] = useState<QualityReportDTO[]>([]);
  const [docsLoading, setDocsLoading] = useState(Boolean(directorateKey));
  const loadDocs = useCallback(() => {
    if (!directorateKey) return;
    portalApi
      .listUploads(directorateKey)
      .then(({ reports }) => setDocs(reports))
      .catch(() => setDocs([]))
      .finally(() => {
        setDocsLoading(false);
      });
  }, [directorateKey]);
  useEffect(() => {
    loadDocs();
  }, [loadDocs]);

  useEffect(() => {
    if (!directorateKey) return;
    let cancelled = false;
    evaluationsApi
      .list({ directorateKey, quarter })
      .then(({ evaluations }) => {
        if (cancelled) return;
        const latest = [...evaluations].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setEvaluation(latest[0] ?? null);
      })
      .catch(() => {
        if (!cancelled) setEvaluation(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [directorateKey, quarter]);

  /* Submission deadline countdown (best-effort — failures stay silent) */
  const [deadlineState, setDeadlineState] = useState<DeadlineStateDTO | null>(null);
  useEffect(() => {
    let cancelled = false;
    deadlineApi
      .get()
      .then((state) => {
        if (!cancelled) setDeadlineState(state);
      })
      .catch(() => {
        /* the banner simply stays hidden when the deadline is unavailable */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /* Curated useful links (best-effort — the section stays hidden on failure) */
  const [usefulLinks, setUsefulLinks] = useState<LinkItemDTO[]>([]);
  useEffect(() => {
    let cancelled = false;
    linksApi
      .list()
      .then(({ links }) => {
        if (!cancelled) setUsefulLinks(links ?? []);
      })
      .catch(() => {
        /* never disturb the page — just skip the Useful Links section */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const directorate = DIRECTORATES.find((d) => d.key === directorateKey);

  const uploadDocument = async () => {
    if (!upFile) {
      toast({
        variant: "destructive",
        title: t("ፋይል ይምረጡ", "Choose a file"),
        description: t(
          "PDF፣ Word፣ Excel፣ ምስል ወይም ማንኛውም ሰነድ ይሆናል።",
          "PDF, Word, Excel, pictures or any document works."
        ),
      });
      return;
    }
    if (upFile.size > 10 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: t("ፋይሉ በጣም ትልቅ ነው", "File too large"),
        description: t(
          "ሰነዱ ከ10MB መብለጥ የለበትም።",
          "The document must be under 10 MB."
        ),
      });
      return;
    }
    setUploading(true);
    try {
      const result = await portalApi.upload(upFile, {
        directorateKey,
        quarter: upQuarter.trim(),
        title: upTitle.trim() || undefined,
        note: upNote.trim() || undefined,
      });
      setLastUpload(result);
      setUpFile(null);
      setUpTitle("");
      setUpNote("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      loadDocs();
      toast({
        title: t("ሰነድ ተሰቀለ", "Document uploaded"),
        description: t(
          "ብቁ አገናኝ ተፈጠረና በአውቶማት ተልኳል (WhatsApp · Telegram)።",
          "Unique link created and sent automatically (WhatsApp · Telegram)."
        ),
      });
    } catch (e) {
      toast({
        variant: "destructive",
        title: t("መስቀል አልተሳካም", "Upload failed"),
        description:
          e instanceof Error
            ? e.message
            : t("እባክዎ እንደገና ይሞክሩ።", "Please try again."),
      });
    } finally {
      setUploading(false);
    }
  };

  const submitFeedback = async () => {
    if (fbMessage.trim().length < 3) {
      toast({
        variant: "destructive",
        title: t("መልእክት አስፈላጊ ነው", "Message required"),
        description: t(
          "እባክዎ ቢያንስ አጭር መልእክት ይጻፉ።",
          "Please write a message of at least 3 characters."
        ),
      });
      return;
    }
    setFbSending(true);
    try {
      const result = await feedbackApi.submit({
        directorateKey,
        directorateName: directorate?.name ?? directorateKey,
        quarter,
        kind: fbKind,
        message: fbMessage.trim(),
        contact: fbContact.trim() || undefined,
      });
      setFbDeliveries(result.deliveries ?? []);
      setFbSent(true);
      setFbMessage("");
      setFbContact("");
      window.setTimeout(() => setFbSent(false), 8000);
    } catch {
      toast({
        variant: "destructive",
        title: t("መላክ አልተሳካም", "Submission failed"),
        description: t("እባክዎ እንደገና ይሞክሩ።", "Something went wrong — please try again."),
      });
    } finally {
      setFbSending(false);
    }
  };

  const copyLink = (link: string) => {
    navigator.clipboard
      .writeText(link)
      .then(() => toast({ title: t("አገናኝ ተቀድቷል", "Link copied") }))
      .catch(() =>
        toast({
          variant: "destructive",
          title: t("አገናኝ መቅዳት አልተሳካም", "Copy failed"),
          description: t(
            "እባክዎ አገናኙን በእጅ ይቅዱ።",
            "Could not copy — please copy the link manually."
          ),
        })
      );
  };

  const deliveryStatus = (
    type: string,
    source: DeliveryLogDTO[] = lastUpload?.deliveries ?? []
  ): "sent" | "queued" | "failed" | null => {
    const d = source.find((x) => x.channelType === type);
    return (d?.status as "sent" | "queued" | "failed") ?? null;
  };

  const DeliveryChip = ({
    type,
    label,
    icon: Icon,
    deliveries,
  }: {
    type: string;
    label: string;
    icon: typeof MessageCircle;
    /** deliveries to read the status from — defaults to the last upload's */
    deliveries?: DeliveryLogDTO[];
  }) => {
    const status = deliveryStatus(type, deliveries);
    if (!status) return null;
    const cls =
      status === "sent"
        ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
        : status === "queued"
          ? "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400"
          : "border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-400";
    const StatusIcon = status === "sent" ? CheckCircle2 : status === "queued" ? Clock : XCircle;
    return (
      <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${cls}`}>
        <Icon className="w-3 h-3" />
        {label}
        <StatusIcon className="w-3 h-3" aria-label={status} />
      </span>
    );
  };

  /* Incomplete link */
  if (!directorateKey) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="max-w-md w-full text-center p-8">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center dark:bg-red-500/15 dark:text-red-400">
              <AlertCircle className="w-6 h-6" />
            </div>
          </div>
          <h1 className="text-lg font-bold">{t("የሆነ ስህተት", "Something went wrong")}</h1>
          <p className="text-sm text-muted-foreground font-medium">
            {t("አገናኙ ᠍ሙሉ አይደለም", "Link incomplete")}
          </p>
          <p className="text-sm text-muted-foreground mt-3">
            {t(
              "የተጠቀሙት አገናኝ ᠍ሙሉ አይመስልም። እባክዎ አዲስ አገናኝ ይጠይቁ።",
              "The link you used appears to be incomplete. Please request a new link."
            )}
          </p>
        </Card>
      </div>
    );
  }

  const percent = evaluation ? scorePercent(evaluation.totalScore, TOTAL_MAX_SCORE) : 0;
  const commentRows = evaluation
    ? CRITERIA.filter((c) => evaluation.comments?.[c.key]?.trim())
    : [];

  /* Deadline banner variant — urgent while the window is open, ✅ once this
     directorate is no longer in missing[], muted once the window has closed */
  const deadline = deadlineState?.deadline ?? null;
  const deadlineDaysLeft = deadlineState?.daysLeft ?? null;
  const deadlineSubmitted = Boolean(
    deadline && !deadlineState?.missing.some((m) => m.key === directorateKey)
  );
  const deadlineDateText = deadline
    ? new Date(`${deadline.date}T00:00:00`).toLocaleDateString()
    : "";

  return (
    <div className="flex-1 bg-background">
      {/* Public header — no links into the private app */}
      <header className="bg-card border-b">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-3">
          {logoDataUrl ? (
            <img
              src={logoDataUrl}
              alt={t(
                "የሀረሪ ክልል ጤና ቢሮ አርማ",
                "Harari Region Health Bureau logo"
              )}
              className="h-11 w-11 rounded-lg border bg-white object-contain p-0.5 shrink-0"
            />
          ) : (
            <div className="w-10 h-10 rounded-lg bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <HeartPulse className="w-5 h-5" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="font-bold text-sm md:text-base leading-tight">
              {t("የሀረሪ ክልል ጤና ቢሮ", "Harari Region Health Bureau")}
            </div>
            <div className="text-xs text-muted-foreground">
              {t(
                "የዳይሬክቶሬት ሩብ ዓመት ግምገማ ውጤት",
                "Directorate quarterly evaluation results"
              )}
            </div>
          </div>
          {/* About the application — visible on the shared directorate link */}
          <Button
            variant="outline"
            size="sm"
            className="h-9 shrink-0 gap-1.5 text-xs font-semibold"
            asChild
          >
            <a
              href={`/?view=about&from=portal&dir=${encodeURIComponent(directorateKey)}${quarter ? `&quarter=${encodeURIComponent(quarter)}` : ""}`}
              aria-label={t("ስለ አፕሊኬሽኑ", "About the application")}
              title={t("ስለ አፕሊኬሽኑ", "About the application")}
            >
              <Info className="w-4 h-4" />
              <span className="hidden sm:inline">{t("ስለ አፕሊ", "About")}</span>
            </a>
          </Button>
          {/* Language switcher — አማርኛ / English */}
          <Button
            variant="outline"
            size="sm"
            className="h-9 shrink-0 gap-1.5 text-xs font-semibold"
            aria-label={t("ቋንቋ ቀይር ወደ English", "Switch language to Amharic")}
            onClick={() => setLang(lang === "en" ? "am" : "en")}
          >
            <Languages className="w-4 h-4" />
            {lang === "en" ? "አማርኛ" : "English"}
          </Button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4">
        {loading ? (
          <LoadingSpinner />
        ) : (
          <div className={evaluation ? "space-y-5 py-2" : "mt-6 space-y-5"}>
            {/* Submission deadline countdown — urgent / submitted / closed */}
            {deadline && deadlineDaysLeft !== null && deadlineDaysLeft >= 0 && !deadlineSubmitted && (
              <div
                role="status"
                className="flex items-start gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 text-amber-700 dark:text-amber-400"
              >
                <AlarmClock className="w-5 h-5 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <p className="text-sm font-bold leading-snug break-words">
                    {t(
                      `⏰ የ${deadline.quarter} ሪፖርት መላኪያ መጨረሻ ቀን: ${deadlineDateText} (${deadlineDaysLeft} ቀናዎች ይቀሩ)`,
                      `⏰ ${deadline.quarter} report submission deadline: ${deadlineDateText} (${deadlineDaysLeft} days left)`
                    )}
                  </p>
                  <p className="mt-1 text-xs font-medium leading-relaxed break-words">
                    {t(
                      "እባክዎ ከመጨረሻ ቀን በፊት የሩብ ዓመት ሪፖርትዎን ከላይ ያስገቡ።",
                      "Please submit your quarterly report above before the deadline."
                    )}
                  </p>
                </div>
              </div>
            )}
            {deadline && deadlineSubmitted && (deadlineDaysLeft === null || deadlineDaysLeft >= 0) && (
              <div
                role="status"
                className="flex items-start gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-700 dark:text-emerald-400"
              >
                <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                <p className="min-w-0 text-sm font-bold leading-snug break-words">
                  {t(
                    `✅ ለ${deadline.quarter} ሪፖርትዎ ተጠናቅቋል — እናመሰግናለን!`,
                    `✅ Your ${deadline.quarter} report is submitted — thank you!`
                  )}
                </p>
              </div>
            )}
            {deadline && deadlineDaysLeft !== null && deadlineDaysLeft < 0 && (
              <div
                role="status"
                className="flex items-start gap-3 rounded-lg border bg-muted/50 p-4 text-muted-foreground"
              >
                <Clock className="w-5 h-5 shrink-0 mt-0.5" />
                <p className="min-w-0 text-sm font-semibold leading-snug break-words">
                  {t(
                    `የ${deadline.quarter} የመላኪያ ጊዜ አልቋል`,
                    `${deadline.quarter} submission window has closed`
                  )}
                </p>
              </div>
            )}

            {evaluation ? (
              /* Score overview */
              <Card className="p-5">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0">
                    <div className="text-lg font-bold leading-tight">{evaluation.directorateName}</div>
                    <div className="text-sm text-muted-foreground mt-0.5">
                      {evaluation.directorateShort} · {evaluation.quarter}
                    </div>
                  </div>
                  <PerformanceBadge percent={percent} />
                </div>
                <BigScore score={evaluation.totalScore} />
              </Card>
            ) : (
              <Card className="text-center p-10">
                <FolderOpen className="w-10 h-10 mx-auto text-muted-foreground/50" />
                <p className="mt-3 text-sm font-medium">
                  {t("ምንም ውጤት አልተገኘም", "No result found")}
                </p>
                <p className="text-xs text-muted-foreground">
                  {t(
                    `ለ${directorateKey} ገና ግምገማ አልተደረገም`,
                    `No evaluation found for ${directorateKey}`
                  )}
                  {quarter ? ` — ${quarter}` : ""}
                </p>
              </Card>
            )}

            {/* Quarterly report documents — upload ANY file type via this link */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileUp className="w-4 h-4 text-primary" />
                  {t("የሩብ ዓመት ሪፖርት ሰነዶች ያስገቡ", "Upload quarterly report documents")}
                </CardTitle>
                <CardDescription>
                  {t(
                    "ማንኛውም ዓይነት ሰነድ — PDF፣ Word፣ Excel፣ PowerPoint፣ ምስሎች ወይም ሌላ (≤ 10 MB)",
                    "PDF, Word, Excel, PowerPoint, pictures or any other file (≤ 10 MB)"
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Success banner — unique link + automation summary */}
                {lastUpload && (
                  <div
                    role="status"
                    className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 space-y-2.5"
                  >
                    <p className="flex items-start gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>
                        {t(
                          "ሰነድ ተሰቀለ! ብቁ አገናኝ ተፈጥሮ በአውቶማት ተልኳል።",
                          "Document uploaded — a unique link was created and sent automatically."
                        )}
                      </span>
                    </p>
                    <div className="flex items-center gap-2">
                      <input
                        readOnly
                        value={reportShareUrl(lastUpload.report.shareToken)}
                        aria-label={t("ብቁ የሰነድ አገናኝ", "Unique document link")}
                        className="h-8 min-w-0 flex-1 rounded-md border bg-background px-2 text-[11px] text-muted-foreground"
                      />
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-8 w-8 shrink-0"
                        aria-label={t("አገናኝ ቅዳ", "Copy unique link")}
                        onClick={() => copyLink(reportShareUrl(lastUpload.report.shareToken))}
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-muted-foreground">
                        {t("በአውቶማት ተልኳል፦", "Sent automatically:")}
                      </span>
                      <DeliveryChip type="whatsapp" label="WhatsApp" icon={MessageCircle} />
                      <DeliveryChip type="telegram" label="Telegram" icon={Send} />
                      <DeliveryChip type="email" label="Email" icon={Mail} />
                    </div>
                    {lastUpload.handoffs && lastUpload.handoffs.length > 0 && (
                      <div className="space-y-1.5">
                        <span className="block text-[11px] font-semibold text-muted-foreground">
                          {t(
                            "በአንድ ተማፕ ለመላክ ይንኩ (መልእክቱ ተዘጋጅቷል)፦",
                            "One-tap send (message is pre-filled):"
                          )}
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {lastUpload.handoffs.map((h, i) => (
                            <Button
                              key={`${h.channelType}-${i}`}
                              variant="secondary"
                              size="sm"
                              className="h-8 gap-1.5 text-xs font-semibold"
                              asChild
                            >
                              <a
                                href={h.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                title={h.detail}
                              >
                                {h.channelType === "whatsapp" ? (
                                  <MessageCircle className="w-3.5 h-3.5" />
                                ) : h.channelType === "email" ? (
                                  <Mail className="w-3.5 h-3.5" />
                                ) : (
                                  <Send className="w-3.5 h-3.5" />
                                )}
                                {h.channelType === "whatsapp"
                                  ? t("📲 WhatsApp ላክ", "📲 Send via WhatsApp")
                                  : h.channelType === "email"
                                    ? t("📧 Email ላክ", "📧 Send via Email")
                                    : h.label}
                              </a>
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Document title */}
                <div className="space-y-1.5">
                  <Label htmlFor="doc-title">{t("የሰነድ ርዕስ", "Document title")}</Label>
                  <Input
                    id="doc-title"
                    value={upTitle}
                    onChange={(e) => setUpTitle(e.target.value)}
                    placeholder={t(
                      "ለምሳሌ: የQ3 የጥራት ሪፖርት",
                      "e.g. Q3 quality report"
                    )}
                    className="h-9"
                    autoComplete="off"
                  />
                </div>

                {/* Quarter + file */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="doc-quarter">{t("ሩብ ዓመት", "Quarter")}</Label>
                    <Input
                      id="doc-quarter"
                      value={upQuarter}
                      onChange={(e) => setUpQuarter(e.target.value)}
                      className="h-9"
                      autoComplete="off"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="doc-file">
                      {t("ፋይል — ማንኛውም አይነት", "File — any type")}
                    </Label>
                    <Input
                      id="doc-file"
                      ref={fileInputRef}
                      type="file"
                      onChange={(e) => setUpFile(e.target.files?.[0] ?? null)}
                      className="h-9 file:mr-2 file:h-7 file:px-2 file:text-xs file:font-semibold"
                    />
                  </div>
                </div>

                {/* Note */}
                <div className="space-y-1.5">
                  <Label htmlFor="doc-note">
                    {t("ማስታወሻ (አማራጭ)", "Note (optional)")}
                  </Label>
                  <Input
                    id="doc-note"
                    value={upNote}
                    onChange={(e) => setUpNote(e.target.value)}
                    placeholder={t("አጭር ማብራሪያ", "Short description")}
                    className="h-9"
                    autoComplete="off"
                  />
                </div>

                <Button className="w-full h-10" onClick={uploadDocument} disabled={uploading}>
                  {uploading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileUp className="w-4 h-4" />
                  )}
                  {t("ሰነድ ስቀል", "Upload document")}
                </Button>
                <p className="text-[11px] text-muted-foreground flex items-start gap-1.5 leading-relaxed">
                  <Lock className="w-3.5 h-3.5 shrink-0 mt-px" />
                  <span>
                    {t(
                      "ከመላክ በኋላ ለሰነዱ ብቁ አገናኝ ይፈጠራል፤ አገናኙ ወዲያውኑ በWhatsApp (+251911133037)፣ Telegram (@feridmhd1) እና ኢሜይል ይላካል።",
                      "After upload a unique link is created for the document and immediately sent via WhatsApp (+251911133037), Telegram (@feridmhd1) and Email."
                    )}
                  </span>
                </p>
              </CardContent>
            </Card>

            {/* My uploaded documents — unique links + share */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" />
                  {t("የተሰቀሉ ሰነዶች", "My uploaded documents")}
                </CardTitle>
                <CardDescription>
                  {t(
                    "ለእያንዳንዱ ሰነድ የራሱ ብቁ አገናኝ",
                    "Each document with its own unique link"
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {docsLoading ? (
                  <LoadingSpinner />
                ) : docs.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    {t("እስካሁን ሰነድ አልተሰቀለም።", "No documents uploaded yet.")}
                  </p>
                ) : (
                  <ul className="space-y-2 max-h-96 overflow-y-auto pr-1">
                    {docs.map((doc) => {
                      const DocIcon = docIconFor(doc.mimeType);
                      const url = reportShareUrl(doc.shareToken);
                      const links = buildShareLinks(
                        url,
                        `📄 ${doc.title || doc.fileName} — ${doc.directorateKey}${doc.quarter ? ` · ${doc.quarter}` : ""}`
                      );
                      return (
                        <li
                          key={doc.id}
                          className="flex items-center gap-2.5 rounded-lg border p-2.5"
                        >
                          <div className="w-9 h-9 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                            <DocIcon className="w-4.5 h-4.5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-semibold truncate">
                              {doc.title || doc.fileName}
                            </div>
                            <div className="text-[11px] text-muted-foreground truncate">
                              {doc.fileName}
                              {doc.quarter ? ` · ${doc.quarter}` : ""}
                              {formatBytes(doc.size) ? ` · ${formatBytes(doc.size)}` : ""}
                              {` · ${new Date(doc.createdAt).toLocaleDateString()}`}
                            </div>
                          </div>
                          <div className="flex items-center shrink-0">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:bg-primary/10 hover:text-primary"
                              aria-label={t("ብቁ አገናኝ ቅዳ", "Copy unique link")}
                              onClick={() => copyLink(url)}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <a
                              href={links.whatsapp}
                              target="_blank"
                              rel="noopener noreferrer"
                              aria-label={t("በWhatsApp አጋራ", "Share on WhatsApp")}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-emerald-500/10 hover:text-emerald-600 dark:hover:text-emerald-400"
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                            <a
                              href={links.telegram}
                              target="_blank"
                              rel="noopener noreferrer"
                              aria-label={t("በTelegram አጋራ", "Share on Telegram")}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-sky-500/10 hover:text-sky-600 dark:hover:text-sky-400"
                            >
                              <Send className="w-4 h-4" />
                            </a>
                            <a
                              href={links.email}
                              target="_blank"
                              rel="noopener noreferrer"
                              aria-label={t("በኢሜይል አጋራ", "Share via email")}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-amber-500/10 hover:text-amber-600 dark:hover:text-amber-400"
                            >
                              <Mail className="w-4 h-4" />
                            </a>
                            <a
                              href={`${url}${url.includes("?") ? "&" : "?"}download=1`}
                              aria-label={t("ሰነድ አውርድ", "Download document")}
                              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-primary/10 hover:text-primary"
                            >
                              <Download className="w-4 h-4" />
                            </a>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>

            {/* Comments & suggestions */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-primary" />
                  {t("አስተያየት እና ጥቆማ", "Comments & Suggestions")}
                </CardTitle>
                <CardDescription>
                  {t("አስተያየትዎን ወይም ጥቆማዎን ይላኩ", "Share your comments and suggestions")}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {fbSent && (
                  <div
                    role="status"
                    className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 space-y-2.5"
                  >
                    <p className="flex items-start gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>
                        {t(
                          "አስተያየትዎ ተልኳል! እናመሰግናለን።",
                          "Your feedback was submitted — thank you."
                        )}
                      </span>
                    </p>
                    {fbDeliveries.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[11px] font-semibold text-muted-foreground">
                          {t("በአውቶማት ተልኳል", "Sent automatically:")}
                        </span>
                        <DeliveryChip
                          deliveries={fbDeliveries}
                          type="whatsapp"
                          label="WhatsApp"
                          icon={MessageCircle}
                        />
                        <DeliveryChip
                          deliveries={fbDeliveries}
                          type="telegram"
                          label="Telegram"
                          icon={Send}
                        />
                        <DeliveryChip
                          deliveries={fbDeliveries}
                          type="email"
                          label="Email"
                          icon={Mail}
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Kind selector */}
                <div
                  className="flex gap-2"
                  role="group"
                  aria-label={t("የመልእክት አይነት", "Message type")}
                >
                  <Button
                    type="button"
                    size="sm"
                    className="h-9 flex-1 min-w-0 px-2 text-xs sm:px-3 sm:text-sm"
                    variant={fbKind === "comment" ? "default" : "outline"}
                    aria-pressed={fbKind === "comment"}
                    onClick={() => setFbKind("comment")}
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" />
                    {t("አስተያየት", "Comment")}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    className="h-9 flex-1 min-w-0 px-2 text-xs sm:px-3 sm:text-sm"
                    variant={fbKind === "suggestion" ? "default" : "outline"}
                    aria-pressed={fbKind === "suggestion"}
                    onClick={() => setFbKind("suggestion")}
                  >
                    <Lightbulb className="w-4 h-4 shrink-0" />
                    {t("ጥቆማ", "Suggestion")}
                  </Button>
                </div>

                {/* Message */}
                <div className="space-y-1.5">
                  <Label htmlFor="fb-message">
                    {fbKind === "comment"
                      ? t("አስተያየትዎ", "Your comment")
                      : t("ጥቆማዎ", "Your suggestion")}
                  </Label>
                  <Textarea
                    id="fb-message"
                    value={fbMessage}
                    onChange={(e) => setFbMessage(e.target.value)}
                    placeholder={t(
                      "አስተያየትዎን ወይም ጥቆማዎን ይጻፉ…",
                      "Write your comment or suggestion…"
                    )}
                    rows={4}
                    maxLength={2000}
                    className="resize-none"
                  />
                </div>

                {/* Optional contact */}
                <div className="space-y-1.5">
                  <Label htmlFor="fb-contact">
                    {t("ኢሜይል ወይም ስልክ (አማራጭ)", "Email or phone (optional)")}
                  </Label>
                  <Input
                    id="fb-contact"
                    value={fbContact}
                    onChange={(e) => setFbContact(e.target.value)}
                    placeholder="email@example.com · +251…"
                    className="h-9"
                    autoComplete="off"
                  />
                </div>

                {/* Privacy note + submit */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <p className="text-[11px] text-muted-foreground flex items-start gap-1.5 min-w-0 leading-relaxed">
                    <Lock className="w-3.5 h-3.5 shrink-0 mt-px" />
                    <span>
                      {t(
                        "አስተያየትዎ ለቢሮው የሂሳብ ቡድን ብቻ ይታያል።",
                        "Your feedback is visible to the bureau office only."
                      )}
                    </span>
                  </p>
                  <Button className="h-9 sm:ml-auto shrink-0" onClick={submitFeedback} disabled={fbSending}>
                    {fbSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    {t("ላክ", "Send")}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Useful links — curated by the bureau, hidden silently when empty */}
            {usefulLinks.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-primary" />
                    {t("ጠቃሚ አገናኞች", "Useful Links")}
                  </CardTitle>
                  <CardDescription>
                    {t(
                      "ተዛማጅ መተግበሪያዎችና የትምህርት ገጾች",
                      "Related applications and learning resources"
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {usefulLinks.map((link) => {
                      const badgeCls =
                        link.category === "app"
                          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                          : link.category === "learning"
                            ? "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400"
                            : "border-border bg-muted text-muted-foreground";
                      const badgeLabel =
                        link.category === "app"
                          ? t("መተግበሪያ", "App")
                          : link.category === "learning"
                            ? t("ትምህርት", "Learning")
                            : t("ሌላ", "Other");
                      return (
                        <li
                          key={link.id}
                          className="flex items-start gap-2.5 rounded-lg border p-2.5"
                        >
                          <div className="w-9 h-9 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                            <Link2 className="w-4.5 h-4.5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-semibold line-clamp-1 min-w-0 break-words">
                                {link.title}
                              </span>
                              <span
                                className={`inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold ${badgeCls}`}
                              >
                                {badgeLabel}
                              </span>
                            </div>
                            {link.description?.trim() && (
                              <p className="text-[11px] text-muted-foreground line-clamp-2 mt-0.5">
                                {link.description}
                              </p>
                            )}
                          </div>
                          <a
                            href={link.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label={t("አገናኝ ክፈት", "Open link")}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-primary/10 hover:text-primary shrink-0"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </li>
                      );
                    })}
                  </ul>
                </CardContent>
              </Card>
            )}

            {evaluation && (
              <>
                {/* Category scores */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("የምድብ ውጤቶች", "Category Scores")}</CardTitle>
                    <CardDescription>{t("በእያንዳንዱ ምድብ", "Performance per category")}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {CRITERIA.map((c) => {
                      const score = evaluation.scores?.[c.key] ?? 0;
                      return (
                        <div key={c.key}>
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 shrink-0 rounded bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">
                              {c.key}
                            </span>
                            <span className="flex-1 truncate text-sm">{c.nameEn}</span>
                            <ScoreBadge score={score} max={c.maxScore} />
                          </div>
                          <ScoreBar score={score} max={c.maxScore} className="mt-1.5" />
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* Evaluator comments */}
                {commentRows.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("የግምገማ አስተያየቶች", "Evaluator Comments")}</CardTitle>
                      <CardDescription>{t("ከግምገማ ሰጪዎች", "From the evaluators")}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {commentRows.map((c) => (
                        <div key={c.key} className="flex items-start gap-2">
                          <span className="w-6 h-6 shrink-0 rounded bg-primary/10 text-primary text-xs font-bold flex items-center justify-center mt-0.5">
                            {c.key}
                          </span>
                          <div className="min-w-0">
                            <div className="text-sm font-bold">{c.nameEn}</div>
                            <p className="text-sm text-muted-foreground whitespace-pre-line">
                              {evaluation.comments[c.key]}
                            </p>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </>
            )}

            <p className="text-center text-xs text-muted-foreground pb-6">
              {t("ሀረሪ ክልል ጤና ቢሮ", "Harari Region Health Bureau")}
              {evaluation ? ` · ${new Date(evaluation.createdAt).toLocaleDateString()}` : ""}
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
