"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Download,
  Eye,
  Link2,
  Mail,
  MessageCircle,
  QrCode,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DIRECTORATES, DEFAULT_QUARTER } from "@/lib/rubric";
import { buildShareLinks, fetchQrDataUrl } from "@/lib/client-api";
import { useLang } from "@/lib/i18n";
import { buildAbsoluteUrl } from "@/hooks/use-view";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";

function downloadQr(dataUrl: string, short: string, quarter: string) {
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = `QR_${short}_${quarter}.png`;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

type ShareInfo = { portalUrl: string; links: ReturnType<typeof buildShareLinks> };

export function QRCodesView({ navigate }: { navigate: NavigateFn }) {
  const { t } = useLang();
  const [quarter, setQuarter] = useState(DEFAULT_QUARTER);
  const [qrMap, setQrMap] = useState<Record<string, Record<string, string>>>({});

  /* Portal link + share compose URLs per directorate (rebuilt when the quarter changes) */
  const shareByDir = useMemo(() => {
    const map: Record<string, ShareInfo> = {};
    for (const d of DIRECTORATES) {
      const portalUrl = buildAbsoluteUrl("portal", { dir: d.key, quarter });
      const text = t(
        `${d.nameEn} — የውጤት እና ሪፖርት መስኮት`,
        `${d.nameEn} — Score & report portal`
      );
      map[d.key] = { portalUrl, links: buildShareLinks(portalUrl, text) };
    }
    return map;
  }, [quarter, t]);

  const copyPortalLink = (info: ShareInfo) => {
    navigator.clipboard
      .writeText(info.portalUrl)
      .then(() => toast({ title: t("አገናኝ ተቀድቷል", "Link copied") }))
      .catch(() =>
        toast({
          variant: "destructive",
          title: t("አገናኝ መቅዳት አልተሳካም", "Copy failed"),
          description: t(
            "እባክዎ አገናኙን በእጅ ይቅዱ።",
            "Could not copy — please copy the link manually."
          ),
        })
      );
  };

  useEffect(() => {
    let cancelled = false;
    Promise.all(
      DIRECTORATES.map(async (d) => {
        const url = buildAbsoluteUrl("portal", { dir: d.key, quarter });
        return [d.key, await fetchQrDataUrl(url, 300)] as const;
      })
    )
      .then((entries) => {
        if (cancelled) return;
        setQrMap((prev) => ({ ...prev, [quarter]: Object.fromEntries(entries) }));
      })
      .catch(() => {
        if (!cancelled) {
          setQrMap((prev) => ({ ...prev, [quarter]: {} }));
          toast({
            title: "QR generation failed",
            description: t(
              "የQR ኮድ ማመንጨት አልተሳካም። እባክዎ እንደገና ይሞክሩ።",
              "QR generation failed. Please try again."
            ),
          });
        }
      });
    return () => {
      cancelled = true;
    };
  }, [quarter]);

  const loading = !(quarter in qrMap);
  const dataUrls = qrMap[quarter] ?? {};

  return (
    <div className="flex-1 bg-background">
      {/* Header */}
      <header className="bg-card border-b sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("home")}
            aria-label={t("ተመለስ", "Back")}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
          <h1 className="text-base md:text-lg font-bold leading-tight min-w-0 truncate">
            QR Codes <span className="text-muted-foreground font-normal">— Directorate Score Portals</span>
          </h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
        {/* Quarter input */}
        <Card className="p-4">
          <div className="flex flex-col sm:flex-row sm:items-end gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="qr-quarter">{t("ሩብ ዓመት", "Quarter")}</Label>
              <Input
                id="qr-quarter"
                value={quarter}
                onChange={(e) => setQuarter(e.target.value)}
                placeholder={DEFAULT_QUARTER}
                className="w-full sm:w-56"
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
            {t(
              "እያንዳንዱ QR ኮድ ዳይሬክቶሬውን ወደ ራሱ ገጽ ይወስዳል — የራሱን ውጤት ማየት፣ ማንኛውም ዓይነት የሩብ ዓመት ሪፖርት ሰነድ (PDF፣ Word፣ ምስል…) ማስገባት እና አስተያየት መላክ ይችላል። ከተሰቀለ በኋላ ለሰነዱ ብቁ አገናኝ ተፈጥሮ በአውቶማት ይላካል።",
              "Each QR opens the directorate's own hub — view their score, upload quarterly report documents in any format (PDF, Word, pictures…), complete the evaluation form and share feedback. Every upload instantly gets a unique link that is sent out automatically (WhatsApp · Telegram)."
            )}
          </p>
        </Card>

        {/* QR grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {DIRECTORATES.map((d) => {
            const dataUrl = dataUrls[d.key];
            const info = shareByDir[d.key];
            return (
              <Card key={d.key} className="p-4 flex flex-col items-center gap-2 text-center">
                <div className="font-bold text-sm">{d.short}</div>
                <div className="text-xs text-muted-foreground leading-snug min-h-[2rem] line-clamp-2">
                  {d.nameEn}
                </div>
                {loading || !dataUrl ? (
                  <div
                    className="w-[140px] h-[140px] rounded-lg bg-muted animate-pulse"
                    aria-label={`Generating QR for ${d.short}`}
                  />
                ) : (
                  <img
                    src={dataUrl}
                    width={140}
                    height={140}
                    alt={`QR code — ${d.short} score portal`}
                    className="rounded-lg border bg-white p-1"
                  />
                )}
                <div className="flex gap-2 w-full mt-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 text-xs h-8"
                    onClick={() => window.open(info.portalUrl, "_blank")}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Preview
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 text-xs h-8"
                    disabled={!dataUrl}
                    onClick={() => dataUrl && downloadQr(dataUrl, d.short, quarter)}
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download QR
                  </Button>
                </div>
                {/* Share row — send the portal hub link */}
                <div className="flex items-center justify-center gap-1 w-full border-t pt-2 mt-1">
                  <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mr-1">
                    {t("አጋራ", "Share")}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:bg-primary/10 hover:text-primary"
                    aria-label={t(`${d.short} አገናኝ ቅዳ`, `${d.short} Copy portal link`)}
                    onClick={() => copyPortalLink(info)}
                  >
                    <Link2 className="w-4 h-4" />
                  </Button>
                  <a
                    href={info.links.whatsapp}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t(`${d.short} በWhatsApp አጋራ`, `${d.short} Share on WhatsApp`)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-emerald-500/10 hover:text-emerald-600 dark:hover:text-emerald-400"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </a>
                  <a
                    href={info.links.telegram}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t(`${d.short} በTelegram አጋራ`, `${d.short} Share on Telegram`)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-sky-500/10 hover:text-sky-600 dark:hover:text-sky-400"
                  >
                    <Send className="w-4 h-4" />
                  </a>
                  <a
                    href={info.links.email}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t(`${d.short} በኢሜይል አጋራ`, `${d.short} Share via email`)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-amber-500/10 hover:text-amber-600 dark:hover:text-amber-400"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                </div>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
}
