"use client";

/**
 * Score Delivery Automation — configure WhatsApp / Telegram / Email channels,
 * review delivery logs and monitor server + memory-optimization status.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  BellOff,
  Bot,
  CheckCircle2,
  Clock,
  Database,
  Gauge,
  Info,
  Loader2,
  Lock,
  Mail,
  MemoryStick,
  MessageCircle,
  RefreshCw,
  Save,
  Send,
  Server,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { LoadingSpinner } from "@/components/shared";
import {
  automationApi,
  clearAutomationPin,
  getAutomationPin,
  setAutomationPin,
  systemApi,
} from "@/lib/client-api";
import type { AutomationChannelInput } from "@/lib/client-api";
import type { AutomationChannelDTO, DeliveryLogDTO, SystemStatus } from "@/lib/types";
import { DIRECTORATES } from "@/lib/rubric";
import { useLang } from "@/lib/i18n";
import type { NavigateFn } from "@/hooks/use-view";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

/* ---------------- Channel metadata ---------------- */

interface ChannelMeta {
  type: string;
  name: string;
  nameAm: string;
  description: string;
  icon: LucideIcon;
  iconClass: string;
  badgeClass: string;
  targetPlaceholder: string;
  tokenField: boolean;
  tokenHelp: string | null;
}

const CHANNEL_TYPES: ChannelMeta[] = [
  {
    type: "telegram",
    name: "Telegram",
    nameAm: "ቴሌግራም",
    description: "Telegram bot chat delivery",
    icon: Send,
    iconClass: "bg-sky-100 text-sky-600",
    badgeClass: "bg-sky-100 text-sky-700 hover:bg-sky-100",
    targetPlaceholder: "@chat_id or 123456789",
    tokenField: true,
    tokenHelp: "Get a token from @BotFather",
  },
  {
    type: "whatsapp",
    name: "WhatsApp",
    nameAm: "ዋትስአፕ",
    description: "WhatsApp Cloud API or wa.me manual sending",
    icon: MessageCircle,
    iconClass: "bg-emerald-100 text-emerald-600",
    badgeClass: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
    targetPlaceholder: "+2519…",
    tokenField: true,
    tokenHelp: "WhatsApp Cloud API access token (botToken field doubles as the API token)",
  },
  {
    type: "email",
    name: "Email",
    nameAm: "ኢሜይል",
    description: "Email delivery queue (SMTP relay)",
    icon: Mail,
    iconClass: "bg-amber-100 text-amber-600",
    badgeClass: "bg-amber-100 text-amber-700 hover:bg-amber-100",
    targetPlaceholder: "director@example.com",
    tokenField: false,
    tokenHelp: null,
  },
];

const CHANNEL_META_BY_TYPE: Record<string, ChannelMeta> = Object.fromEntries(
  CHANNEL_TYPES.map((m) => [m.type, m])
);

interface ChannelForm {
  id: string | null;
  label: string;
  target: string;
  botToken: string;
  enabled: boolean;
  hasToken: boolean;
  saving: boolean;
  testing: boolean;
}

function blankForm(): ChannelForm {
  return { id: null, label: "", target: "", botToken: "", enabled: false, hasToken: false, saving: false, testing: false };
}

function initialForms(): Record<string, ChannelForm> {
  return Object.fromEntries(CHANNEL_TYPES.map((m) => [m.type, blankForm()]));
}

/* ---------------- Small helpers ---------------- */

function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const sec = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  return `${Math.floor(hr / 24)}d ago`;
}

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m`;
  return `${sec}s`;
}

/** Short label for a log row — TEST rows flagged, otherwise directorate short name */
function logSubject(log: DeliveryLogDTO): string {
  if (log.directorateKey === "TEST") return "🧪 ሙከራ / Test";
  const short = DIRECTORATES.find((d) => d.key === log.directorateKey)?.short;
  const label = short || log.directorateName || log.directorateKey;
  return log.quarter ? `${label} · ${log.quarter}` : label;
}

function StatusBadge({ status }: { status: string }) {
  const { t } = useLang();
  if (status === "sent") {
    return (
      <Badge className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
        {t("ተልኳል", "Sent")}
      </Badge>
    );
  }
  if (status === "failed") {
    return (
      <Badge variant="destructive">{t("አልተሳካም", "Failed")}</Badge>
    );
  }
  return (
    <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
      {t("በወረፋ", "Queued")}
    </Badge>
  );
}

/** Detail line — renders wa.me manual-send links as clickable anchors */
function DetailLine({ text }: { text: string }) {
  const idx = text.indexOf("https://wa.me/");
  if (idx >= 0) {
    const end = text.indexOf(" ", idx);
    const url = end === -1 ? text.slice(idx) : text.slice(idx, end);
    return (
      <p className="mt-1 truncate text-xs text-muted-foreground" title={text}>
        {text.slice(0, idx)}
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary underline underline-offset-2"
        >
          {url}
        </a>
        {end === -1 ? "" : text.slice(end)}
      </p>
    );
  }
  return (
    <p className="mt-1 truncate text-xs text-muted-foreground" title={text}>
      {text || "—"}
    </p>
  );
}

function KpiChip({
  icon: Icon,
  label,
  value,
  valueClass,
  sub,
  children,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  valueClass?: string;
  sub?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border bg-background/60 p-3">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3.5 w-3.5" aria-hidden />
        <span className="text-[11px] font-medium uppercase tracking-wide">{label}</span>
      </div>
      <div className={cn("mt-1.5 font-bold leading-none", valueClass ?? "text-lg")}>{value}</div>
      {sub && <div className="mt-1 text-[11px] text-muted-foreground">{sub}</div>}
      {children}
    </div>
  );
}

/* ---------------- Automation edit password gate ---------------- */

/**
 * Editing the delivery automation (WhatsApp / Telegram / Email targets) is
 * password-protected — both in the UI and enforced server-side on every
 * save/delete/test request.
 */
function AutomationPinGate({ onUnlock }: { onUnlock: (pin: string) => void }) {
  const { t } = useLang();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const value = pin.trim();
    if (!value || busy) return;
    setBusy(true);
    setError("");
    try {
      await automationApi.verify(value);
      onUnlock(value);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Verification failed");
      setPin("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="glass-card mx-auto max-w-md">
      <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <div>
          <p className="text-sm font-semibold">{t("የአውቶማሽን ማስተካከያ ተቆልፏል", "Automation editing is locked")}</p>
          <p className="text-xs text-muted-foreground">
            Editing delivery channels is protected by a password — enter it to continue.
          </p>
        </div>
        <form onSubmit={submit} className="flex w-full max-w-xs items-center gap-2">
          <Input
            type="password"
            inputMode="numeric"
            autoComplete="off"
            className="h-9 text-center tracking-[0.4em]"
            placeholder="••••"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            aria-label={t("የአውቶማሽን የይለፍ ቃል", "Automation password")}
            disabled={busy}
          />
          <Button type="submit" className="h-9 shrink-0" disabled={!pin.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <ShieldCheck className="h-4 w-4" aria-hidden />}
            {t("ክፈት", "Unlock")}
          </Button>
        </form>
        {error && (
          <p className="text-xs font-medium text-destructive" role="alert">
            {error}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------------- View ---------------- */

export function AutomationView({ navigate }: { navigate: NavigateFn }) {
  const { t } = useLang();
  const [channelForms, setChannelForms] = useState<Record<string, ChannelForm>>(initialForms);
  const [logs, setLogs] = useState<DeliveryLogDTO[] | null>(null);
  const [logsRefreshing, setLogsRefreshing] = useState(false);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [clearingCache, setClearingCache] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const statusToastedRef = useRef(false);

  const updateForm = useCallback((type: string, patch: Partial<ChannelForm>) => {
    setChannelForms((prev) => ({ ...prev, [type]: { ...prev[type], ...patch } }));
  }, []);

  /* Restore an unlocked tab session (password already verified earlier) */
  useEffect(() => {
    const saved = getAutomationPin();
    if (saved) setUnlocked(true);
  }, []);

  const unlock = useCallback((pin: string) => {
    setAutomationPin(pin);
    setUnlocked(true);
  }, []);

  const lock = useCallback(() => {
    clearAutomationPin();
    setUnlocked(false);
  }, []);

  /** 401 from a channel mutation → the password changed or expired: re-lock */
  const handleAuthFailure = useCallback(
    (e: unknown) => {
      const msg = e instanceof Error ? e.message : "";
      if (/password|ይለፍ|401/i.test(msg)) {
        clearAutomationPin();
        setUnlocked(false);
      }
    },
    []
  );

  /* Load saved channels (one card per type — first saved channel per type wins) */
  useEffect(() => {
    let cancelled = false;
    automationApi
      .listChannels()
      .then(({ channels }: { channels: AutomationChannelDTO[] }) => {
        if (cancelled) return;
        setChannelForms((prev) => {
          const next = { ...prev };
          for (const ch of channels) {
            const base = next[ch.type];
            if (!base || base.id) continue;
            next[ch.type] = {
              ...base,
              id: ch.id,
              label: ch.label,
              target: ch.target,
              enabled: ch.enabled,
              hasToken: ch.hasToken,
            };
          }
          return next;
        });
      })
      .catch(() => {
        if (!cancelled) {
          toast({
            title: t("ስህተት", "Error"),
            description: "Failed to load delivery channels",
            variant: "destructive",
          });
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const refreshLogs = useCallback(async () => {
    try {
      const data = await automationApi.logs(50);
      setLogs(data.logs);
    } catch {
      toast({ title: t("ስህተት", "Error"), description: "Failed to load delivery logs", variant: "destructive" });
    }
  }, []);

  /* Load delivery logs */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await automationApi.logs(50);
        if (!cancelled) setLogs(data.logs);
      } catch {
        if (!cancelled) {
          toast({ title: t("ስህተት", "Error"), description: "Failed to load delivery logs", variant: "destructive" });
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* Server status: on mount + every 30s */
  useEffect(() => {
    let cancelled = false;
    const load = () => {
      systemApi
        .status()
        .then((s) => {
          if (!cancelled) setStatus(s);
        })
        .catch(() => {
          if (!cancelled && !statusToastedRef.current) {
            statusToastedRef.current = true;
            toast({
              title: t("ስህተት", "Error"),
              description: "Failed to load server status",
              variant: "destructive",
            });
          }
        });
    };
    load();
    const interval = setInterval(load, 30_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const handleManualRefreshLogs = async () => {
    setLogsRefreshing(true);
    await refreshLogs();
    setLogsRefreshing(false);
  };

  const saveChannel = async (type: string) => {
    const form = channelForms[type];
    if (!form || form.saving) return;
    updateForm(type, { saving: true });
    try {
      const payload: AutomationChannelInput & { id?: string } = {
        type,
        label: form.label,
        target: form.target.trim(),
        enabled: form.enabled,
      };
      if (form.id) payload.id = form.id;
      const token = form.botToken.trim();
      if (token) payload.botToken = token;

      const { channel } = await automationApi.saveChannel(payload);
      updateForm(type, {
        id: channel.id,
        label: channel.label,
        target: channel.target,
        enabled: channel.enabled,
        hasToken: channel.hasToken,
        botToken: "",
      });
      const meta = CHANNEL_META_BY_TYPE[channel.type];
      toast({
        title: t("መስመሩ ተቀምጧል", "Channel saved"),
        description: `${meta?.name ?? channel.type} configuration stored on the server.`,
      });
    } catch (e) {
      handleAuthFailure(e);
      toast({
        title: t("ማስቀመጥ አልተሳካም", "Save failed"),
        description: e instanceof Error ? e.message : "Failed to save channel",
        variant: "destructive",
      });
    } finally {
      updateForm(type, { saving: false });
    }
  };

  const testChannel = async (type: string) => {
    const form = channelForms[type];
    if (!form?.id || form.testing) return;
    updateForm(type, { testing: true });
    try {
      const { result } = await automationApi.testChannel({ channelId: form.id });
      if (result.status === "sent") {
        toast({
          title: t("የሙከራ መልእክት ተልኳል 🎉", "Test message sent 🎉"),
          description: "Test message delivered — check the chat / inbox.",
        });
      } else if (result.status === "queued") {
        toast({
          title: t("ወደ ወረፋ ገባ", "Queued"),
          description: result.detail || "Delivery queued — see the log below for the manual link.",
        });
      } else {
        toast({
          title: t("መላክ አልተሳካም", "Delivery failed"),
          description: result.detail || "See the delivery log for details.",
          variant: "destructive",
        });
      }
      await refreshLogs();
    } catch (e) {
      handleAuthFailure(e);
      toast({
        title: t("ሙከራ አልተሳካም", "Test failed"),
        description: e instanceof Error ? e.message : "Failed to send test message",
        variant: "destructive",
      });
    } finally {
      updateForm(type, { testing: false });
    }
  };

  const deleteChannel = async (type: string) => {
    const form = channelForms[type];
    if (!form?.id || form.saving) return;
    if (!window.confirm(t("ይህን የመስመር ምርጫ ለማጥፋት እርግጠኛ ነዎት?", "Delete this channel configuration?"))) return;
    updateForm(type, { saving: true });
    try {
      await automationApi.deleteChannel(form.id);
      updateForm(type, { id: null, label: "", target: "", botToken: "", enabled: false, hasToken: false });
      toast({ title: t("መስመር ተሰርዟል", "Channel deleted") });
    } catch (e) {
      handleAuthFailure(e);
      toast({
        title: t("መሰረዝ አልተሳካም", "Delete failed"),
        description: e instanceof Error ? e.message : "Failed to delete channel",
        variant: "destructive",
      });
    } finally {
      updateForm(type, { saving: false });
    }
  };

  const clearCache = async () => {
    setClearingCache(true);
    try {
      await systemApi.clearCache();
      const s = await systemApi.status();
      setStatus(s);
      toast({ title: t("ካሽ ተጽድቷል", "Cache cleared"), description: "Server cache cleared" });
    } catch {
      toast({
        title: t("ካሽ ማጽዳት አልተሳካል", "Failed to clear cache"),
        description: "Failed to clear server cache",
        variant: "destructive",
      });
    } finally {
      setClearingCache(false);
    }
  };

  const enabledCount = CHANNEL_TYPES.filter((m) => channelForms[m.type]?.enabled).length;

  return (
    <div className="flex-1 flex flex-col">
      {/* Sticky header */}
      <header className="sticky top-0 z-20 border-b bg-card">
        <div className="mx-auto flex w-full max-w-5xl items-center gap-3 px-4 py-3">
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={() => navigate("home")}
            aria-label={t("ተመለስ", "Back")}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-sm">
            <Bot className="h-5 w-5" aria-hidden />
          </div>
          <div className="min-w-0">
            <h1 className="truncate font-bold leading-tight">
              {t("የውጤት ማስረስ አውቶማሽን", "Score Delivery Automation")}
            </h1>
            <p className="truncate text-xs text-muted-foreground">
              {t(
                "WhatsApp · Telegram · Email — የተጠናቀቁ ውጤቶች በአውቶማቲክ ይላካሉ",
                "WhatsApp · Telegram · Email — completed scores are sent automatically"
              )}
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 space-y-6 px-4 py-6">
        {/* Section 1 — Delivery channels (editing is password-protected) */}
        <section aria-labelledby="channels-heading" className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <h2 id="channels-heading" className="text-lg font-bold">
              {t("የመልእክት መስመሮች", "Delivery Channels")}
            </h2>
            {unlocked ? (
              <>
                <Badge variant="secondary">{enabledCount}/3 {t("ንቁ", "active")}</Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto h-8 text-muted-foreground hover:text-foreground"
                  onClick={lock}
                >
                  <Lock className="h-3.5 w-3.5" aria-hidden />
                  {t("ቁልፍ ዝጋ", "Lock")}
                </Button>
              </>
            ) : (
              <Badge
                variant="outline"
                className="border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
              >
                <Lock className="h-3 w-3" aria-hidden />
                {t("ተቆልፏል", "Locked")}
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            {t(
              "የተጠናቀቁ ውጤቶች እና አዳዲስ ሰነዶች አገናኞች የሚላኩበትን ይምረጡ — ለማስተካከል የይለፍ ቃል ያስፈልጋል።",
              "Choose where completed scores and new document links get delivered — editing requires the password."
            )}
          </p>

          {unlocked ? (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {CHANNEL_TYPES.map((meta) => {
              const form = channelForms[meta.type] ?? blankForm();
              const Icon = meta.icon;
              return (
                <Card key={meta.type} className="glass-card">
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                          meta.iconClass
                        )}
                      >
                        <Icon className="h-5 w-5" aria-hidden />
                      </div>
                      <div className="min-w-0 flex-1">
                        <CardTitle className="text-base">
                          {t(meta.nameAm, meta.name)}
                        </CardTitle>
                        <CardDescription className="text-xs">{meta.description}</CardDescription>
                      </div>
                      <Switch
                        checked={form.enabled}
                        onCheckedChange={(v) => updateForm(meta.type, { enabled: v })}
                        aria-label={`Enable ${meta.name} channel`}
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-muted-foreground">{t("ዒላማ", "Target")}</p>
                      <Input
                        className="h-9"
                        value={form.target}
                        onChange={(e) => updateForm(meta.type, { target: e.target.value })}
                        placeholder={meta.targetPlaceholder}
                        aria-label={`${meta.name} target`}
                      />
                    </div>

                    {meta.tokenField && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground">{t("የመለያ ቁልፍ", "Credentials")}</p>
                        <Input
                          type="password"
                          autoComplete="new-password"
                          className="h-9"
                          value={form.botToken}
                          onChange={(e) => updateForm(meta.type, { botToken: e.target.value })}
                          placeholder="Bot token / API token (kept secret)"
                          aria-label={`${meta.name} bot token`}
                        />
                        {form.hasToken && !form.botToken && (
                          <p className="flex items-center gap-1 text-[11px] font-medium text-emerald-600">
                            <CheckCircle2 className="h-3 w-3" aria-hidden />
                            Token saved — leave blank to keep it
                          </p>
                        )}
                        {meta.tokenHelp && (
                          <p className="text-[11px] text-muted-foreground">{meta.tokenHelp}</p>
                        )}
                      </div>
                    )}

                    <div className="space-y-1">
                      <p className="text-xs font-medium text-muted-foreground">{t("መለያ", "Label (optional)")}</p>
                      <Input
                        className="h-9"
                        value={form.label}
                        onChange={(e) => updateForm(meta.type, { label: e.target.value })}
                        placeholder="e.g. Bureau directors group"
                        aria-label={`${meta.name} label`}
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <Button
                        size="sm"
                        className="h-9 flex-1"
                        onClick={() => saveChannel(meta.type)}
                        disabled={form.saving}
                      >
                        {form.saving ? (
                          <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                        ) : (
                          <Save className="h-4 w-4" aria-hidden />
                        )}
                        {t("አስቀምጥ", "Save")}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-9 flex-1"
                        onClick={() => testChannel(meta.type)}
                        disabled={!form.id || form.testing}
                      >
                        {form.testing ? (
                          <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                        ) : (
                          <Send className="h-4 w-4" aria-hidden />
                        )}
                        {t("ሙከራ ላክ", "Send Test")}
                      </Button>
                      {form.id && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-9 w-9 shrink-0 text-muted-foreground hover:text-destructive"
                          onClick={() => deleteChannel(meta.type)}
                          disabled={form.saving}
                          aria-label={`Delete ${meta.name} channel`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
              })}
            </div>
          ) : (
            <AutomationPinGate onUnlock={unlock} />
          )}
        </section>

        {/* Section 2 — Delivery log */}
        <section aria-labelledby="logs-heading">
          <Card className="glass-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <div className="min-w-0">
                <CardTitle id="logs-heading" className="text-lg">
                  {t("የመላክ ታሪክ", "Delivery Log")}
                </CardTitle>
                <CardDescription className="text-xs">
                  {t("የቅርብ ጊዜ የመላክ ሙከራዎች", "Latest delivery attempts")}
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="h-9 shrink-0"
                onClick={handleManualRefreshLogs}
                disabled={logsRefreshing}
              >
                <RefreshCw className={cn("h-4 w-4", logsRefreshing && "animate-spin")} aria-hidden />
                <span className="hidden sm:inline">{t("አድስ", "Refresh")}</span>
              </Button>
            </CardHeader>
            <CardContent>
              {logs === null ? (
                <LoadingSpinner className="py-8" />
              ) : logs.length === 0 ? (
                <div className="py-10 text-center">
                  <BellOff className="mx-auto h-10 w-10 text-muted-foreground/50" aria-hidden />
                  <p className="mt-3 text-sm font-medium">{t("እስካሁን መላክ አልተመዘገበም", "No deliveries logged yet")}</p>
                  <p className="text-xs text-muted-foreground">No deliveries logged yet</p>
                </div>
              ) : (
                <div className="max-h-96 space-y-2 overflow-y-auto pr-1 [scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar]:w-1.5">
                  {logs.map((log) => {
                    const meta = CHANNEL_META_BY_TYPE[log.channelType];
                    const Icon = meta?.icon ?? Bot;
                    return (
                      <div
                        key={log.id}
                        className="flex items-start gap-3 rounded-lg border bg-background/60 p-3"
                      >
                        <div
                          className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                            meta?.iconClass ?? "bg-slate-100 text-slate-600"
                          )}
                        >
                          <Icon className="h-4 w-4" aria-hidden />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                            <Badge className={cn("text-[10px]", meta?.badgeClass ?? "")}>
                              {meta?.name ?? log.channelType}
                            </Badge>
                            <span className="text-xs font-semibold">{logSubject(log)}</span>
                            <span className="max-w-[160px] truncate text-xs text-muted-foreground sm:max-w-none">
                              {log.target || "—"}
                            </span>
                            <StatusBadge status={log.status} />
                            <span className="ml-auto shrink-0 text-[11px] text-muted-foreground">
                              {timeAgo(log.createdAt)}
                            </span>
                          </div>
                          <DetailLine text={log.detail} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Section 3 — Server & memory optimization */}
        <section aria-labelledby="server-heading">
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-100 text-teal-600">
                  <Server className="h-5 w-5" aria-hidden />
                </div>
                <div className="min-w-0">
                  <CardTitle id="server-heading" className="text-lg">
                    {t("አገልጋይ እና ማህደረ ትውስታ", "Server & Memory Optimization")}
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Live server health, cache efficiency and storage engine — auto-refreshes every 30s
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {status === null ? (
                <LoadingSpinner className="py-6" />
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
                    <KpiChip
                      icon={Clock}
                      label="Uptime"
                      value={formatUptime(status.uptimeSec)}
                      sub="server uptime"
                    />
                    <KpiChip
                      icon={Server}
                      label="Runtime"
                      value={status.node}
                      valueClass="text-base"
                      sub={status.platform}
                    />
                    <KpiChip
                      icon={Database}
                      label="DB Engine"
                      value={status.dbEngine}
                      valueClass="text-base"
                      sub="persistent storage"
                    />
                    <KpiChip
                      icon={Gauge}
                      label="Cache hit rate"
                      value={`${status.cache.hitRate}%`}
                      sub={`${status.cache.hits} hits · ${status.cache.misses} misses`}
                    >
                      <Progress
                        value={status.cache.hitRate}
                        className="mt-2 h-1.5"
                        aria-label="Cache hit rate percentage"
                      />
                    </KpiChip>
                    <KpiChip
                      icon={MemoryStick}
                      label="Cache entries"
                      value={`${status.cache.size}/${status.cache.maxEntries}`}
                      sub={`${status.cache.evictions} evictions · ${status.cache.invalidations} invalidations`}
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="flex max-w-xl items-start gap-1.5 text-xs text-muted-foreground">
                      <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                      GET endpoints are cached server-side with automatic invalidation — reduces repeated
                      database work and memory pressure.
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-9"
                      onClick={clearCache}
                      disabled={clearingCache}
                    >
                      {clearingCache ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <Trash2 className="h-4 w-4" aria-hidden />
                      )}
                      {t("ካሽ አጽዳ", "Clear Cache")}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
