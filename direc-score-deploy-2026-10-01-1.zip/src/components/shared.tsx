"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { TOTAL_MAX_SCORE, performanceLabel, scorePercent } from "@/lib/rubric";
import { useLang } from "@/lib/i18n";

export function ScoreBadge({ score, max = TOTAL_MAX_SCORE }: { score: number; max?: number }) {
  const pct = scorePercent(score, max);
  const label = performanceLabel(pct);
  return (
    <span className={cn("text-xs font-bold px-2 py-0.5 rounded-full whitespace-nowrap", label.className)}>
      {score}/{max}
    </span>
  );
}

export function ScoreBar({ score, max, className }: { score: number; max: number; className?: string }) {
  const pct = scorePercent(score, max);
  const label = performanceLabel(pct);
  return (
    <div className={cn("w-full bg-muted rounded-full h-1.5 overflow-hidden", className)}>
      <div
        className={cn("h-1.5 rounded-full transition-all", label.barClass)}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function BigScore({ score, max = TOTAL_MAX_SCORE }: { score: number; max?: number }) {
  const pct = scorePercent(score, max);
  const { t } = useLang();
  return (
    <div className="flex flex-col items-center py-4">
      <div
        className={cn(
          "text-5xl font-extrabold",
          pct >= 75 ? "text-emerald-600" : pct >= 50 ? "text-amber-500" : "text-red-500"
        )}
      >
        {score}
      </div>
      <div className="text-sm text-muted-foreground mt-1">
        {t(`ከ ${max} ነጥብ (${pct}%)`, `${pct}% of ${max} points`)}
      </div>
      <div className="w-full max-w-sm mt-4 bg-muted rounded-full h-3 overflow-hidden">
        <div
          className={cn("h-3 rounded-full transition-all", performanceLabel(pct).barClass)}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function PerformanceBadge({ percent }: { percent: number }) {
  const label = performanceLabel(percent);
  const { lang } = useLang();
  return (
    <span className={cn("text-xs font-semibold px-3 py-1 rounded-full", label.className)}>
      {lang === "en" ? label.en : lang === "am" ? label.am : `${label.am} / ${label.en}`}
    </span>
  );
}

export function LoadingSpinner({ className }: { className?: string }) {
  return (
    <div className={cn("flex justify-center py-12", className)}>
      <div className="w-8 h-8 border-4 border-slate-200 border-t-primary rounded-full animate-spin" />
    </div>
  );
}

/* ---------------- AI evaluation output language ---------------- */

export type AiLanguage = "amharic" | "english" | "bilingual";

const AI_LANGUAGE_OPTIONS: Array<{ key: AiLanguage; label: string }> = [
  { key: "amharic", label: "አማርኛ" },
  { key: "english", label: "English" },
  { key: "bilingual", label: "አማ / EN" },
];

/**
 * Chooses the language the AI evaluator writes its comments in.
 * The report itself may be written in Amharic or English — the AI
 * understands both regardless of this choice.
 */
export function AiLanguageSelector({
  value,
  onChange,
}: {
  value: AiLanguage;
  onChange: (value: AiLanguage) => void;
}) {
  const { t } = useLang();
  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <span className="text-xs font-medium text-muted-foreground">
        {t("የAI አስተያየት ቋንቋ", "AI comment language")}
      </span>
      <div className="flex gap-1.5" role="group" aria-label={t("የAI አስተያየት ቋንቋ", "AI comment language")}>
        {AI_LANGUAGE_OPTIONS.map((o) => (
          <Button
            key={o.key}
            type="button"
            size="sm"
            variant={value === o.key ? "default" : "outline"}
            aria-pressed={value === o.key}
            className="h-8 px-2.5 text-xs"
            onClick={() => onChange(o.key)}
          >
            {o.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
