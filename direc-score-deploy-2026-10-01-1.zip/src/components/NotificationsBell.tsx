"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { notificationsApi } from "@/lib/client-api";
import { useLang } from "@/lib/i18n";
import type { NotificationDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

const REFRESH_EVENT = "direcscore:refresh-notifications";

function timeAgo(createdAt: string): string {
  const seconds = Math.floor((Date.now() - new Date(createdAt).getTime()) / 1000);
  if (!Number.isFinite(seconds) || seconds < 0) return "";
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export function NotificationsBell() {
  const { t } = useLang();
  const [notifications, setNotifications] = useState<NotificationDTO[]>([]);

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await notificationsApi.list();
      setNotifications(res.notifications);
    } catch {
      /* silent — bell is non-critical */
    }
  }, []);

  useEffect(() => {
    // Defer initial fetch + subscribe to refresh events (external system)
    const t = setTimeout(() => {
      void fetchNotifications();
    }, 0);
    window.addEventListener(REFRESH_EVENT, fetchNotifications);
    return () => {
      clearTimeout(t);
      window.removeEventListener(REFRESH_EVENT, fetchNotifications);
    };
  }, [fetchNotifications]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleItemClick = async (n: NotificationDTO) => {
    if (n.isRead) return;
    try {
      await notificationsApi.markRead(n.id);
      await fetchNotifications();
    } catch {
      /* ignore */
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationsApi.markAllRead();
      await fetchNotifications();
    } catch {
      /* ignore */
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label={t("ማሳወቂያዎች", "Notifications")}>
          <Bell />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex items-center justify-center bg-destructive text-white rounded-full text-[10px] min-w-4 h-4 px-1 font-semibold">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="text-xs">
          {t("ማሳወቂያዎች", "Notifications")} {unreadCount > 0 ? `(${unreadCount})` : ""}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {notifications.length === 0 ? (
          <div className="px-3 py-6 text-center text-xs text-muted-foreground">{t("ማሳወቂያ የለም", "No notifications")}</div>
        ) : (
          <div className="max-h-80 overflow-y-auto">
            {notifications.map((n) => (
              <DropdownMenuItem
                key={n.id}
                className={cn(
                  "flex items-start gap-2 py-2 cursor-pointer",
                  !n.isRead && "bg-primary/5"
                )}
                onClick={() => handleItemClick(n)}
              >
                <span
                  className={cn(
                    "rounded-full w-1.5 h-1.5 mt-1.5 shrink-0",
                    n.isRead ? "bg-transparent" : "bg-primary"
                  )}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold">{n.title}</div>
                  <div className="text-xs text-muted-foreground line-clamp-2">{n.message}</div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(n.createdAt)}</div>
                </div>
              </DropdownMenuItem>
            ))}
          </div>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          className="justify-center text-primary font-semibold cursor-pointer"
          onClick={handleMarkAllRead}
        >
          {t("ሁሉንም አንብብ", "Mark all as read")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
