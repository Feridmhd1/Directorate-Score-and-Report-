import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { LanguageProvider } from "@/lib/i18n";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "Direc-Score — Harari Region Health Bureau",
  description:
    "Directorate quarterly report evaluation system: unique score portals per directorate, quality report uploads, AI-assisted review, analytics and automated score delivery.",
  applicationName: "Direc-Score",
  keywords: [
    "Harari Region Health Bureau",
    "directorate evaluation",
    "quarterly report",
    "score report",
    "quality reports",
  ],
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [{ url: "/icon-64.png", type: "image/png" }],
    apple: [{ url: "/apple-touch-icon.png" }],
  },
  openGraph: {
    type: "website",
    siteName: "Direc-Score — Harari Region Health Bureau",
    title: "Direc-Score — Harari Region Health Bureau",
    description:
      "Quarterly directorate evaluation, scoring portals and quality report management for the Harari Region Health Bureau.",
    images: [{ url: "/harari-logo.jpg", width: 440, height: 280, alt: "Harari Regional Health Bureau" }],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f4f7fc" },
    { media: "(prefers-color-scheme: dark)", color: "#0b1220" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          <LanguageProvider>
            {children}
            <Toaster />
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
