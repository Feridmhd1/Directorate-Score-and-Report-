"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FolderLock, ShieldAlert } from "lucide-react";
import { readCollection, getFileBlob } from "@/lib/local-db";
import type { FiledDocumentDTO } from "@/lib/types";

/**
 * Browser-mode share page for the secure Document Filing room.
 * Mirrors the server /api/share/file route in local mode.
 */

function ShareFileInner() {
  const params = useSearchParams();
  const [status, setStatus] = useState<"loading" | "ready" | "missing">("loading");
  const [doc, setDoc] = useState<FiledDocumentDTO | null>(null);
  const [url, setUrl] = useState("");

  useEffect(() => {
    let objectUrl = "";
    const run = async () => {
      try {
        const rows = await readCollection<FiledDocumentDTO>("filedDocuments", []);
        const token = params.get("token") ?? "";
        const id = params.get("id") ?? "";
        const found = rows.find((r) => (token ? r.shareToken === token : r.id === id));
        if (!found) {
          setStatus("missing");
          return;
        }
        setDoc(found);
        const blob = await getFileBlob(found.id);
        if (blob) {
          objectUrl = URL.createObjectURL(blob);
          setUrl(objectUrl);
        }
        setStatus("ready");
        if (params.get("download") === "1" && blob) {
          const anchor = document.createElement("a");
          anchor.href = objectUrl;
          anchor.download = found.fileName;
          document.body.appendChild(anchor);
          anchor.click();
          anchor.remove();
        }
      } catch {
        setStatus("missing");
      }
    };
    void run();
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [params]);

  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-6">
        <p className="text-sm text-muted-foreground">በመጫን ላይ… / Loading…</p>
      </div>
    );
  }

  if (status === "missing" || !doc) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-6">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ShieldAlert className="h-5 w-5 text-amber-500" />
              ሰነዱ አልተገኘም / Document not found
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>ይህ የተመዘገበ ሰነድ በዚህ መሣሪያ ብራውዘር ውስጥ አይገኝም።</p>
            <p>
              Filed documents live in the browser that stored them (this deployment keeps data
              on-device). Open the link on the same device, or request the file through the
              WhatsApp / Telegram / Email channel it was shared to.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FolderLock className="h-5 w-5 text-emerald-600" />
            {doc.title}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="grid gap-1 text-muted-foreground">
            <span>ምድብ / Category: {doc.category}</span>
            <span>ፋይል / File: {doc.fileName}</span>
            <span>መጠን / Size: {(doc.size / 1024).toFixed(1)} KB</span>
            {doc.note && <span>ማስታወሻ / Note: {doc.note}</span>}
            <span>
              የመተላለፊያ ውጤት / Scan verdict: <strong>{doc.scanVerdict}</strong>
            </span>
          </div>
          {url ? (
            <a href={url} download={doc.fileName}>
              <Button className="w-full">
                <Download className="mr-2 h-4 w-4" />
                አውርድ / Download
              </Button>
            </a>
          ) : (
            <p className="text-amber-600">
              The file contents are not available on this device — only its details are.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function ShareFilePage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-background p-6">
          <p className="text-sm text-muted-foreground">በመጫን ላይ… / Loading…</p>
        </div>
      }
    >
      <ShareFileInner />
    </Suspense>
  );
}
