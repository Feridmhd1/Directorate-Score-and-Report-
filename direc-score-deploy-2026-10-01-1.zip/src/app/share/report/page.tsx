"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileText, ShieldAlert } from "lucide-react";
import { readCollection, getFileBlob } from "@/lib/local-db";
import type { QualityReportDTO } from "@/lib/types";

/**
 * Browser-mode share page for uploaded quality report documents.
 * Used when the app runs on hosts without a writable server database —
 * the unique link still opens on THIS device; other devices see a clear
 * notice (document delivery across devices happens through Telegram /
 * WhatsApp / Email hand-offs instead).
 */

function ShareReportInner() {
  const params = useSearchParams();
  const [status, setStatus] = useState<"loading" | "ready" | "missing">("loading");
  const [report, setReport] = useState<QualityReportDTO | null>(null);
  const [url, setUrl] = useState("");

  useEffect(() => {
    let objectUrl = "";
    const run = async () => {
      try {
        const rows = await readCollection<QualityReportDTO>("qualityReports", []);
        const token = params.get("token") ?? "";
        const id = params.get("id") ?? "";
        const found = rows.find((r) => (token ? r.shareToken === token : r.id === id));
        if (!found) {
          setStatus("missing");
          return;
        }
        setReport(found);
        const blob = await getFileBlob(found.id);
        if (blob) {
          objectUrl = URL.createObjectURL(blob);
          setUrl(objectUrl);
        }
        setStatus("ready");
        if (params.get("download") === "1" && blob) {
          const anchor = document.createElement("a");
          anchor.href = objectUrl;
          anchor.download = found.fileName;
          document.body.appendChild(anchor);
          anchor.click();
          anchor.remove();
        }
      } catch {
        setStatus("missing");
      }
    };
    void run();
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [params]);

  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-6">
        <p className="text-sm text-muted-foreground">በመጫን ላይ… / Loading…</p>
      </div>
    );
  }

  if (status === "missing" || !report) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-6">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ShieldAlert className="h-5 w-5 text-amber-500" />
              ሰነዱ አልተገኘም / Document not found
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>ይህ ሰነድ በዚህ መሣሪያ ብራውዘር ውስጥ አይገኝም። ሰነዶች በእያንዳንዱ ብራውዘር ውስጥ ይቀመጣሉ።</p>
            <p>
              This document is stored in the uploader&apos;s own browser (this deployment keeps
              data on-device). Ask for the file through the WhatsApp / Telegram / Email link that
              was shared with it.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="h-5 w-5 text-emerald-600" />
            {report.title}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="grid gap-1 text-muted-foreground">
            <span>ዳይሬክቶሬት / Directorate: {report.directorateKey}</span>
            {report.quarter && <span>ሩብ ዓመት / Quarter: {report.quarter}</span>}
            <span>ፋይል / File: {report.fileName}</span>
            <span>መጠን / Size: {(report.size / 1024).toFixed(1)} KB</span>
            {report.note && <span>ማስታወሻ / Note: {report.note}</span>}
          </div>
          {url ? (
            <a href={url} download={report.fileName}>
              <Button className="w-full">
                <Download className="mr-2 h-4 w-4" />
                አውርድ / Download
              </Button>
            </a>
          ) : (
            <p className="text-amber-600">
              The file contents are not available on this device — only its details are.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function ShareReportPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-background p-6">
          <p className="text-sm text-muted-foreground">በመጫን ላይ… / Loading…</p>
        </div>
      }
    >
      <ShareReportInner />
    </Suspense>
  );
}
