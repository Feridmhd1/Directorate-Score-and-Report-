import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import { cacheGet, cacheSet, cacheInvalidate } from "@/lib/cache";

function serialize(e: {
  id: string;
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  email: string | null;
  scoresJson: string;
  answersJson: string;
  commentsJson: string;
  totalScore: number;
  status: string;
  attachmentsJson: string;
  actionPlanJson: string;
  aiGenerated: boolean;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    id: e.id,
    directorateKey: e.directorateKey,
    directorateName: e.directorateName,
    directorateShort: e.directorateShort,
    quarter: e.quarter,
    email: e.email,
    scores: safeParse(e.scoresJson, {}),
    answers: safeParse(e.answersJson, {}),
    comments: safeParse(e.commentsJson, {}),
    totalScore: e.totalScore,
    status: e.status,
    attachments: safeParse(e.attachmentsJson, []),
    actionPlan: safeParse(e.actionPlanJson, []),
    aiGenerated: e.aiGenerated,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt.toISOString(),
  };
}

function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const quarter = searchParams.get("quarter");
    const directorateKey = searchParams.get("directorateKey");
    const all = searchParams.get("all");

    const cacheKey = `evals:${all ? "all" : quarter ?? ""}:${directorateKey ?? ""}`;
    const cached = cacheGet<{ evaluations: unknown[] }>(cacheKey);
    if (cached) return NextResponse.json(cached);

    const where: Record<string, string> = {};
    if (quarter) where.quarter = quarter;
    if (directorateKey) where.directorateKey = directorateKey;

    const evaluations = await db.directorateEvaluation.findMany({
      where,
      orderBy: { createdAt: all ? "desc" : "asc" },
      take: all ? 1000 : undefined,
    });
    const payload = { evaluations: evaluations.map(serialize) };
    cacheSet(cacheKey, payload);
    return NextResponse.json(payload);
  } catch (e) {
    console.error("evaluations GET error", e);
    return NextResponse.json({ error: "Failed to load evaluations" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    const body = await req.json();
    const {
      directorateKey,
      directorateName,
      directorateShort,
      quarter,
      email,
      scores,
      answers,
      comments,
      totalScore,
      status,
      attachments,
      actionPlan,
      aiGenerated,
    } = body;

    if (!directorateKey || !quarter) {
      return NextResponse.json({ error: "directorateKey and quarter are required" }, { status: 400 });
    }

    const evaluation = await db.directorateEvaluation.create({
      data: {
        directorateKey: String(directorateKey),
        directorateName: String(directorateName ?? ""),
        directorateShort: String(directorateShort ?? ""),
        quarter: String(quarter),
        email: email ? String(email) : null,
        scoresJson: JSON.stringify(scores ?? {}),
        answersJson: JSON.stringify(answers ?? {}),
        commentsJson: JSON.stringify(comments ?? {}),
        totalScore: Number(totalScore ?? 0),
        status: String(status ?? "completed"),
        attachmentsJson: JSON.stringify(attachments ?? []),
        actionPlanJson: JSON.stringify(actionPlan ?? []),
        aiGenerated: Boolean(aiGenerated ?? false),
      },
    });
    return NextResponse.json({ evaluation: serialize(evaluation), createdBy: user?.email ?? null });
  } catch (e) {
    console.error("evaluations POST error", e);
    return NextResponse.json({ error: "Failed to create evaluation" }, { status: 500 });
  } finally {
    cacheInvalidate("evals:");
    cacheInvalidate("analytics:");
  }
}
