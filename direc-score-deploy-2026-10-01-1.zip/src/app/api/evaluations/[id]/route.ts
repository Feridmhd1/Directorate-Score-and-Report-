import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cacheInvalidate } from "@/lib/cache";

function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

function serialize(e: {
  id: string;
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  email: string | null;
  scoresJson: string;
  answersJson: string;
  commentsJson: string;
  totalScore: number;
  status: string;
  attachmentsJson: string;
  actionPlanJson: string;
  aiGenerated: boolean;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    id: e.id,
    directorateKey: e.directorateKey,
    directorateName: e.directorateName,
    directorateShort: e.directorateShort,
    quarter: e.quarter,
    email: e.email,
    scores: safeParse(e.scoresJson, {}),
    answers: safeParse(e.answersJson, {}),
    comments: safeParse(e.commentsJson, {}),
    totalScore: e.totalScore,
    status: e.status,
    attachments: safeParse(e.attachmentsJson, []),
    actionPlan: safeParse(e.actionPlanJson, []),
    aiGenerated: e.aiGenerated,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt.toISOString(),
  };
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const existing = await db.directorateEvaluation.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Evaluation not found" }, { status: 404 });
    }
    const data: Record<string, unknown> = {};
    if (body.email !== undefined) data.email = body.email ? String(body.email) : null;
    if (body.scores !== undefined) data.scoresJson = JSON.stringify(body.scores);
    if (body.answers !== undefined) data.answersJson = JSON.stringify(body.answers);
    if (body.comments !== undefined) data.commentsJson = JSON.stringify(body.comments);
    if (body.totalScore !== undefined) data.totalScore = Number(body.totalScore);
    if (body.status !== undefined) data.status = String(body.status);
    if (body.attachments !== undefined) data.attachmentsJson = JSON.stringify(body.attachments);
    if (body.actionPlan !== undefined) data.actionPlanJson = JSON.stringify(body.actionPlan);
    if (body.quarter !== undefined) data.quarter = String(body.quarter);

    const evaluation = await db.directorateEvaluation.update({ where: { id }, data });
    return NextResponse.json({ evaluation: serialize(evaluation) });
  } catch (e) {
    console.error("evaluations PATCH error", e);
    return NextResponse.json({ error: "Failed to update evaluation" }, { status: 500 });
  } finally {
    cacheInvalidate("evals:");
    cacheInvalidate("analytics:");
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.directorateEvaluation.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("evaluations DELETE error", e);
    return NextResponse.json({ error: "Failed to delete evaluation" }, { status: 500 });
  } finally {
    cacheInvalidate("evals:");
    cacheInvalidate("analytics:");
  }
}
