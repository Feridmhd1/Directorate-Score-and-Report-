import { NextResponse } from "next/server";
import { readFile } from "fs/promises";
import path from "path";
import sharp from "sharp";
import { SETTING_KEYS, getSetting, setSetting } from "@/lib/settings-store";
import { requireSettingsPin } from "@/lib/settings-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_INPUT_BYTES = 5 * 1024 * 1024; // 5 MB upload cap

/** In-memory cache for the built-in Harari logo data URL (avoids disk hits) */
let defaultLogoCache: string | null = null;

async function defaultLogoDataUrl(): Promise<string> {
  if (defaultLogoCache) return defaultLogoCache;
  const filePath = path.join(process.cwd(), "public", "harari-logo.jpg");
  const raw = await readFile(filePath);
  const png = await sharp(raw)
    .resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true })
    .png({ compressionLevel: 9 })
    .toBuffer();
  defaultLogoCache = `data:image/png;base64,${png.toString("base64")}`;
  return defaultLogoCache;
}

/**
 * GET /api/settings/logo
 * Returns { logoDataUrl, custom } — the stored custom logo, or the built-in
 * Harari Regional Health Bureau logo. Always a data URL so the logo can be
 * embedded directly in <img> tags and in exported PDF files.
 */
export async function GET() {
  const stored = await getSetting(SETTING_KEYS.logoDataUrl);
  if (stored) {
    return NextResponse.json(
      { logoDataUrl: stored, custom: true },
      { headers: { "Cache-Control": "private, max-age=120" } }
    );
  }
  return NextResponse.json(
    { logoDataUrl: await defaultLogoDataUrl(), custom: false },
    { headers: { "Cache-Control": "private, max-age=300" } }
  );
}

/** POST /api/settings/logo — multipart upload of a logo picture (password-protected) */
export async function POST(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }
    if (file.size > MAX_INPUT_BYTES) {
      return NextResponse.json({ error: "Logo must be under 5 MB" }, { status: 413 });
    }
    const type = file.type || "";
    if (!type.startsWith("image/")) {
      return NextResponse.json({ error: "Only image files are accepted" }, { status: 415 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    // Normalize: max 512px wide, PNG keeps transparency
    const png = await sharp(buffer)
      .resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true })
      .png({ compressionLevel: 9 })
      .toBuffer();

    const dataUrl = `data:image/png;base64,${png.toString("base64")}`;
    await setSetting(SETTING_KEYS.logoDataUrl, dataUrl);

    return NextResponse.json({ logoDataUrl: dataUrl, custom: true });
  } catch (err) {
    return NextResponse.json(
      {
        error:
          err instanceof Error
            ? `Logo processing failed: ${err.message}`
            : "Logo processing failed",
      },
      { status: 500 }
    );
  }
}

/** DELETE /api/settings/logo — remove the custom logo (falls back to the built-in Harari logo) */
export async function DELETE(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  await setSetting(SETTING_KEYS.logoDataUrl, "");
  return NextResponse.json({ logoDataUrl: await defaultLogoDataUrl(), custom: false });
}
