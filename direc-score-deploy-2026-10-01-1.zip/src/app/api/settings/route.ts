import { NextResponse } from "next/server";
import {
  SETTING_KEYS,
  getSetting,
  getSettings,
  isTrue,
  setSettings,
  invalidateSettingsCache,
} from "@/lib/settings-store";
import { requireSettingsPin } from "@/lib/settings-guard";
import { loadDriveConfig, isDriveConfigured } from "@/lib/drive-backup";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/settings — public-safe settings (no secrets) */
export async function GET() {
  const s = await getSettings([
    SETTING_KEYS.organizationName,
    SETTING_KEYS.autoBackupEnabled,
    SETTING_KEYS.backupFrequency,
    SETTING_KEYS.lastBackupAt,
    SETTING_KEYS.lastBackupStatus,
    SETTING_KEYS.lastBackupDetail,
  ]);
  const drive = await loadDriveConfig();

  return NextResponse.json(
    {
      settings: {
        organizationName: s[SETTING_KEYS.organizationName] || "Harari Region Health Bureau",
        customLogo: Boolean(await getSetting(SETTING_KEYS.logoDataUrl)),
        autoBackupEnabled: isTrue(s[SETTING_KEYS.autoBackupEnabled]),
        backupFrequency: s[SETTING_KEYS.backupFrequency] || "weekly",
        lastBackupAt: s[SETTING_KEYS.lastBackupAt] || null,
        lastBackupStatus: s[SETTING_KEYS.lastBackupStatus] || "idle",
        lastBackupDetail: s[SETTING_KEYS.lastBackupDetail] || "",
        driveConfigured: isDriveConfigured(drive),
      },
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/** PUT /api/settings — update settings (password-protected) */
export async function PUT(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  try {
    const body = (await req.json()) as Record<string, unknown>;
    const updates: Record<string, string> = {};

    if (typeof body.organizationName === "string") {
      updates[SETTING_KEYS.organizationName] = body.organizationName.slice(0, 120);
    }
    if (typeof body.autoBackupEnabled === "boolean") {
      updates[SETTING_KEYS.autoBackupEnabled] = String(body.autoBackupEnabled);
    }
    if (body.backupFrequency === "weekly" || body.backupFrequency === "daily") {
      updates[SETTING_KEYS.backupFrequency] = body.backupFrequency;
    }
    // Drive credentials are write-only — blank/missing keeps the stored value
    if (typeof body.driveClientId === "string" && body.driveClientId.trim()) {
      updates[SETTING_KEYS.driveClientId] = body.driveClientId.trim().slice(0, 300);
    }
    if (typeof body.driveClientSecret === "string" && body.driveClientSecret.trim()) {
      updates[SETTING_KEYS.driveClientSecret] = body.driveClientSecret.trim().slice(0, 300);
    }
    if (typeof body.driveRefreshToken === "string" && body.driveRefreshToken.trim()) {
      updates[SETTING_KEYS.driveRefreshToken] = body.driveRefreshToken.trim().slice(0, 600);
    }
    if (typeof body.driveFolderId === "string") {
      updates[SETTING_KEYS.driveFolderId] = body.driveFolderId.trim().slice(0, 300);
    }
    if (body.clearDriveConfig === true) {
      updates[SETTING_KEYS.driveClientId] = "";
      updates[SETTING_KEYS.driveClientSecret] = "";
      updates[SETTING_KEYS.driveRefreshToken] = "";
      updates[SETTING_KEYS.driveFolderId] = "";
    }
    // Security PINs are write-only — never echoed back by GET
    if (typeof body.filingPin === "string" && body.filingPin.trim()) {
      updates[SETTING_KEYS.filingPin] = body.filingPin.trim().slice(0, 32);
    }
    if (typeof body.automationPin === "string" && body.automationPin.trim()) {
      updates[SETTING_KEYS.automationPin] = body.automationPin.trim().slice(0, 32);
    }
    // Settings page password itself (write-only, never echoed back by GET)
    if (typeof body.settingsPin === "string" && body.settingsPin.trim()) {
      updates[SETTING_KEYS.settingsPin] = body.settingsPin.trim().slice(0, 32);
    }

    if (Object.keys(updates).length === 0) {
      return NextResponse.json({ error: "No valid settings provided" }, { status: 400 });
    }

    await setSettings(updates);
    invalidateSettingsCache();
    return GET();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}
