import { NextResponse } from "next/server";
import { getSettingsPin } from "@/lib/settings-guard";
import { clearFailures, clientIp, recordFailure, throttleFailure } from "@/lib/filing-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/settings/verify — unlock the Settings page.
 * Body: { pin }. Same brute-force throttling as the other password guards.
 */
export async function POST(req: Request) {
  const ip = clientIp(req);
  const throttled = throttleFailure(ip);
  if (throttled) return throttled;

  let pin = "";
  try {
    const body = (await req.json()) as { pin?: unknown };
    pin = String(body?.pin ?? "").trim();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const expected = await getSettingsPin();
  if (!pin || pin !== expected) {
    recordFailure(ip);
    return NextResponse.json(
      { error: "ትክክለኛ የይለፍ ቃል ያስፈልጋል / Incorrect settings password" },
      { status: 401 }
    );
  }

  clearFailures(ip);
  return NextResponse.json({ ok: true });
}
