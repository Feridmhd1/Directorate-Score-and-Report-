import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest, deleteSession } from "@/lib/auth";

const SESSION_COOKIE = "direcscore_session";

export async function POST(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (token) {
    await deleteSession(token).catch(() => {});
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", { path: "/", expires: new Date(0) });
  return res;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  return NextResponse.json({ user: null });
}
