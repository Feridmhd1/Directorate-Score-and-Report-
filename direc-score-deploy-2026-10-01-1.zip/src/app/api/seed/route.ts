import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { CRITERIA, DIRECTORATES, computeScores } from "@/lib/rubric";

const DEMO_PASSWORD = "Admin@123";

export async function POST() {
  try {
    const existing = await db.user.findUnique({ where: { email: "admin@harari.gov.et" } });
    if (existing) {
      return NextResponse.json({ ok: true, seeded: false, message: "Already seeded" });
    }

    await db.user.create({
      data: {
        email: "admin@harari.gov.et",
        passwordHash: hashPassword(DEMO_PASSWORD),
        name: "Evaluation Admin",
      },
    });

    // Deterministic pseudo-random generator for stable demo data
    let seed = 42;
    const rand = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };

    const quarters = ["Q1-2018EFY", "Q2-2018EFY", "Q3-2018EFY"];
    const evaluationsData: Array<{
      directorateKey: string;
      directorateName: string;
      directorateShort: string;
      quarter: string;
      scoresJson: string;
      answersJson: string;
      commentsJson: string;
      totalScore: number;
      status: string;
      createdAt: Date;
    }> = [];

    quarters.forEach((quarter, qi) => {
      DIRECTORATES.forEach((d, di) => {
        // leave a few gaps so UI shows "not evaluated" states
        if ((di + qi) % 7 === 3 && qi === 2) return;
        const answers: Record<string, string> = {};
        CRITERIA.forEach((c) => {
          c.subQuestions.forEach((q) => {
            answers[q.id] = rand() < 0.55 + qi * 0.12 + (di % 3) * 0.05 ? "yes" : "no";
          });
        });
        const { scores, totalScore } = computeScores(answers);
        const comments: Record<string, string> = {};
        if (totalScore > 40) {
          comments.C = "Strong alignment with bureau annual goals; priorities well articulated.";
          comments.F =
            totalScore > 60
              ? "Notable achievements this quarter with clear outputs."
              : "Progress is steady but several activities remain ongoing.";
        }
        evaluationsData.push({
          directorateKey: d.key,
          directorateName: d.name,
          directorateShort: d.short,
          quarter,
          scoresJson: JSON.stringify(scores),
          answersJson: JSON.stringify(answers),
          commentsJson: JSON.stringify(comments),
          totalScore,
          status: qi < 2 ? "sent" : "completed",
          createdAt: new Date(Date.now() - (quarters.length - qi) * 45 * 24 * 3600 * 1000 + di * 3600 * 1000),
        });
      });
    });

    await db.directorateEvaluation.createMany({ data: evaluationsData });

    await db.notification.createMany({
      data: [
        {
          type: "evaluation_completed",
          title: "ግምገማ ተጠናቅቋል — HPDP",
          message: "Health Promotion & Disease Prevention የQ3-2018EFY ግምገማ ተጠናቅቋል።",
          directorateKey: "HPDP",
          directorateName: "Health Promotion & Disease Prevention",
          quarter: "Q3-2018EFY",
          totalScore: evaluationsData.find((e) => e.directorateKey === "HPDP" && e.quarter === "Q3-2018EFY")
            ?.totalScore ?? 0,
          isRead: false,
        },
        {
          type: "report_submitted",
          title: "ዳይሬክተር ሪፖርት ቀርቧል — MSD",
          message: "Medical Service Delivery የQ3-2018EFY ሪፖርት በAI ተገምግሟል።",
          directorateKey: "MSD",
          directorateName: "Medical Service Delivery",
          quarter: "Q3-2018EFY",
          totalScore: evaluationsData.find((e) => e.directorateKey === "MSD" && e.quarter === "Q3-2018EFY")
            ?.totalScore ?? 0,
          isRead: false,
        },
      ],
    });

    return NextResponse.json({
      ok: true,
      seeded: true,
      credentials: { email: "admin@harari.gov.et", password: DEMO_PASSWORD },
    });
  } catch (e) {
    console.error("seed error", e);
    return NextResponse.json({ error: "Seeding failed" }, { status: 500 });
  }
}
