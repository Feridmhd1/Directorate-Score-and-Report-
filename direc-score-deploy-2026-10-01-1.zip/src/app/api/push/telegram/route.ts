import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * POST /api/push/telegram — server-side Telegram relay.
 *
 * Purpose: portal submissions made by directorates on THEIR OWN devices
 * cannot read the supervisor's browser-stored bot token, so this route
 * delivers their uploads/notifications instead using deployment environment
 * variables:
 *
 *   TELEGRAM_BOT_TOKEN  — bot token from @BotFather
 *   TELEGRAM_CHAT_ID    — the supervisor's chat id (@feridmhd1 or numeric)
 *
 * When the variables are missing the route answers
 *   { ok: false, error: "not-configured" }
 * and the portal falls back to its one-tap WhatsApp / Email hand-off links.
 *
 * Accepts multipart/form-data with:
 *   message   (string, required)
 *   chatId    (string, optional — overrides TELEGRAM_CHAT_ID)
 *   file      (File, optional — sent via sendDocument)
 */
export async function POST(req: NextRequest) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN?.trim() ?? "";
  const defaultChat = process.env.TELEGRAM_CHAT_ID?.trim() ?? "";

  if (!botToken) {
    return NextResponse.json({ ok: false, error: "not-configured" }, { status: 200 });
  }

  try {
    const form = await req.formData();
    const message = String(form.get("message") ?? "").trim();
    const chatId = String(form.get("chatId") ?? "").trim() || defaultChat;
    if (!message && !form.get("file")) {
      return NextResponse.json({ ok: false, error: "message is required" }, { status: 400 });
    }
    if (!chatId) {
      return NextResponse.json(
        { ok: false, error: "not-configured", detail: "TELEGRAM_CHAT_ID missing" },
        { status: 200 }
      );
    }

    const file = form.get("file");
    if (file instanceof File && file.size > 0) {
      if (file.size > 45 * 1024 * 1024) {
        return NextResponse.json(
          { ok: false, error: "file-too-large", detail: "Telegram documents are limited to ~45MB" },
          { status: 413 }
        );
      }
      const documentForm = new FormData();
      documentForm.append("chat_id", chatId);
      documentForm.append("document", file, file.name || "document");
      if (message) documentForm.append("caption", message.slice(0, 900));
      const res = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
        method: "POST",
        body: documentForm,
        signal: AbortSignal.timeout(50_000),
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; description?: string } | null;
      if (res.ok && json?.ok) {
        return NextResponse.json({ ok: true, via: "sendDocument" });
      }
      return NextResponse.json(
        { ok: false, error: "telegram-error", detail: json?.description || `HTTP ${res.status}` },
        { status: 200 }
      );
    }

    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message || "(empty message)" }),
      signal: AbortSignal.timeout(20_000),
    });
    const json = (await res.json().catch(() => null)) as { ok?: boolean; description?: string } | null;
    if (res.ok && json?.ok) {
      return NextResponse.json({ ok: true, via: "sendMessage" });
    }
    return NextResponse.json(
      { ok: false, error: "telegram-error", detail: json?.description || `HTTP ${res.status}` },
      { status: 200 }
    );
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: "relay-failed", detail: e instanceof Error ? e.message : String(e) },
      { status: 200 }
    );
  }
}
