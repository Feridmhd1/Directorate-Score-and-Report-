import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { deliverEvaluation, createResultNotification, serializeLog } from "@/lib/automation";

export const dynamic = "force-dynamic";

/**
 * POST /api/automation/auto-notify
 * Body: { evaluationId }
 * Fan-out of a freshly completed evaluation to every enabled channel.
 * Called automatically after an evaluation is completed/saved.
 * Does NOT change the evaluation status.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const evaluationId = body?.evaluationId ? String(body.evaluationId) : "";
    if (!evaluationId) {
      return NextResponse.json({ error: "evaluationId is required" }, { status: 400 });
    }

    const evaluation = await db.directorateEvaluation.findUnique({ where: { id: evaluationId } });
    if (!evaluation) {
      return NextResponse.json({ error: "Evaluation not found" }, { status: 404 });
    }

    const channels = await db.automationChannel.findMany({
      where: { enabled: true },
      orderBy: { createdAt: "asc" },
    });
    if (channels.length === 0) {
      return NextResponse.json({ results: [] });
    }

    const delivered = await deliverEvaluation(evaluation, channels);
    await createResultNotification(evaluation);

    return NextResponse.json({ results: delivered.map(serializeLog) });
  } catch (e) {
    console.error("automation auto-notify error", e);
    return NextResponse.json({ error: "Failed to run auto-notify" }, { status: 500 });
  }
}
