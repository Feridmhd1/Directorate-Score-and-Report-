import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { serializeLog } from "@/lib/automation";

export const dynamic = "force-dynamic";

/** GET /api/automation/logs?limit=50 — latest delivery attempts, newest first */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const parsed = Number.parseInt(searchParams.get("limit") ?? "50", 10);
    const limit = Number.isFinite(parsed) ? Math.min(Math.max(parsed, 1), 200) : 50;

    const logs = await db.deliveryLog.findMany({
      orderBy: { createdAt: "desc" },
      take: limit,
    });
    return NextResponse.json({ logs: logs.map(serializeLog) });
  } catch (e) {
    console.error("automation logs GET error", e);
    return NextResponse.json({ error: "Failed to load delivery logs" }, { status: 500 });
  }
}
