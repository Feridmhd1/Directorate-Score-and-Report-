import { NextRequest, NextResponse } from "next/server";
import type { DeliveryLog } from "@prisma/client";
import { db } from "@/lib/db";
import { cacheInvalidate } from "@/lib/cache";
import { deliverEvaluation, createResultNotification, serializeLog } from "@/lib/automation";

export const dynamic = "force-dynamic";

/**
 * POST /api/automation/send
 * Body: { channelId?, evaluationIds: string[] }
 * Sends completed score summaries through one specific channel (channelId)
 * or through every enabled channel. Also creates in-app notifications and
 * marks evaluations as "sent" when at least one delivery succeeded/queued.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawIds: unknown = body?.evaluationIds;
    if (!Array.isArray(rawIds) || rawIds.length === 0) {
      return NextResponse.json({ error: "evaluationIds must be a non-empty array" }, { status: 400 });
    }
    const ids = rawIds.map((v) => String(v)).filter(Boolean);

    let channels;
    const channelId = body?.channelId ? String(body.channelId) : "";
    if (channelId) {
      const channel = await db.automationChannel.findUnique({ where: { id: channelId } });
      if (!channel) {
        return NextResponse.json({ error: "Channel not found" }, { status: 404 });
      }
      channels = [channel];
    } else {
      channels = await db.automationChannel.findMany({
        where: { enabled: true },
        orderBy: { createdAt: "asc" },
      });
    }

    const evaluations = await db.directorateEvaluation.findMany({
      where: { id: { in: ids } },
    });
    if (evaluations.length === 0) {
      return NextResponse.json({ error: "No matching evaluations found" }, { status: 404 });
    }

    const results: DeliveryLog[] = [];
    for (const evaluation of evaluations) {
      const delivered = await deliverEvaluation(evaluation, channels);
      results.push(...delivered);

      // Side effects: in-app notification + status → "sent" when something went out
      try {
        await createResultNotification(evaluation);
        const wentOut = delivered.some((l) => l.status === "sent" || l.status === "queued");
        if (wentOut) {
          await db.directorateEvaluation.update({
            where: { id: evaluation.id },
            data: { status: "sent" },
          });
        }
      } catch (sideEffectError) {
        console.error("automation send side-effect error", sideEffectError);
      }
    }

    // Evaluation statuses may have changed — refresh cached GET payloads
    cacheInvalidate("evals:");
    cacheInvalidate("analytics:");

    return NextResponse.json({ results: results.map(serializeLog) });
  } catch (e) {
    console.error("automation send error", e);
    return NextResponse.json({ error: "Failed to send scores" }, { status: 500 });
  }
}
