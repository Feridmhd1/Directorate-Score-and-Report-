import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { VALID_CHANNEL_TYPES, ensureDefaultDeliveryChannels, serializeChannel } from "@/lib/automation";
import { requireAutomationPin } from "@/lib/automation-guard";

export const dynamic = "force-dynamic";

/** GET /api/automation/channels — list delivery channels (botToken never returned) */
export async function GET() {
  try {
    // First run: seed the default WhatsApp / Telegram / Email recipients
    await ensureDefaultDeliveryChannels();
    const channels = await db.automationChannel.findMany({ orderBy: { createdAt: "asc" } });
    return NextResponse.json({ channels: channels.map(serializeChannel) });
  } catch (e) {
    console.error("automation channels GET error", e);
    return NextResponse.json({ error: "Failed to load channels" }, { status: 500 });
  }
}

/**
 * POST /api/automation/channels — create or update a channel.
 * PASSWORD-PROTECTED (x-automation-pin header — editing the automation requires the password).
 * Body: { id?, type, label?, target?, botToken?, enabled? }
 * On update, a blank/missing botToken keeps the stored credentials.
 */
export async function POST(req: NextRequest) {
  const denied = await requireAutomationPin(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const type = String(body?.type ?? "");
    if (!VALID_CHANNEL_TYPES.includes(type)) {
      return NextResponse.json(
        { error: "type must be one of: telegram, whatsapp, email" },
        { status: 400 }
      );
    }

    const id = body?.id ? String(body.id) : "";
    const hasLabel = body?.label !== undefined;
    const hasTarget = body?.target !== undefined;
    const hasEnabled = body?.enabled !== undefined;
    const label = hasLabel ? String(body.label) : "";
    const target = hasTarget ? String(body.target).trim() : "";
    const enabled = hasEnabled ? Boolean(body.enabled) : false;
    // Empty string / undefined → keep the existing token on update
    const botToken =
      typeof body?.botToken === "string" && body.botToken.trim() ? body.botToken.trim() : undefined;

    if (id) {
      const existing = await db.automationChannel.findUnique({ where: { id } });
      if (!existing) {
        return NextResponse.json({ error: "Channel not found" }, { status: 404 });
      }
      const updated = await db.automationChannel.update({
        where: { id },
        data: {
          type,
          ...(hasLabel && { label }),
          ...(hasTarget && { target }),
          ...(hasEnabled && { enabled }),
          ...(botToken !== undefined && { botToken }),
        },
      });
      return NextResponse.json({ channel: serializeChannel(updated) });
    }

    const created = await db.automationChannel.create({
      data: {
        type,
        label,
        target,
        enabled,
        ...(botToken !== undefined && { botToken }),
      },
    });
    return NextResponse.json({ channel: serializeChannel(created) });
  } catch (e) {
    console.error("automation channels POST error", e);
    return NextResponse.json({ error: "Failed to save channel" }, { status: 500 });
  }
}

/** DELETE /api/automation/channels?id=... — remove a channel configuration (password-protected) */
export async function DELETE(req: NextRequest) {
  const denied = await requireAutomationPin(req);
  if (denied) return denied;
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "id is required" }, { status: 400 });
    }
    const existing = await db.automationChannel.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Channel not found" }, { status: 404 });
    }
    await db.automationChannel.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("automation channels DELETE error", e);
    return NextResponse.json({ error: "Failed to delete channel" }, { status: 500 });
  }
}
