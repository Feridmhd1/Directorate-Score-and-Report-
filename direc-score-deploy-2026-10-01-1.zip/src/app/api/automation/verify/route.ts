import { NextResponse } from "next/server";
import { getAutomationPin } from "@/lib/automation-guard";
import { clearFailures, clientIp, recordFailure, throttleFailure } from "@/lib/filing-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/automation/verify — unlock automation editing.
 * Body: { pin }. Same brute-force throttling as the channel routes.
 */
export async function POST(req: Request) {
  const ip = clientIp(req);
  const throttled = throttleFailure(ip);
  if (throttled) return throttled;

  let pin = "";
  try {
    const body = (await req.json()) as { pin?: unknown };
    pin = String(body?.pin ?? "").trim();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const expected = await getAutomationPin();
  if (!pin || pin !== expected) {
    recordFailure(ip);
    return NextResponse.json(
      { error: "ትክክለኛ የይለፍ ቃል ያስፈልጋል / Incorrect automation password" },
      { status: 401 }
    );
  }

  clearFailures(ip);
  return NextResponse.json({ ok: true });
}
