import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/share/report?token=<shareToken> — the unique, shareable public link
 * for an uploaded quality report document (safe to send via WhatsApp,
 * Telegram or Email). Serves the file inline so PDFs/images preview in the
 * browser and other types download.
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const token = searchParams.get("token")?.trim();
  const download = searchParams.get("download") === "1";
  if (!token) {
    return NextResponse.json({ error: "token is required" }, { status: 400 });
  }

  const row = await db.qualityReport.findUnique({ where: { shareToken: token } });
  if (!row) {
    return NextResponse.json({ error: "Document not found or link revoked" }, { status: 404 });
  }

  const buffer = Buffer.from(row.data ?? "", "base64");
  const safeName = (row.fileName || "document").replace(/[^\w.\- ()]/g, "_");
  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": row.mimeType || "application/octet-stream",
      "Content-Length": String(buffer.length),
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${safeName}"`,
      "Cache-Control": "private, max-age=120",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
