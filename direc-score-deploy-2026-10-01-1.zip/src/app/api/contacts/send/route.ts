import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  buildScoreMessage,
  createResultNotification,
  deliverDirectMessage,
  deliverTextMessage,
  serializeLog,
  toScoreEvaluation,
} from "@/lib/automation";
import { deadlineDaysLeft, missingDirectorates, parseDeadline } from "@/lib/deadline";
import { getSetting, SETTING_KEYS } from "@/lib/settings-store";
import { DIRECTORATES, DEFAULT_QUARTER } from "@/lib/rubric";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * POST /api/contacts/send — "send it all in one go".
 *
 * body: { mode: "scores" | "reminder", quarter?, directorateKeys? }
 *
 *  - mode "scores": every evaluated directorate of the quarter receives its
 *    own score summary through ITS OWN saved WhatsApp / Telegram / Email
 *    contacts (directorates without saved contacts fall back to the enabled
 *    admin channels).
 *  - mode "reminder": every directorate receives a polite "submit the
 *    quarterly report before the deadline" reminder through its own saved
 *    contacts (the saved deadline from Settings is included when set).
 *
 * Each attempt is persisted as a DeliveryLog row and returned per
 * directorate so the UI can show the outcome of every channel.
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const mode = body.mode === "reminder" ? "reminder" : "scores";

    const keyFilter = Array.isArray(body.directorateKeys)
      ? (body.directorateKeys as unknown[]).map((k) => String(k).trim()).filter(Boolean)
      : [];

    /* Latest evaluation per directorate (scores mode) */
    const latestFor = new Map<string, (typeof rows)[number]>();
    let rows: Array<{
      id: string;
      directorateKey: string;
      directorateName: string;
      directorateShort: string;
      quarter: string;
      totalScore: number;
      scoresJson: string;
      actionPlanJson: string;
      status: string;
      email: string | null;
    }> = [];

    if (mode === "scores") {
      const quarter = String(body.quarter ?? "").trim() || DEFAULT_QUARTER;
      rows = await db.directorateEvaluation.findMany({
        where: {
          quarter,
          ...(keyFilter.length > 0 ? { directorateKey: { in: keyFilter } } : {}),
        },
        orderBy: { createdAt: "desc" },
        take: 500,
      });
      for (const row of rows) {
        if (!latestFor.has(row.directorateKey)) latestFor.set(row.directorateKey, row);
      }
      if (latestFor.size === 0) {
        return NextResponse.json(
          { error: "No evaluations found for this quarter" },
          { status: 404 }
        );
      }
    }

    /* Deadline context (reminder mode) */
    const deadline =
      mode === "reminder"
        ? parseDeadline(await getSetting(SETTING_KEYS.reportDeadline))
        : null;
    const quarter =
      String(body.quarter ?? "").trim() || deadline?.quarter || DEFAULT_QUARTER;
    const missing =
      deadline && mode === "reminder" ? await missingDirectorates(deadline) : [];
    const daysLeft = deadline ? deadlineDaysLeft(deadline.date) : null;

    const origin = new URL(req.url).origin;
    const portalLink = (key: string) =>
      `${origin}/?view=portal&dir=${encodeURIComponent(key)}&quarter=${encodeURIComponent(quarter)}`;

    const results: Array<{
      directorateKey: string;
      directorateName: string;
      directorateShort: string;
      contactSaved: boolean;
      channels: string[];
      logs: ReturnType<typeof serializeLog>[];
    }> = [];

    const targets: Array<{ key: string; name: string; short: string }> =
      mode === "scores"
        ? [...latestFor.values()].map((r) => ({
            key: r.directorateKey,
            name: r.directorateName,
            short: r.directorateShort,
          }))
        : DIRECTORATES.filter((d) => keyFilter.length === 0 || keyFilter.includes(d.key)).map(
            (d) => ({ key: d.key, name: d.nameEn || d.name, short: d.short })
          );

    for (const target of targets) {
      const dMeta = DIRECTORATES.find((d) => d.key === target.key);
      const name = target.name || dMeta?.nameEn || dMeta?.name || target.key;
      const short = target.short || dMeta?.short || target.key;

      /* ---- Build the message ---- */
      let message: string;
      if (mode === "scores") {
        const row = latestFor.get(target.key)!;
        message = buildScoreMessage(
          toScoreEvaluation(
            row as unknown as Parameters<typeof toScoreEvaluation>[0]
          )
        );
      } else {
        const isMissing = missing.some((m) => m.key === target.key);
        const lines = [
          "⏰ Direc-Score — የሪፖርት ማስታወሻ / Report reminder",
          `ዳይሬክቶሬት / Directorate: ${name} (${short})`,
          deadline
            ? `ሩብ ዓመት / Quarter: ${deadline.quarter} — መጨረሻ ቀን / Deadline: ${deadline.date}${
                daysLeft !== null && daysLeft >= 0 ? ` (${daysLeft} ቀናት ይቀራሉ / ${daysLeft} days left)` : ""
              }`
            : `ሩብ ዓመት / Quarter: ${quarter}`,
          "",
          isMissing
            ? "እባክዎ ሪፖርትዎን ከመጣሪያ ቀኑ በፊት ያስገቡ።\nPlease submit your quarterly report before the deadline."
            : "የሩብ ዓመት ሪፖርት ማስገቢያ እንዳሉ እናስታውስዎታለን።\nThis is a friendly reminder to keep your quarterly report up to date.",
          "",
          `🔗 ${portalLink(target.key)}`,
        ];
        message = lines.join("\n");
      }

      /* ---- Deliver through the directorate's own contacts ---- */
      const contact = await db.directorateContact.findUnique({
        where: { directorateKey: target.key },
      });
      const contactSaved = Boolean(
        contact && (contact.whatsapp.trim() || contact.telegram.trim() || contact.email.trim())
      );
      const meta = { directorateKey: target.key, directorateName: name, quarter };

      const logs = contactSaved
        ? await deliverDirectMessage(
            message,
            {
              whatsapp: contact?.whatsapp,
              telegram: contact?.telegram,
              email: contact?.email,
            },
            meta
          )
        : await deliverTextMessage(
            `${message}\n\n(ማስታወሻ — ለዚህ ዳይሬክቶሬት ቀጥታ እውቂያ አልተቀመጠም / No direct contact saved for this directorate — sent to the admin channels instead)`,
            meta
          );

      const channels = [...new Set(logs.map((l) => l.channelType))];

      if (mode === "scores") {
        const row = latestFor.get(target.key)!;
        if (logs.some((l) => l.status === "sent") && row.status !== "sent") {
          try {
            await db.directorateEvaluation.update({
              where: { id: row.id },
              data: { status: "sent" },
            });
          } catch {
            /* status update is cosmetic */
          }
        }
        void createResultNotification(
          row as unknown as Parameters<typeof createResultNotification>[0]
        );
      }

      results.push({
        directorateKey: target.key,
        directorateName: name,
        directorateShort: short,
        contactSaved,
        channels,
        logs: logs.map(serializeLog),
      });
    }

    if (mode === "reminder") {
      try {
        await db.notification.create({
          data: {
            type: "reminders_sent",
            title: `⏰ ማስታወሻ ተልኳል — ${quarter}`,
            message: `${results.length} ዳይሬክቶሬቶች ማስታወሻ ደርሷቸዋል${deadline ? ` (መጨረሻ: ${deadline.date})` : ""}`,
            quarter,
          },
        });
      } catch {
        /* notification is a side-benefit */
      }
    }

    return NextResponse.json({ mode, quarter, results });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}
