import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { DIRECTORATES } from "@/lib/rubric";
import { requireSettingsPin } from "@/lib/settings-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Directorate delivery contacts (email / WhatsApp / Telegram).
 *
 *  - GET    /api/contacts          — list every saved contact (open)
 *  - PUT    /api/contacts          — insert/update one directorate (settings PIN)
 *  - DELETE /api/contacts?key=KEY  — remove one directorate (settings PIN)
 *
 * Saving contacts enables the "send it all in one go" flows (score reports,
 * deadline reminders) powered by /api/contacts/send.
 */

function serialize(row: {
  id: string;
  directorateKey: string;
  directorateName: string;
  email: string;
  whatsapp: string;
  telegram: string;
  createdAt: Date;
  updatedAt: Date;
}) {
  const meta = DIRECTORATES.find((d) => d.key === row.directorateKey);
  return {
    id: row.id,
    directorateKey: row.directorateKey,
    directorateName: row.directorateName || meta?.nameEn || meta?.name || row.directorateKey,
    directorateShort: meta?.short ?? "",
    email: row.email,
    whatsapp: row.whatsapp,
    telegram: row.telegram,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** GET /api/contacts — every saved directorate contact */
export async function GET() {
  const rows = await db.directorateContact.findMany({
    orderBy: { directorateKey: "asc" },
  });
  return NextResponse.json(
    { contacts: rows.map(serialize) },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/** PUT /api/contacts — insert or update one directorate's contacts (settings PIN) */
export async function PUT(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const directorateKey = String(body.directorateKey ?? "").trim();
    const meta = DIRECTORATES.find((d) => d.key === directorateKey);
    if (!meta) {
      return NextResponse.json({ error: "Unknown directorateKey" }, { status: 400 });
    }
    const data = {
      directorateName: meta.nameEn || meta.name,
      email: String(body.email ?? "").trim().slice(0, 200),
      whatsapp: String(body.whatsapp ?? "").trim().slice(0, 40),
      telegram: String(body.telegram ?? "").trim().slice(0, 100),
    };
    const row = await db.directorateContact.upsert({
      where: { directorateKey },
      update: data,
      create: { directorateKey, ...data },
    });
    return NextResponse.json({ contact: serialize(row) });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

/** DELETE /api/contacts?key=HPDP — remove a directorate's saved contacts (settings PIN) */
export async function DELETE(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;
  const { searchParams } = new URL(req.url);
  const directorateKey = searchParams.get("key")?.trim();
  if (!directorateKey) {
    return NextResponse.json({ error: "key is required" }, { status: 400 });
  }
  await db.directorateContact.deleteMany({ where: { directorateKey } });
  return NextResponse.json({ ok: true });
}
