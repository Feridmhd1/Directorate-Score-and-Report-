import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { cacheGet, cacheSet } from "@/lib/cache";
import { CRITERIA, TOTAL_MAX_SCORE } from "@/lib/rubric";

export const dynamic = "force-dynamic";

/**
 * Server-side analytics aggregation.
 * Computes KPIs, per-directorate latest/trend, category averages and quarterly
 * history on the SERVER so clients don't need to download & process raw rows
 * (memory optimization). Result is cached in-process.
 */
export async function GET() {
  try {
    const cached = cacheGet<unknown>("analytics:summary");
    if (cached) return NextResponse.json(cached);

    const evaluations = await db.directorateEvaluation.findMany({
      orderBy: { createdAt: "asc" },
      take: 2000,
    });

    // latest + previous per directorate
    const byDir = new Map<string, { latest: (typeof evaluations)[number]; previous: (typeof evaluations)[number] | null }>();
    for (const e of evaluations) {
      const entry = byDir.get(e.directorateKey);
      if (!entry) {
        byDir.set(e.directorateKey, { latest: e, previous: null });
      } else {
        // evaluations are ascending by createdAt, so newer ones come later
        entry.previous = entry.latest;
        entry.latest = e;
      }
    }

    const pct = (t: number) => (TOTAL_MAX_SCORE > 0 ? Math.round((t / TOTAL_MAX_SCORE) * 100) : 0);

    const byDirectorate = [...byDir.entries()].map(([key, { latest, previous }]) => ({
      key,
      short: latest.directorateShort,
      nameEn: latest.directorateName,
      latest: { total: latest.totalScore, pct: pct(latest.totalScore), quarter: latest.quarter, status: latest.status },
      previousTotal: previous ? previous.totalScore : null,
      trend: previous ? Math.round(latest.totalScore - previous.totalScore) : null,
    }));

    const totals = evaluations.map((e) => e.totalScore);
    const avgScore = totals.length ? totals.reduce((a, b) => a + b, 0) / totals.length : 0;

    const sorted = [...evaluations].sort((a, b) => b.totalScore - a.totalScore);
    const best = sorted[0];
    const worst = sorted[sorted.length - 1];

    const good = totals.filter((t) => pct(t) >= 75).length;
    const average = totals.filter((t) => pct(t) >= 50 && pct(t) < 75).length;
    const needsImprovement = totals.filter((t) => pct(t) < 50).length;

    const categoryAverages = CRITERIA.map((c) => {
      const vals = evaluations.map((e) => {
        try {
          return (JSON.parse(e.scoresJson) as Record<string, number>)[c.key] ?? 0;
        } catch {
          return 0;
        }
      });
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      return { key: c.key, nameEn: c.nameEn, avg: Math.round(avg * 10) / 10, max: c.maxScore };
    });

    // quarterly history (avg score per quarter)
    const quarterMap = new Map<string, number[]>();
    for (const e of evaluations) {
      const arr = quarterMap.get(e.quarter) ?? [];
      arr.push(e.totalScore);
      quarterMap.set(e.quarter, arr);
    }
    const history = [...quarterMap.entries()]
      .map(([quarter, arr]) => ({
        quarter,
        count: arr.length,
        avg: Math.round((arr.reduce((a, b) => a + b, 0) / arr.length) * 10) / 10,
      }))
      .sort((a, b) => a.quarter.localeCompare(b.quarter));

    const payload = {
      quarters: history.map((h) => h.quarter),
      kpis: {
        evaluations: evaluations.length,
        directoratesEvaluated: byDir.size,
        avgScore: Math.round(avgScore * 10) / 10,
        avgPct: pct(avgScore),
        needsImprovement,
        average,
        good,
        highest: best
          ? { short: best.directorateShort, nameEn: best.directorateName, total: best.totalScore, quarter: best.quarter }
          : null,
        lowest: worst
          ? { short: worst.directorateShort, nameEn: worst.directorateName, total: worst.totalScore, quarter: worst.quarter }
          : null,
      },
      byDirectorate,
      categoryAverages,
      history,
    };

    cacheSet("analytics:summary", payload, 60_000);
    return NextResponse.json(payload);
  } catch (e) {
    console.error("analytics summary error", e);
    return NextResponse.json({ error: "Failed to compute analytics summary" }, { status: 500 });
  }
}
