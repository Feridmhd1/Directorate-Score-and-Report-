import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSettingsPin } from "@/lib/settings-guard";
import type { LinkItemDTO } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const LINK_CATEGORIES = ["app", "learning", "other"] as const;

function serialize(row: {
  id: string;
  title: string;
  url: string;
  category: string;
  description: string;
  createdAt: Date;
}): LinkItemDTO {
  return {
    id: row.id,
    title: row.title,
    url: row.url,
    category: row.category,
    description: row.description,
    createdAt: row.createdAt.toISOString(),
  };
}

/** GET /api/links?category=learning — list curated links (public: portal shows them too) */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category")?.trim();
  const rows = await db.linkItem.findMany({
    where: category ? { category } : {},
    orderBy: [{ category: "asc" }, { createdAt: "asc" }],
    take: 300,
  });
  return NextResponse.json(
    { links: rows.map(serialize) },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/**
 * POST /api/links — add a link to the library.
 * Protected by the Settings password (x-settings-pin header), same as the
 * Settings page and other admin surfaces.
 * body: { title, url, category?, description? }
 */
export async function POST(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  try {
    const body = (await req.json()) as Record<string, unknown>;
    const title = String(body.title ?? "").trim();
    let url = String(body.url ?? "").trim();
    if (!title || !url) {
      return NextResponse.json(
        { error: "ርዕስና ሊንክ ያስፈልጋሉ / Title and URL are required" },
        { status: 400 }
      );
    }
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    try {
      new URL(url);
    } catch {
      return NextResponse.json({ error: "ትክክለኛ URL ያስገቡ / Enter a valid URL" }, { status: 400 });
    }
    const category = LINK_CATEGORIES.includes(String(body.category ?? "") as never)
      ? String(body.category)
      : "other";
    const row = await db.linkItem.create({
      data: {
        title: title.slice(0, 200),
        url: url.slice(0, 1000),
        category,
        description: String(body.description ?? "").trim().slice(0, 500),
      },
    });
    return NextResponse.json({ link: serialize(row) });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

/** PATCH /api/links?id=<id> — update a link (Settings password protected) */
export async function PATCH(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  const existing = await db.linkItem.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  try {
    const body = (await req.json()) as Record<string, unknown>;
    const data: { title?: string; url?: string; category?: string; description?: string } = {};
    if (body.title !== undefined) {
      const title = String(body.title).trim();
      if (!title) return NextResponse.json({ error: "Title is required" }, { status: 400 });
      data.title = title.slice(0, 200);
    }
    if (body.url !== undefined) {
      let url = String(body.url).trim();
      if (!url) return NextResponse.json({ error: "URL is required" }, { status: 400 });
      if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
      try {
        new URL(url);
      } catch {
        return NextResponse.json({ error: "ትክክለኛ URL ያስገቡ / Enter a valid URL" }, { status: 400 });
      }
      data.url = url.slice(0, 1000);
    }
    if (body.category !== undefined) {
      data.category = LINK_CATEGORIES.includes(String(body.category) as never)
        ? String(body.category)
        : existing.category;
    }
    if (body.description !== undefined) {
      data.description = String(body.description).trim().slice(0, 500);
    }
    const row = await db.linkItem.update({ where: { id }, data });
    return NextResponse.json({ link: serialize(row) });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

/** DELETE /api/links?id=<id> — remove a link (Settings password protected) */
export async function DELETE(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  const existing = await db.linkItem.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.linkItem.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
