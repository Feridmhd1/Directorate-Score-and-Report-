import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

function serialize(d: {
  id: string;
  fileName: string;
  content: string;
  contentLength: number;
  wordCount: number;
  status: string;
  insightsJson: string | null;
  graphicsJson: string | null;
  chartsJson: string | null;
  finalReportJson: string | null;
  finalized: boolean;
  documentType: string;
  language: string;
  sentiment: string;
  mimeType: string;
  createdAt: Date;
}) {
  return {
    id: d.id,
    fileName: d.fileName,
    content: d.content,
    contentLength: d.contentLength,
    wordCount: d.wordCount,
    status: d.status,
    insights: safeParse<Record<string, unknown> | null>(d.insightsJson, null),
    graphics: safeParse<Record<string, unknown>[]>(d.graphicsJson, []),
    charts: safeParse<Record<string, unknown>[]>(d.chartsJson, []),
    finalized: d.finalized,
    finalReport: safeParse<Record<string, unknown> | null>(d.finalReportJson, null),
    documentType: d.documentType,
    language: d.language,
    sentiment: d.sentiment,
    mimeType: d.mimeType,
    createdAt: d.createdAt.toISOString(),
  };
}

export async function GET() {
  try {
    const documents = await db.documentHistory.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json({ documents: documents.map(serialize) });
  } catch (e) {
    console.error("documents GET error", e);
    return NextResponse.json({ error: "Failed to load documents" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { fileName, content, status, mimeType } = body;
    if (!fileName) {
      return NextResponse.json({ error: "fileName is required" }, { status: 400 });
    }
    const text = typeof content === "string" ? content : "";
    const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
    const document = await db.documentHistory.create({
      data: {
        fileName: String(fileName),
        content: text.slice(0, 200000),
        contentLength: text.length,
        wordCount,
        status: String(status ?? "processing"),
        mimeType: String(mimeType ?? ""),
      },
    });
    return NextResponse.json({ document: serialize(document) });
  } catch (e) {
    console.error("documents POST error", e);
    return NextResponse.json({ error: "Failed to save document" }, { status: 500 });
  }
}
