import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

function serialize(d: {
  id: string;
  fileName: string;
  content: string;
  contentLength: number;
  wordCount: number;
  status: string;
  insightsJson: string | null;
  graphicsJson: string | null;
  chartsJson: string | null;
  finalReportJson: string | null;
  finalized: boolean;
  documentType: string;
  language: string;
  sentiment: string;
  mimeType: string;
  createdAt: Date;
}) {
  return {
    id: d.id,
    fileName: d.fileName,
    content: d.content,
    contentLength: d.contentLength,
    wordCount: d.wordCount,
    status: d.status,
    insights: safeParse<Record<string, unknown> | null>(d.insightsJson, null),
    graphics: safeParse<Record<string, unknown>[]>(d.graphicsJson, []),
    charts: safeParse<Record<string, unknown>[]>(d.chartsJson, []),
    finalized: d.finalized,
    finalReport: safeParse<Record<string, unknown> | null>(d.finalReportJson, null),
    documentType: d.documentType,
    language: d.language,
    sentiment: d.sentiment,
    mimeType: d.mimeType,
    createdAt: d.createdAt.toISOString(),
  };
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const document = await db.documentHistory.findUnique({ where: { id } });
    if (!document) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ document: serialize(document) });
  } catch (e) {
    console.error("document GET error", e);
    return NextResponse.json({ error: "Failed to load document" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const data: Record<string, unknown> = {};
    if (body.insights !== undefined) data.insightsJson = JSON.stringify(body.insights);
    if (body.graphics !== undefined) data.graphicsJson = JSON.stringify(body.graphics);
    if (body.charts !== undefined) data.chartsJson = JSON.stringify(body.charts);
    if (body.status !== undefined) data.status = String(body.status);
    if (body.documentType !== undefined) data.documentType = String(body.documentType);
    if (body.language !== undefined) data.language = String(body.language);
    if (body.sentiment !== undefined) data.sentiment = String(body.sentiment);
    if (body.mimeType !== undefined) data.mimeType = String(body.mimeType);
    if (body.finalized !== undefined) data.finalized = Boolean(body.finalized);
    if (body.finalReport !== undefined) data.finalReportJson = JSON.stringify(body.finalReport);

    const document = await db.documentHistory.update({ where: { id }, data });
    return NextResponse.json({ document: serialize(document) });
  } catch (e) {
    console.error("document PATCH error", e);
    return NextResponse.json({ error: "Failed to update document" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.documentHistory.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("document DELETE error", e);
    return NextResponse.json({ error: "Failed to delete document" }, { status: 500 });
  }
}
