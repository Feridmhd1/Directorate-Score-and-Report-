import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { deliverTextMessage, serializeLog } from "@/lib/automation";
import { emitAppEvent } from "@/lib/events";
import { DIRECTORATES } from "@/lib/rubric";
import type { FeedbackDTO } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function serialize(row: {
  id: string;
  directorateKey: string;
  directorateName: string;
  quarter: string;
  kind: string;
  message: string;
  contact: string;
  isRead: boolean;
  createdAt: Date;
}): FeedbackDTO {
  return {
    id: row.id,
    directorateKey: row.directorateKey,
    directorateName: row.directorateName,
    quarter: row.quarter,
    kind: row.kind,
    message: row.message,
    contact: row.contact,
    isRead: row.isRead,
    createdAt: row.createdAt.toISOString(),
  };
}

/** GET /api/feedback?directorateKey=HPDP&unread=1 — list feedback (admin view) */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const directorateKey = searchParams.get("directorateKey")?.trim();
  const unreadOnly = searchParams.get("unread") === "1";
  const rows = await db.directorateFeedback.findMany({
    where: {
      ...(directorateKey ? { directorateKey } : {}),
      ...(unreadOnly ? { isRead: false } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json(
    {
      feedback: rows.map(serialize),
      unreadCount: rows.filter((r) => !r.isRead).length,
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/**
 * POST /api/feedback — public endpoint used from a directorate's own portal
 * (unique QR/link) to share comments or suggestions.
 * body: { directorateKey, directorateName?, quarter?, kind?, message, contact? }
 *
 * The moment a directorate shares feedback the application automates it to
 * every enabled delivery channel (WhatsApp +251911133037, Telegram
 * @feridmhd1, email) and raises an in-app notification + realtime event.
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const directorateKey = String(body.directorateKey ?? "").trim();
    const message = String(body.message ?? "").trim();
    if (!directorateKey) {
      return NextResponse.json({ error: "directorateKey is required" }, { status: 400 });
    }
    if (message.length < 3) {
      return NextResponse.json(
        { error: "እባክዎ ትርጉም ያለው መልእክት ይጻፉ · Please write a meaningful message" },
        { status: 400 }
      );
    }
    const kind = body.kind === "suggestion" ? "suggestion" : "comment";
    const meta = DIRECTORATES.find((d) => d.key === directorateKey);
    const directorateName = String(body.directorateName ?? "").slice(0, 200) || meta?.nameEn || meta?.name || "";
    const quarter = String(body.quarter ?? "").slice(0, 60);
    const row = await db.directorateFeedback.create({
      data: {
        directorateKey,
        directorateName,
        quarter,
        kind,
        message: message.slice(0, 4000),
        contact: String(body.contact ?? "").trim().slice(0, 200),
      },
    });

    /* ---- Automate the feedback to WhatsApp / Telegram / Email ---- */
    const kindLabel = kind === "suggestion" ? "ጥቆማ / Suggestion" : "አስተያየት / Comment";
    const outgoing = [
      "📝 Direc-Score — አስተያየት እና ጥቆማ",
      `ዳይሬክቶሬት / Directorate: ${row.directorateName || directorateKey} (${directorateKey})`,
      `አይነት / Type: ${kindLabel}`,
      quarter ? `ሩብ ዓመት / Quarter: ${quarter}` : "",
      "",
      row.message,
      "",
      row.contact ? `ተጠቃሚ / Contact: ${row.contact}` : "ተጠቃሚ / Contact: —",
    ]
      .filter((line) => line !== "")
      .join("\n");
    const logs = await deliverTextMessage(outgoing, {
      directorateKey,
      directorateName: row.directorateName || directorateKey,
      quarter,
      notification: {
        type: "feedback_shared",
        title: `${kind === "suggestion" ? "ጥቆማ" : "አስተያየት"} — ${
          meta?.short || directorateKey
        }`,
        message: row.message.slice(0, 300),
      },
    });
    /* Realtime ping so the dashboard feedback list + bell update instantly */
    void emitAppEvent("feedback_shared", {
      id: row.id,
      directorateKey,
      directorateName: row.directorateName || directorateKey,
      quarter,
      kind,
      message: row.message.slice(0, 300),
      createdAt: row.createdAt.toISOString(),
    });

    return NextResponse.json({
      feedback: serialize(row),
      deliveries: logs.map(serializeLog),
    });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

/** PATCH /api/feedback?id=<id> — mark feedback as read */
export async function PATCH(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  const existing = await db.directorateFeedback.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const row = await db.directorateFeedback.update({
    where: { id },
    data: { isRead: true },
  });
  return NextResponse.json({ feedback: serialize(row) });
}
