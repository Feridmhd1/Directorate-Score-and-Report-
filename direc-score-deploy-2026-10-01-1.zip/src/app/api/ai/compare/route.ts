import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-provider";

export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const { documents } = await req.json();
    if (!Array.isArray(documents) || documents.length < 2) {
      return NextResponse.json({ error: "At least 2 documents are required" }, { status: 400 });
    }

    const docsText = documents
      .map(
        (d: { fileName: string; content: string }, i: number) =>
          `Document ${i + 1}: "${d.fileName}"\n${String(d.content ?? "").slice(0, 4000) || "No content"}`
      )
      .join("\n\n---\n\n");

    const prompt = `You are an expert document analyst. Compare the following ${documents.length} documents thoroughly.

${docsText}

Provide a detailed comparative analysis with these exact JSON keys:
- overview: A 2-3 sentence overview of the comparison
- common_themes: Array of themes/topics shared across all documents (strings)
- conflicts: Array of objects {topic, doc1_view, doc2_view, explanation} where documents disagree or differ
- unique_insights: Array of objects {document_name, insight} for notable insights unique to each document
- consolidated_summary: A comprehensive synthesis combining the best insights from all documents
- similarity_score: A number 0-100 indicating overall similarity between documents
- recommendation: What a reader should take away from reading all documents together

Respond ONLY with a valid JSON object with exactly those keys.`;

    const raw = await aiChat(req, [
      {
        role: "assistant",
        content:
          "You are an expert document analyst specializing in comparative analysis. Respond with valid JSON only — no markdown fences, no extra text.",
      },
      { role: "user", content: prompt },
    ]);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace === -1 || lastBrace === -1) {
      return NextResponse.json({ error: "AI returned an invalid response" }, { status: 502 });
    }
    const result = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
    return NextResponse.json(result);
  } catch (e) {
    console.error("ai/compare error", e);
    return NextResponse.json({ error: "AI comparison failed. Please try again." }, { status: 500 });
  }
}
