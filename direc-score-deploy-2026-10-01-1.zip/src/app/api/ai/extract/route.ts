import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-provider";

export const maxDuration = 120;
export const dynamic = "force-dynamic";

const MAX_FILE_SIZE = 15 * 1024 * 1024; // 15MB
const MAX_CHARS = 200000;

function extensionOf(name: string): string {
  const m = /\.([a-zA-Z0-9]+)$/.exec(name);
  return m ? m[1].toLowerCase() : "";
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { error: "File is too large — the maximum size is 15MB." },
        { status: 413 }
      );
    }

    const fileName = file.name || "upload";
    const mimeType = file.type || "";
    const ext = extensionOf(fileName);
    const buf = Buffer.from(await file.arrayBuffer());

    let extractedText = "";
    let kind = "text";
    let meta: Record<string, unknown> = {};

    const isPdf = mimeType === "application/pdf" || ext === "pdf";
    const isDocx =
      mimeType.includes("wordprocessingml") || ext === "docx";
    const isSheet =
      ["xlsx", "xls"].includes(ext) ||
      mimeType.includes("spreadsheetml") ||
      mimeType === "application/vnd.ms-excel" ||
      mimeType === "application/vnd.oasis.opendocument.spreadsheet";
    const isCsv = ext === "csv" || mimeType === "text/csv";
    const isTsv = ext === "tsv" || mimeType === "text/tab-separated-values";
    const isImage =
      mimeType.startsWith("image/") ||
      ["png", "jpg", "jpeg", "webp", "gif"].includes(ext);

    if (isPdf) {
      // unpdf bundles a modern pdf.js — handles current PDF generators reliably
      const { extractText, getDocumentProxy } = await import("unpdf");
      const pdf = await getDocumentProxy(new Uint8Array(buf));
      const { text, totalPages } = await extractText(pdf, { mergePages: true });
      extractedText = typeof text === "string" ? text : String(text ?? "");
      kind = "text";
      meta = { pages: totalPages };
    } else if (isDocx) {
      const mammoth = await import("mammoth");
      const { value } = await mammoth.extractRawText({ buffer: buf });
      extractedText = value ?? "";
      kind = "text";
    } else if (isSheet) {
      const XLSX = await import("xlsx");
      const wb = XLSX.read(buf, { type: "buffer" });
      let sheetName = wb.SheetNames[0] ?? "";
      let csv = "";
      for (const name of wb.SheetNames) {
        const sheet = wb.Sheets[name];
        if (!sheet) continue;
        const text = XLSX.utils.sheet_to_csv(sheet);
        if (text && text.trim().length > 0) {
          sheetName = name;
          csv = text;
          break;
        }
      }
      const rowCount = csv
        ? csv.split(/\r?\n/).filter((line) => line.trim().length > 0).length
        : 0;
      extractedText = csv;
      kind = "table";
      meta = { sheets: wb.SheetNames, sheet: sheetName, rows: rowCount };
    } else if (isImage) {
      // AI vision extraction for images (charts, screenshots, scanned tables)
      // ai-provider routes array-content messages to the vision endpoint
      // (built-in path) or the OpenAI-compatible BYO provider (headers).
      try {
        const visionText = await aiChat(req, [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Extract all text and describe the data/charts in this image in detail for analysis purposes.",
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:${mimeType || "image/png"};base64,${buf.toString("base64")}`,
                },
              },
            ],
          },
        ]);
        if (!visionText.trim()) throw new Error("empty vision result");
        extractedText = visionText;
        kind = "image";
        meta = { vision: true };
      } catch {
        return NextResponse.json(
          {
            error:
              "Could not process this image — try a clearer screenshot or a text-based file",
          },
          { status: 422 }
        );
      }
    } else {
      // Text-ish files: csv, tsv, txt, md, json, html, htm, any text/*, and best-effort others
      const text = buf.toString("utf8");
      const nulCount = (text.match(/\u0000/g) ?? []).length;
      const looksBinary = nulCount > Math.max(16, text.length * 0.01);
      if (looksBinary) {
        return NextResponse.json(
          {
            error:
              "Unsupported file type. Please upload a document, spreadsheet, PDF, image, or text file.",
          },
          { status: 415 }
        );
      }
      extractedText = text;
      kind = isCsv || isTsv ? "table" : "text";
      if (isTsv) meta = { delimiter: "tab" };
    }

    extractedText = extractedText.slice(0, MAX_CHARS);

    return NextResponse.json({
      fileName,
      mimeType,
      extractedText,
      wordCount: countWords(extractedText),
      kind,
      meta,
    });
  } catch (e) {
    console.error("ai/extract error", e);
    return NextResponse.json(
      { error: "Could not extract this file. Please try a different file." },
      { status: 500 }
    );
  }
}
