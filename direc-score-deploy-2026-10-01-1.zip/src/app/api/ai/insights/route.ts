import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-provider";

export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const { fileName, content } = await req.json();
    if (!content || String(content).trim().length === 0) {
      return NextResponse.json({ error: "Document content is required" }, { status: 400 });
    }

    const prompt = `Analyze the following document ("${fileName ?? "document"}") and provide a thorough analytical breakdown.

DOCUMENT CONTENT:
${String(content).slice(0, 12000)}

Respond ONLY with a valid JSON object in this exact format:
{
  "document_type": "one of: report, policy, plan, minutes, letter, academic, other",
  "language": "primary language of the document (e.g. English, Amharic, Mixed)",
  "sentiment": "one of: positive, negative, neutral, mixed",
  "summary": "a comprehensive 3-5 sentence summary of the document",
  "key_points": ["5-8 key points extracted from the document"],
  "topics": ["3-6 main topics/themes covered"],
  "recommendations": ["2-4 actionable recommendations based on the document"]
}`;

    const raw = await aiChat(req, [
      {
        role: "assistant",
        content:
          "You are an expert document analyst. You always respond with valid JSON only — no markdown fences, no extra text.",
      },
      { role: "user", content: prompt },
    ]);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace === -1 || lastBrace === -1) {
      return NextResponse.json({ error: "AI returned an invalid response" }, { status: 502 });
    }
    const insights = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));

    // Generate chart/graphic suggestions based on the insights
    let graphics: Array<Record<string, unknown>> = [];
    try {
      const gPrompt = `Based on this document summary and key points, suggest 2-3 data visualizations that could represent the content.

SUMMARY: ${JSON.stringify(insights.summary)}
KEY POINTS: ${JSON.stringify(insights.key_points)}
TOPICS: ${JSON.stringify(insights.topics)}

Respond ONLY with valid JSON:
{
  "graphics": [
    { "title": "...", "type": "one of: bar, pie, line, progress, radial", "description": "what it visualizes and why" }
  ]
}`;
      const gRaw = (await aiChat(req, [
        {
          role: "assistant",
          content: "You suggest data visualizations. Respond with valid JSON only.",
        },
        { role: "user", content: gPrompt },
      ]))
        .replace(/```json\s*/g, "")
        .replace(/```\s*/g, "")
        .trim();
      const gFirst = gRaw.indexOf("{");
      const gLast = gRaw.lastIndexOf("}");
      if (gFirst !== -1 && gLast !== -1) {
        const gParsed = JSON.parse(gRaw.slice(gFirst, gLast + 1));
        graphics = (gParsed.graphics ?? []).map((g: Record<string, unknown>, i: number) => ({
          ...g,
          id: `g${i + 1}`,
        }));
      }
    } catch {
      graphics = [];
    }

    return NextResponse.json({ insights, graphics });
  } catch (e) {
    console.error("ai/insights error", e);
    return NextResponse.json({ error: "AI analysis failed. Please try again." }, { status: 500 });
  }
}
