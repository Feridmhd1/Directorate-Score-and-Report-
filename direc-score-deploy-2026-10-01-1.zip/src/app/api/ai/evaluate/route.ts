import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-provider";
import { CRITERIA, buildEvaluationPrompt } from "@/lib/rubric";
import type { EvaluationLanguage } from "@/lib/rubric";

export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const { directorateName, quarter, content, language } = await req.json();
    if (!directorateName || !quarter || !content) {
      return NextResponse.json(
        { error: "directorateName, quarter and content are required" },
        { status: 400 }
      );
    }

    // Output language for comments — Amharic / English / bilingual
    const lang: EvaluationLanguage =
      language === "amharic" || language === "bilingual" ? language : "english";

    const prompt = buildEvaluationPrompt(
      String(directorateName),
      String(quarter),
      String(content),
      lang
    );

    const raw = await aiChat(req, [
      {
        role: "assistant",
        content:
          "You are an expert evaluator for health bureau quarterly reports. You always respond with valid JSON only — no markdown fences, no extra text.",
      },
      { role: "user", content: prompt },
    ]);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace === -1 || lastBrace === -1) {
      return NextResponse.json({ error: "AI returned an invalid response" }, { status: 502 });
    }
    const parsed = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));

    // Normalize answers: keep only known ids, coerce to yes/no
    const validIds = new Set(CRITERIA.flatMap((c) => c.subQuestions.map((q) => q.id)));
    const answers: Record<string, string> = {};
    const rawAnswers = (parsed.answers ?? {}) as Record<string, unknown>;
    validIds.forEach((id) => {
      const v = String(rawAnswers[id] ?? "no").toLowerCase().trim();
      answers[id] = v === "yes" || v === "true" || v === "1" ? "yes" : "no";
    });

    // Normalize comments: one per category A-J
    const comments: Record<string, string> = {};
    const rawComments = (parsed.comments ?? {}) as Record<string, unknown>;
    CRITERIA.forEach((c) => {
      const v = rawComments[c.key];
      comments[c.key] = typeof v === "string" ? v : "";
    });

    return NextResponse.json({ answers, comments });
  } catch (e) {
    console.error("ai/evaluate error", e);
    return NextResponse.json({ error: "AI analysis failed. Please try again." }, { status: 500 });
  }
}
