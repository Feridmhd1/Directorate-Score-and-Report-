import { NextResponse } from "next/server";
import { hasHeaderProvider, aiChat } from "@/lib/ai-provider";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * POST /api/ai/test-provider — verifies the personal AI provider configured
 * in Settings → AI Provider (passed via x-ai-base-url / x-ai-key / x-ai-model
 * headers). Used by the "Test connection" button so the user can confirm a
 * free provider key works BEFORE relying on AI features.
 *
 * Always routes through the header provider — the built-in SDK is
 * deliberately NOT used as a fallback, otherwise the test could pass without
 * a working personal key.
 */
export async function POST(req: Request) {
  if (!hasHeaderProvider(req)) {
    return NextResponse.json(
      {
        ok: false,
        error:
          "No AI provider credentials supplied. Fill the Base URL, API key and Model fields first.",
      },
      { status: 400 }
    );
  }
  try {
    const reply = await aiChat(
      req,
      [
        {
          role: "assistant",
          content: "You are a connection tester. Always reply with exactly: OK",
        },
        { role: "user", content: "Reply with OK if you can read this." },
      ],
      { temperature: 0 }
    );
    return NextResponse.json({
      ok: true,
      reply: reply.trim().slice(0, 80),
      model: req.headers.get("x-ai-model") ?? "",
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "Provider test failed" },
      { status: 502 }
    );
  }
}
