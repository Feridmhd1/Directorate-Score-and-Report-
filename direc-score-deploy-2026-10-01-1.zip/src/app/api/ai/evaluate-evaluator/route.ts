import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { aiChat } from "@/lib/ai-provider";
import { CRITERIA, buildEvaluatorAuditPrompt } from "@/lib/rubric";
import type { Answers, Comments, EvaluationLanguage } from "@/lib/rubric";
import type { EvaluatorAuditReport, EvaluatorDisagreement } from "@/lib/types";

export const maxDuration = 120;

const VALID_IDS = new Set(CRITERIA.flatMap((c) => c.subQuestions.map((q) => q.id)));

/** The audit verdict is always derived server-side from the score — never trusted from the AI */
function deriveVerdict(score: number): "reliable" | "review" | "unreliable" {
  if (score >= 80) return "reliable";
  if (score >= 60) return "review";
  return "unreliable";
}

/**
 * POST /api/ai/evaluate-evaluator
 *
 * Meta-evaluation: a supervising AI re-checks the AI evaluator's own work
 * (answers, comments, total score) against the report content, flags every
 * answer it disagrees with (with a suggested correction), grades the
 * evaluation's reliability 0-100 and returns concrete strengths and advice.
 * Every audit is persisted in the EvaluatorAudit table.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { directorateKey, directorateName, quarter, language, answers, comments, totalScore, reportContent } =
      body ?? {};

    if (!directorateName || !quarter || !reportContent) {
      return NextResponse.json(
        { error: "directorateName, quarter and reportContent are required" },
        { status: 400 }
      );
    }
    if (!answers || typeof answers !== "object") {
      return NextResponse.json(
        { error: "answers object is required — run the AI evaluation first" },
        { status: 400 }
      );
    }

    const lang: EvaluationLanguage =
      language === "amharic" || language === "bilingual" ? language : "english";

    // Normalize the AI evaluator's work into known rubric ids / categories
    const safeAnswers: Answers = {};
    VALID_IDS.forEach((id) => {
      safeAnswers[id] = answers?.[id] === "yes" ? "yes" : "no";
    });
    const safeComments: Comments = {};
    CRITERIA.forEach((c) => {
      safeComments[c.key] = typeof comments?.[c.key] === "string" ? comments[c.key] : "";
    });
    const numericTotal = Number.isFinite(Number(totalScore)) ? Number(totalScore) : 0;

    const prompt = buildEvaluatorAuditPrompt(
      String(directorateName),
      String(quarter),
      safeAnswers,
      safeComments,
      numericTotal,
      String(reportContent),
      lang
    );

    const raw = await aiChat(req, [
      {
        role: "assistant",
        content:
          "You are a meticulous quality assurance auditor. You always respond with valid JSON only — no markdown fences, no extra text.",
      },
      { role: "user", content: prompt },
    ]);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace === -1 || lastBrace === -1) {
      return NextResponse.json({ error: "AI returned an invalid response" }, { status: 502 });
    }
    const parsed = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));

    // Quality score: clamp to 0-100
    let qualityScore = Math.round(Number(parsed.qualityScore));
    if (!Number.isFinite(qualityScore)) qualityScore = 0;
    qualityScore = Math.max(0, Math.min(100, qualityScore));
    const verdict = deriveVerdict(qualityScore);

    // Disagreements: keep only real question ids with a written reason
    const rawDisagreements = Array.isArray(parsed.disagreements) ? parsed.disagreements : [];
    const seen = new Set<string>();
    const disagreements: EvaluatorDisagreement[] = [];
    for (const item of rawDisagreements.slice(0, 30)) {
      const questionId = String(item?.questionId ?? "").trim().toUpperCase();
      if (!VALID_IDS.has(questionId) || seen.has(questionId)) continue;
      const reason = typeof item?.reason === "string" ? item.reason.trim() : "";
      if (!reason) continue;
      const severity = ["high", "medium", "low"].includes(String(item?.severity))
        ? String(item.severity)
        : "medium";
      const suggestedRaw = String(item?.suggestedAnswer ?? "").toLowerCase().trim();
      disagreements.push({
        questionId,
        severity,
        reason,
        suggestedAnswer: suggestedRaw === "yes" ? "yes" : "no",
      });
      seen.add(questionId);
      if (disagreements.length >= 15) break;
    }

    const asStrings = (v: unknown, cap = 8): string[] =>
      Array.isArray(v)
        ? v.filter((x): x is string => typeof x === "string" && x.trim().length > 0).slice(0, cap)
        : [];

    const report: EvaluatorAuditReport = {
      qualityScore,
      verdict,
      summary: typeof parsed.summary === "string" ? parsed.summary.trim() : "",
      disagreements,
      strengths: asStrings(parsed.strengths),
      improvements: asStrings(parsed.improvements),
    };

    // Persist the audit so the bureau can track AI-evaluator reliability over
    // time. On serverless hosts the database may be read-only — the audit
    // itself already succeeded, so persistence failures are swallowed and the
    // browser keeps its own copy in local mode.
    let auditId = "";
    let createdAt = new Date().toISOString();
    try {
      const audit = await db.evaluatorAudit.create({
        data: {
          directorateKey: String(directorateKey ?? ""),
          directorateName: String(directorateName),
          quarter: String(quarter),
          evaluationId: typeof body.evaluationId === "string" ? body.evaluationId : "",
          answersJson: JSON.stringify(safeAnswers),
          commentsJson: JSON.stringify(safeComments),
          totalScore: numericTotal,
          qualityScore,
          verdict,
          reportJson: JSON.stringify(report),
        },
      });
      auditId = audit.id;
      createdAt = audit.createdAt.toISOString();
    } catch (persistError) {
      console.warn(
        "audit persistence skipped (server cannot write):",
        persistError instanceof Error ? persistError.message : persistError
      );
    }

    return NextResponse.json({
      id: auditId,
      createdAt,
      qualityScore,
      verdict,
      report,
    });
  } catch (e) {
    console.error("ai/evaluate-evaluator error", e);
    return NextResponse.json(
      { error: "Auditing the AI evaluation failed. Please try again." },
      { status: 500 }
    );
  }
}
