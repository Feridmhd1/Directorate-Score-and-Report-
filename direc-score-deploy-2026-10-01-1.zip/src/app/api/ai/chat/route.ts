import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { aiChat } from "@/lib/ai-provider";

export const maxDuration = 120;

const SYSTEM_PROMPT =
  "You are the Direc-Score Data Analysis Assistant for Harari Region Health Bureau. You help analyze documents and evaluation data. Be concise, professional, use markdown-free plain text with clear bullet lines starting with '- ' when listing. If a document/context is provided, ground your answers in it.";

function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ error: "sessionId is required" }, { status: 400 });
  }
  try {
    const messages = await db.chatMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: "asc" },
      take: 100,
    });
    return NextResponse.json({
      messages: messages.map((m) => ({
        id: m.id,
        sessionId: m.sessionId,
        role: m.role,
        content: m.content,
        documentId: m.documentId,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  } catch (e) {
    console.error("ai/chat GET error", e);
    return NextResponse.json({ error: "Failed to load chat history" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const sessionId = typeof body.sessionId === "string" ? body.sessionId : "";
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const documentId = typeof body.documentId === "string" ? body.documentId : "";
    if (!sessionId || !message) {
      return NextResponse.json({ error: "sessionId and message are required" }, { status: 400 });
    }

    // Optional client-supplied grounding so the chat also works in local mode
    // (serverless hosts where the DB cannot be read or written).
    const clientContext = typeof body.context === "string" ? body.context.trim() : "";
    const clientHistory: unknown[] =
      Array.isArray(body.history) && body.history.length > 0 ? body.history : [];

    // Persist the user message first (non-fatal: serverless filesystems are read-only)
    try {
      await db.chatMessage.create({
        data: { sessionId, role: "user", content: message.slice(0, 8000), documentId },
      });
    } catch (persistError) {
      console.warn(
        "chat user-message persistence skipped (server cannot write):",
        persistError instanceof Error ? persistError.message : persistError
      );
    }

    // Optional grounding context from the analyzed document
    let context = "";
    if (clientContext) {
      context = clientContext;
    } else if (documentId) {
      try {
        const doc = await db.documentHistory.findUnique({ where: { id: documentId } });
        if (doc) {
          const insights = safeParse<Record<string, unknown> | null>(doc.insightsJson, null);
          const charts = safeParse<Record<string, unknown>[]>(doc.chartsJson, []);
          const insightSummary = insights
            ? `\nSAVED ANALYSIS INSIGHTS: ${JSON.stringify(insights).slice(0, 2500)}`
            : "";
          const chartList =
            Array.isArray(charts) && charts.length > 0
              ? `\nRENDERED CHARTS: ${JSON.stringify(charts.map((c) => ({ title: c.title, type: c.type, description: c.description })))}`
              : "";
          context = `The user is currently analyzing the document "${doc.fileName}".\nDOCUMENT EXCERPT (first 6000 chars):\n${doc.content.slice(0, 6000)}${insightSummary}${chartList}`;
        }
      } catch (contextError) {
        console.warn(
          "document context lookup skipped (server cannot read):",
          contextError instanceof Error ? contextError.message : contextError
        );
      }
    }

    // Conversation history: client-supplied when present, else the last 12
    // messages from the DB (asc order, ends with the user's new message)
    let history: Array<{ role: "user" | "assistant"; content: string }> = [];
    if (clientHistory.length > 0) {
      history = clientHistory
        .filter((m): m is { role: "user" | "assistant"; content: string } => {
          if (typeof m !== "object" || m === null) return false;
          const r = (m as { role?: unknown }).role;
          return (r === "user" || r === "assistant") && typeof (m as { content?: unknown }).content === "string";
        })
        .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }))
        .slice(-12);
    } else {
      try {
        const rows = await db.chatMessage.findMany({
          where: { sessionId },
          orderBy: { createdAt: "desc" },
          take: 12,
        });
        rows.reverse();
        history = rows.map((m) => ({
          role: m.role === "user" ? ("user" as const) : ("assistant" as const),
          content: m.content,
        }));
      } catch (historyError) {
        console.warn(
          "chat history read skipped (server cannot read):",
          historyError instanceof Error ? historyError.message : historyError
        );
        history = [];
      }
    }

    const reply = await aiChat(req, [
      {
        role: "assistant",
        content: context
          ? `${SYSTEM_PROMPT}\n\nCURRENT DOCUMENT CONTEXT:\n${context}`
          : SYSTEM_PROMPT,
      },
      ...history.map((m) => ({
        role: m.role === "user" ? ("user" as const) : ("assistant" as const),
        content: m.content,
      })),
    ]);

    let replyText = reply;
    let createdAt = new Date().toISOString();
    try {
      const saved = await db.chatMessage.create({
        data: { sessionId, role: "assistant", content: reply, documentId },
      });
      replyText = saved.content;
      createdAt = saved.createdAt.toISOString();
    } catch (persistError) {
      console.warn(
        "chat assistant-message persistence skipped (server cannot write):",
        persistError instanceof Error ? persistError.message : persistError
      );
    }

    return NextResponse.json({
      reply: replyText,
      createdAt,
    });
  } catch (e) {
    console.error("ai/chat POST error", e);
    return NextResponse.json(
      { error: "The assistant could not respond. Please try again." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ error: "sessionId is required" }, { status: 400 });
  }
  try {
    await db.chatMessage.deleteMany({ where: { sessionId } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("ai/chat DELETE error", e);
    return NextResponse.json({ error: "Failed to clear chat" }, { status: 500 });
  }
}
