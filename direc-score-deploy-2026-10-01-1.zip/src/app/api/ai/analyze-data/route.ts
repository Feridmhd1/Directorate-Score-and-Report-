import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-provider";

export const maxDuration = 120;

/* ------------------------------------------------------------------ */
/* Server-side quick data parsing                                      */
/* ------------------------------------------------------------------ */

interface ColumnStatRaw {
  column: string;
  type: string; // number | text | date
  missing: number;
  unique: number;
  min?: number;
  max?: number;
  mean?: number;
}

function detectDelimiter(line: string): string {
  const candidates = [",", ";", "\t", "|"];
  let best = ",";
  let bestCount = 0;
  for (const d of candidates) {
    const count = line.split(d).length - 1;
    if (count > bestCount) {
      best = d;
      bestCount = count;
    }
  }
  return best;
}

/** Simple quoted-aware delimited parser */
function parseDelimited(text: string, delimiter: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === delimiter) {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") {
      field += ch;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

function tryParseJsonRows(text: string): Record<string, unknown>[] | null {
  const trimmed = text.trim();
  if (!trimmed.startsWith("[")) return null;
  try {
    const parsed: unknown = JSON.parse(trimmed);
    if (
      Array.isArray(parsed) &&
      parsed.length > 0 &&
      typeof parsed[0] === "object" &&
      parsed[0] !== null
    ) {
      return parsed as Record<string, unknown>[];
    }
  } catch {
    /* not json */
  }
  return null;
}

function jsonRowsToMatrix(rows: Record<string, unknown>[]): string[][] {
  const columns: string[] = [];
  for (const r of rows.slice(0, 100)) {
    Object.keys(r ?? {}).forEach((k) => {
      if (!columns.includes(k)) columns.push(k);
    });
  }
  const body = rows.map((r) =>
    columns.map((c) => {
      const v = (r as Record<string, unknown>)[c];
      return v === undefined || v === null ? "" : String(v);
    })
  );
  return [columns, ...body];
}

function computeColumnStats(matrix: string[][], maxCols = 12): ColumnStatRaw[] {
  if (matrix.length === 0) return [];
  const header = matrix[0].map((h, i) => h.trim() || `Column ${i + 1}`);
  const body = matrix.slice(1);
  const stats: ColumnStatRaw[] = [];
  const colCount = Math.min(header.length, maxCols);
  for (let c = 0; c < colCount; c++) {
    const values = body.map((r) => (r[c] ?? "").trim());
    const missing = values.filter((v) => v === "").length;
    const present = values.filter((v) => v !== "");
    const unique = new Set(present).size;
    const nums = present
      .map((v) => Number(v.replace(/[,\s]/g, "")))
      .filter((n) => Number.isFinite(n));
    const dateLike = present.filter(
      (v) => !Number.isNaN(Date.parse(v)) && /[/\-]|\d{4}/.test(v)
    ).length;
    let type = "text";
    if (present.length > 0 && nums.length / present.length >= 0.8) type = "number";
    else if (present.length > 0 && dateLike / present.length >= 0.8) type = "date";
    const stat: ColumnStatRaw = { column: header[c], type, missing, unique };
    if (type === "number" && nums.length > 0) {
      const min = Math.min(...nums);
      const max = Math.max(...nums);
      const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
      stat.min = Math.round(min * 100) / 100;
      stat.max = Math.round(max * 100) / 100;
      stat.mean = Math.round(mean * 100) / 100;
    }
    stats.push(stat);
  }
  return stats;
}

function detectLanguage(text: string): string {
  if (/[\u1200-\u137F]/.test(text)) return "Amharic";
  return "English";
}

/* ------------------------------------------------------------------ */
/* Chart validation / coercion                                         */
/* ------------------------------------------------------------------ */

function toNum(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const n = Number(v.trim().replace(/,/g, ""));
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function cleanCharts(raw: unknown): Array<Record<string, unknown>> {
  if (!Array.isArray(raw)) return [];
  const out: Array<Record<string, unknown>> = [];
  raw.forEach((c, i) => {
    if (typeof c !== "object" || c === null) return;
    const chart = c as Record<string, unknown>;
    const dataRaw = Array.isArray(chart.data) ? chart.data : [];
    const xKey =
      typeof chart.xKey === "string" && chart.xKey.trim() ? chart.xKey : "label";
    const yKeys =
      Array.isArray(chart.yKeys) &&
      chart.yKeys.length > 0 &&
      chart.yKeys.every((k) => typeof k === "string")
        ? (chart.yKeys as string[])
        : ["value"];
    const allowedTypes = ["bar", "line", "pie", "area"];
    const type =
      typeof chart.type === "string" && allowedTypes.includes(chart.type.toLowerCase())
        ? chart.type.toLowerCase()
        : "bar";
    const data: Array<Record<string, string | number>> = [];
    for (const row of dataRaw) {
      if (typeof row !== "object" || row === null) continue;
      const r = row as Record<string, unknown>;
      const entry: Record<string, string | number> = {};
      const xv = r[xKey];
      entry[xKey] =
        typeof xv === "string"
          ? xv
          : xv !== undefined && xv !== null
            ? String(xv)
            : `Item ${data.length + 1}`;
      let hasNumeric = false;
      for (const yk of yKeys) {
        const n = toNum(r[yk]);
        if (n !== null) {
          entry[yk] = n;
          hasNumeric = true;
        }
      }
      if (hasNumeric) data.push(entry);
      if (data.length >= 12) break;
    }
    if (data.length === 0) return; // drop charts without usable numeric rows
    out.push({
      id: `c${i + 1}`,
      title: typeof chart.title === "string" && chart.title.trim() ? chart.title : `Chart ${i + 1}`,
      type,
      xKey,
      yKeys,
      unit: typeof chart.unit === "string" && chart.unit.trim() ? chart.unit : undefined,
      description:
        typeof chart.description === "string" && chart.description.trim()
          ? chart.description
          : undefined,
      data,
    });
  });
  return out.slice(0, 6);
}

/* ------------------------------------------------------------------ */
/* Route                                                               */
/* ------------------------------------------------------------------ */

export async function POST(req: NextRequest) {
  try {
    const { fileName, content, mimeType } = await req.json();
    if (!content || String(content).trim().length === 0) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 });
    }
    const text = String(content);

    /* ---- quick server-side parsing ---- */
    const jsonRows = tryParseJsonRows(text);
    let matrix: string[][] = [];
    let isProse = false;
    if (jsonRows) {
      matrix = jsonRowsToMatrix(jsonRows);
    } else {
      const firstLine = text.split(/\r?\n/).find((l) => l.trim().length > 0) ?? "";
      const delimiter = detectDelimiter(firstLine);
      const parsed = parseDelimited(text, delimiter);
      const headerCols = parsed[0]?.length ?? 0;
      if (headerCols >= 2 && parsed.length >= 3) {
        matrix = parsed;
      } else {
        isProse = true;
      }
    }
    if (matrix.length > 0 && matrix[0].length < 2) isProse = true;

    const rowCount = Math.max(0, matrix.length - 1);
    const colCount = matrix[0]?.length ?? 0;
    const statistics = isProse ? [] : computeColumnStats(matrix);
    const language = detectLanguage(text.slice(0, 5000));
    const numericColumns = statistics
      .filter((s) => s.type === "number")
      .map((s) => s.column);

    /* ---- build sample for the LLM ---- */
    const header = matrix[0] ?? [];
    const sampleRows = matrix.slice(1, 21);
    const sampleText = [header.join(" | "), ...sampleRows.map((r) => r.join(" | "))].join("\n");

    const datasetContext = isProse
      ? `This is a TEXT DOCUMENT (not tabular data). Analyze its narrative content. "charts" may be an empty array [] if no meaningful numeric series can be derived from the text.`
      : `This is TABULAR data.\nROWS: ${rowCount}\nCOLUMNS: ${colCount}\nNUMERIC COLUMNS: ${JSON.stringify(numericColumns)}\nCOMPUTED COLUMN STATISTICS (use these real numbers in your analysis):\n${JSON.stringify(statistics)}\nDATA SAMPLE (header + first 20 rows, columns separated by "|"):\n${sampleText.slice(0, 6000)}`;

    const prompt = `You are a senior data analyst for a government health bureau. Analyze the following dataset and produce an executive analysis plus renderable charts.

FILE: ${fileName ?? "dataset"}
${mimeType ? `MIME TYPE: ${mimeType}` : ""}
${datasetContext}

CHART RULES (critical):
- Produce 2-4 charts (or [] for prose documents without numeric series).
- Each chart's "data" must be CONCRETE NUMERIC rows you derive from the sample/statistics — e.g. averages per category, counts per group, min/max comparisons. Do NOT invent a "label"/"value" structure that doesn't match the data.
- Up to 12 rows per chart; every value must be a plain JSON number (no strings, no commas, no units).
- For pie charts use exactly one yKey.
- The keys inside each data row MUST exactly match the "xKey" and "yKeys" values you choose (e.g. xKey "region" + yKeys ["patients"] means every row looks like {"region": "...", "patients": 123}).
- Keep "title" short, add "description" and optionally "unit".

Respond ONLY with a valid JSON object in this exact shape (no markdown fences, no extra text):
{
  "dataset_type": "short label of the dataset (e.g. health facility report, HR statistics, budget table, survey results, prose document)",
  "summary": "3-5 sentence executive analysis of the data",
  "key_findings": ["4-7 specific findings with numbers where possible"],
  "recommendations": ["2-4 actionable recommendations"],
  "conclusion": "1-2 sentence conclusion",
  "charts": [
    {
      "title": "chart title",
      "type": "bar|line|pie|area",
      "xKey": "name-of-label-column",
      "yKeys": ["value-column"],
      "unit": "optional unit",
      "description": "what this chart shows",
      "data": [{"label": "example", "value": 123}]
    }
  ]
}`;

    const raw = await aiChat(req, [
      {
        role: "assistant",
        content:
          "You are an expert data analyst. You always respond with valid JSON only — no markdown fences, no extra text.",
      },
      { role: "user", content: prompt },
    ]);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace === -1 || lastBrace === -1) {
      return NextResponse.json({ error: "AI returned an invalid response" }, { status: 502 });
    }
    let parsed: Record<string, unknown>;
    try {
      parsed = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1)) as Record<string, unknown>;
    } catch {
      return NextResponse.json({ error: "AI returned an unparseable analysis. Please try again." }, { status: 502 });
    }

    const charts = cleanCharts(parsed.charts);
    const datasetType =
      typeof parsed.dataset_type === "string" && parsed.dataset_type.trim()
        ? parsed.dataset_type
        : isProse
          ? "prose document"
          : "tabular dataset";
    const summary = typeof parsed.summary === "string" ? parsed.summary : "";
    const keyFindings = Array.isArray(parsed.key_findings)
      ? parsed.key_findings.filter((k): k is string => typeof k === "string")
      : [];
    const recommendations = Array.isArray(parsed.recommendations)
      ? parsed.recommendations.filter((k): k is string => typeof k === "string")
      : [];
    const conclusion = typeof parsed.conclusion === "string" ? parsed.conclusion : "";

    const analysis: Record<string, unknown> = {
      dataset_type: datasetType,
      rows: rowCount,
      columns: colCount,
      summary,
      key_findings: keyFindings,
      statistics,
      recommendations,
      conclusion,
    };

    const insights: Record<string, unknown> = {
      document_type: datasetType === "prose" || isProse ? "report" : "dataset",
      language,
      sentiment: "neutral",
      summary,
      key_points: keyFindings,
      topics: [],
      recommendations,
    };

    return NextResponse.json({ analysis, charts, insights });
  } catch (e) {
    console.error("ai/analyze-data error", e);
    return NextResponse.json(
      { error: "AI data analysis failed. Please try again." },
      { status: 500 }
    );
  }
}
