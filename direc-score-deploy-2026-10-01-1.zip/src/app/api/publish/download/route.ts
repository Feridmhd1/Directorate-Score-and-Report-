import { NextResponse } from "next/server";
import { createRequire } from "module";
import { existsSync, statSync, promises as fsp } from "fs";
import path from "path";
import type { Archiver, ArchiverOptions } from "archiver";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Streams a ready-to-deploy ZIP of the whole application source.
 *
 * The archive contains everything needed to publish the app on Netlify
 * (or any Node host): src/, prisma/, public/, all config files,
 * netlify.toml, the bilingual DEPLOY-NETLIFY.md guide, a .gitignore,
 * a .env.example and an empty db/ folder.
 *
 * Deliberately excluded: node_modules, .next, runtime database files,
 * logs, sandbox-only folders (.git, examples, mini-services, skills,
 * tests, upload/download scratch dirs, worklog, agent tooling).
 */

const PROJECT_ROOT = process.cwd();

const ROOT_FILES = [
  "package.json",
  "bun.lock",
  "netlify.toml",
  "DEPLOY-NETLIFY.md",
  "next.config.ts",
  "tsconfig.json",
  "tailwind.config.ts",
  "postcss.config.mjs",
  "components.json",
  "eslint.config.mjs",
] as const;

const ROOT_DIRS = ["src", "prisma", "public"] as const;

/** Extra ignore rules appended to the packaged .gitignore for deployment. */
const GITIGNORE_APPENDIX = [
  "",
  "# --- deployment packaging ---",
  "/db/*.db",
  "/db/*.db-journal",
  "/db/*.db-wal",
  "/db/*.db-shm",
  "dev.log",
  "server.log",
  "",
].join("\n");

const ENV_EXAMPLE = [
  "# ── Option A (RECOMMENDED): shared cloud database ──",
  "# Every device sees the same recordings, edits and updates; nothing is",
  "# ever lost. Create a FREE database at https://turso.tech (~5 minutes):",
  "#   turso db create direcscore  →  copy the URL below",
  "#   turso db tokens create direcscore  →  copy the token below",
  "# (the app creates its own tables automatically on first open)",
  "",
  'DATABASE_URL=""        # e.g. libsql://direcscore-yourname.turso.io',
  'DATABASE_AUTH_TOKEN="" # the long token from turso db tokens create',
  "",
  "# ── Option B: no database (works instantly, per-device storage) ──",
  "# Leave both values empty. Data lives in each browser (IndexedDB),",
  "# survives reloads, and can be moved between devices via",
  "# Settings → backup (single JSON file).",
  "",
  "# Optional: any long random string (NextAuth compatibility, not required)",
  "NEXTAUTH_SECRET=",
  "",
].join("\n");

const START_HERE = [
  "Direc-Score — Harari Region Health Bureau",
  "Quarterly Report Evaluation System",
  "Developed by Mr Ferid Mohammed  +251911133037  feridmhd3@gmail.com",
  "",
  "QUICK START — 100% functional on Netlify (no database, no accounts, no",
  "commands). Full bilingual guide: DEPLOY-NETLIFY.md.",
  "  1. EXTRACT this ZIP into a folder.",
  "  2. Open https://app.netlify.com/drop and DRAG THE EXTRACTED FOLDER",
  "     (not the ZIP) onto the page. Or upload the folder's contents to a",
  "     GitHub repository and import it on netlify.com — netlify.toml has",
  "     the build settings (Node 20 + @netlify/plugin-nextjs).",
  "     Do not upload node_modules, .next or db/.",
  "  3. (RECOMMENDED — ~5 min) SHARED CLOUD DATA so every device sees the",
  "     same recordings, edits and updates (nothing is ever lost):",
  "     a. Create a free account at https://turso.tech",
  "     b. Create a database (e.g. \"direcscore\") and copy its URL",
  "        (libsql://…turso.io) and an auth token.",
  "     c. On the deployed site in Netlify: Site configuration →",
  "        Environment variables → add:",
  "          DATABASE_URL = libsql://direcscore-….turso.io",
  "          DATABASE_AUTH_TOKEN = <the token>",
  "     d. Redeploy (Deploys → Trigger deploy). Done — the app creates",
  "        its tables automatically on first open.",
  "     Without these variables the app still works 100%: data is stored",
  "     in each browser (IndexedDB), survives reloads, and can be moved",
  "     between devices with Settings → backup (single JSON file).",
  "  4. (Optional, ~5 min) Full AI: on the deployed site open",
  "     Settings → AI Provider — add any OpenAI-compatible key",
  "     (OpenRouter / Groq / Google Gemini / OpenAI), Save, press Test.",
  "     Without a key everything still works via the built-in offline",
  "     analysis engine.",
  "  5. (Optional) Portal auto-delivery: in the Netlify dashboard add the",
  "     environment variables TELEGRAM_BOT_TOKEN (from @BotFather) and",
  "     TELEGRAM_CHAT_ID, then redeploy — portal submissions are delivered",
  "     to the supervisor automatically. Without them the portal shows",
  "     WhatsApp/Email hand-off buttons.",
  "",
  "SECURITY: Settings / Filing / Automation are PIN-protected (default",
  "3472). All recordings, edits and updates are stored in the shared cloud",
  "database when configured — they appear on every device instantly and",
  "survive refreshes, restarts and redeployments.",
  "",
].join("\n");

function safeAppend(fsPath: string, archive: Archiver, zipName: string) {
  if (!existsSync(fsPath)) return false;
  const st = statSync(fsPath);
  if (st.isDirectory()) {
    archive.directory(fsPath, zipName);
  } else {
    archive.file(fsPath, { name: zipName });
  }
  return true;
}

/**
 * Create a zip archiver.
 * - On Node (Netlify/production): `require("archiver")` is the classic callable.
 * - Under Bun (dev sandbox): the module resolves to a namespace with ZipArchive.
 */
function createZipArchiver(opts: ArchiverOptions): Archiver {
  const req = createRequire(import.meta.url);
  const mod: unknown = req("archiver");
  if (typeof mod === "function") {
    return (mod as (format: string, o?: ArchiverOptions) => Archiver)("zip", opts);
  }
  const ns = mod as {
    ZipArchive?: new (o?: ArchiverOptions) => Archiver;
    default?: { ZipArchive?: new (o?: ArchiverOptions) => Archiver };
  };
  const Zip = ns.ZipArchive ?? ns.default?.ZipArchive;
  if (!Zip) throw new Error("archiver module could not be loaded");
  return new Zip(opts);
}

export async function GET() {
  try {
    const zip = createZipArchiver({ zlib: { level: 9 } });

    // Root source directories
    for (const dir of ROOT_DIRS) {
      safeAppend(path.join(PROJECT_ROOT, dir), zip, dir);
    }

    // Root config / doc files
    for (const file of ROOT_FILES) {
      safeAppend(path.join(PROJECT_ROOT, file), zip, file);
    }

    // Empty db folder so the default DATABASE_URL path works out of the box
    zip.append("", { name: "db/.gitkeep" });

    // Generated deployment helpers
    zip.append(START_HERE, { name: "START-HERE.txt" });
    zip.append(ENV_EXAMPLE, { name: ".env.example" });

    // .gitignore with database-exclusion rules appended
    const gitignorePath = path.join(PROJECT_ROOT, ".gitignore");
    const baseGitignore = existsSync(gitignorePath)
      ? await fsp.readFile(gitignorePath, "utf8")
      : "";
    zip.append(baseGitignore + GITIGNORE_APPENDIX, { name: ".gitignore" });

    // Collect the archive into a single buffer.
    // Draining the readable side with `for await` works on both Node and Bun
    // (Bun's ZipArchive does not reliably emit 'finish' on a custom sink).
    const chunks: Buffer[] = [];
    let zipError: Error | null = null;
    const drain = (async () => {
      for await (const chunk of zip) {
        chunks.push(Buffer.from(chunk));
      }
    })();
    zip.on("error", (err: Error) => {
      zipError = err;
    });
    await zip.finalize();
    await drain;
    if (zipError) throw zipError;

    const buf = Buffer.concat(chunks);
    const stamp = new Date().toISOString().slice(0, 10);

    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="direc-score-deploy-${stamp}.zip"`,
        "Content-Length": String(buf.length),
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    console.error("publish/download error", e);
    return NextResponse.json(
      { error: "Could not build the deployment package. Please try again." },
      { status: 500 }
    );
  }
}
