import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** True when the runtime is a short-lived serverless function (read-only FS). */
function isServerlessHost(): boolean {
  return Boolean(
    process.env.NETLIFY ||
      process.env.NETLIFY_DEV ||
      process.env.VERCEL ||
      process.env.AWS_LAMBDA_FUNCTION_NAME
  );
}

/** True when DATABASE_URL points at a shared cloud database (Turso/LibSQL). */
function hasCloudDatabase(): boolean {
  const url = process.env.DATABASE_URL ?? "";
  return url.startsWith("libsql://") || url.startsWith("libsql:");
}

/**
 * Backend health probe used by the client to decide between "server" and
 * "local" (browser) data mode.
 *
 * The probe performs a REAL database write + read-back. A successful probe
 * means: every device that opens the app shares this database — recordings,
 * edits and updates are visible everywhere and survive restarts.
 *
 * On serverless hosts WITHOUT a cloud database the local filesystem is
 * ephemeral: a bare write would succeed inside one instance and the data
 * would silently vanish on the next cold start. We therefore report
 * ok:false up-front so the browser switches to its own persisted data
 * engine instead of losing data.
 */
export async function POST() {
  // Deterministic pre-check: a serverless function without a shared cloud
  // database can never persist data — never let the client trust one.
  if (isServerlessHost() && !hasCloudDatabase()) {
    return NextResponse.json(
      {
        ok: false,
        mode: "local",
        reason: "ephemeral-storage",
        hint: "Set DATABASE_URL (libsql://…) + DATABASE_AUTH_TOKEN to enable shared cloud storage.",
      },
      { status: 503 }
    );
  }

  try {
    const stamp = new Date().toISOString();
    await db.appSetting.upsert({
      where: { key: "systemHealth" },
      create: { key: "systemHealth", value: stamp },
      update: { value: stamp },
    });
    const row = await db.appSetting.findUnique({ where: { key: "systemHealth" } });
    if (row?.value !== stamp) {
      return NextResponse.json({ ok: false, reason: "write not readable" }, { status: 503 });
    }
    return NextResponse.json({
      ok: true,
      mode: "server",
      storage: hasCloudDatabase() ? "cloud" : "server-sqlite",
      time: stamp,
    });
  } catch (e) {
    console.error(
      "system/health probe failed — server cannot persist data, client will use local mode:",
      e instanceof Error ? e.message : e
    );
    return NextResponse.json({ ok: false, mode: "local" }, { status: 503 });
  }
}
