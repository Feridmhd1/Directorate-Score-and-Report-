import { NextResponse } from "next/server";
import { cacheClear, cacheStats } from "@/lib/cache";

export const dynamic = "force-dynamic";

/** Clear the server-side cache (memory optimization control) */
export async function DELETE() {
  cacheClear();
  return NextResponse.json({ ok: true, cache: cacheStats() });
}

export async function GET() {
  return NextResponse.json({ cache: cacheStats() });
}
