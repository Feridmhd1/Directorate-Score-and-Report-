import { NextResponse } from "next/server";
import { cacheStats } from "@/lib/cache";

export const dynamic = "force-dynamic";

/** Server health + memory/cache optimization status */
export async function GET() {
  return NextResponse.json({
    ok: true,
    uptimeSec: Math.round(process.uptime()),
    node: process.version,
    platform: process.platform,
    dbEngine: "SQLite (Prisma)",
    cache: cacheStats(),
    time: new Date().toISOString(),
  });
}
