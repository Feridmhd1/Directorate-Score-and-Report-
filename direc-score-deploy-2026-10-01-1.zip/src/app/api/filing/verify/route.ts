import { NextResponse } from "next/server";
import {
  clearFailures,
  clientIp,
  getFilingPin,
  recordFailure,
  throttleFailure,
} from "@/lib/filing-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/filing/verify — check the filing-room password.
 * Body: { pin: string } → 200 { ok: true } | 401 | 429 (throttled)
 */
export async function POST(req: Request) {
  const ip = clientIp(req);
  const throttled = throttleFailure(ip);
  if (throttled) return throttled;

  let pin = "";
  try {
    const body = (await req.json()) as { pin?: string };
    pin = String(body.pin ?? "").trim();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const expected = await getFilingPin();
  if (!pin || pin !== expected) {
    recordFailure(ip);
    return NextResponse.json(
      { error: "ትክክል ያልሆነ የይለፍ ቃል / Incorrect password" },
      { status: 401 }
    );
  }

  clearFailures(ip);
  return NextResponse.json({ ok: true });
}
