import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { requireFilingPin } from "@/lib/filing-guard";
import { scanFile } from "@/lib/file-scanner";
import type { FileScanReport, FiledDocumentDTO } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10 MB per filed document

function serialize(row: {
  id: string;
  title: string;
  category: string;
  fileName: string;
  mimeType: string;
  size: number;
  note: string;
  shareToken: string;
  scanVerdict: string;
  scanReportJson: string;
  createdAt: Date;
}): FiledDocumentDTO {
  let scanReport: FileScanReport | null = null;
  try {
    const parsed = row.scanReportJson ? JSON.parse(row.scanReportJson) : null;
    if (parsed && typeof parsed === "object" && "verdict" in parsed) {
      scanReport = parsed as FileScanReport;
    }
  } catch {
    scanReport = null;
  }
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    fileName: row.fileName,
    mimeType: row.mimeType,
    size: row.size,
    note: row.note,
    shareToken: row.shareToken,
    scanVerdict: row.scanVerdict,
    scanReport,
    createdAt: row.createdAt.toISOString(),
  };
}

/** GET /api/filing/documents — list filed documents (metadata only, PIN required) */
export async function GET(req: Request) {
  const denied = await requireFilingPin(req);
  if (denied) return denied;

  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category")?.trim();

  const rows = await db.filedDocument.findMany({
    where: category ? { category } : undefined,
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      title: true,
      category: true,
      fileName: true,
      mimeType: true,
      size: true,
      note: true,
      shareToken: true,
      scanVerdict: true,
      scanReportJson: true,
      createdAt: true,
    },
  });
  return NextResponse.json(
    { documents: rows.map(serialize) },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/**
 * POST /api/filing/documents — upload a document into the secure cabinet.
 * Multipart fields: file (required), title?, category?, note?
 * The file is SCANNED before storage: executables/EICAR are rejected (422),
 * suspicious files are stored with a "warning" verdict.
 */
export async function POST(req: Request) {
  const denied = await requireFilingPin(req);
  if (denied) return denied;

  try {
    const form = await req.formData();
    const file = form.get("file");
    const title = String(form.get("title") ?? "").trim();
    const category = String(form.get("category") ?? "").trim() || "General";
    const note = String(form.get("note") ?? "").trim();

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }
    if (file.size === 0) {
      return NextResponse.json({ error: "The uploaded file is empty" }, { status: 400 });
    }
    if (file.size > MAX_FILE_BYTES) {
      return NextResponse.json({ error: "Document must be under 10 MB" }, { status: 413 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const scan = scanFile(buffer, file.name || "document", file.type || "");

    if (scan.verdict === "blocked") {
      // Refuse dangerous uploads — nothing is stored
      return NextResponse.json(
        {
          error: "File blocked by the security scanner",
          scan,
        },
        { status: 422 }
      );
    }

    const row = await db.filedDocument.create({
      data: {
        title: (title || file.name || "Filed document").slice(0, 200),
        category: category.slice(0, 60),
        fileName: (file.name || "document").slice(0, 250),
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        note: note.slice(0, 500),
        shareToken: randomUUID(),
        scanVerdict: scan.verdict,
        scanReportJson: JSON.stringify(scan),
        data: buffer.toString("base64"),
      },
    });

    const { data: _omit, ...meta } = row;
    return NextResponse.json({ document: serialize(meta), scan });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Upload failed" },
      { status: 500 }
    );
  }
}

/** DELETE /api/filing/documents?id=<id> */
export async function DELETE(req: Request) {
  const denied = await requireFilingPin(req);
  if (denied) return denied;

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

  const existing = await db.filedDocument.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await db.filedDocument.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
