import { NextResponse } from "next/server";
import {
  SETTING_KEYS,
  getSettings,
  isTrue,
  setSetting,
  invalidateSettingsCache,
} from "@/lib/settings-store";
import {
  loadDriveConfig,
  isDriveConfigured,
  runBackup,
  recordBackupOutcome,
} from "@/lib/drive-backup";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

function freqMs(frequency: string): number {
  return frequency === "daily" ? 24 * 3600_000 : 7 * 24 * 3600_000;
}

/** GET /api/backup/drive — backup status for the scheduler + settings UI */
export async function GET() {
  const s = await getSettings([
    SETTING_KEYS.autoBackupEnabled,
    SETTING_KEYS.backupFrequency,
    SETTING_KEYS.lastBackupAt,
    SETTING_KEYS.lastBackupStatus,
    SETTING_KEYS.lastBackupDetail,
  ]);
  const drive = await loadDriveConfig();
  const frequency = s[SETTING_KEYS.backupFrequency] || "weekly";
  const last = s[SETTING_KEYS.lastBackupAt] || null;
  const nextDueAt =
    last && isTrue(s[SETTING_KEYS.autoBackupEnabled]) && isDriveConfigured(drive)
      ? new Date(new Date(last).getTime() + freqMs(frequency)).toISOString()
      : null;

  return NextResponse.json(
    {
      autoBackupEnabled: isTrue(s[SETTING_KEYS.autoBackupEnabled]),
      backupFrequency: frequency,
      driveConfigured: isDriveConfigured(drive),
      lastBackupAt: last,
      lastBackupStatus: s[SETTING_KEYS.lastBackupStatus] || "idle",
      lastBackupDetail: s[SETTING_KEYS.lastBackupDetail] || "",
      nextBackupDueAt: nextDueAt,
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/** POST /api/backup/drive — run a JSON backup to Google Drive now */
export async function POST() {
  const drive = await loadDriveConfig();
  if (!isDriveConfigured(drive)) {
    return NextResponse.json(
      {
        ok: false,
        fileName: "",
        detail:
          "Google Drive is not configured. Add the Client ID, Client Secret and Refresh Token in Settings → Backup.",
      },
      { status: 400 }
    );
  }

  await setSetting(SETTING_KEYS.lastBackupStatus, "running");
  try {
    const { result, counts } = await runBackup();
    await recordBackupOutcome(result);
    invalidateSettingsCache();
    return NextResponse.json({
      ok: result.ok,
      fileName: result.fileName,
      fileId: result.fileId,
      webViewLink: result.webViewLink,
      sizeBytes: result.sizeBytes,
      counts,
      detail: result.error ?? "",
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : "Backup failed";
    await setSetting(SETTING_KEYS.lastBackupStatus, "failed");
    await setSetting(SETTING_KEYS.lastBackupDetail, detail.slice(0, 500));
    return NextResponse.json({ ok: false, fileName: "", detail }, { status: 500 });
  }
}
