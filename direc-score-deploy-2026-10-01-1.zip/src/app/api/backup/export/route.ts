import { NextResponse } from "next/server";
import { buildBackupSnapshot } from "@/lib/drive-backup";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** GET /api/backup/export — download the full JSON snapshot locally */
export async function GET() {
  try {
    const { json, counts } = await buildBackupSnapshot();
    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(json, {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="direc-score-backup-${stamp}.json"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Backup export failed" },
      { status: 500 }
    );
  }
}
