import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const notification = await db.notification.update({
      where: { id },
      data: { isRead: Boolean(body.isRead ?? true) },
    });
    return NextResponse.json({ notification: { id: notification.id, isRead: notification.isRead } });
  } catch (e) {
    console.error("notification PATCH error", e);
    return NextResponse.json({ error: "Failed to update notification" }, { status: 500 });
  }
}
