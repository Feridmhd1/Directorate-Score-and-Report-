import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const notifications = await db.notification.findMany({
      orderBy: { createdAt: "desc" },
      take: 30,
    });
    return NextResponse.json({
      notifications: notifications.map((n) => ({
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        directorateKey: n.directorateKey,
        directorateName: n.directorateName,
        quarter: n.quarter,
        totalScore: n.totalScore,
        directorEmail: n.directorEmail,
        isRead: n.isRead,
        createdAt: n.createdAt.toISOString(),
      })),
    });
  } catch (e) {
    console.error("notifications GET error", e);
    return NextResponse.json({ error: "Failed to load notifications" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const notification = await db.notification.create({
      data: {
        type: String(body.type ?? "evaluation_completed"),
        title: String(body.title ?? ""),
        message: String(body.message ?? ""),
        directorateKey: String(body.directorateKey ?? ""),
        directorateName: String(body.directorateName ?? ""),
        quarter: String(body.quarter ?? ""),
        totalScore: body.totalScore !== undefined && body.totalScore !== null ? Number(body.totalScore) : null,
        directorEmail: String(body.directorEmail ?? body.director_email ?? ""),
        isRead: Boolean(body.isRead ?? false),
      },
    });
    return NextResponse.json({
      notification: {
        id: notification.id,
        type: notification.type,
        title: notification.title,
        message: notification.message,
        directorateKey: notification.directorateKey,
        directorateName: notification.directorateName,
        quarter: notification.quarter,
        totalScore: notification.totalScore,
        directorEmail: notification.directorEmail,
        isRead: notification.isRead,
        createdAt: notification.createdAt.toISOString(),
      },
    });
  } catch (e) {
    console.error("notifications POST error", e);
    return NextResponse.json({ error: "Failed to create notification" }, { status: 500 });
  }
}
