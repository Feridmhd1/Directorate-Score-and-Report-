import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST() {
  try {
    await db.notification.updateMany({ data: { isRead: true } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("notifications read-all error", e);
    return NextResponse.json({ error: "Failed to mark all read" }, { status: 500 });
  }
}
