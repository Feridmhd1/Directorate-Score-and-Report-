import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { deliverFileNotification, serializeLog } from "@/lib/automation";
import { DIRECTORATES } from "@/lib/rubric";
import { emitAppEvent } from "@/lib/events";
import type { QualityReportDTO } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10 MB per document

function serialize(row: {
  id: string;
  directorateKey: string;
  quarter: string;
  title: string;
  fileName: string;
  mimeType: string;
  size: number;
  note: string;
  shareToken: string;
  createdAt: Date;
}): QualityReportDTO {
  return {
    id: row.id,
    directorateKey: row.directorateKey,
    quarter: row.quarter,
    title: row.title,
    fileName: row.fileName,
    mimeType: row.mimeType,
    size: row.size,
    note: row.note,
    shareToken: row.shareToken,
    createdAt: row.createdAt.toISOString(),
  };
}

/** GET /api/quality-reports?directorateKey=HPDP — list documents (metadata only) */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const directorateKey = searchParams.get("directorateKey")?.trim();

  // Backfill share tokens for legacy rows so every document has a unique link
  await db.qualityReport.updateMany({
    where: { shareToken: "" },
    data: { shareToken: randomUUID() },
  });

  const rows = await db.qualityReport.findMany({
    where: directorateKey ? { directorateKey } : undefined,
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      directorateKey: true,
      quarter: true,
      title: true,
      fileName: true,
      mimeType: true,
      size: true,
      note: true,
      shareToken: true,
      createdAt: true,
    },
  });
  return NextResponse.json(
    { reports: rows.map(serialize) },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/**
 * POST /api/quality-reports — multipart upload of a quality report document
 * fields: file (required), directorateKey (required), quarter?, title?, note?
 * Any document type is accepted (pdf, docx, xlsx, csv, images, txt…).
 */
export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    const directorateKey = String(form.get("directorateKey") ?? "").trim();
    const quarter = String(form.get("quarter") ?? "").trim();
    const title = String(form.get("title") ?? "").trim();
    const note = String(form.get("note") ?? "").trim();

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }
    if (!directorateKey) {
      return NextResponse.json({ error: "directorateKey is required" }, { status: 400 });
    }
    if (file.size > MAX_FILE_BYTES) {
      return NextResponse.json(
        { error: "Document must be under 10 MB" },
        { status: 413 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const row = await db.qualityReport.create({
      data: {
        directorateKey,
        quarter,
        title: (title || file.name || "Quality report").slice(0, 200),
        fileName: (file.name || "document").slice(0, 250),
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        note: note.slice(0, 500),
        shareToken: randomUUID(),
        data: buffer.toString("base64"),
      },
    });

    const { data: _omit, ...meta } = row;
    const report = serialize(meta);

    // Immediately automate the unique share link out to every enabled
    // channel (WhatsApp / Telegram / Email). Best-effort — the upload itself
    // must never fail because delivery could not complete.
    let deliveries: ReturnType<typeof serializeLog>[] = [];
    try {
      const origin = new URL(req.url).origin;
      const shareUrl = `${origin}/api/share/report?token=${encodeURIComponent(row.shareToken)}`;
      const logs = await deliverFileNotification(
        {
          directorateKey: row.directorateKey,
          quarter: row.quarter,
          title: row.title,
          fileName: row.fileName,
          size: row.size,
          note: row.note || undefined,
          shareToken: row.shareToken,
        },
        shareUrl
      );
      deliveries = logs.map(serializeLog);
    } catch (deliveryError) {
      console.error("quality-report upload delivery error", deliveryError);
    }

    // In-app notification (best-effort)
    try {
      const d = DIRECTORATES.find((x) => x.key === row.directorateKey);
      await db.notification.create({
        data: {
          type: "document_uploaded",
          title: `ሪፖርት ተሰቀለ — ${d?.short ?? row.directorateKey}`,
          message: `${d?.name ?? row.directorateKey} uploaded "${row.title}" for ${row.quarter || "—"}. Unique link sent automatically.`,
          directorateKey: row.directorateKey,
          directorateName: d?.name ?? row.directorateKey,
          quarter: row.quarter,
        },
      });
    } catch {
      /* notification is informational */
    }

    // Real-time broadcast — the upload appears on the dashboard instantly.
    await emitAppEvent("document_uploaded", {
      id: row.id,
      directorateKey: row.directorateKey,
      directorateShort: DIRECTORATES.find((x) => x.key === row.directorateKey)?.short,
      directorateName: DIRECTORATES.find((x) => x.key === row.directorateKey)?.name,
      quarter: row.quarter,
      title: row.title,
      fileName: row.fileName,
      mimeType: row.mimeType,
      size: row.size,
      note: row.note || undefined,
      shareToken: row.shareToken,
      source: "app",
      createdAt: row.createdAt.toISOString(),
    });

    return NextResponse.json({ report, deliveries });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Upload failed" },
      { status: 500 }
    );
  }
}

/** DELETE /api/quality-reports?id=<id> */
export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  const existing = await db.qualityReport.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.qualityReport.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
