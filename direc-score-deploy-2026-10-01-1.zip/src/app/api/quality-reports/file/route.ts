import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/quality-reports/file?id=<id> — download (or preview with &inline=1)
 * a stored quality report document.
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  const inline = searchParams.get("inline") === "1";
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

  const row = await db.qualityReport.findUnique({ where: { id } });
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const buffer = Buffer.from(row.data ?? "", "base64");
  const safeName = (row.fileName || "document").replace(/[^\w.\- ()]/g, "_");
  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": row.mimeType || "application/octet-stream",
      "Content-Length": String(buffer.length),
      "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${safeName}"`,
      "Cache-Control": "private, max-age=60",
    },
  });
}
