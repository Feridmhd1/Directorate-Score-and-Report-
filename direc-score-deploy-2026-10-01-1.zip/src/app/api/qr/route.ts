import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const data = searchParams.get("data");
    const size = Math.min(Math.max(Number(searchParams.get("size") ?? 300), 100), 1000);
    if (!data) {
      return NextResponse.json({ error: "data parameter is required" }, { status: 400 });
    }
    const dataUrl = await QRCode.toDataURL(data, {
      width: size,
      margin: 2,
      color: { dark: "#0f172a", light: "#ffffff" },
      errorCorrectionLevel: "M",
    });
    return NextResponse.json({ dataUrl });
  } catch (e) {
    console.error("qr error", e);
    return NextResponse.json({ error: "Failed to generate QR code" }, { status: 500 });
  }
}
