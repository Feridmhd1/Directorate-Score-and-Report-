import { NextResponse } from "next/server";
import { getSetting, setSetting, SETTING_KEYS } from "@/lib/settings-store";
import { requireSettingsPin } from "@/lib/settings-guard";
import { deadlineDaysLeft, parseDeadline, sendDeadlineReminders } from "@/lib/deadline";
import { serializeLog } from "@/lib/automation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/deadline/remind — send the "submit before the deadline"
 * reminder right now (Settings password protected). The automatic daily
 * pre-deadline reminder runs inside GET /api/deadline instead.
 */
export async function POST(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  const raw = await getSetting(SETTING_KEYS.reportDeadline);
  const deadline = parseDeadline(raw);
  if (!deadline) {
    return NextResponse.json(
      { error: "መጀመሪያ የመጨረሻ ቀን ያስቀምጡ / Set a deadline first" },
      { status: 400 }
    );
  }
  const logs = await sendDeadlineReminders(deadline, deadlineDaysLeft(deadline.date));
  /* Mark today as reminded so the automatic path does not double-send */
  await setSetting(SETTING_KEYS.deadlineLastAuto, new Date().toISOString().slice(0, 10));
  return NextResponse.json({ deliveries: logs.map(serializeLog) });
}
