import { NextResponse } from "next/server";
import { getSetting, setSetting, SETTING_KEYS } from "@/lib/settings-store";
import { requireSettingsPin } from "@/lib/settings-guard";
import {
  deadlineDaysLeft,
  maybeAutoRemind,
  missingDirectorates,
  parseDeadline,
} from "@/lib/deadline";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/deadline — public: both the dashboard and the directorate portal
 * show the submission countdown. Also fires the automatic once-a-day
 * pre-deadline reminder (best-effort, never blocks the response).
 */
export async function GET() {
  const deadline = parseDeadline(await getSetting(SETTING_KEYS.reportDeadline));
  if (!deadline) {
    return NextResponse.json(
      { deadline: null, daysLeft: null, missing: [] },
      { headers: { "Cache-Control": "no-store" } }
    );
  }
  const missing = await missingDirectorates(deadline);
  /* Automatic reminder while the app is open — fire and forget */
  void maybeAutoRemind();
  return NextResponse.json(
    { deadline, daysLeft: deadlineDaysLeft(deadline.date), missing },
    { headers: { "Cache-Control": "no-store" } }
  );
}

/** PUT /api/deadline — set the quarterly submission deadline (Settings password) */
export async function PUT(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;

  try {
    const body = (await req.json()) as { quarter?: unknown; date?: unknown };
    const quarter = String(body.quarter ?? "").trim();
    const date = String(body.date ?? "").trim();
    if (!quarter) {
      return NextResponse.json({ error: "Quarter is required" }, { status: 400 });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(new Date(`${date}T00:00:00`).getTime())) {
      return NextResponse.json(
        { error: "ትክክለኛ ቀን ያስገቡ / Enter a valid date (YYYY-MM-DD)" },
        { status: 400 }
      );
    }
    await setSetting(SETTING_KEYS.reportDeadline, JSON.stringify({ quarter, date }));
    return NextResponse.json({ deadline: { quarter, date } });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

/** DELETE /api/deadline — clear the deadline (Settings password) */
export async function DELETE(req: Request) {
  const denied = await requireSettingsPin(req);
  if (denied) return denied;
  await setSetting(SETTING_KEYS.reportDeadline, "");
  return NextResponse.json({ ok: true });
}
