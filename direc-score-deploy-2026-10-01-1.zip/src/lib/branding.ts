"use client";

/**
 * Cached branding helpers — the bureau logo (custom upload or the built-in
 * Harari Regional Health Bureau logo) and organization name. Shared by the
 * app header, public portal pages and every PDF export.
 */

import { resolveBackendMode } from "@/lib/backend-mode";
import { getLocalSettings } from "@/lib/local-db";

export const DEFAULT_ORG_NAME = "Harari Region Health Bureau";

let logoPromise: Promise<string> | null = null;
let orgNamePromise: Promise<string> | null = null;

/** Fetch the logo as a data URL (cached for the whole session) */
export function getLogoDataUrl(): Promise<string> {
  if (!logoPromise) {
    logoPromise = resolveBackendMode()
      .then((mode) =>
        mode === "local"
          ? getLocalSettings().then((s) => s.logoDataUrl || "")
          : fetch("/api/settings/logo", { credentials: "same-origin" })
              .then((res) => (res.ok ? res.json() : Promise.reject(new Error("logo fetch failed"))))
              .then((json: { logoDataUrl: string }) => json.logoDataUrl)
      )
      .catch(() => "");
  }
  return logoPromise;
}

/** Call after uploading/removing a custom logo to refresh the cache */
export function refreshLogoCache(): void {
  logoPromise = null;
}

export function getOrganizationName(): Promise<string> {
  if (!orgNamePromise) {
    orgNamePromise = resolveBackendMode()
      .then((mode) =>
        mode === "local"
          ? getLocalSettings().then((s) => s.organizationName || DEFAULT_ORG_NAME)
          : fetch("/api/settings", { credentials: "same-origin" })
              .then((res) => (res.ok ? res.json() : Promise.reject(new Error("settings fetch failed"))))
              .then((json: { settings: { organizationName: string } }) =>
                json.settings?.organizationName || DEFAULT_ORG_NAME
              )
      )
      .catch(() => DEFAULT_ORG_NAME);
  }
  return orgNamePromise;
}
