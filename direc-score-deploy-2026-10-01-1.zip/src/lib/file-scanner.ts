import { createHash } from "crypto";
import type { FileScanReport } from "@/lib/types";

/**
 * Server-side file scanner for the secure Document Filing cabinet.
 *
 * Every uploaded file is inspected BEFORE it is stored:
 *  1. Magic-byte sniffing — detects the real file type regardless of the
 *     name/declared MIME (PDF, ZIP/Office, images, executables, scripts…)
 *  2. Declared-vs-detected MIME mismatch detection (disguised uploads)
 *  3. Dangerous content detection — Windows/Linux executables, shell and
 *     script payloads, Office macro projects (vbaProject.bin), EICAR test
 *     signature, active content inside SVG/HTML
 *  4. Extension-vs-content mismatch check
 *  5. SHA-256 fingerprint for integrity tracking
 *
 * Verdicts:
 *  - "clean"   → stored normally
 *  - "warning" → stored, but flagged (review recommended)
 *  - "blocked" → refused, never written to the database
 */

export type ScanVerdict = "clean" | "warning" | "blocked";

interface DetectedType {
  type: string;
  flags: string[];
  details: string[];
}

/* ---------------- Magic byte + content sniffing ---------------- */

function startsWith(buf: Buffer, bytes: number[], offset = 0): boolean {
  if (buf.length < offset + bytes.length) return false;
  return bytes.every((b, i) => buf[offset + i] === b);
}

function ascii(buf: Buffer, start: number, length: number): string {
  return buf.subarray(start, Math.min(start + length, buf.length)).toString("latin1");
}

/** True when the buffer looks like mostly-printable text (first 4 KB) */
function looksLikeText(buf: Buffer): boolean {
  const sample = buf.subarray(0, Math.min(4096, buf.length));
  if (sample.length === 0) return true;
  let suspicious = 0;
  for (const byte of sample) {
    if (byte === 0) return false; // NUL byte → binary
    if (byte < 7 || (byte > 13 && byte < 32)) suspicious++;
  }
  return suspicious / sample.length < 0.05;
}

function detectType(buf: Buffer, fileName: string): DetectedType {
  const flags: string[] = [];
  const details: string[] = [];

  // ---- Windows / Linux executables → blocked ----
  if (startsWith(buf, [0x4d, 0x5a])) {
    // "MZ"
    flags.push("executable");
    details.push("Windows executable (MZ header) detected — executable files are blocked.");
    return { type: "executable/windows", flags, details };
  }
  if (startsWith(buf, [0x7f, 0x45, 0x4c, 0x46])) {
    // \x7fELF
    flags.push("executable");
    details.push("Linux/Unix executable (ELF header) detected — executable files are blocked.");
    return { type: "executable/elf", flags, details };
  }
  if (startsWith(buf, [0xca, 0xfe, 0xba, 0xbe])) {
    flags.push("executable-java");
    details.push("Java class / Mach-O binary detected.");
    return { type: "binary/java-class", flags, details };
  }

  // ---- EICAR antivirus test signature → blocked (lets staff verify the scanner) ----
  const head = ascii(buf, 0, 128);
  if (head.includes("EICAR-STANDARD-ANTIVIRUS-TEST-FILE")) {
    flags.push("eicar-test-signature");
    details.push("EICAR antivirus test signature detected — file blocked as a security measure.");
    return { type: "text/eicar", flags, details };
  }

  // ---- PDF ----
  if (head.startsWith("%PDF")) {
    // PDF can embed JavaScript / launch actions — flag but allow
    const sample = ascii(buf, 0, Math.min(buf.length, 512 * 1024));
    if (/\/JavaScript|\/JS\b|\/Launch|\/EmbeddedFile/.test(sample)) {
      flags.push("pdf-active-content");
      details.push("PDF contains active content (JavaScript / launch action / embedded file).");
    }
    return { type: "application/pdf", flags, details };
  }

  // ---- ZIP family (docx / xlsx / pptx / odf / jar / apk / generic zip) ----
  if (startsWith(buf, [0x50, 0x4b])) {
    // "PK"
    const sample = ascii(buf, 0, Math.min(buf.length, 2 * 1024 * 1024));
    const isOffice =
      sample.includes("[Content_Types].xml") ||
      sample.includes("opendocument") ||
      sample.includes("mimetypeapplication/");
    if (sample.includes("vbaProject.bin") || sample.includes("macroEnabled")) {
      flags.push("office-macros");
      details.push("Office document contains a VBA macro project — review before opening.");
    }
    if (/\.jar\b|META-INF\/MANIFEST.MF/i.test(sample) && !isOffice) {
      flags.push("java-archive");
      details.push("Java archive (JAR) detected — executable archive content.");
    }
    if (sample.includes("AndroidManifest.xml")) {
      flags.push("android-package");
      details.push("Android package (APK) detected.");
    }
    if (isOffice) return { type: "office/zip-document", flags, details };
    if (flags.length > 0) return { type: "archive/zip", flags, details };
    return { type: "archive/zip", flags, details };
  }

  // ---- Images ----
  if (startsWith(buf, [0xff, 0xd8, 0xff])) return { type: "image/jpeg", flags, details };
  if (startsWith(buf, [0x89, 0x50, 0x4e, 0x47])) return { type: "image/png", flags, details };
  if (startsWith(buf, [0x47, 0x49, 0x46, 0x38])) return { type: "image/gif", flags, details };
  if (startsWith(buf, [0x42, 0x4d])) return { type: "image/bmp", flags, details };
  if (startsWith(buf, [0x52, 0x49, 0x46, 0x46]) && ascii(buf, 8, 4) === "WEBP") {
    return { type: "image/webp", flags, details };
  }
  // TIFF (little/big endian)
  if (startsWith(buf, [0x49, 0x49, 0x2a, 0x00]) || startsWith(buf, [0x4d, 0x4d, 0x00, 0x2a])) {
    return { type: "image/tiff", flags, details };
  }

  // ---- Archives ----
  if (startsWith(buf, [0x52, 0x61, 0x72, 0x21])) {
    flags.push("archive-rar");
    details.push("RAR archive detected — contents cannot be inspected.");
    return { type: "archive/rar", flags, details };
  }
  if (startsWith(buf, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) {
    flags.push("archive-7z");
    details.push("7-Zip archive detected — contents cannot be inspected.");
    return { type: "archive/7z", flags, details };
  }
  if (startsWith(buf, [0x1f, 0x8b])) return { type: "archive/gzip", flags, details };

  // ---- Text family (also catches scripts) ----
  if (looksLikeText(buf)) {
    const text = ascii(buf, 0, Math.min(buf.length, 256 * 1024));
    const trimmed = text.trimStart();
    if (trimmed.startsWith("#!")) {
      flags.push("script");
      details.push(`Executable script detected (shebang: ${trimmed.split("\n")[0].slice(0, 60)}).`);
      return { type: "text/script", flags, details };
    }
    if (/^\s*<\?php/.test(text)) {
      flags.push("script");
      details.push("PHP script detected.");
      return { type: "text/php", flags, details };
    }
    if (/^\s*<svg[\s>]/i.test(text) && /<script[\s>]/i.test(text)) {
      flags.push("svg-active-content");
      details.push("SVG image contains embedded JavaScript.");
      return { type: "image/svg+script", flags, details };
    }
    if (/^\s*<!doctype html|^\s*<html[\s>]/i.test(text) && /<script[\s>]/i.test(text)) {
      flags.push("html-active-content");
      details.push("HTML document contains <script> tags.");
      return { type: "text/html+script", flags, details };
    }
    if (/^\s*[\[{]/.test(text)) return { type: "application/json", flags, details };
    if (fileName.toLowerCase().endsWith(".xml") || /^\s*<\?xml|^\s*<[\w!]/.test(text)) {
      return { type: "text/xml", flags, details };
    }
    return { type: "text/plain", flags, details };
  }

  return { type: "application/octet-stream", flags, details };
}

/* ---------------- Extension checks ---------------- */

const BLOCKED_EXTENSIONS = [
  ".exe", ".dll", ".scr", ".com", ".msi", ".bat", ".cmd", ".ps1",
  ".vbs", ".jar", ".apk", ".deb", ".rpm", ".app", ".dmg",
];

const SCRIPT_EXTENSIONS = [".sh", ".bash", ".py", ".pl", ".rb", ".php", ".js", ".wsf"];

function extensionOf(fileName: string): string {
  const idx = fileName.lastIndexOf(".");
  return idx >= 0 ? fileName.slice(idx).toLowerCase() : "";
}

/* ---------------- MIME compatibility ---------------- */

const MIME_FAMILY: Record<string, RegExp[]> = {
  "application/pdf": [/^pdf$/, /^pdf$/],
  "image/": [/(png|jpe?g|gif|bmp|webp|tiff?|svg)/],
  "text/": [/(text|plain|csv|html|xml|json|javascript|script)/],
  "application/json": [/(json|text)/],
  "application/zip": [/(zip|office|word|excel|powerpoint|document|sheet|presentation|opendocument)/],
  "office/zip-document": [
    /(word|excel|powerpoint|document|sheet|presentation|opendocument|officedocument|zip)/,
  ],
};

/** Rough check that the declared MIME agrees with the sniffed type */
function mimeMatches(detected: string, declared: string): boolean {
  if (!declared || declared === "application/octet-stream") return true; // unknown is not a lie
  const patterns = MIME_FAMILY[detected];
  if (patterns) return patterns.some((re) => re.test(declared.toLowerCase()));
  const family = detected.split("/")[0];
  if (family === "image") return /^image\//.test(declared);
  if (family === "text") return /^(text|application\/(json|xml|javascript))/.test(declared);
  if (family === "archive") return /(zip|compressed|tar|gzip|x-7z|rar|octet-stream)/.test(declared);
  return true;
}

/* ---------------- Public API ---------------- */

export function scanFile(
  buffer: Buffer,
  fileName: string,
  declaredMime: string
): FileScanReport {
  const flags: string[] = [];
  const details: string[] = [];

  const detected = detectType(buffer, fileName);
  flags.push(...detected.flags);
  details.push(...detected.details);

  const ext = extensionOf(fileName);

  // Extension-based blocking (even when the header was disguised)
  if (BLOCKED_EXTENSIONS.includes(ext)) {
    if (!flags.includes("executable")) {
      flags.push("executable");
      details.push(`Blocked file extension "${ext}" — executable/installer files are not allowed.`);
    }
  }
  if (SCRIPT_EXTENSIONS.includes(ext) && !flags.includes("script")) {
    flags.push("script");
    details.push(`Script file ("${ext}") — scripts require review before use.`);
  }

  // Declared-vs-detected mismatch
  const typeMatch = mimeMatches(detected.type, declaredMime);
  if (!typeMatch) {
    flags.push("mime-mismatch");
    details.push(
      `Declared type "${declaredMime}" does not match the detected content type "${detected.type}".`
    );
  }

  // Extension-vs-content mismatch (e.g. "report.pdf" that is really a ZIP)
  const extFamily = ext.replace(".", "");
  const detectedFamily = detected.type.split("/").pop() ?? detected.type;
  const knownPairs: Record<string, string[]> = {
    pdf: ["pdf"],
    docx: ["zip-document"], xlsx: ["zip-document"], pptx: ["zip-document"],
    doc: ["zip-document"], xls: ["zip-document"],
    zip: ["zip", "zip-document"], png: ["png"], jpg: ["jpeg"], jpeg: ["jpeg"],
    gif: ["gif"], webp: ["webp"], txt: ["plain", "text"], csv: ["plain", "text", "csv"],
    json: ["json"], html: ["html+script", "plain"], svg: ["svg+script", "xml"],
  };
  const expected = knownPairs[extFamily];
  if (expected && !expected.some((e) => detectedFamily.includes(e))) {
    if (!flags.includes("mime-mismatch")) {
      flags.push("extension-mismatch");
      details.push(
        `File extension "${ext}" does not match the detected content (${detected.type}).`
      );
    }
  }

  // Verdict: any executable/EICAR flag blocks; other flags warn
  const hardBlock = ["executable", "executable-java", "eicar-test-signature", "android-package"].some(
    (f) => flags.includes(f)
  );
  const verdict: ScanVerdict = hardBlock ? "blocked" : flags.length > 0 ? "warning" : "clean";

  if (verdict === "clean") {
    details.push("No threats or anomalies detected — type verification passed.");
  }

  return {
    verdict,
    declaredMime: declaredMime || "application/octet-stream",
    detectedType: detected.type,
    typeMatch,
    flags: Array.from(new Set(flags)),
    checksum: createHash("sha256").update(buffer).digest("hex"),
    sizeBytes: buffer.length,
    scannedAt: new Date().toISOString(),
    details,
  };
}
