import { db } from "@/lib/db";
import { getSetting, SETTING_KEYS } from "@/lib/settings-store";
import { deliverTextMessage } from "@/lib/automation";
import { DIRECTORATES } from "@/lib/rubric";

/**
 * Quarterly-report submission deadline helpers.
 *
 * The deadline is stored in AppSetting `reportDeadline` as JSON
 * { quarter, date(ISO yyyy-mm-dd) }. Reminders fan out to every enabled
 * delivery channel (WhatsApp / Telegram / Email) and raise an in-app
 * notification — used by the Settings "Send reminder now" button and by the
 * automatic once-a-day pre-deadline reminder.
 */

export interface DeadlineInfo {
  quarter: string;
  date: string; // ISO yyyy-mm-dd
}

export function parseDeadline(raw: string | null | undefined): DeadlineInfo | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { quarter?: unknown; date?: unknown };
    const quarter = String(parsed.quarter ?? "").trim();
    const date = String(parsed.date ?? "").trim();
    if (!quarter || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
    return { quarter, date };
  } catch {
    return null;
  }
}

export function deadlineDaysLeft(date: string): number {
  const target = new Date(`${date}T23:59:59`);
  return Math.ceil((target.getTime() - Date.now()) / 86_400_000);
}

/** Directorate keys that already submitted an evaluation for the quarter */
export async function submittedKeys(quarter: string): Promise<Set<string>> {
  const rows = await db.directorateEvaluation.findMany({
    where: { quarter },
    select: { directorateKey: true },
  });
  return new Set(rows.map((r) => r.directorateKey));
}

export interface MissingDirectorate {
  key: string;
  short: string;
  name: string;
}

/** Directorates without an evaluation for the deadline's quarter */
export async function missingDirectorates(deadline: DeadlineInfo): Promise<MissingDirectorate[]> {
  const done = await submittedKeys(deadline.quarter);
  return DIRECTORATES.filter((d) => !done.has(d.key)).map((d) => ({
    key: d.key,
    short: d.short,
    name: d.nameEn,
  }));
}

/** Build the bilingual reminder message sent through every channel */
export function buildReminderMessage(
  deadline: DeadlineInfo,
  daysLeft: number,
  missing: MissingDirectorate[]
): string {
  const dayWord =
    daysLeft > 0
      ? `${daysLeft} ቀናዎች / ${daysLeft} day${daysLeft === 1 ? "" : "s"} left`
      : "ዛሬ ይውዳል / due today";
  return [
    "📅 Direc-Score — የሩብ ዓመት ሪፖርት አስታዋሻ / Quarterly report reminder",
    `ሩብ ዓመት / Quarter: ${deadline.quarter}`,
    `መጨረሻ ቀን / Deadline: ${deadline.date} (${dayWord})`,
    "",
    "እስካሁን ያልገቡ ዳይሬክቶሬቶች / Not yet submitted:",
    ...missing.map((d) => `• ${d.name} (${d.short})`),
    "",
    "እባክዎ ከመጨረሻ ቀን በፊት በዳይሬክቶሬት ፖርታልዎ ሪፖርትዎን ያስገቡ።",
    "Please submit your report through your directorate portal before the deadline.",
  ].join("\n");
}

/**
 * Send the deadline reminder to every enabled channel + persist DeliveryLog
 * rows + raise an in-app notification. Returns [] when everyone submitted.
 */
export async function sendDeadlineReminders(
  deadline: DeadlineInfo,
  daysLeft: number
) {
  const missing = await missingDirectorates(deadline);
  if (missing.length === 0) return [];
  const message = buildReminderMessage(deadline, daysLeft, missing);
  return deliverTextMessage(message, {
    quarter: deadline.quarter,
    notification: {
      type: "deadline_reminder",
      title: `⏰ የሪፖርት ጊዜ ማስታወሻ — ${deadline.quarter}`,
      message: `${missing.length} ዳይሬክቶሬቶች ሪፖርት አልገቡም · ${missing.length} directorate${
        missing.length === 1 ? "" : "s"
      } have not submitted — deadline ${deadline.date}`,
    },
  });
}

/**
 * Automatic pre-deadline reminder — called fire-and-forget whenever the
 * dashboard (or portal) loads. Sends at most once per calendar day, and only
 * within the last 7 days before the deadline while directorates are missing.
 */
export async function maybeAutoRemind(): Promise<void> {
  try {
    const deadline = parseDeadline(await getSetting(SETTING_KEYS.reportDeadline));
    if (!deadline) return;
    const days = deadlineDaysLeft(deadline.date);
    if (days < 0 || days > 7) return;
    const missing = await missingDirectorates(deadline);
    if (missing.length === 0) return;
    const today = new Date().toISOString().slice(0, 10);
    const last = await getSetting(SETTING_KEYS.deadlineLastAuto);
    if (last === today) return;
    await sendDeadlineReminders(deadline, days);
    const { setSetting } = await import("@/lib/settings-store");
    await setSetting(SETTING_KEYS.deadlineLastAuto, today);
  } catch (e) {
    console.error("auto deadline reminder failed", e);
  }
}
