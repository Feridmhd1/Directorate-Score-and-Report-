"use client";

/**
 * Lightweight app language switcher (አማርኛ / English).
 *
 * - Default language is Amharic ("am") — the bureau's working language.
 * - Choice persists in localStorage and is applied after mount (SSR-safe:
 *   server and the first client render both use the default, so there is no
 *   hydration mismatch).
 * - `t(amharic, english)` returns the string for the active language.
 * - Every screen already shows bilingual "Amharic / English" inline text; the
 *   switcher converts key surfaces (portal, shared components, settings) to a
 *   single pure language.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export type Lang = "am" | "en";

const STORAGE_KEY = "direcscore:lang";

interface LangContextValue {
  lang: Lang;
  setLang: (lang: Lang) => void;
  /** Pick the string for the active language */
  t: (am: string, en: string) => string;
}

const LangContext = createContext<LangContextValue>({
  lang: "am",
  setLang: () => {},
  t: (am) => am,
});

function readStoredLang(): Lang {
  try {
    return window.localStorage.getItem(STORAGE_KEY) === "en" ? "en" : "am";
  } catch {
    return "am";
  }
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  /**
   * Lazily read the saved choice. Safe for SSR: all language-dependent views
   * render only after AppShell's mounted gate, so the server HTML (default
   * "am") always matches the first client render.
   */
  const [lang, setLangState] = useState<Lang>(() =>
    typeof window === "undefined" ? "am" : readStoredLang()
  );

  /* Keep <html lang> in sync with the active language */
  useEffect(() => {
    document.documentElement.lang = lang === "en" ? "en" : "am";
  }, [lang]);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* storage unavailable — in-memory choice still applies */
    }
    document.documentElement.lang = next === "en" ? "en" : "am";
  }, []);

  const t = useCallback((am: string, en: string) => (lang === "en" ? en : am), [lang]);

  const value = useMemo(() => ({ lang, setLang, t }), [lang, setLang, t]);

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export function useLang(): LangContextValue {
  return useContext(LangContext);
}
