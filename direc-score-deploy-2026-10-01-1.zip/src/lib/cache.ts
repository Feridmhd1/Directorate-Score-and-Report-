/**
 * Lightweight in-process server cache with TTL + invalidation.
 * Used to reduce repeated DB round-trips and lower memory/CPU pressure
 * ("server-side memory optimization") for hot GET endpoints.
 */

interface CacheEntry {
  value: unknown;
  expiresAt: number;
}

const store = new Map<string, CacheEntry>();

const stats = { hits: 0, misses: 0, evictions: 0, invalidations: 0 };

/** Maximum entries kept — prevents unbounded memory growth */
const MAX_ENTRIES = 500;
/** Default TTL */
export const DEFAULT_TTL_MS = 30_000;

export function cacheGet<T>(key: string): T | undefined {
  const entry = store.get(key);
  if (!entry) {
    stats.misses++;
    return undefined;
  }
  if (Date.now() > entry.expiresAt) {
    store.delete(key);
    stats.evictions++;
    stats.misses++;
    return undefined;
  }
  stats.hits++;
  return entry.value as T;
}

export function cacheSet<T>(key: string, value: T, ttlMs: number = DEFAULT_TTL_MS): void {
  if (store.size >= MAX_ENTRIES) {
    // Evict the oldest entry (Map preserves insertion order)
    const oldest = store.keys().next().value;
    if (oldest !== undefined) {
      store.delete(oldest);
      stats.evictions++;
    }
  }
  store.set(key, { value, expiresAt: Date.now() + ttlMs });
}

/** Remove all cache entries whose key starts with the given prefix. */
export function cacheInvalidate(prefix: string): number {
  let removed = 0;
  for (const key of [...store.keys()]) {
    if (key.startsWith(prefix)) {
      store.delete(key);
      removed++;
    }
  }
  stats.invalidations += removed;
  return removed;
}

export function cacheClear(): void {
  store.clear();
}

export function cacheStats() {
  const total = stats.hits + stats.misses;
  return {
    ...stats,
    size: store.size,
    maxEntries: MAX_ENTRIES,
    hitRate: total === 0 ? 0 : Math.round((stats.hits / total) * 100),
  };
}
