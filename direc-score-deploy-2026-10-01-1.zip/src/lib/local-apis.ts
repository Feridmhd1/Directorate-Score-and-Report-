"use client";

/**
 * Browser-mode implementations of every application API.
 *
 * Used automatically when the backend probe fails (Netlify/Vercel
 * serverless — read-only filesystem, no SQLite). Each namespace mirrors the
 * exact request/response DTO shapes of the corresponding server route, so
 * views work identically in both modes (see client-api.ts).
 *
 * Storage lives in the user's browser: collections and uploaded files in
 * IndexedDB (local-db.ts), intelligence from the offline engine
 * (local-ai.ts), delivery through the browser push engine (client-push.ts).
 */

import {
  appendDeliveryLogs,
  deleteChannel as dbDeleteChannel,
  deleteFileBlob,
  downloadJsonFile,
  getChannels,
  getDeliveryLogs,
  getLocalPin,
  getLocalSettings,
  nowIso,
  readCollection,
  readValue,
  saveFileBlob,
  saveLocalSettings,
  shareToken,
  uid,
  upsertChannel,
  writeCollection,
  writeValue,
  type AIProviderConfig,
  type LocalChannel,
} from "@/lib/local-db";
import {
  OFFLINE_MARKER,
  offlineAnalyzeData,
  offlineChat,
  offlineCompareDocuments,
  offlineDocumentInsights,
  offlineEvaluateEvaluator,
  offlineEvaluateReport,
  offlineExtractDocument,
} from "@/lib/local-ai";
import {
  deliverThroughBrowserChannels,
  relayTelegramFromServer,
} from "@/lib/client-push";
import { buildScoreMessage, buildWaMeLink } from "@/lib/message-templates";
import { CRITERIA, DIRECTORATES, TOTAL_MAX_SCORE, computeScores } from "@/lib/rubric";
import type {
  AICompareResult,
  AppSettingsDTO,
  AutomationChannelDTO,
  BackupResultDTO,
  BackupStatusDTO,
  ChatMessageDTO,
  ContactDTO,
  ContactSendAllDTO,
  ContactSendResultDTO,
  DeadlineStateDTO,
  DeliveryLogDTO,
  DocumentHistoryDTO,
  EvaluationDTO,
  FeedbackDTO,
  FiledDocumentDTO,
  FileScanReport,
  FinalAnalysisReport,
  GraphicSuggestion,
  Insights,
  LinkItemDTO,
  NotificationDTO,
  QualityReportDTO,
  SystemStatus,
  ChartSpec,
} from "@/lib/types";
import type { ActionPlanItem } from "@/lib/rubric";

/* ------------------------------------------------------------------ */
/* Shared helpers                                                      */
/* ------------------------------------------------------------------ */

const MAX_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB — matches the server routes

function assertUploadSize(file: File): void {
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error("File is too large — the maximum size is 10MB.");
  }
}

async function verifyPin(kind: "filingPin" | "automationPin" | "settingsPin", pin: string): Promise<void> {
  const expected = await getLocalPin(kind);
  if (!pin || pin !== expected) {
    const labels: Record<string, string> = {
      filingPin: "filing room",
      automationPin: "automation",
      settingsPin: "settings",
    };
    throw new Error(`ትክክለኛ የ${labels[kind]} ይለፍ ቃል ያስፈልጋል / Incorrect ${labels[kind]} password`);
  }
}

function fileBase64Url(origin: string, path: string): string {
  return `${origin}${path}`;
}

/* ------------------------------------------------------------------ */
/* 1. Evaluations                                                      */
/* ------------------------------------------------------------------ */

function toEvaluationDTO(row: Record<string, unknown>): EvaluationDTO {
  return {
    id: String(row.id ?? uid()),
    directorateKey: String(row.directorateKey ?? ""),
    directorateName: String(row.directorateName ?? ""),
    directorateShort: String(row.directorateShort ?? ""),
    quarter: String(row.quarter ?? ""),
    email: (row.email as string | null) ?? null,
    scores: (row.scores as Record<string, number>) ?? {},
    answers: (row.answers as Record<string, string>) ?? {},
    comments: (row.comments as Record<string, string>) ?? {},
    totalScore: Number(row.totalScore ?? 0),
    status: String(row.status ?? "submitted"),
    attachments: (row.attachments as string[]) ?? [],
    actionPlan: (row.actionPlan as ActionPlanItem[]) ?? [],
    aiGenerated: Boolean(row.aiGenerated),
    createdAt: String(row.createdAt ?? nowIso()),
    updatedAt: String(row.updatedAt ?? row.createdAt ?? nowIso()),
  };
}

export const localEvaluationsApi = {
  list: async (params?: { quarter?: string; directorateKey?: string }) => {
    let rows = await readCollection<Record<string, unknown>>("evaluations", []);
    if (params?.quarter) rows = rows.filter((r) => r.quarter === params.quarter);
    if (params?.directorateKey) rows = rows.filter((r) => r.directorateKey === params.directorateKey);
    const evaluations = rows.map(toEvaluationDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { evaluations };
  },
  listAll: async () => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const evaluations = rows.map(toEvaluationDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { evaluations };
  },
  create: async (data: {
    directorateKey: string;
    directorateName: string;
    directorateShort: string;
    quarter: string;
    email?: string;
    scores: Record<string, number>;
    answers: Record<string, string>;
    comments: Record<string, string>;
    totalScore: number;
    status?: string;
    attachments?: string[];
    actionPlan?: ActionPlanItem[];
    aiGenerated?: boolean;
  }) => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const scores = data.scores && Object.keys(data.scores).length ? data.scores : computeScores(data.answers).scores;
    const totalScore =
      typeof data.totalScore === "number" && data.totalScore > 0
        ? data.totalScore
        : computeScores(data.answers).totalScore;
    const evaluation: Record<string, unknown> = {
      id: uid(),
      directorateKey: data.directorateKey,
      directorateName: data.directorateName,
      directorateShort: data.directorateShort,
      quarter: data.quarter,
      email: data.email ?? null,
      scores,
      answers: data.answers ?? {},
      comments: data.comments ?? {},
      totalScore,
      status: data.status ?? "submitted",
      attachments: data.attachments ?? [],
      actionPlan: data.actionPlan ?? [],
      aiGenerated: Boolean(data.aiGenerated),
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
    rows.push(evaluation);
    await writeCollection("evaluations", rows.slice(-2000));

    // In-app notification (mirrors the server behavior)
    const notifications = await readCollection<Record<string, unknown>>("notifications", []);
    notifications.push({
      id: uid(),
      type: "evaluation",
      title: "አዲስ ግምገማ / New evaluation",
      message: `${data.directorateName} — ${data.quarter}: ${totalScore}/${TOTAL_MAX_SCORE}`,
      directorateKey: data.directorateKey,
      directorateName: data.directorateName,
      quarter: data.quarter,
      totalScore,
      directorEmail: data.email ?? "",
      isRead: false,
      createdAt: nowIso(),
    });
    await writeCollection("notifications", notifications.slice(-300));
    return { evaluation: toEvaluationDTO(evaluation) };
  },
  update: async (id: string, data: Partial<{
    directorateKey: string;
    directorateName: string;
    directorateShort: string;
    quarter: string;
    email?: string;
    scores: Record<string, number>;
    answers: Record<string, string>;
    comments: Record<string, string>;
    totalScore: number;
    status?: string;
    attachments?: string[];
    actionPlan?: ActionPlanItem[];
    aiGenerated?: boolean;
  }>) => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const index = rows.findIndex((r) => r.id === id);
    if (index < 0) throw new Error("Evaluation not found");
    const updated = { ...rows[index], ...data, updatedAt: nowIso() };
    rows[index] = updated;
    await writeCollection("evaluations", rows);
    return { evaluation: toEvaluationDTO(updated) };
  },
  remove: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    await writeCollection("evaluations", rows.filter((r) => r.id !== id));
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 2. Document history (AI Studio documents)                           */
/* ------------------------------------------------------------------ */

function toDocumentDTO(row: Record<string, unknown>): DocumentHistoryDTO {
  return {
    id: String(row.id ?? uid()),
    fileName: String(row.fileName ?? "document"),
    content: String(row.content ?? ""),
    contentLength: Number(row.contentLength ?? String(row.content ?? "").length),
    wordCount: Number(row.wordCount ?? 0),
    status: String(row.status ?? "uploaded"),
    insights: (row.insights as Insights | null) ?? null,
    graphics: (row.graphics as GraphicSuggestion[]) ?? [],
    charts: (row.charts as ChartSpec[]) ?? [],
    finalized: Boolean(row.finalized),
    finalReport: (row.finalReport as FinalAnalysisReport | null) ?? null,
    documentType: String(row.documentType ?? ""),
    language: String(row.language ?? ""),
    sentiment: String(row.sentiment ?? ""),
    mimeType: String(row.mimeType ?? ""),
    createdAt: String(row.createdAt ?? nowIso()),
  };
}

export const localDocumentsApi = {
  list: async () => {
    const rows = await readCollection<Record<string, unknown>>("documents", []);
    const documents = rows.map(toDocumentDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { documents };
  },
  getById: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("documents", []);
    const found = rows.find((r) => r.id === id);
    if (!found) throw new Error("Document not found");
    return { document: toDocumentDTO(found) };
  },
  create: async (data: {
    fileName: string;
    content: string;
    status?: string;
    mimeType?: string;
  }) => {
    const rows = await readCollection<Record<string, unknown>>("documents", []);
    const document: Record<string, unknown> = {
      id: uid(),
      fileName: data.fileName,
      content: data.content,
      contentLength: data.content.length,
      wordCount: data.content.trim().split(/\s+/).filter(Boolean).length,
      status: data.status ?? "uploaded",
      insights: null,
      graphics: [],
      charts: [],
      finalized: false,
      finalReport: null,
      documentType: "",
      language: /[\u1200-\u137F]/.test(data.content) ? "amharic" : "english",
      sentiment: "",
      mimeType: data.mimeType ?? "",
      createdAt: nowIso(),
    };
    rows.push(document);
    await writeCollection("documents", rows.slice(-300));
    return { document: toDocumentDTO(document) };
  },
  update: async (
    id: string,
    data: Partial<{
      insights: Record<string, unknown>;
      graphics: Array<Record<string, unknown>>;
      charts: Array<Record<string, unknown>>;
      status: string;
      documentType: string;
      language: string;
      sentiment: string;
      mimeType: string;
      finalized: boolean;
      finalReport: FinalAnalysisReport;
    }>
  ) => {
    const rows = await readCollection<Record<string, unknown>>("documents", []);
    const index = rows.findIndex((r) => r.id === id);
    if (index < 0) throw new Error("Document not found");
    const updated = { ...rows[index], ...data };
    rows[index] = updated;
    await writeCollection("documents", rows);
    return { document: toDocumentDTO(updated) };
  },
  remove: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("documents", []);
    await writeCollection("documents", rows.filter((r) => r.id !== id));
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 3. Notifications                                                    */
/* ------------------------------------------------------------------ */

export const localNotificationsApi = {
  list: async () => {
    const rows = await readCollection<Record<string, unknown>>("notifications", []);
    const notifications = rows
      .map((r) => ({
        id: String(r.id ?? uid()),
        type: String(r.type ?? "info"),
        title: String(r.title ?? ""),
        message: String(r.message ?? ""),
        directorateKey: String(r.directorateKey ?? ""),
        directorateName: String(r.directorateName ?? ""),
        quarter: String(r.quarter ?? ""),
        totalScore: (r.totalScore as number | null) ?? null,
        directorEmail: String(r.directorEmail ?? ""),
        isRead: Boolean(r.isRead),
        createdAt: String(r.createdAt ?? nowIso()),
      }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { notifications };
  },
  create: async (data: Partial<NotificationDTO>) => {
    const rows = await readCollection<Record<string, unknown>>("notifications", []);
    const notification: Record<string, unknown> = {
      id: uid(),
      type: data.type ?? "info",
      title: data.title ?? "",
      message: data.message ?? "",
      directorateKey: data.directorateKey ?? "",
      directorateName: data.directorateName ?? "",
      quarter: data.quarter ?? "",
      totalScore: data.totalScore ?? null,
      directorEmail: data.directorEmail ?? "",
      isRead: false,
      createdAt: nowIso(),
    };
    rows.push(notification);
    await writeCollection("notifications", rows.slice(-300));
    return { notification: data as NotificationDTO };
  },
  markRead: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("notifications", []);
    const index = rows.findIndex((r) => r.id === id);
    if (index >= 0) {
      rows[index] = { ...rows[index], isRead: true };
      await writeCollection("notifications", rows);
    }
    return { ok: true as const };
  },
  markAllRead: async () => {
    const rows = await readCollection<Record<string, unknown>>("notifications", []);
    await writeCollection(
      "notifications",
      rows.map((r) => ({ ...r, isRead: true }))
    );
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 4. AI (offline engine + persistence)                                */
/* ------------------------------------------------------------------ */

export const localAiApi = {
  evaluateReport: async (data: {
    directorateName: string;
    quarter: string;
    content: string;
    language?: "english" | "amharic" | "bilingual";
  }) => offlineEvaluateReport(data),

  evaluateEvaluator: async (data: {
    directorateName: string;
    quarter: string;
    answers: Record<string, string>;
    comments: Record<string, string>;
    totalScore: number;
    reportContent: string;
  }) => offlineEvaluateEvaluator(data),

  documentInsights: async (data: { fileName: string; content: string }) =>
    (await offlineDocumentInsights(data)) as unknown as {
      insights: Record<string, unknown>;
      graphics: Array<Record<string, unknown>>;
    },

  compareDocuments: async (data: {
    documents: Array<{ fileName: string; content: string }>;
  }): Promise<AICompareResult> => offlineCompareDocuments(data),

  extractDocument: async (file: File) => offlineExtractDocument(file),

  analyzeData: async (data: { fileName: string; content: string; mimeType?: string }) =>
    offlineAnalyzeData(data),

  chat: async (data: { sessionId: string; message: string; documentId?: string }) => {
    // Ground the reply in the locally stored document when provided
    let documentContext: { fileName: string; content: string } | undefined;
    if (data.documentId) {
      try {
        const { document } = await localDocumentsApi.getById(data.documentId);
        documentContext = { fileName: document.fileName, content: document.content };
      } catch {
        /* grounding optional */
      }
    }
    const { reply } = await offlineChat({
      sessionId: data.sessionId,
      message: data.message,
      documentId: data.documentId,
      documentContext,
    });
    // Persist the conversation (IndexedDB, shared with chatHistory)
    try {
      const key = `chat:${data.sessionId}`;
      const rows = await readValue<ChatMessageDTO[]>(key, []);
      rows.push(
        {
          id: uid(),
          sessionId: data.sessionId,
          role: "user",
          content: data.message,
          documentId: data.documentId ?? "",
          createdAt: nowIso(),
        },
        {
          id: uid(),
          sessionId: data.sessionId,
          role: "assistant",
          content: reply,
          documentId: data.documentId ?? "",
          createdAt: nowIso(),
        }
      );
      await writeValue(key, rows.slice(-100));
    } catch {
      /* history is a bonus */
    }
    return { reply };
  },

  chatHistory: async (sessionId: string) => {
    const rows = await readValue<ChatMessageDTO[]>(`chat:${sessionId}`, []);
    return { messages: rows };
  },

  clearChat: async (sessionId: string) => {
    await writeValue(`chat:${sessionId}`, []);
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 5. Automation (channel manager + delivery)                          */
/* ------------------------------------------------------------------ */

function channelToDTO(channel: LocalChannel): AutomationChannelDTO {
  return {
    id: channel.id,
    type: channel.type,
    label: channel.label,
    target: channel.target,
    hasToken: Boolean(channel.botToken),
    enabled: Boolean(channel.enabled),
    createdAt: channel.createdAt,
  };
}

async function deliverEvaluation(evaluation: Record<string, unknown>): Promise<DeliveryLogDTO[]> {
  const dto = toEvaluationDTO(evaluation);
  const message = buildScoreMessage(dto);
  const delivery = await deliverThroughBrowserChannels(message, {
    directorateKey: dto.directorateKey,
    directorateName: dto.directorateName,
    quarter: dto.quarter,
  });
  return delivery.logs;
}

export const localAutomationApi = {
  listChannels: async () => {
    const channels = await getChannels();
    return { channels: channels.map(channelToDTO) };
  },

  verify: async (pin: string) => {
    await verifyPin("automationPin", pin);
    return { ok: true as const };
  },

  saveChannel: async (data: {
    type: string;
    label?: string;
    target?: string;
    botToken?: string;
    enabled?: boolean;
    id?: string;
    _pin?: string;
  }) => {
    await verifyPin("automationPin", data._pin ?? "");
    const channels = await getChannels();
    const existing = data.id ? channels.find((c) => c.id === data.id) : undefined;
    const channel: LocalChannel = {
      id: existing?.id ?? uid(),
      type: data.type,
      label: data.label ?? "",
      target: data.target ?? "",
      botToken: data.botToken || existing?.botToken || "",
      enabled: data.enabled ?? true,
      createdAt: existing?.createdAt ?? nowIso(),
    };
    await upsertChannel(channel);
    return { channel: channelToDTO(channel) };
  },

  deleteChannel: async (id: string, pin: string) => {
    await verifyPin("automationPin", pin);
    await dbDeleteChannel(id);
    return { ok: true as const };
  },

  send: async (data: { evaluationIds: string[] }) => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const logs: DeliveryLogDTO[] = [];
    for (const id of data.evaluationIds ?? []) {
      const evaluation = rows.find((r) => r.id === id);
      if (evaluation) logs.push(...(await deliverEvaluation(evaluation)));
    }
    return { results: logs };
  },

  autoNotify: async (data: { evaluationId: string }) => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const evaluation = rows.find((r) => r.id === data.evaluationId);
    const logs = evaluation ? await deliverEvaluation(evaluation) : [];
    return { results: logs };
  },

  testChannel: async (data: { channelId: string }, pin: string) => {
    await verifyPin("automationPin", pin);
    const channels = await getChannels();
    const channel = channels.find((c) => c.id === data.channelId);
    if (!channel) throw new Error("Channel not found");
    const message =
      "✅ Direc-Score test message — የቻናል ሙከራ። If you can read this, the channel works.";
    const delivery = await deliverThroughBrowserChannels(
      message,
      {},
      { channels: [channel] }
    );
    return { result: delivery.logs[0] ?? null };
  },

  logs: async (limit = 50) => {
    const logs = await getDeliveryLogs(limit);
    return { logs };
  },
};

/* ------------------------------------------------------------------ */
/* 6. System status                                                    */
/* ------------------------------------------------------------------ */

const ZERO_CACHE = {
  hits: 0,
  misses: 0,
  evictions: 0,
  invalidations: 0,
  size: 0,
  maxEntries: 0,
  hitRate: 0,
};

const BOOT_TIME = Date.now();

export const localSystemApi = {
  status: async (): Promise<SystemStatus> => ({
    ok: true,
    uptimeSec: Math.round((Date.now() - BOOT_TIME) / 1000),
    node: "browser",
    platform: typeof navigator !== "undefined" ? navigator.platform || "web" : "web",
    dbEngine: "IndexedDB (browser storage)",
    cache: { ...ZERO_CACHE },
    time: nowIso(),
  }),
  clearCache: async () => ({ cache: { ...ZERO_CACHE } }),
};

/* ------------------------------------------------------------------ */
/* 7. Analytics summary (port of the server aggregation)               */
/* ------------------------------------------------------------------ */

export interface LocalAnalyticsSummary {
  quarters: string[];
  kpis: {
    evaluations: number;
    directoratesEvaluated: number;
    avgScore: number;
    avgPct: number;
    needsImprovement: number;
    average: number;
    good: number;
    highest: { short: string; nameEn: string; total: number; quarter: string } | null;
    lowest: { short: string; nameEn: string; total: number; quarter: string } | null;
  };
  byDirectorate: Array<{
    key: string;
    short: string;
    nameEn: string;
    latest: { total: number; pct: number; quarter: string; status: string } | null;
    previousTotal: number | null;
    trend: number | null;
  }>;
  categoryAverages: Array<{ key: string; nameEn: string; avg: number; max: number }>;
  history: Array<{ quarter: string; count: number; avg: number }>;
}

export const localAnalyticsApi = {
  summary: async (): Promise<LocalAnalyticsSummary> => {
    const rows = await readCollection<Record<string, unknown>>("evaluations", []);
    const evaluations = rows.map(toEvaluationDTO).sort((a, b) => a.createdAt.localeCompare(b.createdAt));

    const pct = (t: number) => (TOTAL_MAX_SCORE > 0 ? Math.round((t / TOTAL_MAX_SCORE) * 100) : 0);

    const byDir = new Map<string, { latest: EvaluationDTO; previous: EvaluationDTO | null }>();
    for (const e of evaluations) {
      const entry = byDir.get(e.directorateKey);
      if (!entry) byDir.set(e.directorateKey, { latest: e, previous: null });
      else {
        entry.previous = entry.latest;
        entry.latest = e;
      }
    }

    const byDirectorate = [...byDir.entries()].map(([key, { latest, previous }]) => ({
      key,
      short: latest.directorateShort,
      nameEn: latest.directorateName,
      latest: { total: latest.totalScore, pct: pct(latest.totalScore), quarter: latest.quarter, status: latest.status },
      previousTotal: previous ? previous.totalScore : null,
      trend: previous ? Math.round(latest.totalScore - previous.totalScore) : null,
    }));

    const totals = evaluations.map((e) => e.totalScore);
    const avgScore = totals.length ? totals.reduce((a, b) => a + b, 0) / totals.length : 0;
    const sorted = [...evaluations].sort((a, b) => b.totalScore - a.totalScore);
    const best = sorted[0];
    const worst = sorted[sorted.length - 1];

    const good = totals.filter((t) => pct(t) >= 75).length;
    const average = totals.filter((t) => pct(t) >= 50 && pct(t) < 75).length;
    const needsImprovement = totals.filter((t) => pct(t) < 50).length;

    const categoryAverages = CRITERIA.map((c) => {
      const vals = evaluations.map((e) => e.scores?.[c.key] ?? 0);
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      return { key: c.key, nameEn: c.nameEn, avg: Math.round(avg * 10) / 10, max: c.maxScore };
    });

    const quarterMap = new Map<string, number[]>();
    for (const e of evaluations) {
      const arr = quarterMap.get(e.quarter) ?? [];
      arr.push(e.totalScore);
      quarterMap.set(e.quarter, arr);
    }
    const history = [...quarterMap.entries()]
      .map(([quarter, arr]) => ({
        quarter,
        count: arr.length,
        avg: Math.round((arr.reduce((a, b) => a + b, 0) / arr.length) * 10) / 10,
      }))
      .sort((a, b) => a.quarter.localeCompare(b.quarter));

    return {
      quarters: history.map((h) => h.quarter),
      kpis: {
        evaluations: evaluations.length,
        directoratesEvaluated: byDir.size,
        avgScore: Math.round(avgScore * 10) / 10,
        avgPct: pct(avgScore),
        needsImprovement,
        average,
        good,
        highest: best
          ? { short: best.directorateShort, nameEn: best.directorateName, total: best.totalScore, quarter: best.quarter }
          : null,
        lowest: worst
          ? { short: worst.directorateShort, nameEn: worst.directorateName, total: worst.totalScore, quarter: worst.quarter }
          : null,
      },
      byDirectorate,
      categoryAverages,
      history,
    };
  },
};

/* ------------------------------------------------------------------ */
/* 8. Settings / branding / PINs / logo                                */
/* ------------------------------------------------------------------ */

function settingsToDTO(settings: Awaited<ReturnType<typeof getLocalSettings>>): AppSettingsDTO {
  return {
    organizationName: settings.organizationName,
    customLogo: Boolean(settings.logoDataUrl),
    autoBackupEnabled: settings.autoBackupEnabled,
    backupFrequency: settings.backupFrequency,
    lastBackupAt: settings.lastBackupAt,
    lastBackupStatus: settings.lastBackupStatus,
    lastBackupDetail: settings.lastBackupDetail,
    driveConfigured: Boolean(settings.driveClientId && settings.driveClientSecret && settings.driveRefreshToken),
  };
}

/** Built-in logo from /public (works without sharp in the browser) */
async function builtinLogoDataUrl(): Promise<string> {
  try {
    const res = await fetch("/harari-logo.jpg", { credentials: "same-origin" });
    if (!res.ok) return "";
    const blob = await res.blob();
    return await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ""));
      reader.onerror = () => resolve("");
      reader.readAsDataURL(blob);
    });
  } catch {
    return "";
  }
}

/** Downscale a logo image to ≤512px PNG data URL (canvas, no deps) */
async function normalizeLogo(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Could not read the logo file"));
    reader.readAsDataURL(file);
  });
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Invalid image"));
      img.src = dataUrl;
    });
    const maxSide = 512;
    const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) return dataUrl;
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  } catch {
    return dataUrl; // non-rasterizable (e.g. SVG) — store the original
  }
}

export const localSettingsApi = {
  get: async () => {
    const settings = await getLocalSettings();
    return { settings: settingsToDTO(settings) };
  },

  verify: async (pin: string) => {
    await verifyPin("settingsPin", pin);
    return { ok: true as const };
  },

  update: async (data: Record<string, unknown>) => {
    const patch: Record<string, unknown> = {};
    if (typeof data.organizationName === "string") patch.organizationName = data.organizationName;
    if (typeof data.autoBackupEnabled === "boolean") patch.autoBackupEnabled = data.autoBackupEnabled;
    if (data.backupFrequency === "weekly" || data.backupFrequency === "daily") {
      patch.backupFrequency = data.backupFrequency;
    }
    for (const key of ["driveClientId", "driveClientSecret", "driveRefreshToken", "driveFolderId"] as const) {
      if (typeof data[key] === "string") patch[key] = data[key];
    }
    if (data.clearDriveConfig === true) {
      patch.driveClientId = "";
      patch.driveClientSecret = "";
      patch.driveRefreshToken = "";
      patch.driveFolderId = "";
    }
    // Write-only PIN updates (empty string = unchanged)
    for (const key of ["filingPin", "automationPin", "settingsPin"] as const) {
      const value = data[key];
      if (typeof value === "string" && value.trim().length >= 4) {
        patch[key] = value.trim();
      }
    }
    const settings = await saveLocalSettings(patch);
    return { settings: settingsToDTO(settings) };
  },

  getLogo: async () => {
    const settings = await getLocalSettings();
    if (settings.logoDataUrl) {
      return { logoDataUrl: settings.logoDataUrl, custom: true };
    }
    return { logoDataUrl: await builtinLogoDataUrl(), custom: false };
  },

  uploadLogo: async (file: File, pin: string) => {
    await verifyPin("settingsPin", pin);
    const logoDataUrl = await normalizeLogo(file);
    await saveLocalSettings({ logoDataUrl });
    return { logoDataUrl, custom: true };
  },

  removeLogo: async (pin: string) => {
    await verifyPin("settingsPin", pin);
    await saveLocalSettings({ logoDataUrl: "" });
    return { logoDataUrl: await builtinLogoDataUrl(), custom: false };
  },
};

/* ------------------------------------------------------------------ */
/* 9. Backup (JSON download + restore)                                 */
/* ------------------------------------------------------------------ */

export const localBackupApi = {
  status: async (): Promise<BackupStatusDTO> => {
    const settings = await getLocalSettings();
    let nextBackupDueAt: string | null = null;
    if (settings.autoBackupEnabled && settings.lastBackupAt) {
      const days = settings.backupFrequency === "daily" ? 1 : 7;
      nextBackupDueAt = new Date(
        new Date(settings.lastBackupAt).getTime() + days * 86_400_000
      ).toISOString();
    }
    return {
      autoBackupEnabled: settings.autoBackupEnabled,
      backupFrequency: settings.backupFrequency,
      driveConfigured: false,
      lastBackupAt: settings.lastBackupAt,
      lastBackupStatus: settings.lastBackupStatus,
      lastBackupDetail: settings.lastBackupDetail,
      nextBackupDueAt,
    };
  },

  run: async (): Promise<BackupResultDTO & { _settings?: Record<string, unknown> }> => {
    const { exportLocalBackup } = await import("@/lib/local-db");
    try {
      const payload = await exportLocalBackup();
      const stamp = new Date().toISOString().slice(0, 10);
      const fileName = `direcscore-backup-${stamp}.json`;
      downloadJsonFile(fileName, payload);
      const bookkeeping = {
        lastBackupAt: nowIso(),
        lastBackupStatus: "success",
        lastBackupDetail: `Browser backup downloaded (${payload.collections.length} collections, ${payload.files.length} files)`,
      };
      await saveLocalSettings(bookkeeping);
      return {
        ok: true,
        fileName,
        sizeBytes: JSON.stringify(payload).length,
        detail: bookkeeping.lastBackupDetail,
        _settings: bookkeeping,
      };
    } catch (e) {
      const bookkeeping = {
        lastBackupAt: nowIso(),
        lastBackupStatus: "failed",
        lastBackupDetail: e instanceof Error ? e.message : "Backup failed",
      };
      await saveLocalSettings(bookkeeping);
      return {
        ok: false,
        fileName: "",
        detail: bookkeeping.lastBackupDetail,
        _settings: bookkeeping,
      };
    }
  },
};

/* ------------------------------------------------------------------ */
/* 10. Quality report documents (per directorate)                      */
/* ------------------------------------------------------------------ */

function shareLinkFor(kind: "report" | "file", token: string): string {
  if (typeof window === "undefined") return `/share/${kind}?token=${token}`;
  return fileBase64Url(window.location.origin, `/share/${kind}?token=${encodeURIComponent(token)}`);
}

function toQualityDTO(row: Record<string, unknown>): QualityReportDTO {
  return {
    id: String(row.id ?? uid()),
    directorateKey: String(row.directorateKey ?? ""),
    quarter: String(row.quarter ?? ""),
    title: String(row.title ?? ""),
    fileName: String(row.fileName ?? ""),
    mimeType: String(row.mimeType ?? ""),
    size: Number(row.size ?? 0),
    note: String(row.note ?? ""),
    shareToken: String(row.shareToken ?? ""),
    createdAt: String(row.createdAt ?? nowIso()),
  };
}

async function storeUploadedDocument(
  collection: string,
  file: File,
  meta: { directorateKey: string; quarter?: string; title?: string; note?: string }
): Promise<Record<string, unknown>> {
  assertUploadSize(file);
  const rows = await readCollection<Record<string, unknown>>(collection, []);
  const row: Record<string, unknown> = {
    id: uid(),
    directorateKey: meta.directorateKey,
    quarter: meta.quarter ?? "",
    title: meta.title ?? file.name,
    fileName: file.name,
    mimeType: file.type || "application/octet-stream",
    size: file.size,
    note: meta.note ?? "",
    shareToken: shareToken(),
    createdAt: nowIso(),
  };
  rows.push(row);
  await writeCollection(collection, rows.slice(-500));
  await saveFileBlob(row.id as string, file);
  return row;
}

async function announceUpload(
  row: Record<string, unknown>,
  kind: "report" | "file"
): Promise<{ deliveries: DeliveryLogDTO[]; handoffs: Array<{ channelType: string; label: string; url: string; detail: string }> }> {
  const link = shareLinkFor(kind, String(row.shareToken ?? ""));
  const message = [
    "📄 Direc-Score — አዲስ ሰነድ / New document",
    `ዳይሬክቶሬ / Directorate: ${row.directorateKey ?? ""}`,
    `ሰነድ: ${row.title ?? row.fileName ?? ""}`,
    `ሩብ ዓመት / Quarter: ${row.quarter || "—"}`,
    "",
    `የሰነዱ ብቸኛ አገናኝ / Unique link: ${link}`,
  ].join("\n");
  const delivery = await deliverThroughBrowserChannels(message, {
    directorateKey: String(row.directorateKey ?? ""),
    directorateName: String(row.directorateKey ?? ""),
    quarter: String(row.quarter ?? ""),
  });
  return { deliveries: delivery.logs, handoffs: delivery.handoffs };
}

export const localQualityApi = {
  list: async (directorateKey?: string) => {
    let rows = await readCollection<Record<string, unknown>>("qualityReports", []);
    if (directorateKey) rows = rows.filter((r) => r.directorateKey === directorateKey);
    const reports = rows.map(toQualityDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { reports };
  },
  upload: async (
    file: File,
    meta: { directorateKey: string; quarter?: string; title?: string; note?: string }
  ) => {
    const row = await storeUploadedDocument("qualityReports", file, meta);
    const { deliveries } = await announceUpload(row, "report");
    return { report: toQualityDTO(row), deliveries, _handoffs: [] };
  },
  remove: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("qualityReports", []);
    await writeCollection("qualityReports", rows.filter((r) => r.id !== id));
    await deleteFileBlob(id);
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 11. Public portal (directorate self-service upload)                 */
/* ------------------------------------------------------------------ */

export const localPortalApi = {
  upload: async (
    file: File,
    meta: { directorateKey: string; quarter?: string; title?: string; note?: string }
  ) => {
    const row = await storeUploadedDocument("qualityReports", file, meta);
    const link = shareLinkFor("report", String(row.shareToken ?? ""));
    const { deliveries, handoffs } = await announceUpload(row, "report");

    // Optional server relay (TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID deployment
    // variables) so uploads made on the directorate's own device still reach
    // the supervisor automatically.
    const relay = await relayTelegramFromServer(
      `📄 New portal upload — ${meta.directorateKey}: ${row.title ?? file.name}\n${link}`,
      { blob: file, fileName: file.name }
    );
    if (relay.status === "sent") {
      const relayLog: DeliveryLogDTO = {
        id: uid(),
        channelType: "telegram",
        target: "server-relay",
        directorateKey: meta.directorateKey,
        directorateName: meta.directorateKey,
        quarter: meta.quarter ?? "",
        message: "Portal upload relayed to the supervisor",
        status: "sent",
        detail: relay.detail,
        createdAt: nowIso(),
      };
      deliveries.push(relayLog);
      await appendDeliveryLogs([relayLog]);
    } else {
      handoffs.push({
        channelType: "telegram",
        label: "Telegram — @feridmhd1",
        url: "https://t.me/feridmhd1",
        detail: relay.detail,
      });
    }

    return {
      report: toQualityDTO(row),
      shareUrl: link,
      deliveries,
      _handoffs: handoffs,
    };
  },
};

/* ------------------------------------------------------------------ */
/* 12. Feedback (comments & suggestions)                               */
/* ------------------------------------------------------------------ */

function toFeedbackDTO(row: Record<string, unknown>): FeedbackDTO {
  return {
    id: String(row.id ?? uid()),
    directorateKey: String(row.directorateKey ?? ""),
    directorateName: String(row.directorateName ?? ""),
    quarter: String(row.quarter ?? ""),
    kind: String(row.kind ?? "comment"),
    message: String(row.message ?? ""),
    contact: String(row.contact ?? ""),
    isRead: Boolean(row.isRead),
    createdAt: String(row.createdAt ?? nowIso()),
  };
}

export const localFeedbackApi = {
  submit: async (data: {
    directorateKey: string;
    directorateName?: string;
    quarter?: string;
    kind?: "comment" | "suggestion";
    message: string;
    contact?: string;
  }) => {
    const rows = await readCollection<Record<string, unknown>>("feedback", []);
    const row: Record<string, unknown> = {
      id: uid(),
      directorateKey: data.directorateKey,
      directorateName: data.directorateName ?? data.directorateKey,
      quarter: data.quarter ?? "",
      kind: data.kind ?? "comment",
      message: data.message,
      contact: data.contact ?? "",
      isRead: false,
      createdAt: nowIso(),
    };
    rows.push(row);
    await writeCollection("feedback", rows.slice(-300));

    // Notify the supervisor through the browser channels (mirrors the server)
    const message = [
      "💬 Direc-Score — አዲስ አስተያየት / New feedback",
      `ዳይሬክቶሬ: ${row.directorateName ?? data.directorateKey}`,
      `አይነት / Type: ${row.kind === "suggestion" ? "ጥቆማ / Suggestion" : "አስተያየት / Comment"}`,
      "",
      String(data.message ?? ""),
      data.contact ? `ማግኘት / Contact: ${data.contact}` : "",
    ]
      .filter(Boolean)
      .join("\n");
    const delivery = await deliverThroughBrowserChannels(message, {
      directorateKey: data.directorateKey,
      directorateName: String(row.directorateName ?? ""),
      quarter: data.quarter ?? "",
    });
    return { feedback: toFeedbackDTO(row), deliveries: delivery.logs };
  },
  list: async (params?: { directorateKey?: string; unreadOnly?: boolean }) => {
    let rows = await readCollection<Record<string, unknown>>("feedback", []);
    if (params?.directorateKey) rows = rows.filter((r) => r.directorateKey === params.directorateKey);
    if (params?.unreadOnly) rows = rows.filter((r) => !r.isRead);
    const feedback = rows.map(toFeedbackDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const all = await readCollection<Record<string, unknown>>("feedback", []);
    return { feedback, unreadCount: all.filter((r) => !r.isRead).length };
  },
  markRead: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("feedback", []);
    const index = rows.findIndex((r) => r.id === id);
    if (index >= 0) {
      rows[index] = { ...rows[index], isRead: true };
      await writeCollection("feedback", rows);
      return { feedback: toFeedbackDTO(rows[index]) };
    }
    throw new Error("Feedback not found");
  },
};

/* ------------------------------------------------------------------ */
/* 13. Secure filing room (PIN + browser file scanner)                 */
/* ------------------------------------------------------------------ */

interface ScanInput {
  bytes: Uint8Array;
  declaredMime: string;
  fileName: string;
}

async function scanUploadedFile({ bytes, declaredMime, fileName }: ScanInput): Promise<FileScanReport> {
  const details: string[] = [];
  const flags: string[] = [];

  // SHA-256 via Web Crypto
  let checksum = "";
  try {
    const digest = await crypto.subtle.digest("SHA-256", bytes as unknown as ArrayBuffer);
    checksum = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    checksum = "unavailable";
  }

  const ext = (/\.([a-zA-Z0-9]+)$/.exec(fileName)?.[1] ?? "").toLowerCase();
  const b0 = bytes[0];
  const b1 = bytes[1];
  const ascii = (start: number, length: number) =>
    Array.from(bytes.subarray(start, Math.min(bytes.length, start + length)), (b) =>
      String.fromCharCode(b)
    ).join("");

  let detectedType = "unknown";
  if (ascii(0, 4) === "%PDF") detectedType = "pdf";
  else if (b0 === 0x50 && b1 === 0x4b) detectedType = "zip-office";
  else if (b0 === 0xff && b1 === 0xd8) detectedType = "jpeg";
  else if (b0 === 0x89 && ascii(1, 3) === "PNG") detectedType = "png";
  else if (ascii(0, 3) === "GIF") detectedType = "gif";
  else if (b0 === 0x7f && ascii(1, 3) === "ELF") {
    detectedType = "executable (ELF)";
    flags.push("executable");
  } else if (b0 === 0x4d && b1 === 0x5a) {
    detectedType = "executable (Windows PE)";
    flags.push("executable");
  } else if (ascii(0, 5) === "<?xml" || ascii(0, 4) === "<svg") {
    detectedType = ext === "svg" ? "svg" : "xml";
    if (ext === "svg" || /<script/i.test(ascii(0, Math.min(bytes.length, 4096)))) {
      flags.push("active-content");
    }
  } else if (ascii(0, 5) === "EICAR") {
    detectedType = "eicar-test-signature";
    flags.push("eicar", "blocked-signature");
  } else {
    // text-ish?
    const sample = ascii(0, Math.min(bytes.length, 1024));
    const nulCount = (sample.match(/\u0000/g) ?? []).length;
    detectedType = nulCount > 8 ? "binary" : "text";
  }

  const declaredFamily = declaredMime.split("/")[0] ?? "";
  const detectedFamily =
    detectedType === "pdf"
      ? "application"
      : ["jpeg", "png", "gif"].includes(detectedType)
        ? "image"
        : detectedType === "zip-office"
          ? "application"
          : detectedType === "text"
            ? "text"
            : "other";
  const typeMatch =
    (declaredFamily === "image" && detectedFamily === "image") ||
    (declaredFamily === "text" && detectedFamily === "text") ||
    (declaredFamily === "application" && detectedFamily === "application") ||
    declaredMime === "" ||
    declaredMime === "application/octet-stream";
  if (!typeMatch) flags.push("mime-mismatch");

  // Office macro detection: look for vbaProject.bin inside the first KBs of a ZIP
  if (detectedType === "zip-office") {
    const head = ascii(0, Math.min(bytes.length, 65536));
    if (/vbaProject\.bin/i.test(head)) {
      flags.push("macro");
      details.push("Office macro project (vbaProject.bin) detected inside the document package.");
    }
  }
  if (flags.includes("executable")) {
    details.push("Executable content detected — blocked for safety.");
  }
  if (flags.includes("mime-mismatch")) {
    details.push(`Declared type "${declaredMime || "unknown"}" does not match the detected type "${detectedType}".`);
  }
  if (details.length === 0) {
    details.push(`File type confirmed as ${detectedType}; no dangerous content found.`);
  }

  const verdict = flags.includes("blocked-signature") || flags.includes("executable")
    ? "blocked"
    : flags.length
      ? "warning"
      : "clean";

  return {
    verdict,
    declaredMime,
    detectedType,
    typeMatch,
    flags,
    checksum,
    sizeBytes: bytes.length,
    scannedAt: nowIso(),
    details,
  };
}

function toFiledDTO(row: Record<string, unknown>): FiledDocumentDTO {
  return {
    id: String(row.id ?? uid()),
    title: String(row.title ?? ""),
    category: String(row.category ?? ""),
    fileName: String(row.fileName ?? ""),
    mimeType: String(row.mimeType ?? ""),
    size: Number(row.size ?? 0),
    note: String(row.note ?? ""),
    shareToken: String(row.shareToken ?? ""),
    scanVerdict: String(row.scanVerdict ?? "clean"),
    scanReport: (row.scanReport as FileScanReport | null) ?? null,
    createdAt: String(row.createdAt ?? nowIso()),
  };
}

export const localFilingApi = {
  verify: async (pin: string) => {
    await verifyPin("filingPin", pin);
    return { ok: true as const };
  },
  list: async () => {
    const rows = await readCollection<Record<string, unknown>>("filedDocuments", []);
    const documents = rows.map(toFiledDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { documents };
  },
  upload: async (file: File, meta: { title?: string; category?: string; note?: string } = {}) => {
    assertUploadSize(file);
    const bytes = new Uint8Array(await file.arrayBuffer());
    const scan = await scanUploadedFile({ bytes, declaredMime: file.type, fileName: file.name });
    if (scan.verdict === "blocked") {
      throw new Error(
        "This file was blocked by the security scanner (executable or dangerous content)."
      );
    }
    const rows = await readCollection<Record<string, unknown>>("filedDocuments", []);
    const row: Record<string, unknown> = {
      id: uid(),
      title: meta.title ?? file.name,
      category: meta.category ?? "",
      fileName: file.name,
      mimeType: file.type || "application/octet-stream",
      size: file.size,
      note: meta.note ?? "",
      shareToken: shareToken(),
      scanVerdict: scan.verdict,
      scanReport: scan,
      createdAt: nowIso(),
    };
    rows.push(row);
    await writeCollection("filedDocuments", rows.slice(-500));
    await saveFileBlob(row.id as string, file);
    return { document: toFiledDTO(row), scan };
  },
  remove: async (id: string) => {
    const rows = await readCollection<Record<string, unknown>>("filedDocuments", []);
    await writeCollection("filedDocuments", rows.filter((r) => r.id !== id));
    await deleteFileBlob(id);
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 14. Link attachment library                                         */
/* ------------------------------------------------------------------ */

function toLinkDTO(row: Record<string, unknown>): LinkItemDTO {
  return {
    id: String(row.id ?? uid()),
    title: String(row.title ?? ""),
    url: String(row.url ?? ""),
    category: String(row.category ?? "other"),
    description: String(row.description ?? ""),
    createdAt: String(row.createdAt ?? nowIso()),
  };
}

export const localLinksApi = {
  list: async (category?: string) => {
    let rows = await readCollection<Record<string, unknown>>("links", []);
    if (category) rows = rows.filter((r) => r.category === category);
    const links = rows.map(toLinkDTO).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { links };
  },
  create: async (
    data: { title: string; url: string; category?: string; description?: string },
    pin: string
  ) => {
    await verifyPin("settingsPin", pin);
    const rows = await readCollection<Record<string, unknown>>("links", []);
    const row: Record<string, unknown> = {
      id: uid(),
      title: data.title,
      url: data.url,
      category: data.category ?? "other",
      description: data.description ?? "",
      createdAt: nowIso(),
    };
    rows.push(row);
    await writeCollection("links", rows.slice(-300));
    return { link: toLinkDTO(row) };
  },
  update: async (
    id: string,
    data: { title?: string; url?: string; category?: string; description?: string },
    pin: string
  ) => {
    await verifyPin("settingsPin", pin);
    const rows = await readCollection<Record<string, unknown>>("links", []);
    const index = rows.findIndex((r) => r.id === id);
    if (index < 0) throw new Error("Link not found");
    rows[index] = { ...rows[index], ...data };
    await writeCollection("links", rows);
    return { link: toLinkDTO(rows[index]) };
  },
  remove: async (id: string, pin: string) => {
    await verifyPin("settingsPin", pin);
    const rows = await readCollection<Record<string, unknown>>("links", []);
    await writeCollection("links", rows.filter((r) => r.id !== id));
    return { ok: true as const };
  },
};

/* ------------------------------------------------------------------ */
/* 15. Quarterly deadline                                              */
/* ------------------------------------------------------------------ */

export const localDeadlineApi = {
  get: async (): Promise<DeadlineStateDTO> => {
    const settings = await getLocalSettings();
    if (!settings.deadline) {
      return { deadline: null, daysLeft: null, missing: [] };
    }
    const deadline = settings.deadline;
    const target = new Date(`${deadline.date}T23:59:59`);
    const daysLeft = Math.ceil((target.getTime() - Date.now()) / 86_400_000);
    const evaluations = await readCollection<Record<string, unknown>>("evaluations", []);
    const submitted = new Set(
      evaluations.filter((r) => r.quarter === deadline.quarter).map((r) => String(r.directorateKey))
    );
    const missing = DIRECTORATES.filter((d) => !submitted.has(d.key)).map((d) => ({
      key: d.key,
      short: d.short,
      name: d.nameEn,
    }));
    return { deadline, daysLeft, missing };
  },
  set: async (quarter: string, date: string, pin: string) => {
    await verifyPin("settingsPin", pin);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      throw new Error("ትክክለኛ ቀን ያስገቡ / Enter a valid date (YYYY-MM-DD)");
    }
    await saveLocalSettings({ deadline: { quarter, date } });
    return { deadline: { quarter, date } };
  },
  clear: async (pin: string) => {
    await verifyPin("settingsPin", pin);
    await saveLocalSettings({ deadline: null });
    return { ok: true as const };
  },
  remindNow: async (pin: string) => {
    await verifyPin("settingsPin", pin);
    const state = await localDeadlineApi.get();
    if (!state.deadline) throw new Error("No deadline is configured yet");
    if (state.missing.length === 0) {
      return { deliveries: [] as DeliveryLogDTO[] };
    }
    const dayWord =
      (state.daysLeft ?? 0) > 0
        ? `${state.daysLeft} ቀናዎች / ${state.daysLeft} day(s) left`
        : "ዛሬ ይውዳል / due today";
    const message = [
      "📅 Direc-Score — የሩብ ዓመት ሪፖርት አስታዋሻ / Quarterly report reminder",
      `ሩብ ዓመት / Quarter: ${state.deadline.quarter}`,
      `መጨረሻ ቀን / Deadline: ${state.deadline.date} (${dayWord})`,
      "",
      "እስካሁን ያልገቡ ዳይሬክቶሬቶች / Not yet submitted:",
      ...state.missing.map((d) => `• ${d.name} (${d.short})`),
      "",
      "እባክዎ ከመጨረሻ ቀን በፊት በዳይሬክቶሬት ፖርታልዎ ሪፖርትዎን ያስገቡ።",
      "Please submit your report through your directorate portal before the deadline.",
    ].join("\n");
    const delivery = await deliverThroughBrowserChannels(message, {
      quarter: state.deadline.quarter,
    });
    return { deliveries: delivery.logs, _handoffs: delivery.handoffs };
  },
};

/* ------------------------------------------------------------------ */
/* 16. Directorate contacts (one-go sending)                           */
/* ------------------------------------------------------------------ */

function toContactDTO(row: Record<string, unknown>): ContactDTO {
  return {
    id: String(row.id ?? uid()),
    directorateKey: String(row.directorateKey ?? ""),
    directorateName: String(row.directorateName ?? ""),
    directorateShort: String(row.directorateShort ?? ""),
    email: String(row.email ?? ""),
    whatsapp: String(row.whatsapp ?? ""),
    telegram: String(row.telegram ?? ""),
    createdAt: String(row.createdAt ?? nowIso()),
    updatedAt: String(row.updatedAt ?? row.createdAt ?? nowIso()),
  };
}

export const localContactsApi = {
  list: async () => {
    const rows = await readCollection<Record<string, unknown>>("contacts", []);
    const contacts = rows.map(toContactDTO).sort((a, b) => a.directorateKey.localeCompare(b.directorateKey));
    return { contacts };
  },
  save: async (
    data: { directorateKey: string; email?: string; whatsapp?: string; telegram?: string },
    pin: string
  ) => {
    await verifyPin("settingsPin", pin);
    const rows = await readCollection<Record<string, unknown>>("contacts", []);
    const directorate = DIRECTORATES.find((d) => d.key === data.directorateKey);
    const existingIndex = rows.findIndex((r) => r.directorateKey === data.directorateKey);
    const row: Record<string, unknown> = {
      id: existingIndex >= 0 ? String(rows[existingIndex].id) : uid(),
      directorateKey: data.directorateKey,
      directorateName: directorate?.nameEn ?? data.directorateKey,
      directorateShort: directorate?.short ?? data.directorateKey,
      email: data.email ?? "",
      whatsapp: data.whatsapp ?? "",
      telegram: data.telegram ?? "",
      createdAt: existingIndex >= 0 ? String(rows[existingIndex].createdAt) : nowIso(),
      updatedAt: nowIso(),
    };
    if (existingIndex >= 0) rows[existingIndex] = row;
    else rows.push(row);
    await writeCollection("contacts", rows);
    return { contact: toContactDTO(row) };
  },
  remove: async (directorateKey: string, pin: string) => {
    await verifyPin("settingsPin", pin);
    const rows = await readCollection<Record<string, unknown>>("contacts", []);
    await writeCollection("contacts", rows.filter((r) => r.directorateKey !== directorateKey));
    return { ok: true as const };
  },
  sendAll: async (data: {
    mode: "scores" | "reminder";
    quarter?: string;
    directorateKeys?: string[];
  }): Promise<ContactSendAllDTO> => {
    const contacts = (await readCollection<Record<string, unknown>>("contacts", [])).map(toContactDTO);
    const adminChannels = await getChannels();
    const quarter = data.quarter ?? "";
    const results: ContactSendResultDTO[] = [];

    if (data.mode === "reminder") {
      const state = await localDeadlineApi.get();
      const targets = data.directorateKeys?.length
        ? DIRECTORATES.filter((d) => data.directorateKeys!.includes(d.key))
        : DIRECTORATES;
      for (const directorate of targets) {
        const contact = contacts.find((c) => c.directorateKey === directorate.key);
        const message = [
          "📅 Direc-Score — የሪፖርት አስታዋሻ / Submission reminder",
          `ዳይሬክቶሬ: ${directorate.nameEn} (${directorate.short})`,
          state.deadline
            ? `መጨረሻ ቀን / Deadline: ${state.deadline.quarter} — ${state.deadline.date}`
            : "Please submit your quarterly report.",
          "",
          "እባክዎ በፖርታልዎ ሪፖርትዎን ያስገቡ / Please submit through your portal.",
        ].join("\n");
        const logs: DeliveryLogDTO[] = [];
        if (contact) {
          const delivery = await deliverThroughBrowserChannels(
            message,
            { directorateKey: directorate.key, directorateName: directorate.nameEn, quarter },
            {
              channels: [
                ...(contact.telegram
                  ? [{ ...adminChannels.find((c) => c.type === "telegram")!, target: contact.telegram }]
                  : []),
                ...(contact.whatsapp
                  ? [{ ...adminChannels.find((c) => c.type === "whatsapp")!, target: contact.whatsapp }]
                  : []),
                ...(contact.email
                  ? [{ ...adminChannels.find((c) => c.type === "email")!, target: contact.email }]
                  : []),
              ].filter((c): c is LocalChannel => Boolean(c)),
            }
          );
          logs.push(...delivery.logs);
        } else {
          const delivery = await deliverThroughBrowserChannels(message, {
            directorateKey: directorate.key,
            directorateName: directorate.nameEn,
            quarter,
          });
          logs.push(...delivery.logs);
        }
        results.push({
          directorateKey: directorate.key,
          directorateName: directorate.nameEn,
          directorateShort: directorate.short,
          contactSaved: Boolean(contact),
          channels: [...new Set(logs.map((l) => l.channelType))],
          logs,
        });
      }
      return { mode: "reminder", quarter, results };
    }

    // scores mode — the latest evaluation per directorate (optionally per quarter)
    const evaluations = (await readCollection<Record<string, unknown>>("evaluations", []))
      .map(toEvaluationDTO)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const latestByKey = new Map<string, EvaluationDTO>();
    for (const e of evaluations) {
      if (quarter && e.quarter !== quarter) continue;
      latestByKey.set(e.directorateKey, e);
    }
    const keys = data.directorateKeys?.length
      ? data.directorateKeys
      : [...latestByKey.keys()];
    for (const key of keys) {
      const evaluation = latestByKey.get(key);
      const directorate = DIRECTORATES.find((d) => d.key === key);
      const contact = contacts.find((c) => c.directorateKey === key);
      if (!evaluation) {
        results.push({
          directorateKey: key,
          directorateName: directorate?.nameEn ?? key,
          directorateShort: directorate?.short ?? key,
          contactSaved: Boolean(contact),
          channels: [],
          logs: [],
        });
        continue;
      }
      const message = buildScoreMessage(evaluation);
      const logs: DeliveryLogDTO[] = [];
      if (contact) {
        const delivery = await deliverThroughBrowserChannels(
          message,
          { directorateKey: key, directorateName: evaluation.directorateName, quarter: evaluation.quarter },
          {
            channels: [
              ...(contact.telegram
                ? [{ ...adminChannels.find((c) => c.type === "telegram")!, target: contact.telegram }]
                : []),
              ...(contact.whatsapp
                ? [{ ...adminChannels.find((c) => c.type === "whatsapp")!, target: contact.whatsapp }]
                : []),
              ...(contact.email
                ? [{ ...adminChannels.find((c) => c.type === "email")!, target: contact.email }]
                : []),
            ].filter((c): c is LocalChannel => Boolean(c)),
          }
        );
        logs.push(...delivery.logs);
      } else {
        const delivery = await deliverThroughBrowserChannels(message, {
          directorateKey: key,
          directorateName: evaluation.directorateName,
          quarter: evaluation.quarter,
        });
        logs.push(...delivery.logs);
      }
      results.push({
        directorateKey: key,
        directorateName: evaluation.directorateName,
        directorateShort: evaluation.directorateShort,
        contactSaved: Boolean(contact),
        channels: [...new Set(logs.map((l) => l.channelType))],
        logs,
      });
    }
    return { mode: "scores", quarter, results };
  },
};

/* ------------------------------------------------------------------ */
/* WhatsApp deep-link helper reused by portal hand-off buttons         */
/* ------------------------------------------------------------------ */

export function localWaMeLink(target: string, message: string): string {
  return buildWaMeLink(target, message);
}

export const LOCAL_MODE_NOTICE = OFFLINE_MARKER;
