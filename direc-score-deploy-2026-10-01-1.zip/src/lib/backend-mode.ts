"use client";

/**
 * Backend capability detection.
 *
 * The app runs in two modes, decided automatically at runtime:
 *
 *  - "server" — a real Node server with a writable SQLite database is
 *    reachable (sandbox preview, Railway/Render/Fly/VPS deployments).
 *    All data APIs hit the server; data is shared between every device.
 *
 *  - "local" — the server either is unreachable or cannot persist writes
 *    (Netlify/Vercel serverless: read-only filesystem, no SQLite). Every
 *    data operation is performed by the browser data engine
 *    (local-db.ts) so the application remains FULLY functional.
 *
 * Detection runs once per browser session: a cheap POST /api/system/health
 * probe asks the server to write one row. Any failure → local mode.
 * NEXT_PUBLIC_FORCE_LOCAL_DATA=1 forces local mode (used to test the exact
 * Netlify behavior during development).
 */

export type BackendMode = "server" | "local";

const MODE_KEY = "direcscore:backendMode";

let modePromise: Promise<BackendMode> | null = null;

function forcedLocal(): boolean {
  try {
    return Boolean(process.env.NEXT_PUBLIC_FORCE_LOCAL_DATA);
  } catch {
    return false;
  }
}

function cachedMode(): BackendMode | null {
  try {
    const value = window.sessionStorage.getItem(MODE_KEY);
    return value === "server" || value === "local" ? value : null;
  } catch {
    return null;
  }
}

async function probeServer(): Promise<BackendMode> {
  if (forcedLocal()) return "local";
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch("/api/system/health", {
      method: "POST",
      credentials: "same-origin",
      signal: controller.signal,
    });
    clearTimeout(timer);
    const json = (await res.json().catch(() => null)) as { ok?: boolean } | null;
    return res.ok && json?.ok ? "server" : "local";
  } catch {
    return "local";
  }
}

/** Resolve (and cache for the session) which backend the app should use */
export function resolveBackendMode(): Promise<BackendMode> {
  if (!modePromise) {
    const cached = cachedMode();
    modePromise = cached
      ? Promise.resolve(cached)
      : probeServer().then((mode) => {
          try {
            window.sessionStorage.setItem(MODE_KEY, mode);
          } catch {
            /* private mode — memory cache still works */
          }
          return mode;
        });
  }
  return modePromise;
}

/** Synchronous read of an already-resolved mode (null before the first probe) */
export function peekBackendMode(): BackendMode | null {
  return cachedMode();
}

/** Forget the cached decision (used by the Settings storage card to re-detect) */
export function resetBackendMode(): void {
  modePromise = null;
  try {
    window.sessionStorage.removeItem(MODE_KEY);
  } catch {
    /* ignore */
  }
}
