import { NextResponse } from "next/server";
import { DEFAULT_SETTINGS_PIN, getSetting, SETTING_KEYS } from "@/lib/settings-store";
import { clearFailures, clientIp, recordFailure, throttleFailure } from "@/lib/filing-guard";

/**
 * Guard helpers for the Settings page.
 * The Settings page (appearance, logo, Google Drive backup, organization
 * name, security passwords, …) is protected by a password (default 3472,
 * configurable via the `settingsPin` app setting). Every mutating settings
 * request must carry it in the `x-settings-pin` header:
 *   - PUT  /api/settings
 *   - POST/DELETE /api/settings/logo
 * Reading (GET /api/settings, GET /api/settings/logo) stays open so the
 * header branding (logo / org name) works on every public page.
 */

/** Resolve the current settings password (configurable; defaults to 3472) */
export async function getSettingsPin(): Promise<string> {
  const stored = await getSetting(SETTING_KEYS.settingsPin);
  return stored || DEFAULT_SETTINGS_PIN;
}

/**
 * Returns a 401 response when the request does not carry the correct
 * password (with per-IP brute-force throttling), or null when the caller
 * may proceed.
 */
export async function requireSettingsPin(req: Request): Promise<NextResponse | null> {
  const ip = clientIp(req);
  const throttled = throttleFailure(ip);
  if (throttled) return throttled;

  const provided = req.headers.get("x-settings-pin")?.trim() ?? "";
  const expected = await getSettingsPin();
  if (!provided || provided !== expected) {
    recordFailure(ip);
    return NextResponse.json(
      { error: "ትክክለኛ የይለፍ ቃል ያስፈልጋል / Incorrect settings password" },
      { status: 401 }
    );
  }
  clearFailures(ip);
  return null;
}
