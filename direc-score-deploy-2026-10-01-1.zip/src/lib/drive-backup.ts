import {
  SETTING_KEYS,
  getSettings,
  setSetting,
} from "@/lib/settings-store";

/**
 * Google Drive JSON backup — exports the full application state as a JSON
 * snapshot and uploads it to the user's Google Drive via the Drive REST API
 * (OAuth2 refresh-token flow, configured in Settings).
 */

export interface DriveConfig {
  clientId: string;
  clientSecret: string;
  refreshToken: string;
  folderId: string;
}

export function isDriveConfigured(config: DriveConfig): boolean {
  return Boolean(config.clientId && config.clientSecret && config.refreshToken);
}

export async function loadDriveConfig(): Promise<DriveConfig> {
  const s = await getSettings([
    SETTING_KEYS.driveClientId,
    SETTING_KEYS.driveClientSecret,
    SETTING_KEYS.driveRefreshToken,
    SETTING_KEYS.driveFolderId,
  ]);
  return {
    clientId: s[SETTING_KEYS.driveClientId] ?? "",
    clientSecret: s[SETTING_KEYS.driveClientSecret] ?? "",
    refreshToken: s[SETTING_KEYS.driveRefreshToken] ?? "",
    folderId: s[SETTING_KEYS.driveFolderId] ?? "",
  };
}

async function getAccessToken(config: DriveConfig): Promise<string> {
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: config.clientId,
      client_secret: config.clientSecret,
      refresh_token: config.refreshToken,
      grant_type: "refresh_token",
    }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Google OAuth failed (${res.status}): ${text.slice(0, 300)}`);
  }
  const json = (await res.json()) as { access_token?: string };
  if (!json.access_token) throw new Error("Google OAuth returned no access token");
  return json.access_token;
}

/** Build the full JSON backup snapshot of the application */
export async function buildBackupSnapshot(): Promise<{ json: string; counts: Record<string, number> }> {
  const { db } = await import("@/lib/db");

  const [evaluations, documents, notifications, channels, logs, qualityReports, settings, feedback] =
    await Promise.all([
      db.directorateEvaluation.findMany({ orderBy: { createdAt: "asc" } }),
      db.documentHistory.findMany({ orderBy: { createdAt: "asc" } }),
      db.notification.findMany({ orderBy: { createdAt: "asc" } }),
      db.automationChannel.findMany({ orderBy: { createdAt: "asc" } }),
      db.deliveryLog.findMany({ orderBy: { createdAt: "desc" }, take: 500 }),
      db.qualityReport.findMany({
        orderBy: { createdAt: "asc" },
        select: {
          id: true,
          directorateKey: true,
          quarter: true,
          title: true,
          fileName: true,
          mimeType: true,
          size: true,
          note: true,
          shareToken: true,
          createdAt: true,
        },
      }),
      db.appSetting.findMany(),
      db.directorateFeedback.findMany({ orderBy: { createdAt: "asc" } }),
    ]);

  // Redact secrets — the backup must never leak bot tokens / OAuth credentials
  const safeSettings: Record<string, string> = {};
  const SECRET_KEYS = new Set<string>([
    SETTING_KEYS.driveClientSecret,
    SETTING_KEYS.driveRefreshToken,
  ]);
  for (const row of settings) {
    safeSettings[row.key] = SECRET_KEYS.has(row.key) ? "" : row.value;
  }
  const safeChannels = channels.map((c) => ({ ...c, botToken: "" }));

  const snapshot = {
    app: "Direc-Score — Harari Region Health Bureau",
    schemaVersion: 3,
    exportedAt: new Date().toISOString(),
    counts: {
      evaluations: evaluations.length,
      documents: documents.length,
      notifications: notifications.length,
      channels: channels.length,
      deliveryLogs: logs.length,
      qualityReports: qualityReports.length,
      feedback: feedback.length,
    },
    evaluations,
    documents,
    notifications,
    channels: safeChannels,
    deliveryLogs: logs,
    qualityReports, // metadata only (file contents excluded to keep the backup light)
    feedback,
    settings: safeSettings,
  };

  // Dates/BigInt-free models serialize cleanly with JSON.stringify
  const json = JSON.stringify(snapshot, null, 2);
  return { json, counts: snapshot.counts };
}

export interface DriveUploadResult {
  ok: boolean;
  fileId?: string;
  webViewLink?: string;
  fileName: string;
  sizeBytes: number;
  error?: string;
}

/** Upload a JSON string to Google Drive (multipart upload) */
export async function uploadJsonToDrive(
  config: DriveConfig,
  json: string,
  fileName: string
): Promise<DriveUploadResult> {
  const sizeBytes = Buffer.byteLength(json, "utf8");
  try {
    const accessToken = await getAccessToken(config);

    const metadata: Record<string, unknown> = {
      name: fileName,
      mimeType: "application/json",
    };
    if (config.folderId) metadata.parents = [config.folderId];

    const boundary = `direcscore-${Date.now()}-boundary`;
    const multipartBody =
      `--${boundary}\r\n` +
      `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
      `${JSON.stringify(metadata)}\r\n` +
      `--${boundary}\r\n` +
      `Content-Type: application/json\r\n\r\n` +
      `${json}\r\n` +
      `--${boundary}--`;

    const res = await fetch(
      "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": `multipart/related; boundary=${boundary}`,
        },
        body: multipartBody,
        signal: AbortSignal.timeout(60_000),
      }
    );

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return {
        ok: false,
        fileName,
        sizeBytes,
        error: `Drive upload failed (${res.status}): ${text.slice(0, 300)}`,
      };
    }

    const file = (await res.json()) as { id: string };
    return {
      ok: true,
      fileId: file.id,
      webViewLink: `https://drive.google.com/file/d/${file.id}/view`,
      fileName,
      sizeBytes,
    };
  } catch (err) {
    return {
      ok: false,
      fileName,
      sizeBytes,
      error: err instanceof Error ? err.message : "Unknown Drive upload error",
    };
  }
}

/** Run the full backup cycle: snapshot → upload → persist status */
export async function runBackup(): Promise<{
  result: DriveUploadResult;
  counts: Record<string, number>;
}> {
  const config = await loadDriveConfig();
  const { json, counts } = await buildBackupSnapshot();
  const stamp = new Date().toISOString().slice(0, 10);
  const fileName = `direc-score-backup-${stamp}.json`;
  const result = await uploadJsonToDrive(config, json, fileName);
  return { result, counts };
}

export async function recordBackupOutcome(result: DriveUploadResult): Promise<void> {
  await setSetting(SETTING_KEYS.lastBackupAt, new Date().toISOString());
  await setSetting(SETTING_KEYS.lastBackupStatus, result.ok ? "success" : "failed");
  await setSetting(
    SETTING_KEYS.lastBackupDetail,
    result.ok
      ? `Uploaded ${fileNameOf(result)} (${Math.max(1, Math.round(result.sizeBytes / 1024))} KB)${result.fileId ? " · file " + result.fileId : ""}`
      : (result.error ?? "Unknown error").slice(0, 500)
  );
}

function fileNameOf(result: DriveUploadResult): string {
  return result.fileName || "backup.json";
}
