/**
 * Evaluation rubric — Harari Region Health Bureau
 * Directorate Quarterly Action-Plan Report Evaluation
 * Extracted 1:1 from the original Direc-Score application.
 */

export interface Directorate {
  key: string;
  short: string;
  name: string;
  nameEn: string;
}

export const DIRECTORATES: Directorate[] = [
  { key: "HPDP", short: "HPDP", name: "ጤና ማበልፀግና በሽ/መከ ዳ", nameEn: "Health Promotion & Disease Prevention" },
  { key: "MSD", short: "MSD", name: "ሕክ/አገ/አሰጣጥ ዳ", nameEn: "Medical Service Delivery" },
  { key: "REGU", short: "Regu.", name: "ጤናና ጤና ነክ ግብዓትና አገ/ ቁ/ዳ", nameEn: "Regulatory" },
  { key: "PME", short: "P,M&E", name: "እቅድ ክትትል እና ግምገማ", nameEn: "Planning, M&E" },
  { key: "FINANCE", short: "Finance", name: "ግዢ/ፋ/ን/አስ ደጋፊ ዳ", nameEn: "Finance" },
  { key: "HR", short: "HR", name: "ሰው ሀብት አስ/ደጋፊ ዳ", nameEn: "Human Resource" },
  { key: "AUDIT", short: "Audit", name: "ውስጥ ኦዲት ደጋፊ ዳ", nameEn: "Internal Audit" },
  { key: "LEGAL", short: "Legal", name: "ህግ አገልግሎት ፈጻሚ ዳ", nameEn: "Legal Service" },
  { key: "PR", short: "PR", name: "ሕዝብ ግንኙነት ዳይ", nameEn: "Public Relations" },
  { key: "GENDER", short: "Gender", name: "ሴቶች ወጣ/ህፃ/ጉዳይ ዳ", nameEn: "Gender" },
  { key: "GG", short: "GG", name: "መልካም አሰተዳደር ዳ", nameEn: "Good Governance" },
  { key: "PHEM", short: "PHEM", name: "ህ/ጤ/ላ/ም/ድ/አ/ቁጥ/ዳይ", nameEn: "PHEM" },
  { key: "HHSC", short: "HHSC", name: "Health Science College", nameEn: "Health Science College" },
  { key: "HHAPCO", short: "HHAPCO", name: "HIV AIDS", nameEn: "HIV/AIDS (HAPCO)" },
];

export interface SubQuestion {
  id: string;
  label: string;
  labelEn: string;
  points: number;
}

export interface Criterion {
  key: string;
  name: string;
  nameEn: string;
  maxScore: number;
  subQuestions: SubQuestion[];
}

export const CRITERIA: Criterion[] = [
  {
    key: "A", name: "ሪፖረት ወቅታዊንት", nameEn: "Report Timeliness and Completeness", maxScore: 10,
    subQuestions: [
      { id: "A1", label: "ሪፖርቱ በተፈለገው የጊዜ ገደብ ውስጥ ገብቷል", labelEn: "Report submitted within deadline", points: 5 },
      { id: "A2", label: "የታዘዘውን ወይም ሙያዊ ፎርማትን አሟልቷል/ይከተላል", labelEn: "Follows required professional format", points: 5 },
    ],
  },
  {
    key: "B", name: "የሽፋን ገጽ እና መሰረታዊ መረጃ", nameEn: "Cover Page and Basic Information", maxScore: 10,
    subQuestions: [
      { id: "B1", label: "ርዕሱ ግልጽ እና ገላጭ ነው", labelEn: "Title is clear and descriptive", points: 2 },
      { id: "B2", label: "የሪፖርት ማቅረቢያ ጊዜ በግልፅ ተቀምጧል", labelEn: "Reporting period clearly stated", points: 2 },
      { id: "B3", label: "ተጠያቂው ክፍል(ዎች) ተለይተው ይታወቃሉ", labelEn: "Responsible units identified", points: 2 },
      { id: "B4", label: "ለፊርማዎች ወይም ለማጽደቅ ማህተሞች", labelEn: "Signatures or approval stamps", points: 2 },
      { id: "B5", label: "የሪፖረቱ ማውጫ የቢሮውን የሪፖርት ማድረጊያ ፎርማት ይከተላል", labelEn: "Table of content follows bureau format", points: 2 },
    ],
  },
  {
    key: "C", name: "ከስልታዊ ግቦች ጋር መጣጣም", nameEn: "Alignment with Strategic Goals", maxScore: 12,
    subQuestions: [
      { id: "C1", label: "የድርጊት መርሃ ግብሩ ከቢሮው አመታዊ ግቦች ወይም ስልታዊ አላማዎች ጋር ይጣጣማል", labelEn: "Action plan aligns with annual goals", points: 6 },
      { id: "C2", label: "በሩብ ዓመቱ ቅድሚያ የሚሰጣቸው ተግባራት በግልጽ ተለይተዋል", labelEn: "Quarterly priorities clearly identified", points: 6 },
    ],
  },
  {
    key: "D", name: "የታቀዱ ተግባራት", nameEn: "Planned Activities", maxScore: 15,
    subQuestions: [
      { id: "D1", label: "ሊለኩ የሚችሉ ኢላማዎች ተለይተዋል", labelEn: "Measurable targets identified", points: 3 },
      { id: "D2", label: "አፈፃፀም ከዒላማ አንፃር በእቅድ ተቀምጧል", labelEn: "Performance against targets planned", points: 3 },
      { id: "D3", label: "የታቀዱ ተግባራት በግልፅ ተብራርተው ተዘርዝረዋል", labelEn: "Planned activities clearly described", points: 3 },
      { id: "D4", label: "ያልተሰሩ ኢላማዎች ያልተሰሩበትን ምክንያት ተቀምጧል", labelEn: "Reasons for unmet targets stated", points: 3 },
      { id: "D5", label: "ለእያንዳንዱ ተግባር ኃላፊነት ያለው ሰው/ክፍል በግልፅ ተጠቅሷል", labelEn: "Responsible person/unit clearly cited", points: 3 },
    ],
  },
  {
    key: "E", name: "ክትትል እና ግምገማ", nameEn: "Monitoring and Evaluation", maxScore: 12,
    subQuestions: [
      { id: "E1", label: "የአፈጻጸም አመልካቾች በግልጽ የተቀመጡ እና ጠቃሚ ናቸው", labelEn: "Performance indicators clearly set", points: 4 },
      { id: "E2", label: "ሂደትን ለመከታተል የሚረዱ ዘዴዎች/መሳሪያዎች ተገልጸዋል", labelEn: "Monitoring tools/methods described", points: 4 },
      { id: "E3", label: "ተጨባጭ ውጤቶች ከታቀዱ ግቦች ጋር ይነጻጸራሉ", labelEn: "Actual results compared against targets", points: 4 },
    ],
  },
  {
    key: "F", name: "ግስጋሴዎች እና ስኬቶች", nameEn: "Progress and Achievements", maxScore: 10,
    subQuestions: [
      { id: "F1", label: "ተግባራት እንደተጠናቀቁ፣ በመካሄድ ላይ ያሉ ወይም የዘገዩ ተብለው ተመድበዋል", labelEn: "Activities categorized by status", points: 3 },
      { id: "F2", label: "ለተጠናቀቁ ተግባራት የተወሰኑ ውጤቶች ተገኝተዋል", labelEn: "Specific outputs achieved for completed activities", points: 4 },
      { id: "F3", label: "ለዕድገት ተግዳሮቶች ወይም እንቅፋቶች በግልጽ ተለይተዋል", labelEn: "Challenges clearly identified", points: 3 },
    ],
  },
  {
    key: "G", name: "የበጀት እና የንብረት አጠቃቀም", nameEn: "Budget and Resource Utilization", maxScore: 10,
    subQuestions: [
      { id: "G1", label: "ለእያንዳንዱ የታቀደ ተግባር በጀት አለ", labelEn: "Budget allocated per activity", points: 4 },
      { id: "G2", label: "ወጪዎች ከተመደበው በጀት ጋር ሲነፃፀሩ ክትትል ይደረግባቸዋል", labelEn: "Expenditure tracking against budget", points: 3 },
      { id: "G3", label: "የበጀት ልዩነቶች በዝርዝር ተብራርተዋል", labelEn: "Budget variances explained in detail", points: 3 },
    ],
  },
  {
    key: "H", name: "ያጋጠሙ ተግዳሮቶች እና የተገኙ ልምዶች", nameEn: "Challenges and Lessons Learned", maxScore: 7,
    subQuestions: [
      { id: "H1", label: "በሩብ ዓመቱ ቁልፍ ተግዳሮቶች ተመዝግበዋል", labelEn: "Key challenges documented", points: 3 },
      { id: "H2", label: "የወደፊት እቅድን ለማሳወቅ የተማሩ ትምህርቶች ተዘርዝረዋል", labelEn: "Lessons learned listed", points: 4 },
    ],
  },
  {
    key: "I", name: "ምክረ-ሃሳቦች እና ቀጣይ እርምጃዎች", nameEn: "Recommendations and Next Steps", maxScore: 6,
    subQuestions: [
      { id: "I1", label: "ፈተናዎችን ለማሸነፍ ተግባራዊ መፍትሔዎች ተሰጥተዋል", labelEn: "Actionable recommendations provided", points: 3 },
      { id: "I2", label: "ለቀጣዩ ሩብ አመት ቀጣይ እርምጃዎች ግልጽ ናቸው", labelEn: "Follow-up actions clear for next quarter", points: 3 },
    ],
  },
  {
    key: "J", name: "ዓባሪዎች እና ደጋፊ ሰነዶች", nameEn: "Attachments and Supporting Documents", maxScore: 8,
    subQuestions: [
      { id: "J1", label: "ረዳት ሰነዶች ቀርበዋል (ፎቶዎች፡ ገበታዎች፡ ዝርዝር በጀት)", labelEn: "Supporting documents provided", points: 4 },
      { id: "J2", label: "አስፈላጊ ከሆነ ማጣቀሻዎች ወይም ምንጮች ተጠቅሰዋል", labelEn: "References or sources cited", points: 4 },
    ],
  },
];

export const TOTAL_MAX_SCORE = 100;

/** Answers map: sub-question id -> "yes" | "no" */
export type Answers = Record<string, string>;
/** Comments map: criterion key -> comment text */
export type Comments = Record<string, string>;
/** Scores map: criterion key -> awarded points */
export type Scores = Record<string, number>;

export type ActionPlanStatus = "planned" | "in_progress" | "done";

export interface ActionPlanItem {
  id: string;
  /** The goal or corrective step identified during the quarterly review */
  text: string;
  done?: boolean;
  /** Person or unit responsible for executing the step */
  owner?: string;
  /** Target completion date (YYYY-MM-DD or free text) */
  deadline?: string;
  /** planned | in_progress | done */
  status?: ActionPlanStatus | string;
}

export const ACTION_PLAN_STATUS_LABELS: Record<string, string> = {
  planned: "በመታቀድ ላይ / Planned",
  in_progress: "በሂደት ላይ / In Progress",
  done: "ተጠናቋል / Done",
};

/** Compute per-criterion scores and total from yes/no answers */
export function computeScores(answers: Answers | null | undefined): { scores: Scores; totalScore: number } {
  const scores: Scores = {};
  let total = 0;
  CRITERIA.forEach((c) => {
    let sum = 0;
    c.subQuestions.forEach((q) => {
      if (answers && answers[q.id] === "yes") sum += q.points;
    });
    scores[c.key] = sum;
    total += sum;
  });
  return { scores, totalScore: total };
}

export function getCriterionMax(): number {
  return CRITERIA.reduce((acc, c) => acc + c.maxScore, 0);
}

export function getDirectorate(key: string | null | undefined): Directorate | undefined {
  if (!key) return undefined;
  return DIRECTORATES.find((d) => d.key === key);
}

export function scorePercent(score: number, max: number = TOTAL_MAX_SCORE): number {
  if (max <= 0) return 0;
  return Math.round((score / max) * 100);
}

export function performanceLabel(percent: number): { am: string; en: string; className: string; barClass: string } {
  if (percent >= 75)
    return { am: "ጥሩ", en: "Good", className: "bg-emerald-100 text-emerald-700", barClass: "bg-emerald-500" };
  if (percent >= 50)
    return { am: "መካከለኛ", en: "Average", className: "bg-amber-100 text-amber-700", barClass: "bg-amber-400" };
  return { am: "ደካማ", en: "Poor", className: "bg-red-100 text-red-600", barClass: "bg-red-500" };
}

export const DEFAULT_QUARTER = "Q3-2018EFY";

export const QUARTER_OPTIONS = [
  "Q1-2017EFY", "Q2-2017EFY", "Q3-2017EFY", "Q4-2017EFY",
  "Q1-2018EFY", "Q2-2018EFY", "Q3-2018EFY", "Q4-2018EFY",
];

/** Output language for AI-generated evaluation comments */
export type EvaluationLanguage = "english" | "amharic" | "bilingual";

const LANGUAGE_INSTRUCTIONS: Record<EvaluationLanguage, string> = {
  english:
    "OUTPUT LANGUAGE: Write every comment in clear, professional English.",
  amharic:
    "OUTPUT LANGUAGE: Write every comment in clear, professional Amharic (አማርኛ) using the Ge'ez (Ethiopic) script.",
  bilingual:
    "OUTPUT LANGUAGE: Write every comment twice — first in clear professional Amharic (አማርኛ), then in English — separated by \" / \".",
};

/**
 * Build the prompt for the meta-evaluation — a supervising AI audits the
 * AI evaluator's own answers and comments against the report evidence and
 * grades how trustworthy the automated evaluation is.
 */
export function buildEvaluatorAuditPrompt(
  directorateName: string,
  quarter: string,
  answers: Answers,
  comments: Comments,
  totalScore: number,
  content: string,
  language: EvaluationLanguage = "english"
): string {
  const rubricText = CRITERIA.map((c) => {
    const subs = c.subQuestions
      .map((s) => `  - ${s.id}: "${s.labelEn}" [${s.points} pts]`)
      .join("\n");
    return `Category ${c.key}: ${c.nameEn} (max ${c.maxScore} pts)\n${subs}`;
  }).join("\n\n");

  const aiAnswers = CRITERIA.flatMap((c) =>
    c.subQuestions.map((q) => `${q.id}: ${answers[q.id] === "yes" ? "yes" : "no"}`)
  ).join(", ");

  const aiComments = CRITERIA.map(
    (c) => `${c.key}: ${comments[c.key] || "(no comment written)"}`
  ).join("\n");

  return `You are a QUALITY ASSURANCE SUPERVISOR at the Harari Region Health Bureau. An AI evaluator just assessed the quarterly report of the "${directorateName}" directorate for quarter "${quarter}". Your job is to EVALUATE THE AI EVALUATOR — re-check its work independently and grade how trustworthy it is.

The report content may be written in Amharic (አማርኛ) or in English — you fully understand both languages. Always judge against the report's actual content.

EVALUATION RUBRIC (what the AI evaluator was supposed to check):
${rubricText}

THE AI EVALUATOR'S ANSWERS (yes/no per sub-question):
${aiAnswers}

THE AI EVALUATOR'S COMMENTS (one per category):
${aiComments}

TOTAL SCORE THE AI EVALUATOR AWARDED: ${totalScore}/100

REPORT CONTENT (the evidence you must verify against):
${content.slice(0, 14000)}

AUDIT TASK — evaluate the AI evaluator on four dimensions:
1. ACCURACY — independently re-check the report evidence for every sub-question and flag EVERY yes/no answer you disagree with, citing report evidence in "reason".
2. EVIDENCE — are the AI's comments grounded in the actual report (no invented facts, no generic filler)?
3. CONSISTENCY — do the answers and comments contradict each other anywhere?
4. COMPLETENESS — were all questions answered and all categories commented on?

Grade "qualityScore" 0-100 for the AI evaluator's overall reliability: 90-100 excellent (trust as-is), 75-89 good (minor fixes), 50-74 needs review (check flagged answers), below 50 unreliable (the evaluation should be redone).

${LANGUAGE_INSTRUCTIONS[language] ?? LANGUAGE_INSTRUCTIONS.english} — apply this to "summary", "reason", "strengths" and "improvements". Keep "questionId" and "suggestedAnswer" machine-readable.

Respond ONLY with a valid JSON object in this exact format:
{
  "qualityScore": <0-100 integer>,
  "summary": "<2-3 sentence overall judgement of the AI evaluator's work>",
  "disagreements": [
    { "questionId": "A1", "severity": "high|medium|low", "reason": "<why you disagree, citing report evidence>", "suggestedAnswer": "yes|no" }
  ],
  "strengths": ["<what the AI evaluator did well>"],
  "improvements": ["<concrete advice that would make the AI evaluation better>"]
}`;
}

/** Build the AI evaluation prompt (mirrors the original app) */
export function buildEvaluationPrompt(
  directorateName: string,
  quarter: string,
  content: string,
  language: EvaluationLanguage = "english"
): string {
  const rubricText = CRITERIA.map((c) => {
    const subs = c.subQuestions
      .map((s) => `  - ${s.id}: "${s.labelEn}" [${s.points} pts] → answer yes or no`)
      .join("\n");
    return `Category ${c.key}: ${c.nameEn} (max ${c.maxScore} pts)\n${subs}`;
  }).join("\n\n");

  return `You are evaluating a quarterly report from "${directorateName}" directorate for quarter "${quarter}" at the Harari Region Health Bureau.

The report content may be written in Amharic (አማርኛ) or in English — you fully understand both languages. Judge the report on its substance, regardless of its language.

Based on the report content below, answer each sub-question with "yes" (criteria met) or "no" (not met), and provide a short comment per category.

EVALUATION CRITERIA:
${rubricText}

REPORT CONTENT:
${content.slice(0, 24000)}

${LANGUAGE_INSTRUCTIONS[language] ?? LANGUAGE_INSTRUCTIONS.english}

Respond ONLY with a valid JSON object in this exact format:
{
  "answers": {
    "A1": "yes", "A2": "no",
    ...all question IDs...
  },
  "comments": {
    "A": "...", "B": "...",
    ...one comment per category A-J...
  }
}`;
}
