"use client";

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  CRITERIA,
  DIRECTORATES,
  TOTAL_MAX_SCORE,
  type Answers,
  type Comments,
  type Scores,
  ACTION_PLAN_STATUS_LABELS,
} from "@/lib/rubric";
import type { EvaluationDTO } from "@/lib/types";
import type { ActionPlanItem } from "@/lib/rubric";
import { getLogoDataUrl } from "@/lib/branding";

/* ------------------------------------------------------------------ */
/* CSV                                                                 */
/* ------------------------------------------------------------------ */

function downloadBlob(content: BlobPart, fileName: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}

/** Summary CSV — matrix of directorates × criteria with totals */
export function downloadSummaryCsv(evaluations: EvaluationDTO[], quarter: string, date?: string) {
  const byDir: Record<string, EvaluationDTO> = {};
  evaluations.forEach((e) => {
    byDir[e.directorateKey] = e;
  });
  let csv = "\uFEFF";
  csv += `Harari Region Health Bureau — Directorate Quarterly Report Evaluation Summary\n`;
  csv += `Date: ${date || "___"}    Quarter: ${quarter || "___"}\n`;
  csv += "Directorate,";
  CRITERIA.forEach((c) => (csv += `${c.key},`));
  csv += "Total\n";
  DIRECTORATES.forEach((d) => {
    const ev = byDir[d.key];
    csv += `"${d.name} (${d.nameEn})",`;
    CRITERIA.forEach((c) => {
      csv += `${ev?.scores?.[c.key] ?? ""},`;
    });
    csv += `${ev?.totalScore ?? ""}\n`;
  });
  csv += "Category Max,";
  CRITERIA.forEach((c) => (csv += `${c.maxScore},`));
  csv += `${TOTAL_MAX_SCORE}\n`;

  downloadBlob(csv, `Summary_${quarter || "report"}.csv`, "text/csv;charset=utf-8;");
}

/** Analytics results CSV */
export function downloadResultsCsv(evaluations: EvaluationDTO[], quarterLabel: string) {
  let csv = "\uFEFF";
  csv += "Directorate,Short,Quarter,Total Score,Max,Percent,Status,Email,Created\n";
  evaluations.forEach((e) => {
    const pct = TOTAL_MAX_SCORE > 0 ? Math.round((e.totalScore / TOTAL_MAX_SCORE) * 100) : 0;
    csv += `"${e.directorateName}",${e.directorateShort},${e.quarter},${e.totalScore},${TOTAL_MAX_SCORE},${pct}%,${e.status},${e.email ?? ""},${new Date(e.createdAt).toLocaleString()}\n`;
  });
  downloadBlob(csv, `Results_${quarterLabel}.csv`, "text/csv;charset=utf-8;");
}

/** Full evaluation history CSV */
export function downloadHistoryCsv(evaluations: EvaluationDTO[]) {
  let csv = "\uFEFF";
  csv += "Directorate,Short,Quarter,Total,Percent,Status,AI Generated,Created At\n";
  const sorted = [...evaluations].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );
  sorted.forEach((e) => {
    const pct = Math.round((e.totalScore / TOTAL_MAX_SCORE) * 100);
    csv += `"${e.directorateName}",${e.directorateShort},${e.quarter},${e.totalScore},${pct}%,${e.status},${e.aiGenerated ? "AI" : "Manual"},"${new Date(e.createdAt).toLocaleString()}"\n`;
  });
  downloadBlob(csv, `Performance_History.csv`, "text/csv;charset=utf-8;");
}

/* ------------------------------------------------------------------ */
/* PDF                                                                 */
/* ------------------------------------------------------------------ */

const BUREAU_EN = "Harari Region Health Bureau";
const BUREAU_AM = "\u1200\u1228\u122a \u12ad\u120d\u120d \u1324\u1293 \u1262\u122e";

const DEVELOPER_CREDIT =
  "Developed by Mr Ferid Mohammed · +251911133037 · feridmhd3@gmail.com";

const PRIMARY_RGB: [number, number, number] = [37, 99, 235];

/** Draw the bureau logo fitted inside a box, preserving aspect ratio */
function drawLogo(doc: jsPDF, logoDataUrl: string, xRight: number, y: number, height: number) {
  if (!logoDataUrl) return;
  try {
    const props = doc.getImageProperties(logoDataUrl);
    const w = (props.width / props.height) * height;
    doc.addImage(logoDataUrl, xRight - w, y, w, height, undefined, "FAST");
  } catch {
    /* ignore malformed logo */
  }
}

function docHeader(doc: jsPDF, title: string, subtitle?: string, logoDataUrl?: string) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(...PRIMARY_RGB);
  doc.rect(0, 0, W, 22, "F");
  if (logoDataUrl) drawLogo(doc, logoDataUrl, W - 10, 4, 14);
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text(BUREAU_EN, 14, 9);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.text("Directorate Quarterly Report Evaluation", 14, 15.5);
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text(title, 14, 31);
  if (subtitle) {
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    doc.text(subtitle, 14, 37);
  }
}

function footer(doc: jsPDF) {
  const pages = doc.getNumberOfPages();
  const W = doc.internal.pageSize.getWidth();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `${BUREAU_EN} · Direc-Score — page ${i}/${pages}`,
      14,
      doc.internal.pageSize.getHeight() - 11
    );
    doc.setFontSize(6.5);
    doc.setTextColor(160, 174, 192);
    doc.text(DEVELOPER_CREDIT, W - 14, doc.internal.pageSize.getHeight() - 11, {
      align: "right",
    });
  }
}

function actionPlanRows(items: ActionPlanItem[]): string[][] {
  return items.map((a, i) => {
    const statusKey = a.status ?? (a.done ? "done" : "planned");
    return [
      String(i + 1),
      a.text || "-",
      a.owner?.trim() || "—",
      a.deadline?.trim() || "—",
      ACTION_PLAN_STATUS_LABELS[statusKey]?.split(" / ")[1] ?? (a.done ? "Done" : "Planned"),
    ];
  });
}

/** Summary PDF — one table with all directorates × criteria */
export async function downloadSummaryPdf(evaluations: EvaluationDTO[], quarter: string, date?: string) {
  const logo = await getLogoDataUrl();
  const doc = new jsPDF();
  docHeader(doc, "Quarterly Evaluation Summary", `Quarter: ${quarter || "___"}    Date: ${date || new Date().toLocaleDateString()}`, logo);
  const byDir: Record<string, EvaluationDTO> = {};
  evaluations.forEach((e) => (byDir[e.directorateKey] = e));

  const head = [["Directorate", ...CRITERIA.map((c) => c.key), "Total", "%"]];
  const body = DIRECTORATES.filter((d) => byDir[d.key]).map((d) => {
    const e = byDir[d.key];
    const pct = Math.round((e.totalScore / TOTAL_MAX_SCORE) * 100);
    return [`${d.short} — ${d.nameEn}`, ...CRITERIA.map((c) => String(e.scores?.[c.key] ?? "-")), String(e.totalScore), `${pct}%`];
  });
  autoTable(doc, {
    startY: 42,
    head,
    body,
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
    alternateRowStyles: { fillColor: [241, 245, 249] },
  });
  footer(doc);
  doc.save(`Summary_${quarter || "report"}.pdf`);
}

/** Individual detailed report PDF for one evaluation */
export async function downloadEvaluationPdf(
  data: {
    directorate?: { short: string; name: string; nameEn: string };
    quarter: string;
    totalScore: number;
    scores: Scores;
    answers?: Answers;
    comments?: Comments;
    actionPlan?: ActionPlanItem[];
    email?: string;
    date?: string;
    feedback?: string;
  },
  fileName?: string
) {
  const logo = await getLogoDataUrl();
  const doc = new jsPDF();
  const name = data.directorate ? `${data.directorate.nameEn} (${data.directorate.short})` : "Directorate";
  const pct = Math.round((data.totalScore / TOTAL_MAX_SCORE) * 100);
  docHeader(
    doc,
    `Evaluation Report — ${name}`,
    `Quarter: ${data.quarter}    Score: ${data.totalScore}/${TOTAL_MAX_SCORE} (${pct}%)    Date: ${data.date || new Date().toLocaleDateString()}`,
    logo
  );

  autoTable(doc, {
    startY: 44,
    head: [["Category", "Max", "Score", "Rating"]],
    body: CRITERIA.map((c) => {
      const s = data.scores?.[c.key] ?? 0;
      const p = Math.round((s / c.maxScore) * 100);
      return [`${c.key} — ${c.nameEn}`, String(c.maxScore), String(s), p >= 75 ? "Good" : p >= 50 ? "Average" : "Needs improvement"];
    }),
    foot: [["TOTAL", String(TOTAL_MAX_SCORE), String(data.totalScore), `${pct}%`]],
    styles: { fontSize: 9, cellPadding: 2.5 },
    headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
    footStyles: { fillColor: [226, 232, 240], textColor: 30 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  });

  let y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;

  if (data.comments && Object.keys(data.comments).length > 0) {
    const commentRows = CRITERIA.filter((c) => data.comments?.[c.key]?.trim()).map((c) => [
      `${c.key} — ${c.nameEn}`,
      data.comments![c.key],
    ]);
    if (commentRows.length > 0) {
      autoTable(doc, {
        startY: y,
        head: [["Evaluator Comments", ""]],
        body: commentRows,
        styles: { fontSize: 8.5, cellPadding: 2.5 },
        headStyles: { fillColor: [71, 85, 105], textColor: 255 },
        columnStyles: { 1: { cellWidth: 120 } },
      });
      y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
    }
  }

  if (data.actionPlan && data.actionPlan.length > 0) {
    autoTable(doc, {
      startY: y,
      head: [["#", "Goal / Corrective Step", "Owner", "Deadline", "Status"]],
      body: actionPlanRows(data.actionPlan),
      styles: { fontSize: 8.5, cellPadding: 2.5 },
      headStyles: { fillColor: [22, 163, 74], textColor: 255 },
      columnStyles: { 1: { cellWidth: 70 } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.feedback?.trim()) {
    autoTable(doc, {
      startY: y,
      head: [["Feedback"]],
      body: [[data.feedback]],
      styles: { fontSize: 8.5, cellPadding: 2.5 },
      headStyles: { fillColor: [71, 85, 105], textColor: 255 },
    });
  }

  footer(doc);
  doc.save(fileName || `Evaluation_${data.directorate?.short ?? "report"}_${data.quarter}.pdf`);
}

/** Combined Executive PDF — cover page, executive summary, then one section per selected directorate */
export async function downloadCombinedPdf(
  evaluations: EvaluationDTO[],
  quarter: string,
  onProgress?: (current: number, total: number) => void
) {
  const logo = await getLogoDataUrl();
  const doc = new jsPDF();
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();

  /* ---------- Cover page ---------- */
  doc.setFillColor(...PRIMARY_RGB);
  doc.rect(0, 0, W, H * 0.32, "F");
  doc.setFillColor(30, 64, 175);
  doc.rect(0, H * 0.32, W, 3, "F");
  if (logo) drawLogo(doc, logo, W - 14, 12, 24);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(BUREAU_EN, 14, 34);
  doc.setFontSize(13);
  doc.setFont("helvetica", "normal");
  doc.text(BUREAU_AM, 14, 43);
  doc.text("Directorate Quarterly Report Evaluation", 14, 52);

  doc.setTextColor(30, 41, 59);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(19);
  doc.text("Executive Combined Evaluation Report", 14, H * 0.32 + 26);
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(71, 85, 105);
  const generated = new Date().toLocaleString();
  doc.text(`Quarter: ${quarter}    ·    Directorates: ${evaluations.length}    ·    Generated: ${generated}`, 14, H * 0.32 + 35);

  // mini stat band
  const scores = evaluations.map((e) => e.totalScore);
  const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  const best = evaluations.reduce<EvaluationDTO | null>((acc, e) => (!acc || e.totalScore > acc.totalScore ? e : acc), null);
  const stat = (label: string, value: string, x: number) => {
    doc.setDrawColor(226, 232, 240);
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(x, H * 0.32 + 48, 42, 26, 2, 2, "FD");
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "normal");
    doc.text(label, x + 4, H * 0.32 + 57);
    doc.setFontSize(13);
    doc.setTextColor(30, 41, 59);
    doc.setFont("helvetica", "bold");
    doc.text(value, x + 4, H * 0.32 + 69);
  };
  const bandX = 14;
  stat("AVERAGE SCORE", `${avg}/100`, bandX);
  stat("TOP PERFORMER", best ? best.directorateShort : "—", bandX + 46);
  stat("REPORTS INCLUDED", String(evaluations.length), bandX + 92);
  stat("QUARTER", quarter, bandX + 138);

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.setFont("helvetica", "normal");
  doc.text(
    "This document consolidates the quarterly evaluation results of the selected directorates for executive review.",
    14,
    H - 34,
    { maxWidth: W - 28 }
  );
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(DEVELOPER_CREDIT, 14, H - 22);

  /* ---------- Executive summary page ---------- */
  doc.addPage();
  const ranked = [...evaluations].sort((a, b) => b.totalScore - a.totalScore);
  docHeader(doc, "Executive Summary", `Quarter: ${quarter}    ·    ${evaluations.length} directorates ranked by total score`, logo);

  autoTable(doc, {
    startY: 42,
    head: [["Rank", "Directorate", "Total", "%", "Status"]],
    body: ranked.map((e, i) => [
      i === 0 ? "1 (Top)" : String(i + 1),
      `${e.directorateShort} — ${e.directorateName}`,
      `${e.totalScore}/${TOTAL_MAX_SCORE}`,
      `${Math.round((e.totalScore / TOTAL_MAX_SCORE) * 100)}%`,
      e.status,
    ]),
    styles: { fontSize: 9, cellPadding: 2.5 },
    headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
    alternateRowStyles: { fillColor: [241, 245, 249] },
    didParseCell: (data) => {
      if (data.section === "body" && data.column.index === 0 && data.row.index === 0) {
        data.cell.styles.textColor = [22, 163, 74];
        data.cell.styles.fontStyle = "bold";
      }
    },
  });

  let y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  const good = evaluations.filter((e) => e.totalScore / TOTAL_MAX_SCORE >= 0.75).length;
  const middle = evaluations.filter((e) => e.totalScore / TOTAL_MAX_SCORE >= 0.5 && e.totalScore / TOTAL_MAX_SCORE < 0.75).length;
  const poor = evaluations.length - good - middle;
  autoTable(doc, {
    startY: y,
    head: [["Performance Distribution", "Count"]],
    body: [
      ["Good (>= 75%)", String(good)],
      ["Average (50-74%)", String(middle)],
      ["Needs improvement (< 50%)", String(poor)],
    ],
    styles: { fontSize: 9, cellPadding: 2.5 },
    headStyles: { fillColor: [71, 85, 105], textColor: 255 },
  });

  /* ---------- Per-directorate sections ---------- */
  for (let i = 0; i < evaluations.length; i++) {
    onProgress?.(i + 1, evaluations.length);
    const e = evaluations[i];
    const dir = DIRECTORATES.find((d) => d.key === e.directorateKey);
    doc.addPage();
    docHeader(
      doc,
      `${e.directorateShort} — ${dir?.nameEn ?? e.directorateName}`,
      `Quarter: ${e.quarter}    Score: ${e.totalScore}/${TOTAL_MAX_SCORE} (${Math.round((e.totalScore / TOTAL_MAX_SCORE) * 100)}%)`,
      logo
    );
    autoTable(doc, {
      startY: 42,
      head: [["Category", "Max", "Score"]],
      body: CRITERIA.map((c) => [`${c.key} — ${c.nameEn}`, String(c.maxScore), String(e.scores?.[c.key] ?? 0)]),
      foot: [["TOTAL", String(TOTAL_MAX_SCORE), String(e.totalScore)]],
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
      footStyles: { fillColor: [226, 232, 240], textColor: 30 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
    const commentRows = CRITERIA.filter((c) => e.comments?.[c.key]?.trim()).map((c) => [
      `${c.key}`,
      e.comments[c.key],
    ]);
    if (commentRows.length > 0) {
      autoTable(doc, {
        startY: y,
        head: [["Comments", ""]],
        body: commentRows,
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [71, 85, 105], textColor: 255 },
        columnStyles: { 1: { cellWidth: 130 } },
      });
      y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
    }
    if (e.actionPlan && e.actionPlan.length > 0) {
      autoTable(doc, {
        startY: y,
        head: [["#", "Goal / Corrective Step", "Owner", "Deadline", "Status"]],
        body: actionPlanRows(e.actionPlan),
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [22, 163, 74], textColor: 255 },
        columnStyles: { 1: { cellWidth: 62 } },
      });
    }
  }
  footer(doc);
  doc.save(`Executive_Report_${quarter}.pdf`);
}

/* ------------------------------------------------------------------ */
/* AI analysis report PDF (AI Studio final export)                     */
/* ------------------------------------------------------------------ */

export interface AnalysisReportData {
  fileName: string;
  title?: string;
  generatedAt?: string;
  datasetType?: string;
  rows?: number;
  columns?: number;
  summary?: string;
  keyFindings?: string[];
  recommendations?: string[];
  statistics?: Array<{ column: string; type: string; min?: number; max?: number; mean?: number; missing?: number }>;
  conclusion?: string;
  chartImages?: Array<{ title: string; dataUrl: string }>;
}

/** Final AI analysis report PDF — includes optional chart snapshots */
export async function downloadAnalysisReportPdf(data: AnalysisReportData, fileName?: string) {
  const logo = await getLogoDataUrl();
  const doc = new jsPDF();
  const name = data.title?.trim() || data.fileName;
  docHeader(
    doc,
    `Data Analysis Report — ${name}`,
    `Generated: ${data.generatedAt || new Date().toLocaleString()}${data.datasetType ? `    ·    Dataset: ${data.datasetType}` : ""}`,
    logo
  );

  let y = 44;

  const ensureSpace = (needed: number) => {
    if (y + needed > doc.internal.pageSize.getHeight() - 16) {
      doc.addPage();
      y = 20;
    }
  };

  if (typeof data.rows === "number" && typeof data.columns === "number") {
    autoTable(doc, {
      startY: y,
      head: [["Rows", "Columns", "Dataset Type"]],
      body: [[String(data.rows), String(data.columns), data.datasetType || "—"]],
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.summary?.trim()) {
    ensureSpace(30);
    autoTable(doc, {
      startY: y,
      head: [["Executive Summary"]],
      body: [[data.summary]],
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [71, 85, 105], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.keyFindings && data.keyFindings.length > 0) {
    ensureSpace(30);
    autoTable(doc, {
      startY: y,
      head: [["Key Findings"]],
      body: data.keyFindings.map((f, i) => [`${i + 1}. ${f}`]),
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [22, 163, 74], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.statistics && data.statistics.length > 0) {
    ensureSpace(30);
    autoTable(doc, {
      startY: y,
      head: [["Column", "Type", "Min", "Max", "Mean", "Missing"]],
      body: data.statistics.map((s) => [
        s.column,
        s.type,
        s.min !== undefined ? String(s.min) : "—",
        s.max !== undefined ? String(s.max) : "—",
        s.mean !== undefined ? String(s.mean) : "—",
        s.missing !== undefined ? String(s.missing) : "—",
      ]),
      styles: { fontSize: 8.5, cellPadding: 2 },
      headStyles: { fillColor: [71, 85, 105], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.recommendations && data.recommendations.length > 0) {
    ensureSpace(30);
    autoTable(doc, {
      startY: y,
      head: [["Recommendations"]],
      body: data.recommendations.map((r, i) => [`${i + 1}. ${r}`]),
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [22, 163, 74], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.conclusion?.trim()) {
    ensureSpace(30);
    autoTable(doc, {
      startY: y,
      head: [["Conclusion"]],
      body: [[data.conclusion]],
      styles: { fontSize: 9, cellPadding: 2.5 },
      headStyles: { fillColor: [...PRIMARY_RGB], textColor: 255 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  if (data.chartImages && data.chartImages.length > 0) {
    for (const chart of data.chartImages) {
      ensureSpace(90);
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.setFont("helvetica", "bold");
      doc.text(chart.title, 14, y + 4);
      try {
        doc.addImage(chart.dataUrl, "PNG", 14, y + 8, 180, 80, undefined, "FAST");
        y += 94;
      } catch {
        y += 10;
      }
    }
  }

  footer(doc);
  doc.save(fileName || `Analysis_Report_${data.fileName.replace(/\.[^.]+$/, "")}.pdf`);
}
