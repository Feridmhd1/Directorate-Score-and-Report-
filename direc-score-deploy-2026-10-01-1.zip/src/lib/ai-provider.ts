import ZAI from "z-ai-web-dev-sdk";

/**
 * Unified AI provider for every /api/ai/* route.
 *
 * Two execution paths:
 *
 * 1. BYO provider (headers) — the browser can attach
 *      x-ai-base-url   e.g. "https://openrouter.ai/api/v1"
 *      x-ai-key        the user's personal API key
 *      x-ai-model      e.g. "meta-llama/llama-3.3-70b-instruct:free"
 *    The route then calls any OpenAI-compatible chat-completions endpoint.
 *    This makes every AI feature work on static/serverless hosts (Netlify)
 *    where the built-in sandbox provider is not reachable, without needing
 *    any server-side configuration.
 *
 * 2. Built-in provider — no headers: uses the platform ZAI SDK exactly as
 *    before (sandbox preview / full server deployments).
 *
 * Both paths return the assistant message content. Errors propagate to the
 * route's own try/catch so responses stay identical.
 */

export interface AIMessage {
  role: "system" | "assistant" | "user";
  /** string for text chat; array content for vision calls (OpenAI format) */
  content: string | unknown[];
}

export interface AICallOptions {
  /** Ask OpenAI-compatible providers for strict JSON output when supported */
  json?: boolean;
  /** Route may pass extra model parameters (temperature etc.) */
  temperature?: number;
}

function headerProvider(req: Request): { baseUrl: string; apiKey: string; model: string } | null {
  const baseUrl = req.headers.get("x-ai-base-url")?.trim() ?? "";
  const apiKey = req.headers.get("x-ai-key")?.trim() ?? "";
  const model = req.headers.get("x-ai-model")?.trim() ?? "";
  if (!baseUrl || !apiKey || !model) return null;
  return { baseUrl, apiKey, model };
}

function normalizeBaseUrl(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, "");
}

async function callOpenAiCompatible(
  provider: { baseUrl: string; apiKey: string; model: string },
  messages: AIMessage[],
  options: AICallOptions
): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 110_000);
  try {
    const res = await fetch(`${normalizeBaseUrl(provider.baseUrl)}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${provider.apiKey}`,
        // OpenRouter attribution headers (harmless for other providers)
        "HTTP-Referer": "https://direc-score.app",
        "X-Title": "Direc Score Report",
      },
      body: JSON.stringify({
        model: provider.model,
        messages,
        temperature: options.temperature ?? 0.2,
        ...(options.json ? { response_format: { type: "json_object" } } : {}),
      }),
      signal: controller.signal,
    });
    const raw = await res.text();
    if (!res.ok) {
      throw new Error(
        `AI provider error (HTTP ${res.status}): ${raw.slice(0, 300) || "no response body"}`
      );
    }
    let parsed: { choices?: Array<{ message?: { content?: string } }> } = {};
    try {
      parsed = JSON.parse(raw) as typeof parsed;
    } catch {
      throw new Error("AI provider returned a non-JSON response");
    }
    const content = parsed.choices?.[0]?.message?.content ?? "";
    if (!content) throw new Error("AI provider returned an empty response");
    return content;
  } finally {
    clearTimeout(timer);
  }
}

async function callBuiltIn(messages: AIMessage[]): Promise<string> {
  const zai = await ZAI.create();
  const isVision = messages.some((m) => Array.isArray(m.content));
  if (isVision) {
    const completion = await zai.chat.completions.createVision({
      model: "glm-4.6v",
      messages: messages as never,
      thinking: { type: "disabled" },
    });
    return completion.choices[0]?.message?.content ?? "";
  }
  const completion = await zai.chat.completions.create({
    messages: messages as never,
    thinking: { type: "disabled" },
  });
  return completion.choices[0]?.message?.content ?? "";
}

/** Run a chat completion through the header provider when present, else the built-in SDK */
export async function aiChat(
  req: Request,
  messages: AIMessage[],
  options: AICallOptions = {}
): Promise<string> {
  const provider = headerProvider(req);
  if (provider) {
    return callOpenAiCompatible(provider, messages, options);
  }
  return callBuiltIn(messages);
}

/** True when the request carries a personal provider (used for error hints) */
export function hasHeaderProvider(req: Request): boolean {
  return headerProvider(req) !== null;
}
