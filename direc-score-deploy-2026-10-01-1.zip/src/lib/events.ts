/**
 * Real-time app events relay.
 *
 * When a directorate uploads a quarterly report (from their own shareable link
 * or from the admin Evaluate page) the API routes call `emitAppEvent`, which
 * forwards the event to the lightweight socket.io events service
 * (mini-services/events-service). Every connected admin browser receives the
 * event instantly (via the Caddy gateway: io("/?XTransformPort=3010")) so the
 * upload is visible in the application the moment it lands.
 *
 * The relay is strictly best-effort: if the events service is not running the
 * caller is never blocked and the UI falls back to periodic polling.
 */

const EMIT_URL = process.env.EVENTS_SERVICE_URL || "http://127.0.0.1:3011/emit";

/** Broadcast an app event to every connected dashboard (fire-and-forget). */
export async function emitAppEvent(
  type: string,
  payload: Record<string, unknown>
): Promise<void> {
  try {
    await fetch(EMIT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, payload }),
      signal: AbortSignal.timeout(1500),
    });
  } catch {
    /* Events service unreachable — polling fallback keeps the UI fresh. */
  }
}

/** Standard payload shape for "document_uploaded" events. */
export interface DocumentUploadedEvent {
  id: string;
  directorateKey: string;
  directorateShort?: string;
  directorateName?: string;
  quarter: string;
  title: string;
  fileName: string;
  mimeType: string;
  size: number;
  note?: string;
  shareToken?: string;
  source: "portal" | "app";
  createdAt: string;
}
