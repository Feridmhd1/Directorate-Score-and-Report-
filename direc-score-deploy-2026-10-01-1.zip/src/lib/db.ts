import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'
import { ensureDatabaseReady } from './db-bootstrap'

/**
 * Database client factory.
 *
 * Two storage backends, decided purely by DATABASE_URL:
 *
 *  - "libsql://…"  → a shared cloud database (Turso / any LibSQL server).
 *    Every device that opens the app reads and writes the SAME database,
 *    so all recordings, edits and updates are visible everywhere and can
 *    never be lost. This is the recommended setup for serverless hosts
 *    such as Netlify (set DATABASE_URL + DATABASE_AUTH_TOKEN there).
 *
 *  - "file:…" (default) → the local SQLite file used in the sandbox and on
 *    persistent servers (Railway / Render / Fly.io / VPS).
 *
 * Both use the identical Prisma schema, and `db-bootstrap` creates any
 * missing tables automatically on first use — a brand-new cloud database
 * initializes itself with zero commands.
 */
function createPrismaClient(): PrismaClient {
  const url = process.env.DATABASE_URL ?? ''

  if (url.startsWith('libsql://') || url.startsWith('libsql:')) {
    const adapter = new PrismaLibSQL({
      url,
      authToken: process.env.DATABASE_AUTH_TOKEN || undefined,
    })
    return new PrismaClient({ adapter })
  }

  return new PrismaClient({
    log: ['query'],
  })
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

const prismaBase =
  globalForPrisma.prisma ??
  createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prismaBase

// Start the schema bootstrap eagerly (a no-op once the database exists) and
// make every model operation await it — so the very first request on a fresh
// deployment (e.g. Netlify + Turso) creates the tables instead of failing.
void ensureDatabaseReady(prismaBase).catch((err) =>
  console.error('db bootstrap failed', err)
)

export const db = prismaBase.$extends({
  query: {
    $allOperations: async ({ args, query }) => {
      await ensureDatabaseReady(prismaBase)
      return query(args)
    },
  },
}) as unknown as PrismaClient
