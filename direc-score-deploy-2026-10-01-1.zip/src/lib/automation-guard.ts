import { NextResponse } from "next/server";
import { DEFAULT_AUTOMATION_PIN, getSetting, SETTING_KEYS } from "@/lib/settings-store";
import { clearFailures, clientIp, recordFailure, throttleFailure } from "@/lib/filing-guard";

/**
 * Guard helpers for the score/document delivery automation API.
 * EDITING the automation (create/update/delete channels) is protected by a
 * password (default 3472, configurable via the `automationPin` app setting).
 * Every mutating /api/automation/channels request must carry it in the
 * `x-automation-pin` header. Viewing channels/logs stays open.
 */

/** Resolve the current automation-edit password (configurable; defaults to 3472) */
export async function getAutomationPin(): Promise<string> {
  const stored = await getSetting(SETTING_KEYS.automationPin);
  return stored || DEFAULT_AUTOMATION_PIN;
}

/**
 * Returns a 401 response when the request does not carry the correct password
 * (with per-IP brute-force throttling), or null when the caller may proceed.
 */
export async function requireAutomationPin(req: Request): Promise<NextResponse | null> {
  const ip = clientIp(req);
  const throttled = throttleFailure(ip);
  if (throttled) return throttled;

  const provided = req.headers.get("x-automation-pin")?.trim() ?? "";
  const expected = await getAutomationPin();
  if (!provided || provided !== expected) {
    recordFailure(ip);
    return NextResponse.json(
      { error: "ትክክለኛ የይለፍ ቃል ያስፈልጋል / Incorrect automation password" },
      { status: 401 }
    );
  }
  clearFailures(ip);
  return null;
}
