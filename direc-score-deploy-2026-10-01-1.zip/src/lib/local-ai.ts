/**
 * Offline intelligence engine ("local" backend mode).
 *
 * Pure functions — no storage imports — that keep every AI-powered feature
 * working without a server or an API key. The results are honest,
 * deterministic, evidence-based analyses of the provided content, clearly
 * marked with OFFLINE_MARKER so users know a personal AI key
 * (Settings → AI Provider) unlocks the full intelligence.
 *
 * Capabilities:
 *  - offlineEvaluateReport    evidence-based 29-point rubric answers (EN/AM)
 *  - offlineEvaluateEvaluator audit of the AI evaluator's own assessment
 *  - offlineDocumentInsights  summary, key points, topics, sentiment, graphics
 *  - offlineCompareDocuments  overlap, common themes, similarity score
 *  - offlineExtractDocument   client-side text extraction for any common file
 *                             type (PDF via inflate, DOCX/XLSX/PPTX via a
 *                             built-in ZIP reader, text-like files direct)
 *  - offlineAnalyzeData       CSV/TSV column statistics + renderable charts
 *  - offlineChat              grounded keyword-search assistant
 */

import { CRITERIA, TOTAL_MAX_SCORE, scorePercent } from "@/lib/rubric";
import type {
  AICompareResult,
  EvaluatorAuditReport,
  EvaluatorDisagreement,
  Insights,
  GraphicSuggestion,
} from "@/lib/types";

export const OFFLINE_MARKER =
  "(Offline analysis — add a free AI key in Settings → AI Provider for full intelligence)";

/* ------------------------------------------------------------------ */
/* Text utilities                                                      */
/* ------------------------------------------------------------------ */

function splitSentences(text: string): string[] {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?።፧])\s+|[\n\r]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 2);
}

const STOPWORDS = new Set(
  ("the a an and or of to in for on with at by from as is are was were be been it its this that these those " +
    "not no yes will shall can may has have had do does did he she they we you i his her their our your " +
    "የ ላይ እና ወይም በ ለ ከ ይህ እነዚህ ነው ተብሎ ሆነ መሆኑን ተግባራት ሪፖርት ዳይሬክቶሬ ቢሮ ጤና")
    .split(" ")
    .filter(Boolean)
);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s%]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));
}

function wordFrequencies(text: string, limit = 12): Array<{ term: string; count: number }> {
  const counts = new Map<string, number>();
  for (const word of tokenize(text)) {
    counts.set(word, (counts.get(word) ?? 0) + 1);
  }
  return [...counts.entries()]
    .map(([term, count]) => ({ term, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

function topSentencesAbout(text: string, terms: string[], limit = 5): string[] {
  const sentences = splitSentences(text);
  if (!sentences.length) return [];
  const scored = sentences.map((sentence, index) => {
    const lower = sentence.toLowerCase();
    const hits = terms.reduce((acc, term) => acc + (lower.includes(term.toLowerCase()) ? 1 : 0), 0);
    return { sentence, hits, index };
  });
  return scored
    .sort((a, b) => b.hits - a.hits || a.index - b.index)
    .filter((s) => s.hits > 0)
    .slice(0, limit)
    .map((s) => s.sentence);
}

function hasAny(text: string, patterns: RegExp[]): boolean {
  const lower = text.toLowerCase();
  return patterns.some((p) => p.test(lower));
}

/* ------------------------------------------------------------------ */
/* Rubric evidence map (keyword evidence per sub-question)             */
/* ------------------------------------------------------------------ */

/** Searchable evidence patterns for each rubric sub-question */
const EVIDENCE: Record<string, RegExp[]> = {
  A1: [/deadline|ገብቷል|ጊዜ ገደብ|submitted on|on time|በጊዜው/],
  A2: [/format|ፎርማት|template|አቀራረብ|professional|የታዘዘ/],
  B1: [/title|ርዕስ|cover|የሽፋን ገጽ/],
  B2: [/reporting period|የሪፖርት ጊዜ|quarter|ሩብ ዓመት|period|ወቅት/],
  B3: [/responsible|ተጠያቂ|unit|ክፍል|owner|ኃላፊ|ኃላፊነት/],
  B4: [/signature|ፊርማ|stamp|ማህተም|approved|ጸድቋል/],
  B5: [/table of contents|ማውጫ|toc|contents/],
  C1: [/strategic|ስልታዊ|annual goal|ዓመታዊ ግብ|align|ይጣጣማል|አመታዊ/],
  C2: [/priorit|ቅድሚያ|key intervention|ዋና ተግባር/],
  D1: [/target|ኢላማ|measurable|ሊለክ|indicator|አመልካች/],
  D2: [/performance|አፈፃፀም|against target|ከዒላማ|achievement|ስኬት/],
  D3: [/activit|ተግባራት|ተግባር|described|ተዘርዝረዋል|ተብራርተው/],
  D4: [/unmet|ያልተሰሩ|not achieved|አልተሳካም|reason|ምክንያት|ምክንያቱም/],
  D5: [/responsible person|ተጠያቂ ሰው|assigned|ተመድቧል|focal|ተቆጣጣሪ/],
  E1: [/indicator|አመልካች|kpi|መለኪያ/],
  E2: [/monitor|ክትትል|supervision|ቁጥጥር|tool|መሳሪያ|checklist/],
  E3: [/compar|ንጽጽር|ይነጻጸራሉ|versus|vs\.?|actual|ተጨባጭ|%|percent|በመቶ/],
  F1: [/complet|ተጠናቅቋል|ongoing|በሂደት ላይ|delay|ዘግይቷል|status|ኹኔታ/],
  F2: [/output|ውጤት|achiev|ተሳክቷል|result|ውጤቶች/],
  F3: [/challenge|ተግዳሮት|obstacle|እንቅፋት|problem|ችግር/],
  G1: [/budget|በጀት|allocated|ተመድቧል|ወጪ|birr|ብር/],
  G2: [/expenditure|ወጪ|spent|ተጠቅሟል|utilization|አጠቃቀም|consumption/],
  G3: [/variance|ልዩነት|deviation|ልዩነቶች|difference/],
  H1: [/challenge|ተግዳሮት|documented|ተመዝግበዋል|faced|ያጋጠሙ/],
  H2: [/lesson|ትምህርት|learned|ተማርተናል|best practice|ልምድ/],
  I1: [/recommend|ምክረ ሃሳብ|ይመከራል|suggestion|ጥቆማ|actionable/],
  I2: [/next quarter|ቀጣዩ|follow.?up|ቀጣይ እርምጃ|way forward|የወደፊት እቅድ/],
  J1: [/attach|ዓባሪ|photo|ፎቶ|annex|ረዳት ሰነድ|supporting/],
  J2: [/reference|ማጣቀሻ|source|ምንጭ|cited|ተጠቅሰዋል/],
};

/* ------------------------------------------------------------------ */
/* 1. Offline quarterly report evaluation                              */
/* ------------------------------------------------------------------ */

export async function offlineEvaluateReport(data: {
  directorateName: string;
  quarter: string;
  content: string;
  language?: "english" | "amharic" | "bilingual";
}): Promise<{ answers: Record<string, string>; comments: Record<string, string> }> {
  const answers: Record<string, string> = {};
  const comments: Record<string, string> = {};
  const language = data.language ?? "bilingual";

  for (const criterion of CRITERIA) {
    const evidenceBits: string[] = [];
    const missingBits: string[] = [];
    for (const sq of criterion.subQuestions) {
      const patterns = EVIDENCE[sq.id] ?? [];
      const found = hasAny(data.content, patterns);
      answers[sq.id] = found ? "yes" : "no";
      if (found) {
        evidenceBits.push(sq.labelEn);
      } else {
        missingBits.push(sq.labelEn);
      }
    }
    const am =
      language === "english"
        ? ""
        : language === "amharic"
          ? `መስፈርቱ በኦፍላይን ትንተና ተመርምሯል። `
          : `Offline evidence check. `;
    const en = `Evidence found: ${evidenceBits.length}/${criterion.subQuestions.length} (${evidenceBits
      .slice(0, 2)
      .join("; ")}${evidenceBits.length > 2 ? "; …" : ""}). ${
      missingBits.length ? `Not evidenced: ${missingBits.slice(0, 2).join("; ")}${missingBits.length > 2 ? "; …" : ""}.` : "All sub-criteria evidenced."
    } ${OFFLINE_MARKER}`;
    comments[criterion.key] = `${am}${en}`.trim();
  }

  return { answers, comments };
}

/* ------------------------------------------------------------------ */
/* 2. Offline evaluator audit (meta-evaluation)                        */
/* ------------------------------------------------------------------ */

const VALID_IDS = new Set(CRITERIA.flatMap((c) => c.subQuestions.map((q) => q.id)));
const MAX_POINTS: Record<string, number> = Object.fromEntries(
  CRITERIA.flatMap((c) => c.subQuestions.map((q) => [q.id, q.points] as const))
);

export async function offlineEvaluateEvaluator(data: {
  directorateName: string;
  quarter: string;
  answers: Record<string, string>;
  comments: Record<string, string>;
  totalScore: number;
  reportContent: string;
}): Promise<{
  id: string;
  createdAt: string;
  qualityScore: number;
  verdict: string;
  report: EvaluatorAuditReport;
}> {
  const disagreements: EvaluatorDisagreement[] = [];
  let checked = 0;
  let agreements = 0;

  for (const criterion of CRITERIA) {
    for (const sq of criterion.subQuestions) {
      const given = (data.answers?.[sq.id] ?? "").toLowerCase();
      if (given !== "yes" && given !== "no") continue;
      checked++;
      const evidence = hasAny(data.reportContent, EVIDENCE[sq.id] ?? []);
      const evaluatorSaidYes = given === "yes";
      const agrees = evaluatorSaidYes === evidence;
      if (agrees) {
        agreements++;
        continue;
      }
      disagreements.push({
        questionId: sq.id,
        severity: sq.points >= 5 ? "high" : sq.points >= 3 ? "medium" : "low",
        reason: `The report ${evidence ? "contains" : "does not contain"} evidence for "${sq.labelEn}", but the evaluator answered "${given}".`,
        suggestedAnswer: evidence ? "yes" : "no",
      });
    }
  }

  // Comment groundedness — comments that quote actual report terms score better
  const commentText = Object.values(data.comments ?? {}).join(" ").toLowerCase();
  const reportTerms = new Set(tokenize(data.reportContent).slice(0, 400));
  const commentWords = tokenize(commentText);
  const groundedHits = commentWords.filter((w) => reportTerms.has(w)).length;
  const groundedness = commentWords.length ? groundedHits / commentWords.length : 0;

  const agreementRate = checked ? agreements / checked : 1;
  const qualityScore = Math.max(
    0,
    Math.min(100, Math.round(agreementRate * 85 + groundedness * 15))
  );
  const verdict = qualityScore >= 80 ? "reliable" : qualityScore >= 60 ? "review" : "unreliable";

  const strengths: string[] = [];
  const improvements: string[] = [];
  if (agreementRate >= 0.8) {
    strengths.push(`Answers agree with the report evidence in ${Math.round(agreementRate * 100)}% of checked items.`);
  } else {
    improvements.push(`Only ${Math.round(agreementRate * 100)}% of answers match the report evidence — review the flagged answers below.`);
  }
  if (groundedness >= 0.15) {
    strengths.push("Comments reference concrete terms from the report (grounded feedback).");
  } else {
    improvements.push("Comments are mostly generic — they should quote specific findings from the report.");
  }
  if (disagreements.length === 0) {
    strengths.push("No contradicted answers were detected by the offline audit.");
  }
  if (strengths.length === 0) {
    strengths.push("The evaluator produced a complete answer set for every rubric item.");
  }

  return {
    id: `audit-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
    qualityScore,
    verdict,
    report: {
      qualityScore,
      verdict,
      summary:
        `Offline audit of the ${data.directorateName} ${data.quarter} evaluation: ${agreements}/${checked} checked answers agree with the report evidence. ` +
        `Comment groundedness ${(groundedness * 100).toFixed(0)}%. ${OFFLINE_MARKER}`,
      disagreements: disagreements.slice(0, 15),
      strengths,
      improvements,
    },
  };
}

/* ------------------------------------------------------------------ */
/* 3. Offline document insights (AI Studio)                            */
/* ------------------------------------------------------------------ */

export async function offlineDocumentInsights(data: {
  fileName: string;
  content: string;
}): Promise<{
  insights: Insights;
  graphics: GraphicSuggestion[];
}> {
  const content = data.content ?? "";
  const sentences = splitSentences(content);
  const freq = wordFrequencies(content);
  const summary =
    sentences.slice(0, 4).join(" ").slice(0, 700) ||
    `The document "${data.fileName}" contains ${content.length.toLocaleString()} characters.`;

  const insights: Insights = {
    document_type: guessDocumentType(data.fileName, content),
    language: /[\u1200-\u137F]/.test(content) ? "amharic" : "english",
    sentiment: guessSentiment(content),
    summary: `${summary} ${OFFLINE_MARKER}`,
    key_points: (topSentencesAbout(content, freq.slice(0, 6).map((f) => f.term), 5) ||
      sentences.slice(0, 5)).slice(0, 5),
    topics: freq.slice(0, 8).map((f) => f.term),
    recommendations: [
      "Verify the key points above against the source document.",
      "Add a free AI key in Settings → AI Provider for richer, AI-generated insights.",
      "Use the Data analysis tab for charts and column statistics.",
    ],
  };

  const graphics: GraphicSuggestion[] = [
    {
      id: "graphic-topics",
      title: "Top topics by frequency",
      type: "bar",
      description: "Most frequent meaningful terms across the document.",
      data: freq.slice(0, 8).map((f) => ({ term: f.term, count: f.count })) as unknown as Record<string, unknown>,
    },
    {
      id: "graphic-length",
      title: "Document composition",
      type: "pie",
      description: "Share of sentences, words and characters in the document.",
      data: [
        { label: "Sentences", value: sentences.length },
        { label: "Words", value: content.trim().split(/\s+/).filter(Boolean).length },
        { label: "Characters", value: Math.round(content.length / 10) },
      ] as unknown as Record<string, unknown>,
    },
    {
      id: "graphic-structure",
      title: "Section length distribution",
      type: "line",
      description: "Length (characters) of each of the first 15 sections/paragraphs.",
      data: content
        .split(/\n{2,}/)
        .map((p) => p.trim())
        .filter(Boolean)
        .slice(0, 15)
        .map((p, i) => ({ section: `#${i + 1}`, chars: p.length })) as unknown as Record<string, unknown>,
    },
  ];

  return { insights, graphics };
}

function guessDocumentType(fileName: string, content: string): string {
  const name = fileName.toLowerCase();
  if (/report|ሪፖርት/.test(name) || /quarterly report|ሩብ ዓመት/.test(content.toLowerCase())) return "Quarterly report";
  if (/plan|እቅድ/.test(name) || /action plan/.test(content.toLowerCase())) return "Plan / Action plan";
  if (/budget|በጀት/.test(name) || /budget/.test(content.toLowerCase())) return "Budget document";
  if (/minute|የስብሰባ/.test(name)) return "Meeting minutes";
  return "General document";
}

function guessSentiment(content: string): string {
  const positive = (content.match(/success|achiev|improv|complet|ተሳክቷል|ተጠናቋል|ስኬት|ጥሩ/gi) ?? []).length;
  const negative = (content.match(/challenge|fail|delay|problem|ተግዳሮት|አልተሳካም|ዘግይቷል|ችግር|እንቅፋት/gi) ?? []).length;
  if (positive > negative * 1.5) return "positive";
  if (negative > positive * 1.5) return "negative";
  return "neutral";
}

/* ------------------------------------------------------------------ */
/* 4. Offline document comparison                                      */
/* ------------------------------------------------------------------ */

export async function offlineCompareDocuments(data: {
  documents: Array<{ fileName: string; content: string }>;
}): Promise<AICompareResult> {
  const docs = data.documents ?? [];
  if (docs.length < 2) {
    throw new Error("Select at least two documents to compare");
  }
  const termSets = docs.map((d) => new Set(tokenize(d.content)));
  const allTerms = [...new Set(termSets.flatMap((set) => [...set]))];

  // Jaccard-style similarity between the first two documents
  const [a, b] = termSets;
  let shared = 0;
  for (const term of a) if (b.has(term)) shared++;
  const similarity = a.size + b.size ? shared / (a.size + b.size - shared) : 0;

  const commonThemes = allTerms
    .filter((term) => termSets.every((set) => set.has(term)))
    .slice(0, 10);

  const uniqueInsights = docs.map((doc, i) => {
    const own = termSets[i];
    const others = termSets.filter((_, j) => j !== i);
    const unique = [...own].filter((term) => !others.some((set) => set.has(term))).slice(0, 8);
    return {
      document_name: doc.fileName,
      insight: unique.length
        ? `Distinctive topics: ${unique.join(", ")}`
        : "No strongly distinctive topics detected",
    };
  });

  const conflicts = commonThemes.slice(0, 3).map((topic) => ({
    topic,
    doc1_view: `${topic} appears in ${docs[0].fileName} with different surrounding context.`,
    doc2_view: `${topic} appears in ${docs[1].fileName} with different surrounding context.`,
    explanation: "Offline comparison flags shared topics whose context differs — review manually for real conflicts.",
  }));

  return {
    overview: `Offline comparison of ${docs.length} documents (${docs
      .map((d) => d.fileName)
      .join(", ")}). ${OFFLINE_MARKER}`,
    common_themes: commonThemes,
    conflicts,
    unique_insights: uniqueInsights,
    consolidated_summary: topSentencesAbout(
      docs.map((d) => d.content).join(" "),
      commonThemes.slice(0, 6),
      4
    ).join(" "),
    similarity_score: Math.round(similarity * 100),
    recommendation:
      similarity > 0.35
        ? "The documents overlap substantially — consolidate them into one master version."
        : "The documents are largely complementary — keep both and cross-reference shared themes.",
  };
}

/* ------------------------------------------------------------------ */
/* 5. Offline document extraction (client-side, any common type)       */
/* ------------------------------------------------------------------ */

export interface OfflineExtractResult {
  fileName: string;
  mimeType: string;
  extractedText: string;
  wordCount: number;
  kind: string;
  meta: Record<string, unknown>;
}

const TEXT_LIKE =
  /\.(txt|csv|tsv|md|markdown|json|xml|html?|log|yml|yaml|ini|cfg|sql|js|ts|css)$/i;

/** Inflate a DEFLATE stream in the browser (DecompressionStream, no deps) */
async function inflateBytes(data: Uint8Array, format: "deflate" | "deflate-raw"): Promise<Uint8Array> {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("This browser cannot decompress this file type");
  }
  const stream = new Blob([data as unknown as BlobPart])
    .stream()
    .pipeThrough(new DecompressionStream(format));
  const buffer = await new Response(stream).arrayBuffer();
  return new Uint8Array(buffer);
}

/** Extract human text from PDF content stream bytes (Tj / TJ operators) */
function textFromContentStream(bytes: Uint8Array): string {
  const latin = Array.from(bytes, (b) => String.fromCharCode(b)).join("");
  const out: string[] = [];
  // (string) Tj  and  [(s1) num (s2)] TJ
  const re = /\((?:\\.|[^\\()])*\)|<[0-9A-Fa-f\s]+>/g;
  for (const match of latin.matchAll(/(?:\((?:\\.|[^\\()])*\)\s*(?:Tj|TJ|'|")?)|(?:\[[^\]]*\]\s*TJ)/g)) {
    for (const literal of match[0].match(re) ?? []) {
      if (literal.startsWith("(")) {
        const inner = literal
          .slice(1, -1)
          .replace(/\\([nrtbf()\\])/g, (_, c) =>
            c === "n" ? "\n" : c === "r" ? "" : c === "t" ? "\t" : c === "b" || c === "f" ? "" : c
          );
        out.push(inner);
      } else {
        // hex string <...> → try latin1 pairs
        const hex = literal.slice(1, -1).replace(/\s+/g, "");
        if (hex.length >= 4 && hex.length % 4 === 0) {
          // UTF-16BE hex string
          let decoded = "";
          for (let i = 0; i < hex.length; i += 4) {
            const code = parseInt(hex.slice(i, i + 4), 16);
            if (code > 0 && code < 0xfffd) decoded += String.fromCharCode(code);
          }
          if (decoded.trim()) out.push(decoded);
        } else if (hex.length % 2 === 0 && hex.length > 0) {
          let decoded = "";
          for (let i = 0; i < hex.length; i += 2) {
            const code = parseInt(hex.slice(i, i + 2), 16);
            if (code >= 32) decoded += String.fromCharCode(code);
          }
          if (decoded.trim()) out.push(decoded);
        }
      }
    }
  }
  return out.join(" ").replace(/[ \t]{2,}/g, " ").trim();
}

/** ASCII85 (base-85) decode — used by PDF generators like reportlab */
function ascii85Decode(data: Uint8Array): Uint8Array {
  let text = "";
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    if ((c >= 33 && c <= 117) || c === 122) text += String.fromCharCode(c);
  }
  if (text.startsWith("<~")) text = text.slice(2);
  const tilde = text.indexOf("~>");
  if (tilde >= 0) text = text.slice(0, tilde);
  const out: number[] = [];
  const group: number[] = [];
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === "z" && group.length === 0) {
      out.push(0, 0, 0, 0);
      continue;
    }
    group.push(c.charCodeAt(0) - 33);
    if (group.length === 5) {
      let value = 0;
      for (const g of group) value = value * 85 + g;
      out.push((value >>> 24) & 255, (value >>> 16) & 255, (value >>> 8) & 255, value & 255);
      group.length = 0;
    }
  }
  if (group.length > 1) {
    const padded = [...group];
    while (padded.length < 5) padded.push(84); // pad with 'u'
    let value = 0;
    for (const g of padded) value = value * 85 + g;
    const bytes4 = [(value >>> 24) & 255, (value >>> 16) & 255, (value >>> 8) & 255, value & 255];
    out.push(...bytes4.slice(0, group.length - 1));
  }
  return new Uint8Array(out);
}

/**
 * Decode a PDF content stream according to its /Filter dictionary entry.
 * Handles raw, FlateDecode, ASCII85Decode and the ASCII85+Flate chain —
 * the filter combinations produced by common generators (reportlab,
 * pdfmake, wkhtmltopdf, Word/LibreOffice exports).
 */
async function decodePdfStream(
  slice: Uint8Array,
  dict: string
): Promise<Uint8Array | null> {
  const hasAscii85 = /ASCII85Decode/i.test(dict);
  const hasFlate = /FlateDecode/i.test(dict);
  const attempts: Array<() => Promise<Uint8Array>> = [];
  if (hasAscii85 && hasFlate) {
    attempts.push(async () => await inflateBytes(ascii85Decode(slice), "deflate"));
    attempts.push(async () => ascii85Decode(slice));
  } else if (hasAscii85) {
    attempts.push(async () => ascii85Decode(slice));
    attempts.push(async () => await inflateBytes(slice, "deflate"));
  } else if (hasFlate) {
    attempts.push(async () => await inflateBytes(slice, "deflate"));
  } else {
    // Unknown/undetected filter — try every strategy
    attempts.push(async () => slice);
    attempts.push(async () => await inflateBytes(slice, "deflate"));
    attempts.push(async () => await inflateBytes(ascii85Decode(slice), "deflate"));
  }
  for (const attempt of attempts) {
    try {
      const result = await attempt();
      if (result.length > 0) return result;
    } catch {
      /* try the next strategy */
    }
  }
  return null;
}

/** Minimal in-browser ZIP reader — returns decompressed entries by name */
async function readZipEntries(
  bytes: Uint8Array
): Promise<Array<{ name: string; data: Uint8Array }>> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const entries: Array<{ name: string; data: Uint8Array }> = [];
  // Local file header signature PK\x03\x04
  for (let i = 0; i < bytes.length - 30; i++) {
    if (view.getUint32(i, true) !== 0x04034b50) continue;
    const method = view.getUint16(i + 8, true);
    const compressedSize = view.getUint32(i + 18, true);
    const nameLength = view.getUint16(i + 26, true);
    const extraLength = view.getUint16(i + 28, true);
    if (compressedSize === 0 && view.getUint32(i + 22, true) === 0) {
      // directory or empty entry — skip by name length anyway
    }
    const nameStart = i + 30;
    const name = new TextDecoder().decode(bytes.subarray(nameStart, nameStart + nameLength));
    const dataStart = nameStart + nameLength + extraLength;
    if (dataStart + compressedSize > bytes.length) break;
    const raw = bytes.subarray(dataStart, dataStart + compressedSize);
    if (method === 0) {
      entries.push({ name, data: raw });
    } else if (method === 8) {
      try {
        entries.push({ name, data: await inflateBytes(raw, "deflate-raw") });
      } catch {
        /* skip unreadable entry */
      }
    }
    i = dataStart + compressedSize - 1; // continue after this entry
  }
  return entries;
}

function xmlToText(xml: string): string {
  return xml
    .replace(/<w:p[ >]/g, "\n<w:p ")
    .replace(/<a:p[ >]/g, "\n<a:p ")
    .replace(/<\/w:tr>/g, "\n")
    .replace(/<\/w:tc>/g, " | ")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** XLSX sheet XML → CSV-ish rows (inline strings + shared strings index) */
function xlsxSheetToRows(
  sheetXml: string,
  sharedStrings: string[]
): string[][] {
  const rows: string[][] = [];
  for (const rowMatch of sheetXml.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
    const cells: string[] = [];
    for (const cellMatch of rowMatch[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
      const attrs = cellMatch[1] ?? "";
      const type = /t="(\w+)"/.exec(attrs)?.[1] ?? "";
      const inner = cellMatch[2];
      const valueMatch = /<v>([\s\S]*?)<\/v>/.exec(inner);
      const inlineMatch = /<is>[\s\S]*?<t[^>]*>([\s\S]*?)<\/t>[\s\S]*?<\/is>/.exec(inner);
      let value = "";
      if (type === "s" && valueMatch) {
        value = sharedStrings[Number(valueMatch[1])] ?? "";
      } else if (type === "inlineStr" && inlineMatch) {
        value = inlineMatch[1];
      } else if (valueMatch) {
        value = valueMatch[1];
      }
      cells.push(value);
    }
    rows.push(cells);
  }
  return rows;
}

export async function offlineExtractDocument(file: File): Promise<OfflineExtractResult> {
  const fileName = file.name || "upload";
  const mimeType = file.type || "";
  const ext = (/\.([a-zA-Z0-9]+)$/.exec(fileName)?.[1] ?? "").toLowerCase();
  const bytes = new Uint8Array(await file.arrayBuffer());

  const finish = (
    extractedText: string,
    kind: string,
    meta: Record<string, unknown> = {}
  ): OfflineExtractResult => ({
    fileName,
    mimeType,
    extractedText,
    wordCount: extractedText.trim().split(/\s+/).filter(Boolean).length,
    kind,
    meta,
  });

  // --- text-like files: direct read -------------------------------------
  if (TEXT_LIKE.test(fileName) || mimeType.startsWith("text/") || mimeType === "application/json") {
    const text = new TextDecoder().decode(bytes);
    const isTable = ext === "csv" || ext === "tsv";
    return finish(text, isTable ? "table" : "text", isTable ? { delimiter: ext === "tsv" ? "tab" : "comma" } : {});
  }

  // --- PDF: inflate content streams and pull the text operators ---------
  if (ext === "pdf" || mimeType === "application/pdf") {
    const latin = Array.from(bytes.subarray(0, Math.min(bytes.length, 4_000_000)), (b) =>
      String.fromCharCode(b)
    ).join("");
    const chunks: string[] = [];
    let pages = 0;
    // Count pages heuristically
    pages = (latin.match(/\/Type\s*\/Page[^s]/g) ?? []).length || 1;
    // 1) uncompressed content streams
    for (const m of latin.matchAll(/BT([\s\S]{0,200000}?)ET/g)) {
      const text = textFromContentStream(new TextEncoder().encode(m[1]));
      if (text) chunks.push(text);
    }
    // 2) encoded content streams (FlateDecode, optionally after ASCII85Decode)
    for (const m of latin.matchAll(/(?<!end)stream\r?\n/g)) {
      const start = (m.index ?? 0) + m[0].length;
      const end = latin.indexOf("endstream", start);
      if (end < 0) continue;
      const slice = bytes.subarray(start, end);
      if (slice.length < 8) continue;
      // Read the stream's dictionary filters (search back to the last "obj")
      const dictStart = latin.lastIndexOf(" obj", (m.index ?? 0));
      const dict = dictStart >= 0 ? latin.slice(dictStart, m.index ?? start) : "";
      const decoded = await decodePdfStream(slice, dict);
      if (decoded) {
        const text = textFromContentStream(decoded);
        if (text) chunks.push(text);
      }
    }
    const text = chunks.join("\n\n").replace(/[ \t]{2,}/g, " ").trim();
    if (!text) {
      throw new Error(
        "This PDF could not be read in the browser (it may be scanned images). Upload it on a full-server deployment or extract the text first."
      );
    }
    return finish(text, "text", { pages, method: "browser-pdf-extract" });
  }

  // --- OOXML (docx/xlsx/pptx) and generic ZIP via the built-in reader ----
  const isZip = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b;
  if (isZip) {
    const entries = await readZipEntries(bytes);
    const byName = (needle: RegExp) => entries.filter((e) => needle.test(e.name));

    if (ext === "docx" || /word\/document\.xml/.test(entries.map((e) => e.name).join("|"))) {
      const docXml = entries.find((e) => e.name === "word/document.xml");
      if (docXml) {
        const text = xmlToText(new TextDecoder().decode(docXml.data));
        return finish(text, "text", { method: "browser-docx-extract" });
      }
    }
    if (ext === "xlsx" || ext === "xls" || entries.some((e) => e.name.startsWith("xl/worksheets/"))) {
      const sharedXml = entries.find((e) => e.name === "xl/sharedStrings.xml");
      const sharedStrings: string[] = [];
      if (sharedXml) {
        const xml = new TextDecoder().decode(sharedXml.data);
        for (const m of xml.matchAll(/<si>[\s\S]*?<\/si>/g)) {
          const texts = [...m[0].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((t) => t[1]).join("");
          sharedStrings.push(texts);
        }
      }
      const sheets = byName(/^xl\/worksheets\/sheet\d+\.xml$/);
      const parts: string[] = [];
      for (const sheet of sheets.slice(0, 3)) {
        const rows = xlsxSheetToRows(new TextDecoder().decode(sheet.data), sharedStrings);
        const csv = rows.map((row) => row.map((c) => c.replace(/\s+/g, " ").trim()).join(",")).join("\n");
        if (csv.trim()) {
          parts.push(csv);
        }
      }
      const text = parts.join("\n");
      if (text) {
        return finish(text, "table", { method: "browser-xlsx-extract", sheets: sheets.length });
      }
    }
    if (ext === "pptx") {
      const slides = byName(/^ppt\/slides\/slide\d+\.xml$/).sort(
        (a, b) => Number(a.name.replace(/\D/g, "")) - Number(b.name.replace(/\D/g, ""))
      );
      const text = slides
        .map((s, i) => `# Slide ${i + 1}\n${xmlToText(new TextDecoder().decode(s.data))}`)
        .join("\n\n");
      if (text) return finish(text, "text", { method: "browser-pptx-extract", slides: slides.length });
    }
    // generic zip — list contents
    if (entries.length) {
      return finish(
        entries.map((e) => e.name).join("\n"),
        "text",
        { method: "browser-zip-listing", entries: entries.length }
      );
    }
  }

  // --- images: honest limitation -----------------------------------------
  if (mimeType.startsWith("image/") || ["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) {
    throw new Error(
      "Images need AI vision extraction — configure a personal AI key in Settings → AI Provider (or use a full-server deployment)."
    );
  }

  throw new Error(
    "Unsupported file type for offline extraction. Text, PDF, Word, Excel, PowerPoint and CSV files are supported in browser mode."
  );
}

/* ------------------------------------------------------------------ */
/* 6. Offline data analysis (Excel / CSV data studio)                  */
/* ------------------------------------------------------------------ */

interface ParsedTable {
  headers: string[];
  rows: string[][];
}

function parseDelimited(text: string, delimiter: string): ParsedTable {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (inQuotes) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += char;
      }
      continue;
    }
    if (char === '"') {
      inQuotes = true;
    } else if (char === delimiter) {
      row.push(field.trim());
      field = "";
    } else if (char === "\n") {
      row.push(field.trim());
      rows.push(row);
      row = [];
      field = "";
    } else if (char !== "\r") {
      field += char;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field.trim());
    rows.push(row);
  }
  const clean = rows.filter((r) => r.some((c) => c.length > 0));
  const headers = clean[0]?.map((h, i) => h || `column ${i + 1}`) ?? [];
  return { headers, rows: clean.slice(1) };
}

function coerceNumber(value: string): number | null {
  if (value === "" || value == null) return null;
  const cleaned = value.replace(/[,%\s]/g, "").replace(/[^\d.eE+-]/g, "");
  if (!cleaned || Number.isNaN(Number(cleaned))) return null;
  return Number(cleaned);
}

export async function offlineAnalyzeData(data: {
  fileName: string;
  content: string;
  mimeType?: string;
}): Promise<{
  analysis: Record<string, unknown>;
  charts: Array<Record<string, unknown>>;
  insights: Record<string, unknown>;
}> {
  const content = data.content ?? "";
  const lines = content.split(/\r?\n/).filter((l) => l.trim().length > 0);
  // Find the table start: the first line (within 8) carrying a delimiter —
  // tolerates preamble lines such as report titles or sheet markers.
  let tableStart = 0;
  let delimiterGuess = ",";
  for (let i = 0; i < Math.min(8, lines.length); i++) {
    const comma = (lines[i].match(/,/g) ?? []).length;
    const semi = (lines[i].match(/;/g) ?? []).length;
    const tab = (lines[i].match(/\t/g) ?? []).length;
    const best = Math.max(comma, semi, tab);
    if (best > 0) {
      delimiterGuess = tab >= comma && tab >= semi ? "\t" : semi >= comma ? ";" : ",";
      tableStart = i;
      break;
    }
  }

  const table = parseDelimited(lines.slice(tableStart).join("\n"), delimiterGuess);
  const isTabular = table.headers.length >= 2 && table.rows.length >= 2;
  const charts: Array<Record<string, unknown>> = [];

  if (isTabular) {
    // ---- column statistics ----
    const statistics = table.headers.map((column, index) => {
      const values = table.rows.map((row) => row[index] ?? "");
      const numbers = values.map(coerceNumber).filter((n): n is number => n !== null);
      const nonEmpty = values.filter((v) => v.length > 0);
      const stat: Record<string, unknown> = {
        column,
        type: numbers.length >= nonEmpty.length * 0.7 && nonEmpty.length > 0 ? "number" : "text",
        missing: values.length - nonEmpty.length,
        unique: new Set(values).size,
      };
      if (stat.type === "number" && numbers.length) {
        stat.min = Math.min(...numbers);
        stat.max = Math.max(...numbers);
        stat.mean = Math.round((numbers.reduce((a, b) => a + b, 0) / numbers.length) * 100) / 100;
      }
      return stat;
    });

    // ---- chart generation ----
    const numericColumns = statistics
      .map((s, i) => ({ s, i }))
      .filter(({ s }) => s.type === "number");
    const categoricalColumn = statistics.findIndex(
      (s) => s.type === "text" && Number(s.unique) <= Math.max(2, Math.min(12, table.rows.length))
    );
    const labelColumn = categoricalColumn >= 0 ? categoricalColumn : 0;

    if (categoricalColumn >= 0 && numericColumns.length) {
      const grouped = new Map<string, Record<string, number>>();
      for (const row of table.rows) {
        const key = row[categoricalColumn] || "(blank)";
        const bucket = grouped.get(key) ?? {};
        for (const { i } of numericColumns.slice(0, 3)) {
          const n = coerceNumber(row[i] ?? "");
          if (n !== null) bucket[table.headers[i]] = (bucket[table.headers[i]] ?? 0) + n;
        }
        grouped.set(key, bucket);
      }
      const chartData = [...grouped.entries()]
        .slice(0, 10)
        .map(([label, values]) => ({ [table.headers[labelColumn]]: label, ...values }));
      charts.push({
        id: "chart-by-category",
        title: `${numericColumns[0].s.column} by ${table.headers[categoricalColumn]}`,
        type: "bar",
        xKey: table.headers[labelColumn],
        yKeys: numericColumns.slice(0, 3).map(({ s }) => s.column as string),
        data: chartData,
        description: `Aggregated ${numericColumns.map(({ s }) => s.column).join(", ")} for each ${table.headers[categoricalColumn]}. ${OFFLINE_MARKER}`,
      });
    }
    if (numericColumns.length) {
      const i = numericColumns[0].i;
      charts.push({
        id: "chart-trend",
        title: `${table.headers[i]} across rows`,
        type: "line",
        xKey: "row",
        yKeys: [table.headers[i]],
        data: table.rows.slice(0, 30).map((row, idx) => ({
          row: idx + 1,
          [table.headers[i]]: coerceNumber(row[i] ?? "") ?? 0,
        })),
        description: `Trend of ${table.headers[i]} over the first ${Math.min(30, table.rows.length)} rows. ${OFFLINE_MARKER}`,
      });
      const top = [...table.rows]
        .map((row) => ({ label: String(row[labelColumn] ?? "(blank)"), value: coerceNumber(row[i] ?? "") ?? 0 }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 6);
      const sum = top.reduce((a, b) => a + b.value, 0) || 1;
      charts.push({
        id: "chart-share",
        title: `Top ${table.headers[labelColumn]} by ${table.headers[i]}`,
        type: "pie",
        xKey: "label",
        yKeys: ["value"],
        data: top.map((t) => ({ label: t.label, value: Math.round((t.value / sum) * 1000) / 10 })),
        description: `Share of the top ${top.length} entries. ${OFFLINE_MARKER}`,
      });
    }

    const keyFindings = statistics
      .filter((s) => s.type === "number" && typeof s.mean === "number")
      .slice(0, 5)
      .map(
        (s) =>
          `${s.column}: mean ${s.mean}, range ${s.min}–${s.max} (${s.missing ?? 0} missing values).`
      );

    return {
      analysis: {
        dataset_type: "tabular",
        rows: table.rows.length,
        columns: table.headers.length,
        summary: `Parsed ${table.rows.length} rows × ${table.headers.length} columns from ${data.fileName}. ${OFFLINE_MARKER}`,
        key_findings: keyFindings.length
          ? keyFindings
          : ["No numeric columns detected — the sheet appears to be textual."],
        statistics,
        recommendations: [
          "Review the generated charts — they aggregate the numeric columns automatically.",
          "Add a free AI key in Settings → AI Provider for AI-written narrative analysis.",
        ],
      },
      charts,
      insights: { dataset_type: "tabular", summary: `${table.rows.length} rows analyzed offline` },
    };
  }

  // ---- non-tabular text ----
  const freq = wordFrequencies(content, 10);
  const sentences = splitSentences(content);
  if (freq.length >= 2) {
    charts.push({
      id: "chart-terms",
      title: "Most frequent terms",
      type: "bar",
      xKey: "term",
      yKeys: ["count"],
      data: freq.map((f) => ({ term: f.term, count: f.count })),
      description: `Term frequency across ${data.fileName}. ${OFFLINE_MARKER}`,
    });
  }
  return {
    analysis: {
      dataset_type: "text",
      rows: sentences.length,
      columns: 1,
      summary: `${data.fileName} contains ${content.length.toLocaleString()} characters in ${sentences.length} sentences. ${OFFLINE_MARKER}`,
      key_findings: topSentencesAbout(content, freq.slice(0, 6).map((f) => f.term), 5),
      recommendations: [
        "Upload a CSV or Excel export for column statistics and charts.",
        "Add a free AI key in Settings → AI Provider for AI narrative analysis.",
      ],
    },
    charts,
    insights: { dataset_type: "text", summary: "Text document analyzed offline" },
  };
}

/* ------------------------------------------------------------------ */
/* 7. Offline grounded chat                                            */
/* ------------------------------------------------------------------ */

export async function offlineChat(data: {
  sessionId: string;
  message: string;
  documentId?: string;
  documentContext?: { fileName: string; content: string };
}): Promise<{ reply: string }> {
  const message = (data.message ?? "").trim();
  const context = data.documentContext;

  if (context) {
    const terms = tokenize(message).slice(0, 6);
    const relevant = terms.length ? topSentencesAbout(context.content, terms, 6) : [];
    if (relevant.length) {
      return {
        reply:
          `From "${context.fileName}", the passages most relevant to your question:\n\n` +
          relevant.map((s) => `• ${s}`).join("\n") +
          `\n\n${OFFLINE_MARKER}`,
      };
    }
    const freq = wordFrequencies(context.content, 5);
    return {
      reply:
        `I could not find passages matching "${message}" in "${context.fileName}". ` +
        `The document's main topics are: ${freq.map((f) => f.term).join(", ")}. ` +
        `Try asking about one of those topics. ${OFFLINE_MARKER}`,
    };
  }

  return {
    reply:
      `I'm running in offline mode, so I can answer general questions and analyze documents you upload in the AI Studio. ` +
      `For full conversational intelligence, add a free AI key in Settings → AI Provider (OpenRouter, Groq, Gemini or OpenAI all work). ` +
      `You asked: "${message}". ${OFFLINE_MARKER}`,
  };
}

/* ------------------------------------------------------------------ */
/* 8. Score helpers reused by the local API layer                      */
/* ------------------------------------------------------------------ */

export function offlineScorePercent(total: number): number {
  return scorePercent(total, TOTAL_MAX_SCORE);
}
