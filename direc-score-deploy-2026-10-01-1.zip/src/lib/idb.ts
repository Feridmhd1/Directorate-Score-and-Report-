"use client";

/**
 * Minimal IndexedDB key-value store (zero dependencies).
 *
 * Used by the browser data engine (local-db.ts) to persist large values —
 * uploaded documents (Blobs) and big JSON collections — that would blow the
 * ~5 MB localStorage quota. Works in every modern browser and survives
 * reloads and restarts, which is what makes the app fully functional on
 * static/serverless hosts (Netlify) where the server filesystem is
 * read-only.
 */

const DB_NAME = "direcscore";
const DB_VERSION = 1;
const STORE = "kv";

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not available"));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const database = req.result;
      if (!database.objectStoreNames.contains(STORE)) {
        database.createObjectStore(STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
  });
  return dbPromise;
}

function tx<T>(
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T>
): Promise<T> {
  return openDb().then(
    (database) =>
      new Promise<T>((resolve, reject) => {
        const transaction = database.transaction(STORE, mode);
        const request = run(transaction.objectStore(STORE));
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error ?? new Error("IndexedDB request failed"));
      })
  );
}

export async function idbGet<T>(key: string): Promise<T | undefined> {
  try {
    return await tx<T>("readonly", (store) => store.get(key) as IDBRequest<T>);
  } catch {
    return undefined;
  }
}

export async function idbSet(key: string, value: unknown): Promise<void> {
  await tx("readwrite", (store) => store.put(value, key) as IDBRequest<IDBValidKey>);
}

export async function idbDelete(key: string): Promise<void> {
  await tx("readwrite", (store) => store.delete(key) as unknown as IDBRequest<undefined>);
}

export async function idbClearAll(): Promise<void> {
  await tx("readwrite", (store) => store.clear() as unknown as IDBRequest<undefined>);
}

/** Read every key in the store (used by the full backup export) */
export async function idbKeys(): Promise<string[]> {
  try {
    const keys = await tx<IDBValidKey[]>("readonly", (store) => store.getAllKeys());
    return keys.map(String);
  } catch {
    return [];
  }
}

/** Read every value in the store as [key, value] pairs (full backup export) */
export async function idbEntries(): Promise<Array<[string, unknown]>> {
  try {
    const keys = await idbKeys();
    const out: Array<[string, unknown]> = [];
    for (const key of keys) {
      out.push([key, await idbGet(key)]);
    }
    return out;
  } catch {
    return [];
  }
}

/** Restore a set of [key, value] pairs (backup import) */
export async function idbRestore(entries: Array<[string, unknown]>): Promise<void> {
  for (const [key, value] of entries) {
    await idbSet(key, value);
  }
}
