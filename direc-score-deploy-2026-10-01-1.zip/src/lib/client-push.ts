"use client";

/**
 * Browser-side delivery engine (local mode).
 *
 * Sends score summaries, file notifications and reminders directly from the
 * browser:
 *
 *  - Telegram → real delivery through the Bot API (api.telegram.org allows
 *    cross-origin browser calls). A bot token is configured once in the
 *    Automation page and stored in this browser.
 *  - WhatsApp → no public browser API exists, so the channel produces a
 *    wa.me deep link (status "queued" with a one-tap manual-send URL).
 *    When a WhatsApp Cloud API token is configured the send attempt runs
 *    through the server route instead (works on full-server deployments).
 *  - Email → mailto compose link (status "queued").
 *
 * Every attempt is recorded as a DeliveryLog row in the browser database so
 * the Automation page history keeps working.
 */

import {
  appendDeliveryLogs,
  getChannels,
  nowIso,
  uid,
  type LocalChannel,
} from "@/lib/local-db";
import { buildMailtoLink, buildWaMeLink } from "@/lib/message-templates";
import type { DeliveryLogDTO } from "@/lib/types";

export interface DeliveryOutcome {
  status: "sent" | "failed" | "queued";
  detail: string;
}

interface TelegramSendResponse {
  ok?: boolean;
  description?: string;
}

function errorText(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/** Send a plain text message through the Telegram Bot API from the browser */
export async function sendTelegramText(
  botToken: string,
  target: string,
  message: string
): Promise<DeliveryOutcome> {
  if (!botToken) {
    return { status: "queued", detail: "Bot token not configured — add it in the Automation page" };
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: target, text: message }),
    });
    let json: TelegramSendResponse | null = null;
    try {
      json = (await res.json()) as TelegramSendResponse;
    } catch {
      /* non-JSON */
    }
    if (res.ok && json?.ok) {
      return { status: "sent", detail: `Delivered via Telegram bot to ${target || "chat"}` };
    }
    return { status: "failed", detail: json?.description || `Telegram HTTP ${res.status}` };
  } catch (e) {
    return { status: "failed", detail: `Telegram request failed: ${errorText(e)}` };
  }
}

/** Send a document through the Telegram Bot API from the browser */
export async function sendTelegramDocument(
  botToken: string,
  target: string,
  file: Blob,
  fileName: string,
  caption = ""
): Promise<DeliveryOutcome> {
  if (!botToken) {
    return { status: "queued", detail: "Bot token not configured — add it in the Automation page" };
  }
  try {
    const form = new FormData();
    form.append("chat_id", target);
    form.append("document", file, fileName);
    if (caption) form.append("caption", caption.slice(0, 900));
    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
      method: "POST",
      body: form,
    });
    let json: TelegramSendResponse | null = null;
    try {
      json = (await res.json()) as TelegramSendResponse;
    } catch {
      /* non-JSON */
    }
    if (res.ok && json?.ok) {
      return { status: "sent", detail: `Document delivered via Telegram to ${target || "chat"}` };
    }
    return { status: "failed", detail: json?.description || `Telegram HTTP ${res.status}` };
  } catch (e) {
    return { status: "failed", detail: `Telegram document failed: ${errorText(e)}` };
  }
}

/**
 * Optional server relay for portal submissions: when TELEGRAM_BOT_TOKEN and
 * TELEGRAM_CHAT_ID environment variables are configured on the deployment,
 * uploads made by directorates on THEIR OWN devices can still be delivered
 * automatically to the supervisor. Missing configuration → "not-configured"
 * outcome so callers can fall back to hand-off links.
 */
export async function relayTelegramFromServer(
  message: string,
  file?: { blob: Blob; fileName: string }
): Promise<DeliveryOutcome> {
  try {
    const form = new FormData();
    form.append("message", message);
    if (file) {
      form.append("file", file.blob, file.fileName);
    }
    const res = await fetch("/api/push/telegram", { method: "POST", body: form });
    const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
    if (res.ok && json?.ok) {
      return { status: "sent", detail: "Delivered via Telegram (server relay)" };
    }
    return {
      status: "queued",
      detail:
        json?.error === "not-configured"
          ? "Server Telegram relay not configured (optional TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID deployment variables)"
          : `Server relay unavailable (HTTP ${res.status})`,
    };
  } catch (e) {
    return { status: "queued", detail: `Server relay unreachable: ${errorText(e)}` };
  }
}

/** Build the manual hand-off links for WhatsApp / Email */
export function handoffLinks(channel: { type: string; target: string }, message: string): {
  status: "sent" | "failed" | "queued";
  detail: string;
  url?: string;
} {
  if (channel.type === "whatsapp" && channel.target) {
    return {
      status: "queued",
      detail: `One-tap WhatsApp hand-off to ${channel.target} (message pre-filled — press send in WhatsApp)`,
      url: buildWaMeLink(channel.target, message),
    };
  }
  if (channel.type === "email" && channel.target) {
    return {
      status: "queued",
      detail: `Email hand-off to ${channel.target} (opens your mail app with the message ready)`,
      url: buildMailtoLink(channel.target, "Direc-Score — የሀረሪ ክልል ጤና ቢሮ", message),
    };
  }
  return { status: "queued", detail: "Channel target not configured" };
}

function toLog(
  channel: LocalChannel,
  outcome: DeliveryOutcome & { url?: string },
  message: string,
  meta: { directorateKey?: string; directorateName?: string; quarter?: string }
): DeliveryLogDTO {
  return {
    id: uid(),
    channelType: channel.type,
    target: channel.target,
    directorateKey: meta.directorateKey ?? "",
    directorateName: meta.directorateName ?? "",
    quarter: meta.quarter ?? "",
    message,
    status: outcome.status,
    detail: outcome.detail,
    createdAt: nowIso(),
  };
}

export interface BrowserDelivery {
  logs: DeliveryLogDTO[];
  /** wa.me / mailto hand-off URLs the UI should surface as buttons */
  handoffs: Array<{ channelType: string; label: string; url: string; detail: string }>;
}

/**
 * Deliver one message through every enabled browser channel.
 * Telegram delivers for real; WhatsApp/Email become one-tap hand-off links.
 */
export async function deliverThroughBrowserChannels(
  message: string,
  meta: { directorateKey?: string; directorateName?: string; quarter?: string } = {},
  options: { channels?: LocalChannel[]; persist?: boolean } = {}
): Promise<BrowserDelivery> {
  const channels = options.channels ?? (await getChannels());
  const enabled = channels.filter((c) => c.enabled);
  const logs: DeliveryLogDTO[] = [];
  const handoffs: BrowserDelivery["handoffs"] = [];

  for (const channel of enabled) {
    if (channel.type === "telegram") {
      const outcome = await sendTelegramText(channel.botToken, channel.target, message);
      logs.push(toLog(channel, outcome, message, meta));
    } else if (channel.type === "whatsapp" || channel.type === "email") {
      const outcome = handoffLinks(channel, message);
      if (outcome.url) {
        handoffs.push({
          channelType: channel.type,
          label:
            channel.label ||
            (channel.type === "whatsapp" ? `WhatsApp ${channel.target}` : `Email ${channel.target}`),
          url: outcome.url,
          detail: outcome.detail,
        });
      }
      logs.push(toLog(channel, { status: outcome.status, detail: outcome.detail }, message, meta));
    } else {
      logs.push(toLog(channel, { status: "failed", detail: `Unknown channel type "${channel.type}"` }, message, meta));
    }
  }

  if (options.persist !== false) {
    await appendDeliveryLogs(logs);
  }
  return { logs, handoffs };
}

/** One-tap opening of a hand-off URL (wa.me / mailto) */
export function openHandoff(url: string): void {
  try {
    window.open(url, "_blank", "noopener,noreferrer");
  } catch {
    window.location.href = url;
  }
}
