import { db } from "@/lib/db";

/**
 * Server-side key/value application settings backed by the AppSetting table.
 * Secret values (Drive OAuth credentials) are write-only via the public API.
 */

export const SETTING_KEYS = {
  organizationName: "organizationName",
  logoDataUrl: "logoDataUrl",
  autoBackupEnabled: "autoBackupEnabled",
  backupFrequency: "backupFrequency",
  lastBackupAt: "lastBackupAt",
  lastBackupStatus: "lastBackupStatus",
  lastBackupDetail: "lastBackupDetail",
  driveClientId: "driveClientId",
  driveClientSecret: "driveClientSecret",
  driveRefreshToken: "driveRefreshToken",
  driveFolderId: "driveFolderId",
  filingPin: "filingPin",
  automationPin: "automationPin",
  settingsPin: "settingsPin",
  /** Quarterly-report submission deadline: JSON { quarter, date(ISO yyyy-mm-dd) } */
  reportDeadline: "reportDeadline",
  /** Date (yyyy-mm-dd) of the last automatic pre-deadline reminder blast */
  deadlineLastAuto: "deadlineLastAuto",
} as const;

/** Default PIN for the secure Document Filing room (per requirement: 3472) */
export const DEFAULT_FILING_PIN = "3472";

/** Default password required to EDIT score/document delivery automation (per requirement: secured edit) */
export const DEFAULT_AUTOMATION_PIN = "3472";

/** Default password required to open/change the Settings page (per requirement: secured settings) */
export const DEFAULT_SETTINGS_PIN = "3472";

export type SettingKey = (typeof SETTING_KEYS)[keyof typeof SETTING_KEYS];

/** Small in-process cache so hot paths (logo, settings) avoid repeated DB hits */
const cache = new Map<string, { value: string; expires: number }>();
const TTL_MS = 15_000;

export async function getSetting(key: SettingKey): Promise<string> {
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return hit.value;
  const row = await db.appSetting.findUnique({ where: { key } });
  const value = row?.value ?? "";
  cache.set(key, { value, expires: Date.now() + TTL_MS });
  return value;
}

export async function setSetting(key: SettingKey, value: string): Promise<void> {
  await db.appSetting.upsert({
    where: { key },
    create: { key, value },
    update: { value },
  });
  cache.set(key, { value, expires: Date.now() + TTL_MS });
}

export async function setSettings(entries: Record<string, string>): Promise<void> {
  await Promise.all(
    Object.entries(entries).map(([key, value]) => setSetting(key as SettingKey, value))
  );
}

export async function getSettings(keys: SettingKey[]): Promise<Record<string, string>> {
  const rows = await db.appSetting.findMany({ where: { key: { in: keys } } });
  const out: Record<string, string> = {};
  for (const key of keys) out[key] = "";
  for (const row of rows) out[row.key] = row.value;
  // refresh the cache with fresh values
  const now = Date.now();
  for (const [k, v] of Object.entries(out)) cache.set(k, { value: v, expires: now + TTL_MS });
  return out;
}

export function invalidateSettingsCache(): void {
  cache.clear();
}

export function isTrue(value: string | undefined | null): boolean {
  return value === "true" || value === "1";
}
