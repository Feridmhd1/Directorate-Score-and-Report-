/**
 * AUTO-GENERATED from prisma/schema.prisma — do not edit by hand.
 * Regenerate with:  bun run db:schema-sql
 *
 * Idempotent SQLite DDL executed by the runtime database bootstrap
 * (src/lib/db-bootstrap.ts) so a fresh deployment creates its tables
 * automatically on first run. 31 statements.
 */
export const SCHEMA_SQL = `-- CreateTable
CREATE TABLE IF NOT EXISTS "User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "name" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "Session" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "token" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "DirectorateEvaluation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "directorateKey" TEXT NOT NULL,
    "directorateName" TEXT NOT NULL,
    "directorateShort" TEXT NOT NULL,
    "quarter" TEXT NOT NULL,
    "email" TEXT,
    "scoresJson" TEXT NOT NULL DEFAULT '{}',
    "answersJson" TEXT NOT NULL DEFAULT '{}',
    "commentsJson" TEXT NOT NULL DEFAULT '{}',
    "totalScore" REAL NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'completed',
    "attachmentsJson" TEXT NOT NULL DEFAULT '[]',
    "actionPlanJson" TEXT NOT NULL DEFAULT '[]',
    "aiGenerated" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "DocumentHistory" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "fileName" TEXT NOT NULL,
    "content" TEXT NOT NULL DEFAULT '',
    "contentLength" INTEGER NOT NULL DEFAULT 0,
    "wordCount" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'processing',
    "insightsJson" TEXT,
    "graphicsJson" TEXT,
    "chartsJson" TEXT,
    "finalReportJson" TEXT,
    "finalized" BOOLEAN NOT NULL DEFAULT false,
    "documentType" TEXT NOT NULL DEFAULT '',
    "language" TEXT NOT NULL DEFAULT '',
    "sentiment" TEXT NOT NULL DEFAULT '',
    "mimeType" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "Notification" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "type" TEXT NOT NULL DEFAULT 'evaluation_completed',
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "directorateKey" TEXT NOT NULL DEFAULT '',
    "directorateName" TEXT NOT NULL DEFAULT '',
    "quarter" TEXT NOT NULL DEFAULT '',
    "totalScore" REAL,
    "directorEmail" TEXT NOT NULL DEFAULT '',
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "AutomationChannel" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "type" TEXT NOT NULL DEFAULT 'telegram',
    "label" TEXT NOT NULL DEFAULT '',
    "target" TEXT NOT NULL DEFAULT '',
    "botToken" TEXT NOT NULL DEFAULT '',
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "DeliveryLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "channelType" TEXT NOT NULL DEFAULT '',
    "target" TEXT NOT NULL DEFAULT '',
    "directorateKey" TEXT NOT NULL DEFAULT '',
    "directorateName" TEXT NOT NULL DEFAULT '',
    "quarter" TEXT NOT NULL DEFAULT '',
    "message" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'queued',
    "detail" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "ChatMessage" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sessionId" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "documentId" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "AppSetting" (
    "key" TEXT NOT NULL PRIMARY KEY,
    "value" TEXT NOT NULL DEFAULT '',
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "QualityReport" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "directorateKey" TEXT NOT NULL,
    "quarter" TEXT NOT NULL DEFAULT '',
    "title" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL DEFAULT 'application/octet-stream',
    "size" INTEGER NOT NULL DEFAULT 0,
    "data" TEXT NOT NULL DEFAULT '',
    "note" TEXT NOT NULL DEFAULT '',
    "shareToken" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "DirectorateFeedback" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "directorateKey" TEXT NOT NULL,
    "directorateName" TEXT NOT NULL DEFAULT '',
    "quarter" TEXT NOT NULL DEFAULT '',
    "kind" TEXT NOT NULL DEFAULT 'comment',
    "message" TEXT NOT NULL,
    "contact" TEXT NOT NULL DEFAULT '',
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "FiledDocument" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'General',
    "fileName" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL DEFAULT 'application/octet-stream',
    "size" INTEGER NOT NULL DEFAULT 0,
    "data" TEXT NOT NULL DEFAULT '',
    "note" TEXT NOT NULL DEFAULT '',
    "shareToken" TEXT NOT NULL DEFAULT '',
    "scanVerdict" TEXT NOT NULL DEFAULT 'pending',
    "scanReportJson" TEXT NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "LinkItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'app',
    "description" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "EvaluatorAudit" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "directorateKey" TEXT NOT NULL,
    "directorateName" TEXT NOT NULL DEFAULT '',
    "quarter" TEXT NOT NULL DEFAULT '',
    "evaluationId" TEXT NOT NULL DEFAULT '',
    "answersJson" TEXT NOT NULL DEFAULT '{}',
    "commentsJson" TEXT NOT NULL DEFAULT '{}',
    "totalScore" REAL NOT NULL DEFAULT 0,
    "qualityScore" REAL NOT NULL DEFAULT 0,
    "verdict" TEXT NOT NULL DEFAULT 'review',
    "reportJson" TEXT NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "DirectorateContact" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "directorateKey" TEXT NOT NULL,
    "directorateName" TEXT NOT NULL DEFAULT '',
    "email" TEXT NOT NULL DEFAULT '',
    "whatsapp" TEXT NOT NULL DEFAULT '',
    "telegram" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "Session_token_key" ON "Session"("token");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "DirectorateEvaluation_quarter_idx" ON "DirectorateEvaluation"("quarter");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "DirectorateEvaluation_directorateKey_quarter_idx" ON "DirectorateEvaluation"("directorateKey", "quarter");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "DeliveryLog_createdAt_idx" ON "DeliveryLog"("createdAt");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "ChatMessage_sessionId_idx" ON "ChatMessage"("sessionId");

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "QualityReport_shareToken_key" ON "QualityReport"("shareToken");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "QualityReport_directorateKey_idx" ON "QualityReport"("directorateKey");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "DirectorateFeedback_directorateKey_idx" ON "DirectorateFeedback"("directorateKey");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "DirectorateFeedback_createdAt_idx" ON "DirectorateFeedback"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "FiledDocument_shareToken_key" ON "FiledDocument"("shareToken");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "FiledDocument_category_idx" ON "FiledDocument"("category");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "LinkItem_category_idx" ON "LinkItem"("category");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "EvaluatorAudit_directorateKey_idx" ON "EvaluatorAudit"("directorateKey");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "EvaluatorAudit_createdAt_idx" ON "EvaluatorAudit"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "DirectorateContact_directorateKey_key" ON "DirectorateContact"("directorateKey");`;
