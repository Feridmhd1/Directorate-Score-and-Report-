/**
 * Server-side score-delivery automation helpers.
 *
 * Shared by /api/automation/{send,auto-notify,test}:
 *  - buildScoreMessage(): clean bilingual multiline score summary
 *  - sendViaChannel():    Telegram bot / WhatsApp Cloud API (wa.me fallback) / email queue adapters
 *  - deliverEvaluation(): deliver one evaluation to many channels + persist DeliveryLog rows
 *
 * Delivery adapters NEVER throw — failures are reported as { status: "failed", detail }.
 */
import { db } from "@/lib/db";
import { CRITERIA, TOTAL_MAX_SCORE, scorePercent } from "@/lib/rubric";
import type { AutomationChannel, DeliveryLog, DirectorateEvaluation } from "@prisma/client";

export const VALID_CHANNEL_TYPES: readonly string[] = ["telegram", "whatsapp", "email"];

export interface OutgoingChannel {
  type: string;
  target: string;
  botToken: string;
}

export interface DeliveryOutcome {
  status: "sent" | "failed" | "queued";
  detail: string;
}

/** Minimal evaluation shape needed to build the message */
export interface ScoreEvaluationLike {
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  totalScore: number;
  scores: Record<string, number>;
  actionPlan: Array<{ id?: string; text?: string; done?: boolean }>;
}

export function safeParse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback;
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

/** Parse a Prisma DirectorateEvaluation row into the shape used by the builders */
export function toScoreEvaluation(row: DirectorateEvaluation): ScoreEvaluationLike {
  return {
    directorateKey: row.directorateKey,
    directorateName: row.directorateName,
    directorateShort: row.directorateShort,
    quarter: row.quarter,
    totalScore: row.totalScore,
    scores: safeParse<Record<string, number>>(row.scoresJson, {}),
    actionPlan: safeParse<Array<{ id?: string; text?: string; done?: boolean }>>(row.actionPlanJson, []),
  };
}

/** Build the clean multiline result message sent through every channel */
export function buildScoreMessage(evaluation: ScoreEvaluationLike): string {
  const pct = scorePercent(evaluation.totalScore, TOTAL_MAX_SCORE);
  const criteriaText = CRITERIA.map((c) => `${c.key}: ${evaluation.scores?.[c.key] ?? 0}/${c.maxScore}`).join(" | ");
  const actionCount = Array.isArray(evaluation.actionPlan) ? evaluation.actionPlan.length : 0;

  const lines = [
    "📊 Direc-Score — የሀረሪ ክልል ጤና ቢሮ",
    `${evaluation.directorateName} (${evaluation.directorateShort || evaluation.directorateKey})`,
    `ሩብ ዓመት ${evaluation.quarter}`,
    `ጠቅላላ ውጤት: ${evaluation.totalScore}/${TOTAL_MAX_SCORE} (${pct}%)`,
    "",
    criteriaText,
  ];
  if (actionCount > 0) {
    lines.push("", `የድርጊት እቅድ: ${actionCount} እርምጃዎች`);
  }
  return lines.join("\n");
}

/** Build a wa.me manual-send link (digits only target + url-encoded message) */
export function buildWaMeLink(target: string, message: string): string {
  const digits = target.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

function errorText(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}

/* ---------------- Delivery adapters (never throw) ---------------- */

async function sendTelegram(channel: OutgoingChannel, message: string): Promise<DeliveryOutcome> {
  if (!channel.botToken) {
    return { status: "queued", detail: "Bot token not configured" };
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${channel.botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: channel.target, text: message }),
      signal: AbortSignal.timeout(10_000),
    });
    let json: { ok?: boolean; description?: string } | null = null;
    try {
      json = (await res.json()) as { ok?: boolean; description?: string };
    } catch {
      /* non-JSON response */
    }
    if (res.ok && json?.ok) {
      return { status: "sent", detail: `Delivered via Telegram bot to ${channel.target || "chat"}` };
    }
    return { status: "failed", detail: json?.description || `Telegram HTTP ${res.status}` };
  } catch (e) {
    return { status: "failed", detail: `Telegram request failed: ${errorText(e)}` };
  }
}

async function sendWhatsapp(channel: OutgoingChannel, message: string): Promise<DeliveryOutcome> {
  // botToken field doubles as the WhatsApp Cloud API access token
  if (channel.botToken && channel.target) {
    try {
      const res = await fetch(`https://graph.facebook.com/v18.0/${channel.botToken}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to: channel.target,
          type: "text",
          text: { body: message },
        }),
        signal: AbortSignal.timeout(10_000),
      });
      let json: { error?: { message?: string } } | null = null;
      try {
        json = (await res.json()) as { error?: { message?: string } };
      } catch {
        /* non-JSON response */
      }
      if (res.ok) {
        return { status: "sent", detail: `Delivered via WhatsApp Cloud API to ${channel.target}` };
      }
      const apiMessage = json?.error?.message;
      return { status: "failed", detail: apiMessage ? `WhatsApp: ${apiMessage}` : `WhatsApp HTTP ${res.status}` };
    } catch (e) {
      return { status: "failed", detail: `WhatsApp request failed: ${errorText(e)}` };
    }
  }
  // Not configured — offer the honest wa.me manual-send path
  if (!channel.target) {
    return { status: "queued", detail: "WhatsApp target not configured — add a phone number to enable sending" };
  }
  return {
    status: "queued",
    detail: `Open ${buildWaMeLink(channel.target, message)} to send manually (configure WhatsApp Cloud API token for automatic sending)`,
  };
}

function sendEmail(channel: OutgoingChannel, _message: string): DeliveryOutcome {
  if (!channel.target) {
    return { status: "queued", detail: "No email target configured — queued pending recipient address" };
  }
  return {
    status: "queued",
    detail: `Queued for email delivery to ${channel.target} (SMTP relay not configured in this environment)`,
  };
}

/** Attempt delivery through one channel — resolves an outcome, never throws */
export async function sendViaChannel(channel: OutgoingChannel, message: string): Promise<DeliveryOutcome> {
  try {
    if (channel.type === "telegram") return await sendTelegram(channel, message);
    if (channel.type === "whatsapp") return await sendWhatsapp(channel, message);
    if (channel.type === "email") return sendEmail(channel, message);
    return { status: "failed", detail: `Unknown channel type "${channel.type}"` };
  } catch (e) {
    return { status: "failed", detail: `Delivery error: ${errorText(e)}` };
  }
}

/* ---------------- Shared high-level flows ---------------- */

/** Deliver one evaluation to the given channels, persisting a DeliveryLog row per attempt */
export async function deliverEvaluation(
  evaluation: DirectorateEvaluation,
  channels: AutomationChannel[]
): Promise<DeliveryLog[]> {
  const message = buildScoreMessage(toScoreEvaluation(evaluation));
  const logs: DeliveryLog[] = [];
  for (const channel of channels) {
    const outcome = await sendViaChannel(
      { type: channel.type, target: channel.target, botToken: channel.botToken },
      message
    );
    const log = await db.deliveryLog.create({
      data: {
        channelType: channel.type,
        target: channel.target,
        directorateKey: evaluation.directorateKey,
        directorateName: evaluation.directorateName,
        quarter: evaluation.quarter,
        message,
        status: outcome.status,
        detail: outcome.detail,
      },
    });
    logs.push(log);
  }
  return logs;
}

/** Best-effort in-app notification so the bell reflects a results delivery */
export async function createResultNotification(evaluation: DirectorateEvaluation): Promise<void> {
  try {
    await db.notification.create({
      data: {
        type: "results_sent",
        title: `ውጤት ተልኩ — ${evaluation.directorateShort || evaluation.directorateKey}`,
        message: `${evaluation.directorateName} የ${evaluation.quarter} ውጤት: ${evaluation.totalScore}/100`,
        directorateKey: evaluation.directorateKey,
        directorateName: evaluation.directorateName,
        quarter: evaluation.quarter,
        totalScore: evaluation.totalScore,
        directorEmail: evaluation.email ?? "",
      },
    });
  } catch {
    // notification is a side-benefit — never fail the delivery because of it
  }
}

/* ---------------- Uploaded-document link automation ---------------- */

/**
 * Seed the default delivery channels (per requirement) the first time the app
 * runs with an empty channel table:
 *  - WhatsApp  +251911133037
 *  - Telegram  @feridmhd1
 *  - Email     feridmhd3@gmail.com
 * All three are enabled so uploads/scores flow out immediately. Users can
 * edit or replace them later from the Automation page (PIN-protected).
 */
export async function ensureDefaultDeliveryChannels(): Promise<void> {
  try {
    const count = await db.automationChannel.count();
    if (count > 0) return;
    await db.automationChannel.createMany({
      data: [
        {
          type: "whatsapp",
          label: "Mr Ferid Mohammed (WhatsApp)",
          target: "+251911133037",
          enabled: true,
        },
        {
          type: "telegram",
          label: "Mr Ferid Mohammed (Telegram)",
          target: "@feridmhd1",
          enabled: true,
        },
        {
          type: "email",
          label: "Mr Ferid Mohammed (Email)",
          target: "feridmhd3@gmail.com",
          enabled: true,
        },
      ],
    });
  } catch (e) {
    console.error("ensureDefaultDeliveryChannels error", e);
  }
}

/** Minimal quality-report shape needed to build the upload message */
export interface FileShareReportLike {
  directorateKey: string;
  quarter: string;
  title: string;
  fileName: string;
  size: number;
  note?: string;
  shareToken: string;
}

function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

/** Build the "new document uploaded" message carrying the unique share link */
export function buildFileShareMessage(report: FileShareReportLike, shareUrl: string): string {
  const size = formatBytes(report.size);
  const lines = [
    "📎 አዲስ ሰነድ ተሰቀለ — Direc-Score",
    `ዳይሬክቶሬት: ${report.directorateKey}${report.quarter ? ` · ${report.quarter}` : ""}`,
    `📄 ${report.title || report.fileName}`,
  ];
  if (size) lines.push(`መጠን / Size: ${size}`);
  if (report.note) lines.push(`ማስታወሻ: ${report.note}`);
  lines.push("", `🔗 ${shareUrl}`);
  return lines.join("\n");
}

/**
 * Immediately fan a newly uploaded document's unique share link out to every
 * enabled channel (WhatsApp / Telegram / Email) and persist DeliveryLog rows.
 * Never throws — upload responses must succeed even if delivery fails.
 */
export async function deliverFileNotification(
  report: FileShareReportLike,
  shareUrl: string
): Promise<DeliveryLog[]> {
  try {
    await ensureDefaultDeliveryChannels();
    const channels = await db.automationChannel.findMany({
      where: { enabled: true },
      orderBy: { createdAt: "asc" },
    });
    const message = buildFileShareMessage(report, shareUrl);
    const logs: DeliveryLog[] = [];
    for (const channel of channels) {
      const outcome = await sendViaChannel(
        { type: channel.type, target: channel.target, botToken: channel.botToken },
        message
      );
      try {
        const log = await db.deliveryLog.create({
          data: {
            channelType: channel.type,
            target: channel.target,
            directorateKey: report.directorateKey,
            directorateName: report.title || report.fileName,
            quarter: report.quarter,
            message,
            status: outcome.status,
            detail: outcome.detail,
          },
        });
        logs.push(log);
      } catch (e) {
        console.error("delivery log write failed", e);
      }
    }
    return logs;
  } catch (e) {
    console.error("deliverFileNotification error", e);
    return [];
  }
}

/* ---------------- Generic text automation (feedback, reminders) ---------------- */

export interface TextDeliveryMeta {
  directorateKey?: string;
  directorateName?: string;
  quarter?: string;
  /** Optional in-app notification created alongside the delivery attempt */
  notification?: { type: string; title: string; message: string };
}

/**
 * Fan an arbitrary text message (directorate feedback, deadline reminders, …)
 * out to every enabled channel (WhatsApp / Telegram / Email) and persist a
 * DeliveryLog row per attempt. Never throws — callers must keep working even
 * when delivery fails.
 */
export async function deliverTextMessage(
  message: string,
  meta: TextDeliveryMeta = {}
): Promise<DeliveryLog[]> {
  try {
    await ensureDefaultDeliveryChannels();
    const channels = await db.automationChannel.findMany({
      where: { enabled: true },
      orderBy: { createdAt: "asc" },
    });
    const logs: DeliveryLog[] = [];
    for (const channel of channels) {
      const outcome = await sendViaChannel(
        { type: channel.type, target: channel.target, botToken: channel.botToken },
        message
      );
      try {
        const log = await db.deliveryLog.create({
          data: {
            channelType: channel.type,
            target: channel.target,
            directorateKey: meta.directorateKey ?? "",
            directorateName: meta.directorateName ?? "",
            quarter: meta.quarter ?? "",
            message,
            status: outcome.status,
            detail: outcome.detail,
          },
        });
        logs.push(log);
      } catch (e) {
        console.error("delivery log write failed", e);
      }
    }
    if (meta.notification) {
      try {
        await db.notification.create({
          data: {
            type: meta.notification.type,
            title: meta.notification.title,
            message: meta.notification.message,
            directorateKey: meta.directorateKey ?? "",
            directorateName: meta.directorateName ?? "",
            quarter: meta.quarter ?? "",
          },
        });
      } catch {
        /* notification is a side-benefit */
      }
    }
    return logs;
  } catch (e) {
    console.error("deliverTextMessage error", e);
    return [];
  }
}

/* ---------------- Per-directorate direct delivery (saved contacts) ---------------- */

export interface DirectContact {
  whatsapp?: string;
  telegram?: string;
  email?: string;
}

/**
 * Deliver one message straight to a single directorate through its own saved
 * contact channels (WhatsApp phone / Telegram chat / email). Bot credentials
 * are reused from the enabled admin channels (Automation page) while the
 * recipient is the directorate's own contact — this is what makes "send it
 * all in one go" possible. Never throws — failures come back as DeliveryLog
 * rows with status "failed".
 */
export async function deliverDirectMessage(
  message: string,
  contact: DirectContact,
  meta: TextDeliveryMeta = {}
): Promise<DeliveryLog[]> {
  try {
    const adminChannels = await db.automationChannel.findMany({
      where: { enabled: true },
    });
    const tokenFor = (type: string): string =>
      adminChannels.find((c) => c.type === type && c.botToken)?.botToken ?? "";

    const attempts: Array<{ type: string; target: string }> = [];
    if (contact.whatsapp?.trim()) attempts.push({ type: "whatsapp", target: contact.whatsapp.trim() });
    if (contact.telegram?.trim()) attempts.push({ type: "telegram", target: contact.telegram.trim() });
    if (contact.email?.trim()) attempts.push({ type: "email", target: contact.email.trim() });

    const logs: DeliveryLog[] = [];
    for (const attempt of attempts) {
      const outcome = await sendViaChannel(
        { type: attempt.type, target: attempt.target, botToken: tokenFor(attempt.type) },
        message
      );
      try {
        const log = await db.deliveryLog.create({
          data: {
            channelType: attempt.type,
            target: attempt.target,
            directorateKey: meta.directorateKey ?? "",
            directorateName: meta.directorateName ?? "",
            quarter: meta.quarter ?? "",
            message,
            status: outcome.status,
            detail: outcome.detail,
          },
        });
        logs.push(log);
      } catch (e) {
        console.error("delivery log write failed", e);
      }
    }
    return logs;
  } catch (e) {
    console.error("deliverDirectMessage error", e);
    return [];
  }
}

/* ---------------- Serializers (botToken never leaves the server) ---------------- */

export function serializeChannel(ch: AutomationChannel) {
  return {
    id: ch.id,
    type: ch.type,
    label: ch.label,
    target: ch.target,
    hasToken: Boolean(ch.botToken),
    enabled: ch.enabled,
    createdAt: ch.createdAt.toISOString(),
  };
}

export function serializeLog(log: DeliveryLog) {
  return {
    id: log.id,
    channelType: log.channelType,
    target: log.target,
    directorateKey: log.directorateKey,
    directorateName: log.directorateName,
    quarter: log.quarter,
    message: log.message,
    status: log.status,
    detail: log.detail,
    createdAt: log.createdAt.toISOString(),
  };
}
