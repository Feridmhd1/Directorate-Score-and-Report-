"use client";

/**
 * Browser data engine — persistent storage layer for "local" backend mode.
 *
 * When the app runs on a host without a writable server filesystem
 * (Netlify/Vercel serverless), every data operation is served from THIS
 * module instead of the API routes. All data lives in the user's own
 * browser (IndexedDB for collections and uploaded files, with graceful
 * localStorage fallbacks) and survives reloads and restarts.
 *
 * Everything the app needs is exposed through small primitives:
 *  - key/value collections  (readCollection / writeCollection)
 *  - uploaded file blobs    (saveFileBlob / getFileBlob)
 *  - application settings   (getLocalSettings / saveLocalSettings)
 *    — organization name, custom logo, security PINs, AI provider,
 *      backup bookkeeping, quarterly deadline
 *  - automation channels    (getChannels / upsertChannel / deleteChannel)
 *  - delivery logs          (appendDeliveryLogs / getDeliveryLogs)
 *  - full backup            (exportLocalBackup / importLocalBackup)
 *
 * Zero dependencies — works in every modern browser.
 */

import { idbGet, idbSet, idbDelete, idbEntries, idbRestore } from "@/lib/idb";
import type { DeliveryLogDTO } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */

/** Collision-resistant unique id (crypto.randomUUID with fallback) */
export function uid(): string {
  try {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
  } catch {
    /* fall through */
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

/** ISO timestamp used by every DTO */
export function nowIso(): string {
  return new Date().toISOString();
}

/** Random URL-safe share token (used for unique document links) */
export function shareToken(): string {
  const alphabet = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  try {
    const bytes = new Uint8Array(20);
    crypto.getRandomValues(bytes);
    for (const b of bytes) out += alphabet[b % alphabet.length];
  } catch {
    for (let i = 0; i < 20; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Generic collections (IndexedDB "col:" keys)                         */
/* ------------------------------------------------------------------ */

/**
 * Read a stored collection. Row-style generic: readCollection<EvaluationDTO>("evaluations", [])
 * Matches every existing call site (client-api, share pages, branding…).
 */
export async function readCollection<T>(
  name: string,
  fallback: T[] = []
): Promise<T[]> {
  try {
    const rows = await idbGet<T[]>(`col:${name}`);
    return Array.isArray(rows) ? rows : fallback;
  } catch {
    return fallback;
  }
}

export async function writeCollection<T>(name: string, rows: T[]): Promise<void> {
  await idbSet(`col:${name}`, rows);
}

/** Read one stored single value (any JSON-serializable payload) */
export async function readValue<T>(key: string, fallback: T): Promise<T> {
  try {
    const value = await idbGet<T>(`val:${key}`);
    return value === undefined || value === null ? fallback : value;
  } catch {
    return fallback;
  }
}

export async function writeValue(key: string, value: unknown): Promise<void> {
  await idbSet(`val:${key}`, value);
}

/* ------------------------------------------------------------------ */
/* Uploaded file blobs (IndexedDB "file:" keys)                        */
/* ------------------------------------------------------------------ */

export async function saveFileBlob(id: string, blob: Blob): Promise<void> {
  await idbSet(`file:${id}`, blob);
}

export async function getFileBlob(id: string): Promise<Blob | null> {
  try {
    const blob = await idbGet<Blob>(`file:${id}`);
    return blob instanceof Blob ? blob : null;
  } catch {
    return null;
  }
}

export async function deleteFileBlob(id: string): Promise<void> {
  await idbDelete(`file:${id}`);
}

/* ------------------------------------------------------------------ */
/* Application settings                                                */
/* ------------------------------------------------------------------ */

export interface AIProviderConfig {
  baseUrl: string;
  apiKey: string;
  model: string;
}

export interface LocalAppSettings {
  organizationName: string;
  logoDataUrl: string;
  autoBackupEnabled: boolean;
  backupFrequency: "weekly" | "daily";
  lastBackupAt: string | null;
  lastBackupStatus: string; // idle | success | failed | running
  lastBackupDetail: string;
  /** Security PINs (defaults 3472) */
  filingPin: string;
  automationPin: string;
  settingsPin: string;
  /** Google Drive backup credentials (stored but unused in local mode) */
  driveClientId: string;
  driveClientSecret: string;
  driveRefreshToken: string;
  driveFolderId: string;
  /** Quarterly report submission deadline */
  deadline: { quarter: string; date: string } | null;
  /** yyyy-mm-dd of the last automatic pre-deadline reminder */
  deadlineLastAuto: string;
  /** Personal OpenAI-compatible AI provider (Settings → AI Provider) */
  aiProvider?: AIProviderConfig;
}

export const DEFAULT_LOCAL_SETTINGS: LocalAppSettings = {
  organizationName: "Harari Region Health Bureau",
  logoDataUrl: "",
  autoBackupEnabled: false,
  backupFrequency: "weekly",
  lastBackupAt: null,
  lastBackupStatus: "idle",
  lastBackupDetail: "",
  filingPin: "3472",
  automationPin: "3472",
  settingsPin: "3472",
  driveClientId: "",
  driveClientSecret: "",
  driveRefreshToken: "",
  driveFolderId: "",
  deadline: null,
  deadlineLastAuto: "",
  aiProvider: { baseUrl: "", apiKey: "", model: "" },
};

const SETTINGS_KEY = "settings";

let settingsCache: LocalAppSettings | null = null;

/** Read the full local settings (merged over defaults so new keys never break) */
export async function getLocalSettings(): Promise<LocalAppSettings> {
  if (settingsCache) return settingsCache;
  const stored = await readValue<Partial<LocalAppSettings>>(SETTINGS_KEY, {});
  settingsCache = { ...DEFAULT_LOCAL_SETTINGS, ...stored };
  return settingsCache;
}

/** Patch the local settings and persist them */
export async function saveLocalSettings(
  patch: Partial<LocalAppSettings>
): Promise<LocalAppSettings> {
  const current = await getLocalSettings();
  const next: LocalAppSettings = { ...current, ...patch };
  settingsCache = next;
  await writeValue(SETTINGS_KEY, next);
  return next;
}

/** Clear the in-memory settings cache (used after backup restore) */
export function resetLocalSettingsCache(): void {
  settingsCache = null;
}

/** Security PIN lookup (filing / automation / settings — default 3472 each) */
export async function getLocalPin(
  kind: "filingPin" | "automationPin" | "settingsPin"
): Promise<string> {
  const settings = await getLocalSettings();
  return settings[kind] || "3472";
}

/* ------------------------------------------------------------------ */
/* Automation channels + delivery logs                                 */
/* ------------------------------------------------------------------ */

export interface LocalChannel {
  id: string;
  type: string; // telegram | whatsapp | email
  label: string;
  target: string;
  botToken: string;
  enabled: boolean;
  createdAt: string;
}

const CHANNELS_KEY = "channels";
const LOGS_KEY = "deliveryLogs";

/** Seeded on first run so automation works out of the box in local mode */
const DEFAULT_CHANNELS: LocalChannel[] = [
  {
    id: "ch-whatsapp-default",
    type: "whatsapp",
    label: "WhatsApp — Mr Ferid Mohammed",
    target: "+251911133037",
    botToken: "",
    enabled: true,
    createdAt: nowIso(),
  },
  {
    id: "ch-telegram-default",
    type: "telegram",
    label: "Telegram — @feridmhd1",
    target: "@feridmhd1",
    botToken: "",
    enabled: true,
    createdAt: nowIso(),
  },
  {
    id: "ch-email-default",
    type: "email",
    label: "Email — feridmhd3@gmail.com",
    target: "feridmhd3@gmail.com",
    botToken: "",
    enabled: true,
    createdAt: nowIso(),
  },
];

export async function getChannels(): Promise<LocalChannel[]> {
  const rows = await readValue<LocalChannel[]>(CHANNELS_KEY, []);
  if (!Array.isArray(rows) || rows.length === 0) {
    await writeValue(CHANNELS_KEY, DEFAULT_CHANNELS);
    return [...DEFAULT_CHANNELS];
  }
  return rows;
}

export async function upsertChannel(channel: LocalChannel): Promise<void> {
  const rows = await getChannels();
  const index = rows.findIndex((c) => c.id === channel.id);
  if (index >= 0) rows[index] = channel;
  else rows.push(channel);
  await writeValue(CHANNELS_KEY, rows);
}

export async function deleteChannel(id: string): Promise<void> {
  const rows = await getChannels();
  await writeValue(
    CHANNELS_KEY,
    rows.filter((c) => c.id !== id)
  );
}

export async function appendDeliveryLogs(logs: DeliveryLogDTO[]): Promise<void> {
  if (!logs.length) return;
  const rows = await readValue<DeliveryLogDTO[]>(LOGS_KEY, []);
  rows.push(...logs);
  await writeValue(LOGS_KEY, rows.slice(-500)); // keep the latest 500 entries
}

export async function getDeliveryLogs(limit = 50): Promise<DeliveryLogDTO[]> {
  const rows = await readValue<DeliveryLogDTO[]>(LOGS_KEY, []);
  return rows.slice(-limit).reverse(); // newest first, like the server API
}

/* ------------------------------------------------------------------ */
/* Full backup (download → restore)                                    */
/* ------------------------------------------------------------------ */

export interface LocalBackupPayload {
  app: "direcscore";
  version: 1;
  exportedAt: string;
  settings: LocalAppSettings;
  collections: Array<[string, unknown]>;
  /** uploaded files inlined as base64 */
  files: Array<[string, string]>;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      const comma = result.indexOf(",");
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(reader.error ?? new Error("Blob read failed"));
    reader.readAsDataURL(blob);
  });
}

function base64ToBlob(base64: string, mime = "application/octet-stream"): Blob {
  try {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  } catch {
    return new Blob([], { type: mime });
  }
}

/** Export everything (settings + collections + files) as a restorable payload */
export async function exportLocalBackup(): Promise<LocalBackupPayload> {
  const settings = await getLocalSettings();
  const entries = await idbEntries();
  const collections: Array<[string, unknown]> = [];
  const files: Array<[string, string]> = [];
  for (const [key, value] of entries) {
    if (typeof key !== "string") continue;
    if (key.startsWith("col:") || key.startsWith("val:channels")) {
      collections.push([key, value]);
    } else if (key.startsWith("val:")) {
      collections.push([key, value]);
    } else if (key.startsWith("file:") && value instanceof Blob) {
      files.push([key, await blobToBase64(value)]);
    }
  }
  return {
    app: "direcscore",
    version: 1,
    exportedAt: nowIso(),
    settings,
    collections,
    files,
  };
}

/** Restore a previously exported payload. Returns what was imported. */
export async function importLocalBackup(
  payload: LocalBackupPayload
): Promise<{ collections: number; files: number }> {
  if (!payload || payload.app !== "direcscore") {
    throw new Error("This file is not a Direc-Score backup");
  }
  let collections = 0;
  let files = 0;
  const pairs: Array<[string, unknown]> = [];
  for (const [key, value] of payload.collections ?? []) {
    pairs.push([key, value]);
    collections++;
  }
  for (const [key, base64] of payload.files ?? []) {
    pairs.push([key, base64ToBlob(base64)]);
    files++;
  }
  await idbRestore(pairs);
  if (payload.settings) {
    settingsCache = { ...DEFAULT_LOCAL_SETTINGS, ...payload.settings };
    await writeValue(SETTINGS_KEY, settingsCache);
  }
  return { collections, files };
}

/** Build a JSON file download in the browser (local-mode backup / exports) */
export function downloadJsonFile(fileName: string, payload: unknown): void {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
