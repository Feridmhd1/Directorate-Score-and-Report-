import { NextResponse } from "next/server";
import { DEFAULT_FILING_PIN, getSetting, SETTING_KEYS } from "@/lib/settings-store";

/**
 * Guard helpers for the secure Document Filing API.
 * The filing room is protected by a PIN (default 3472, configurable via the
 * `filingPin` app setting). Every /api/filing/* request must carry it in the
 * `x-filing-pin` header.
 */

/** Resolve the current filing-room PIN (configurable; defaults to 3472) */
export async function getFilingPin(): Promise<string> {
  const stored = await getSetting(SETTING_KEYS.filingPin);
  return stored || DEFAULT_FILING_PIN;
}

/**
 * Returns a 401 response when the request does not carry the correct PIN,
 * or null when the caller is allowed through.
 */
export async function requireFilingPin(req: Request): Promise<NextResponse | null> {
  const provided = req.headers.get("x-filing-pin")?.trim() ?? "";
  const expected = await getFilingPin();
  if (!provided || provided !== expected) {
    return NextResponse.json({ error: "Incorrect filing room password" }, { status: 401 });
  }
  return null;
}

/* ---------------- Brute-force throttle (per IP, in-memory) ---------------- */

const attempts = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60_000;
const MAX_FAILURES = 8;

export function clientIp(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "local"
  );
}

export function throttleFailure(ip: string): NextResponse | null {
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.resetAt < now) return null;
  if (entry.count >= MAX_FAILURES) {
    const retryAfterSec = Math.ceil((entry.resetAt - now) / 1000);
    return NextResponse.json(
      { error: `Too many attempts — try again in ${retryAfterSec}s` },
      { status: 429, headers: { "Retry-After": String(retryAfterSec) } }
    );
  }
  return null;
}

export function recordFailure(ip: string): void {
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + WINDOW_MS });
  } else {
    entry.count += 1;
  }
}

export function clearFailures(ip: string): void {
  attempts.delete(ip);
}
