/**
 * Message templates shared by the server automation layer and the browser
 * push engine. Pure functions — no database imports — so both environments
 * can use them.
 */

import { CRITERIA, TOTAL_MAX_SCORE, scorePercent } from "@/lib/rubric";

export interface ScoreEvaluationLike {
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  totalScore: number;
  scores: Record<string, number>;
  actionPlan: Array<{ id?: string; text?: string; done?: boolean }>;
}

/** Build the clean multiline score summary sent through every channel */
export function buildScoreMessage(evaluation: ScoreEvaluationLike): string {
  const pct = scorePercent(evaluation.totalScore, TOTAL_MAX_SCORE);
  const criteriaText = CRITERIA.map(
    (c) => `${c.key}: ${evaluation.scores?.[c.key] ?? 0}/${c.maxScore}`
  ).join(" | ");
  const actionCount = Array.isArray(evaluation.actionPlan) ? evaluation.actionPlan.length : 0;

  const lines = [
    "📊 Direc-Score — የሀረሪ ክልል ጤና ቢሮ",
    `${evaluation.directorateName} (${evaluation.directorateShort || evaluation.directorateKey})`,
    `ሩብ ዓመት ${evaluation.quarter}`,
    `ጠቅላላ ውጤት: ${evaluation.totalScore}/${TOTAL_MAX_SCORE} (${pct}%)`,
    "",
    criteriaText,
  ];
  if (actionCount > 0) {
    lines.push("", `የድርጊት እቅድ: ${actionCount} እርምጃዎች`);
  }
  return lines.join("\n");
}

/** Build a wa.me manual-send link (digits only target + url-encoded message) */
export function buildWaMeLink(target: string, message: string): string {
  const digits = target.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

export function buildMailtoLink(target: string, subject: string, message: string): string {
  return `mailto:${target}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

export interface FileShareReportLike {
  directorateKey: string;
  quarter: string;
  title: string;
  fileName: string;
  size: number;
  note?: string;
  shareToken: string;
}

/** Build the "new document uploaded" message carrying the unique share link */
export function buildFileShareMessage(report: FileShareReportLike, shareUrl: string): string {
  const size = formatBytes(report.size);
  const lines = [
    "📎 አዲስ ሰነድ ተሰቀለ — Direc-Score",
    `ዳይሬክቶሬት: ${report.directorateKey}${report.quarter ? ` · ${report.quarter}` : ""}`,
    `📄 ${report.title || report.fileName}`,
  ];
  if (size) lines.push(`መጠን / Size: ${size}`);
  if (report.note) lines.push(`ማስታወሻ: ${report.note}`);
  lines.push("", `🔗 ${shareUrl}`);
  return lines.join("\n");
}
