/** Shared application types used by both client and server */

export interface EvaluationDTO {
  id: string;
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  email: string | null;
  scores: Record<string, number>;
  answers: Record<string, string>;
  comments: Record<string, string>;
  totalScore: number;
  status: string;
  attachments: string[];
  actionPlan: Array<{ id: string; text: string; done?: boolean }>;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DocumentHistoryDTO {
  id: string;
  fileName: string;
  content: string;
  contentLength: number;
  wordCount: number;
  status: string;
  insights: Insights | null;
  graphics: GraphicSuggestion[];
  charts: ChartSpec[];
  finalized: boolean;
  finalReport: FinalAnalysisReport | null;
  documentType: string;
  language: string;
  sentiment: string;
  mimeType: string;
  createdAt: string;
}

export interface Insights {
  document_type?: string;
  language?: string;
  sentiment?: string;
  summary?: string;
  key_points?: string[];
  topics?: string[];
  recommendations?: string[];
}

export interface GraphicSuggestion {
  id: string;
  title: string;
  type: string;
  description: string;
  data?: Record<string, unknown>;
}

export interface NotificationDTO {
  id: string;
  type: string;
  title: string;
  message: string;
  directorateKey: string;
  directorateName: string;
  quarter: string;
  totalScore: number | null;
  directorEmail: string;
  isRead: boolean;
  createdAt: string;
}

export interface UserDTO {
  id: string;
  email: string;
  name: string | null;
}

export interface AICompareResult {
  overview: string;
  common_themes: string[];
  conflicts: Array<{ topic: string; doc1_view: string; doc2_view: string; explanation: string }>;
  unique_insights: Array<{ document_name: string; insight: string }>;
  consolidated_summary: string;
  similarity_score: number;
  recommendation: string;
}

/* ---------------- Data analysis & AI studio ---------------- */

/** A renderable chart produced by the data-analysis AI */
export interface ChartSpec {
  id: string;
  title: string;
  type: "bar" | "line" | "pie" | "area" | string;
  /** key in each data row for the x axis / labels */
  xKey?: string;
  /** one or more keys in each data row for the y axis / values */
  yKeys?: string[];
  data: Array<Record<string, string | number>>;
  description?: string;
  unit?: string;
}

/** Column statistics for tabular data */
export interface ColumnStat {
  column: string;
  type: string; // number | text | date
  min?: number;
  max?: number;
  mean?: number;
  missing?: number;
  unique?: number;
}

/** Structured result of AI data analysis */
export interface DataAnalysis {
  dataset_type?: string;
  rows?: number;
  columns?: number;
  summary?: string;
  key_findings?: string[];
  statistics?: ColumnStat[];
  recommendations?: string[];
}

/** Saved "final analysis" report for a document */
export interface FinalAnalysisReport {
  title?: string;
  generatedAt?: string;
  summary?: string;
  key_findings?: string[];
  recommendations?: string[];
  statistics?: ColumnStat[];
  conclusion?: string;
}

/* ---------------- Automation (WhatsApp / Telegram / Email) ---------------- */

export interface AutomationChannelDTO {
  id: string;
  type: "telegram" | "whatsapp" | "email" | string;
  label: string;
  target: string;
  /** true when credentials/token exist — token itself is never returned */
  hasToken: boolean;
  enabled: boolean;
  createdAt: string;
}

export interface DeliveryLogDTO {
  id: string;
  channelType: string;
  target: string;
  directorateKey: string;
  directorateName: string;
  quarter: string;
  message: string;
  status: "sent" | "failed" | "queued" | string;
  detail: string;
  createdAt: string;
}

export interface ChatMessageDTO {
  id: string;
  sessionId: string;
  role: "user" | "assistant" | string;
  content: string;
  documentId: string;
  createdAt: string;
}

export interface SystemStatus {
  ok: boolean;
  uptimeSec: number;
  node: string;
  platform: string;
  dbEngine: string;
  cache: {
    hits: number;
    misses: number;
    evictions: number;
    invalidations: number;
    size: number;
    maxEntries: number;
    hitRate: number;
  };
  time: string;
}

/* ---------------- Branding & application settings ---------------- */

export interface AppSettingsDTO {
  organizationName: string;
  /** true when a custom logo was uploaded (falls back to the built-in Harari logo) */
  customLogo: boolean;
  autoBackupEnabled: boolean;
  backupFrequency: "weekly" | "daily" | string;
  lastBackupAt: string | null;
  lastBackupStatus: string; // idle | success | failed | running
  lastBackupDetail: string;
  driveConfigured: boolean;
}

/* ---------------- Google Drive backup ---------------- */

export interface BackupResultDTO {
  ok: boolean;
  fileName: string;
  fileId?: string;
  webViewLink?: string;
  sizeBytes?: number;
  detail?: string;
}

export interface BackupStatusDTO {
  autoBackupEnabled: boolean;
  backupFrequency: string;
  driveConfigured: boolean;
  lastBackupAt: string | null;
  lastBackupStatus: string;
  lastBackupDetail: string;
  nextBackupDueAt: string | null;
}

/** Public directorate hub descriptor (QR code + shareable link payload) */
export interface DirectorateHubInfo {
  directorateKey: string;
  portalUrl: string;
  submitUrl: string;
}

/* ---------------- Quality report documents (per directorate) ---------------- */

export interface QualityReportDTO {
  id: string;
  directorateKey: string;
  quarter: string;
  title: string;
  fileName: string;
  mimeType: string;
  size: number;
  note: string;
  /** unique token used to build the public share link */
  shareToken: string;
  createdAt: string;
}

/** Comments & suggestions submitted by directorates from their public portal */
export interface FeedbackDTO {
  id: string;
  directorateKey: string;
  directorateName: string;
  quarter: string;
  kind: "comment" | "suggestion" | string;
  message: string;
  contact: string;
  isRead: boolean;
  createdAt: string;
}

/* ---------------- Secure document filing (PIN-protected) ---------------- */

/** Result of the server-side file scanner run on every filed upload */
export interface FileScanReport {
  verdict: "clean" | "warning" | "blocked" | string;
  /** MIME type declared by the uploading browser */
  declaredMime: string;
  /** File type inferred from magic bytes / content */
  detectedType: string;
  /** false when the declared MIME and the detected type disagree */
  typeMatch: boolean;
  /** Short warning identifiers (executable, macro, mime-mismatch, eicar…) */
  flags: string[];
  /** SHA-256 fingerprint of the file contents */
  checksum: string;
  sizeBytes: number;
  scannedAt: string;
  /** Human-readable scanner notes (bilingual-safe English) */
  details: string[];
}

export interface FiledDocumentDTO {
  id: string;
  title: string;
  category: string;
  fileName: string;
  mimeType: string;
  size: number;
  note: string;
  /** unique token behind the public share link */
  shareToken: string;
  /** clean | warning | blocked (blocked files are never stored) */
  scanVerdict: string;
  scanReport: FileScanReport | null;
  createdAt: string;
}

/* ---------------- Link attachment library (similar apps / learning / other) ---------------- */

export type LinkCategory = "app" | "learning" | "other" | string;

export interface LinkItemDTO {
  id: string;
  title: string;
  url: string;
  /** app (similar applications) | learning | other */
  category: LinkCategory;
  description: string;
  createdAt: string;
}

/* ---------------- Quarterly report submission deadline ---------------- */

export interface DeadlineInfoDTO {
  quarter: string;
  /** ISO yyyy-mm-dd */
  date: string;
}

export interface MissingDirectorateDTO {
  key: string;
  short: string;
  name: string;
}

export interface DeadlineStateDTO {
  deadline: DeadlineInfoDTO | null;
  daysLeft: number | null;
  missing: MissingDirectorateDTO[];
}

/* ---------------- Directorate contacts (email / WhatsApp / Telegram) ---------------- */

export interface ContactDTO {
  id: string;
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  email: string;
  whatsapp: string;
  telegram: string;
  createdAt: string;
  updatedAt: string;
}

/** One directorate's outcome of a "send it all in one go" blast */
export interface ContactSendResultDTO {
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  /** false → no saved contact, delivered through the admin channels instead */
  contactSaved: boolean;
  channels: string[];
  logs: DeliveryLogDTO[];
}

export interface ContactSendAllDTO {
  mode: "scores" | "reminder";
  quarter: string;
  results: ContactSendResultDTO[];
}

/* ---------------- AI evaluator quality audit (meta-evaluation) ---------------- */

/** One yes/no answer of the AI evaluator that the supervising audit disputes */
export interface EvaluatorDisagreement {
  questionId: string;
  severity: "high" | "medium" | "low" | string;
  reason: string;
  suggestedAnswer: "yes" | "no" | string;
}

/** Result of auditing ("evaluating") the AI evaluator's own assessment */
export interface EvaluatorAuditReport {
  /** 0-100 reliability grade of the AI evaluator's work */
  qualityScore: number;
  verdict: "reliable" | "review" | "unreliable" | string;
  summary: string;
  disagreements: EvaluatorDisagreement[];
  strengths: string[];
  improvements: string[];
}

/** A stored audit record of the AI evaluator */
export interface EvaluatorAuditDTO {
  id: string;
  directorateKey: string;
  directorateName: string;
  quarter: string;
  qualityScore: number;
  verdict: string;
  report: EvaluatorAuditReport;
  createdAt: string;
}
