/**
 * SVG → PNG export helpers for chart cards.
 * Captures the first <svg> inside a container element, rasterizes it on a
 * canvas at 2x scale and either returns a PNG data URL or triggers a download.
 * No external dependencies.
 */

const SVG_NS = "http://www.w3.org/2000/svg";
const FALLBACK_FONT = "'Segoe UI', system-ui, -apple-system, sans-serif";

interface SerializedChart {
  xml: string;
  width: number;
  height: number;
}

function serializeChartSvg(container: HTMLElement): SerializedChart {
  const svg = container.querySelector("svg");
  if (!svg) throw new Error("No chart graphic found to export.");
  const rect = container.getBoundingClientRect();
  const width = Math.max(1, Math.round(rect.width));
  const height = Math.max(1, Math.round(rect.height));

  const clone = svg.cloneNode(true) as SVGSVGElement;
  if (!clone.getAttribute("xmlns")) clone.setAttribute("xmlns", SVG_NS);
  // Explicit size at 2x for a sharp export; viewBox keeps the layout intact.
  clone.setAttribute("width", String(width * 2));
  clone.setAttribute("height", String(height * 2));
  if (!clone.getAttribute("viewBox")) clone.setAttribute("viewBox", `0 0 ${width} ${height}`);
  if (!clone.getAttribute("font-family")) clone.setAttribute("font-family", FALLBACK_FONT);

  const xml = new XMLSerializer().serializeToString(clone);
  return { xml, width, height };
}

function svgDataUrl(xml: string): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(xml)}`;
}

async function loadImage(src: string): Promise<HTMLImageElement> {
  const img = new Image();
  img.src = src;
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error("Failed to load the chart image."));
    if (typeof img.decode === "function") {
      img.decode().then(resolve).catch(() => {
        /* fall back to onload/onerror */
      });
    }
  });
  return img;
}

async function renderChartCanvas(
  container: HTMLElement,
  background: string
): Promise<HTMLCanvasElement> {
  const { xml, width, height } = serializeChartSvg(container);
  const img = await loadImage(svgDataUrl(xml));

  const scale = 2;
  const canvas = document.createElement("canvas");
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is not supported in this browser.");
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas;
}

function triggerDownload(url: string, fileName: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** Capture the chart inside `container` and return a PNG data URL. */
export async function chartContainerToPngDataUrl(container: HTMLElement): Promise<string> {
  const canvas = await renderChartCanvas(container, "#ffffff");
  return canvas.toDataURL("image/png");
}

/** Capture the chart inside `container` and download it as a PNG file. */
export async function downloadChartPng(
  container: HTMLElement | null,
  fileName: string,
  opts?: { background?: string }
): Promise<void> {
  if (!container) throw new Error("Chart is not ready for export yet.");
  const canvas = await renderChartCanvas(container, opts?.background ?? "#ffffff");

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  if (blob) {
    const url = URL.createObjectURL(blob);
    triggerDownload(url, fileName);
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  } else {
    triggerDownload(canvas.toDataURL("image/png"), fileName);
  }
}
