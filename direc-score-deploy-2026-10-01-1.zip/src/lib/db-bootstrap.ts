/**
 * Runtime database bootstrap — makes every deployment self-initializing.
 *
 * On a fresh database (e.g. a brand-new SQLite file on Netlify's serverless
 * filesystem, or a new persistent server), the tables defined in
 * prisma/schema.prisma do not exist yet and every query would fail.
 * This module creates them automatically on first use, using the idempotent
 * DDL in ./schema-sql (auto-generated from the Prisma schema). Partially
 * initialized databases are healed too — only missing tables are created.
 *
 * Databases that are already complete return after one cheap
 * sqlite_master lookup per process.
 */
import type { PrismaClient } from "@prisma/client";
import { SCHEMA_SQL } from "./schema-sql";

/** All table names the schema expects, parsed from the generated DDL */
function expectedTables(): string[] {
  const names = new Set<string>();
  const re = /CREATE TABLE IF NOT EXISTS "([^"]+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(SCHEMA_SQL)) !== null) names.add(m[1]);
  return [...names];
}

const globalForBootstrap = globalThis as unknown as {
  direcscoreDbReady?: Promise<void>;
};

async function runBootstrap(db: PrismaClient): Promise<void> {
  const tables = expectedTables();
  if (tables.length === 0) return;

  const placeholders = tables.map(() => "?").join(",");
  const rows = await db.$queryRawUnsafe<Array<{ name: string }>>(
    `SELECT name FROM sqlite_master WHERE type = 'table' AND name IN (${placeholders})`,
    ...tables
  );
  const existing = new Set((Array.isArray(rows) ? rows : []).map((r) => String(r.name)));
  if (tables.every((t) => existing.has(t))) return; // database fully initialized

  // Create whatever is missing — every statement is idempotent (IF NOT EXISTS)
  const statements = SCHEMA_SQL.split(";")
    .map((s) => s.trim())
    .filter((s) => s.replace(/--[^\n]*/g, "").trim().length > 0);

  for (const statement of statements) {
    try {
      await db.$executeRawUnsafe(statement);
    } catch (err) {
      // A concurrent instance may have just created the same object — ignore
      const msg = err instanceof Error ? err.message : String(err);
      if (!/already exists/i.test(msg)) throw err;
    }
  }
}

/**
 * Resolves once the database schema is guaranteed to exist.
 * Runs at most once per process; retries on the next call if it failed.
 */
export function ensureDatabaseReady(db: PrismaClient): Promise<void> {
  if (!globalForBootstrap.direcscoreDbReady) {
    globalForBootstrap.direcscoreDbReady = runBootstrap(db).catch((err) => {
      globalForBootstrap.direcscoreDbReady = undefined; // allow a retry
      throw err;
    });
  }
  return globalForBootstrap.direcscoreDbReady;
}
