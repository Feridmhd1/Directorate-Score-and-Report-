"use client";

/**
 * Single API gateway used by every view.
 *
 * Each call first resolves the backend mode (see backend-mode.ts):
 *  - "server" → the request hits the API routes (sandbox / full server with
 *    a writable SQLite database — data is shared across devices).
 *  - "local"  → the request is served by the browser data engine
 *    (local-apis.ts) so the application stays FULLY functional on hosts
 *    like Netlify where the server filesystem is read-only.
 *
 * AI calls are special: they always try the server route first (it works on
 * a real server AND on serverless when a personal provider key is
 * configured in Settings → AI Provider, passed through x-ai-* headers),
 * and fall back to the offline engine (local-ai.ts) so no button ever
 * dead-ends.
 */

import { resolveBackendMode, peekBackendMode } from "@/lib/backend-mode";
import {
  getLocalSettings,
  saveLocalSettings,
  uid,
  readCollection,
  writeCollection,
  nowIso,
} from "@/lib/local-db";
import type { AIProviderConfig } from "@/lib/local-db";
import type {
  AICompareResult,
  AppSettingsDTO,
  AutomationChannelDTO,
  BackupResultDTO,
  BackupStatusDTO,
  ChatMessageDTO,
  ContactDTO,
  ContactSendAllDTO,
  DeadlineStateDTO,
  DeliveryLogDTO,
  DocumentHistoryDTO,
  EvaluationDTO,
  FeedbackDTO,
  FiledDocumentDTO,
  FileScanReport,
  FinalAnalysisReport,
  LinkItemDTO,
  NotificationDTO,
  QualityReportDTO,
  EvaluatorAuditReport,
  SystemStatus,
  UserDTO,
} from "@/lib/types";
import type { ActionPlanItem } from "@/lib/rubric";

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  // Never force a JSON content-type on multipart bodies (file uploads)
  const isFormData =
    typeof FormData !== "undefined" && options?.body instanceof FormData;
  const res = await fetch(url, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(options?.headers ?? {}),
    },
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      if (data?.error) message = data.error;
    } catch {
      /* ignore */
    }
    throw new Error(message);
  }
  return res.json() as Promise<T>;
}

/* ---------------- AI provider configuration (browser-side) ---------------- */

/** Read the personal AI provider configured in Settings (empty = not set) */
export async function getAIProviderConfig(): Promise<AIProviderConfig> {
  try {
    const settings = await getLocalSettings();
    return settings.aiProvider ?? { baseUrl: "", apiKey: "", model: "" };
  } catch {
    return { baseUrl: "", apiKey: "", model: "" };
  }
}

/** Save the personal AI provider (OpenAI-compatible) in browser settings */
export async function setAIProviderConfig(config: AIProviderConfig): Promise<void> {
  await saveLocalSettings({ aiProvider: config });
}

async function aiHeaders(): Promise<Record<string, string>> {
  const config = await getAIProviderConfig();
  if (config.baseUrl && config.apiKey && config.model) {
    return {
      "x-ai-base-url": config.baseUrl,
      "x-ai-key": config.apiKey,
      "x-ai-model": config.model,
    };
  }
  return {};
}

/* ---------------- Auth (kept for API compatibility; UI has no login) ---------------- */

export const authApi = {
  me: () => request<{ user: UserDTO | null }>("/api/auth/me"),
  login: (email: string, password: string) =>
    request<{ user: UserDTO }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  register: (email: string, password: string, name?: string) =>
    request<{ user: UserDTO }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, name }),
    }),
  logout: () => request<{ ok: true }>("/api/auth/logout", { method: "POST" }),
};

/* ---------------- Evaluations ---------------- */

export interface EvaluationInput {
  directorateKey: string;
  directorateName: string;
  directorateShort: string;
  quarter: string;
  email?: string;
  scores: Record<string, number>;
  answers: Record<string, string>;
  comments: Record<string, string>;
  totalScore: number;
  status?: string;
  attachments?: string[];
  actionPlan?: ActionPlanItem[];
  aiGenerated?: boolean;
}

import * as local from "@/lib/local-apis";

export const evaluationsApi = {
  list: async (params?: { quarter?: string; directorateKey?: string }) => {
    if ((await resolveBackendMode()) === "local") return local.localEvaluationsApi.list(params);
    const search = new URLSearchParams();
    if (params?.quarter) search.set("quarter", params.quarter);
    if (params?.directorateKey) search.set("directorateKey", params.directorateKey);
    const qs = search.toString();
    return request<{ evaluations: EvaluationDTO[] }>(`/api/evaluations${qs ? `?${qs}` : ""}`);
  },
  listAll: async () => {
    if ((await resolveBackendMode()) === "local") return local.localEvaluationsApi.listAll();
    return request<{ evaluations: EvaluationDTO[] }>("/api/evaluations?all=1");
  },
  create: async (data: EvaluationInput) => {
    if ((await resolveBackendMode()) === "local") return local.localEvaluationsApi.create(data);
    return request<{ evaluation: EvaluationDTO }>("/api/evaluations", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  update: async (id: string, data: Partial<EvaluationInput>) => {
    if ((await resolveBackendMode()) === "local") return local.localEvaluationsApi.update(id, data);
    return request<{ evaluation: EvaluationDTO }>(`/api/evaluations/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    });
  },
  remove: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localEvaluationsApi.remove(id);
    return request<{ ok: true }>(`/api/evaluations/${id}`, { method: "DELETE" });
  },
};

/* ---------------- Document history ---------------- */

export interface DocumentInput {
  fileName: string;
  content: string;
  status?: string;
  mimeType?: string;
}

export const documentsApi = {
  list: async () => {
    if ((await resolveBackendMode()) === "local") return local.localDocumentsApi.list();
    return request<{ documents: DocumentHistoryDTO[] }>("/api/documents");
  },
  getById: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localDocumentsApi.getById(id);
    return request<{ document: DocumentHistoryDTO }>(`/api/documents/${id}`);
  },
  create: async (data: DocumentInput) => {
    if ((await resolveBackendMode()) === "local") return local.localDocumentsApi.create(data);
    return request<{ document: DocumentHistoryDTO }>("/api/documents", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  update: async (
    id: string,
    data: Partial<{
      insights: Record<string, unknown>;
      graphics: Array<Record<string, unknown>>;
      charts: Array<Record<string, unknown>>;
      status: string;
      documentType: string;
      language: string;
      sentiment: string;
      mimeType: string;
      finalized: boolean;
      finalReport: FinalAnalysisReport;
    }>
  ) => {
    if ((await resolveBackendMode()) === "local") return local.localDocumentsApi.update(id, data);
    return request<{ document: DocumentHistoryDTO }>(`/api/documents/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    });
  },
  remove: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localDocumentsApi.remove(id);
    return request<{ ok: true }>(`/api/documents/${id}`, { method: "DELETE" });
  },
};

/* ---------------- Notifications ---------------- */

export const notificationsApi = {
  list: async () => {
    if ((await resolveBackendMode()) === "local") return local.localNotificationsApi.list();
    return request<{ notifications: NotificationDTO[] }>("/api/notifications");
  },
  create: async (data: Partial<NotificationDTO>) => {
    if ((await resolveBackendMode()) === "local") return local.localNotificationsApi.create(data);
    return request<{ notification: NotificationDTO }>("/api/notifications", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  markRead: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localNotificationsApi.markRead(id);
    return request<{ notification: NotificationDTO }>(`/api/notifications/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ isRead: true }),
    });
  },
  markAllRead: async () => {
    if ((await resolveBackendMode()) === "local") return local.localNotificationsApi.markAllRead();
    return request<{ ok: true }>("/api/notifications/read-all", { method: "POST" });
  },
};

/* ---------------- AI ---------------- */

export const aiApi = {
  /**
   * AI evaluation of a quarterly report. Tries the server route first
   * (built-in AI on full servers, or the personal provider via Settings →
   * AI Provider on Netlify); falls back to the offline engine.
   */
  evaluateReport: async (data: {
    directorateName: string;
    quarter: string;
    content: string;
    language?: "english" | "amharic" | "bilingual";
  }): Promise<{ answers: Record<string, string>; comments: Record<string, string> }> => {
    try {
      return await request<{ answers: Record<string, string>; comments: Record<string, string> }>(
        "/api/ai/evaluate",
        {
          method: "POST",
          body: JSON.stringify(data),
          headers: await aiHeaders(),
        }
      );
    } catch {
      return local.localAiApi.evaluateReport(data);
    }
  },
  /**
   * Meta-evaluation — audits the AI evaluator's own assessment. Same
   * try-server-then-offline strategy as the evaluator itself.
   */
  evaluateEvaluator: async (data: {
    directorateKey?: string;
    directorateName: string;
    quarter: string;
    language?: "english" | "amharic" | "bilingual";
    answers: Record<string, string>;
    comments: Record<string, string>;
    totalScore: number;
    reportContent: string;
  }): Promise<{
    id: string;
    createdAt: string;
    qualityScore: number;
    verdict: string;
    report: EvaluatorAuditReport;
  }> => {
    let result: {
      id: string;
      createdAt: string;
      qualityScore: number;
      verdict: string;
      report: EvaluatorAuditReport;
    };
    try {
      result = await request<{
        id: string;
        createdAt: string;
        qualityScore: number;
        verdict: string;
        report: EvaluatorAuditReport;
      }>("/api/ai/evaluate-evaluator", {
        method: "POST",
        body: JSON.stringify(data),
        headers: await aiHeaders(),
      });
    } catch {
      result = await local.localAiApi.evaluateEvaluator(data);
    }
    // Keep an audit trail in the browser database (always available)
    try {
      if ((await resolveBackendMode()) === "local") {
        const rows = await readCollection<{
          id: string;
          createdAt: string;
          directorateName: string;
          quarter: string;
          qualityScore: number;
          verdict: string;
          report: EvaluatorAuditReport;
        }>("audits", []);
        rows.push({
          id: result.id || uid(),
          createdAt: result.createdAt || nowIso(),
          directorateName: data.directorateName,
          quarter: data.quarter,
          qualityScore: result.qualityScore,
          verdict: result.verdict,
          report: result.report,
        });
        await writeCollection("audits", rows.slice(-200));
      }
    } catch {
      /* audit history is a bonus */
    }
    return result;
  },
  documentInsights: async (data: { fileName: string; content: string }) => {
    try {
      return await request<{
        insights: Record<string, unknown>;
        graphics: Array<Record<string, unknown>>;
      }>("/api/ai/insights", {
        method: "POST",
        body: JSON.stringify(data),
        headers: await aiHeaders(),
      });
    } catch {
      return local.localAiApi.documentInsights(data);
    }
  },
  compareDocuments: async (data: {
    documents: Array<{ fileName: string; content: string }>;
  }): Promise<AICompareResult> => {
    try {
      return await request<AICompareResult>("/api/ai/compare", {
        method: "POST",
        body: JSON.stringify(data),
        headers: await aiHeaders(),
      });
    } catch {
      return local.localAiApi.compareDocuments(data);
    }
  },
  /** Universal document extraction — any file type (pdf, docx, xlsx, csv, txt, images…) */
  extractDocument: async (file: File) => {
    try {
      const form = new FormData();
      form.append("file", file);
      return await request<{
        fileName: string;
        mimeType: string;
        extractedText: string;
        wordCount: number;
        kind: string;
        meta: Record<string, unknown>;
      }>("/api/ai/extract", { method: "POST", body: form, headers: await aiHeaders() });
    } catch (serverError) {
      try {
        return await local.localAiApi.extractDocument(file);
      } catch {
        throw serverError;
      }
    }
  },
  /** AI data analysis for tabular/any content — insights + renderable chart specs */
  analyzeData: async (data: { fileName: string; content: string; mimeType?: string }) => {
    try {
      return await request<{
        analysis: Record<string, unknown>;
        charts: Array<Record<string, unknown>>;
        insights: Record<string, unknown>;
      }>("/api/ai/analyze-data", {
        method: "POST",
        body: JSON.stringify(data),
        headers: await aiHeaders(),
      });
    } catch {
      return local.localAiApi.analyzeData(data);
    }
  },
  /** Chat with the AI (optionally grounded in an analyzed document) */
  chat: async (data: { sessionId: string; message: string; documentId?: string }) => {
    // Build client-side grounding so the chat works even when the server has
    // no database access (Netlify local mode).
    let context = "";
    let history: Array<{ role: "user" | "assistant"; content: string }> = [];
    let localDocument: { fileName: string; content: string } | undefined;
    try {
      if (data.documentId) {
        const doc = await documentsApi.getById(data.documentId);
        if (doc?.document) {
          localDocument = { fileName: doc.document.fileName, content: doc.document.content };
          const insights = doc.document.insights;
          context = `The user is analyzing the document "${doc.document.fileName}".\nDOCUMENT EXCERPT (first 6000 chars):\n${doc.document.content.slice(0, 6000)}${
            insights ? `\nSAVED ANALYSIS INSIGHTS: ${JSON.stringify(insights).slice(0, 2500)}` : ""
          }`;
        }
      }
      if ((await resolveBackendMode()) === "local") {
        const historyResult = await local.localAiApi.chatHistory(data.sessionId);
        history = historyResult.messages.slice(-12).map((m) => ({
          role: m.role === "user" ? ("user" as const) : ("assistant" as const),
          content: m.content,
        }));
      }
    } catch {
      /* grounding is optional */
    }

    try {
      const reply = await request<{ reply: string }>("/api/ai/chat", {
        method: "POST",
        body: JSON.stringify({
          sessionId: data.sessionId,
          message: data.message,
          documentId: data.documentId ?? "",
          context: context || undefined,
          history: history.length > 0 ? history : undefined,
        }),
        headers: await aiHeaders(),
      });
      // Persist locally too when in local mode (server DB may be unavailable)
      if ((await resolveBackendMode()) === "local") {
        try {
          const rows = await readCollection<ChatMessageDTO>(`chat:${data.sessionId}`, []);
          rows.push(
            {
              id: uid(),
              sessionId: data.sessionId,
              role: "user",
              content: data.message,
              documentId: data.documentId ?? "",
              createdAt: nowIso(),
            },
            {
              id: uid(),
              sessionId: data.sessionId,
              role: "assistant",
              content: reply.reply,
              documentId: data.documentId ?? "",
              createdAt: nowIso(),
            }
          );
          await writeCollection(`chat:${data.sessionId}`, rows.slice(-100));
        } catch {
          /* history is a bonus */
        }
      }
      return reply;
    } catch {
      return local.localAiApi.chat(data);
    }
  },
  chatHistory: async (sessionId: string) => {
    if ((await resolveBackendMode()) === "local") return local.localAiApi.chatHistory(sessionId);
    return request<{ messages: ChatMessageDTO[] }>(
      `/api/ai/chat?sessionId=${encodeURIComponent(sessionId)}`
    );
  },
  clearChat: async (sessionId: string) => {
    if ((await resolveBackendMode()) === "local") return local.localAiApi.clearChat(sessionId);
    return request<{ ok: true }>(`/api/ai/chat?sessionId=${encodeURIComponent(sessionId)}`, {
      method: "DELETE",
    });
  },
  /**
   * Test the personal AI provider (Settings → AI Provider). Returns the
   * provider's answer or a concrete error — never falls back silently.
   */
  testProvider: async (): Promise<{ ok: boolean; reply?: string; model?: string; error?: string }> => {
    try {
      return await request<{ ok: boolean; reply?: string; model?: string; error?: string }>(
        "/api/ai/test-provider",
        { method: "POST", headers: await aiHeaders() }
      );
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : "Provider test failed" };
    }
  },
};

/* ---------------- Automation (WhatsApp / Telegram / Email) ---------------- */

export interface AutomationChannelInput {
  type: string;
  label?: string;
  target?: string;
  botToken?: string;
  enabled?: boolean;
}

/* ---- Automation edit password (server-enforced on every channel change) ---- */

const AUTOMATION_PIN_KEY = "direcscore:automationPin";

/** In-memory password cache — attached to every automation *edit* request */
let automationPinMemory = "";

/** Store the verified automation password for this tab session (survives reloads) */
export function setAutomationPin(pin: string): void {
  automationPinMemory = pin;
  try {
    if (pin) window.sessionStorage.setItem(AUTOMATION_PIN_KEY, pin);
    else window.sessionStorage.removeItem(AUTOMATION_PIN_KEY);
  } catch {
    /* sessionStorage unavailable — memory cache still works */
  }
}

/** Retrieve the previously verified automation password (empty when locked) */
export function getAutomationPin(): string {
  if (automationPinMemory) return automationPinMemory;
  try {
    automationPinMemory = window.sessionStorage.getItem(AUTOMATION_PIN_KEY) ?? "";
  } catch {
    automationPinMemory = "";
  }
  return automationPinMemory;
}

/** Clear the stored password — locks automation editing again */
export function clearAutomationPin(): void {
  setAutomationPin("");
}

export const automationApi = {
  listChannels: async () => {
    if ((await resolveBackendMode()) === "local") return local.localAutomationApi.listChannels();
    return request<{ channels: AutomationChannelDTO[] }>("/api/automation/channels");
  },
  /** Verify the automation-edit password (unlocks editing) */
  verify: async (pin: string) => {
    if ((await resolveBackendMode()) === "local") return local.localAutomationApi.verify(pin);
    return request<{ ok: true }>("/api/automation/verify", {
      method: "POST",
      body: JSON.stringify({ pin }),
    });
  },
  saveChannel: async (data: AutomationChannelInput & { id?: string }) => {
    const pin = getAutomationPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.saveChannel({ ...data, _pin: pin });
    }
    return request<{ channel: AutomationChannelDTO }>("/api/automation/channels", {
      method: "POST",
      body: JSON.stringify(data),
      headers: pin ? { "x-automation-pin": pin } : {},
    });
  },
  deleteChannel: async (id: string) => {
    const pin = getAutomationPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.deleteChannel(id, pin);
    }
    return request<{ ok: true }>(`/api/automation/channels?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: pin ? { "x-automation-pin": pin } : {},
    });
  },
  /** Send one evaluation result through a specific channel */
  sendScore: async (data: { channelId: string; evaluationId: string }) => {
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.send({ evaluationIds: [data.evaluationId] });
    }
    return request<{ results: DeliveryLogDTO[] }>("/api/automation/send", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  /** Send several evaluation results to every enabled channel */
  sendScores: async (data: { evaluationIds: string[] }) => {
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.send(data);
    }
    return request<{ results: DeliveryLogDTO[] }>("/api/automation/send", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  /** Called automatically after an evaluation is completed — fans out to enabled channels */
  autoNotify: async (data: { evaluationId: string }) => {
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.autoNotify(data);
    }
    return request<{ results: DeliveryLogDTO[] }>("/api/automation/auto-notify", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  testChannel: async (data: { channelId: string }) => {
    const pin = getAutomationPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localAutomationApi.testChannel(data, pin);
    }
    return request<{ result: DeliveryLogDTO }>("/api/automation/test", {
      method: "POST",
      body: JSON.stringify(data),
      headers: pin ? { "x-automation-pin": pin } : {},
    });
  },
  logs: async (limit = 50) => {
    if ((await resolveBackendMode()) === "local") return local.localAutomationApi.logs(limit);
    return request<{ logs: DeliveryLogDTO[] }>(`/api/automation/logs?limit=${limit}`);
  },
};

/* ---------------- System / server status ---------------- */

export const systemApi = {
  status: async () => {
    if ((await resolveBackendMode()) === "local") return local.localSystemApi.status();
    return request<SystemStatus>("/api/system/status");
  },
  clearCache: async () => {
    if ((await resolveBackendMode()) === "local") return local.localSystemApi.clearCache();
    return request<{ cache: SystemStatus["cache"] }>("/api/system/cache", { method: "DELETE" });
  },
};

/* ---------------- Analytics summary ---------------- */

export interface AnalyticsSummary {
  quarters: string[];
  kpis: {
    evaluations: number;
    directoratesEvaluated: number;
    avgScore: number;
    avgPct: number;
    needsImprovement: number;
    average: number;
    good: number;
    highest: { short: string; nameEn: string; total: number; quarter: string } | null;
    lowest: { short: string; nameEn: string; total: number; quarter: string } | null;
  };
  byDirectorate: Array<{
    key: string;
    short: string;
    nameEn: string;
    latest: { total: number; pct: number; quarter: string; status: string } | null;
    previousTotal: number | null;
    trend: number | null;
  }>;
  categoryAverages: Array<{ key: string; nameEn: string; avg: number; max: number }>;
  history: Array<{ quarter: string; count: number; avg: number }>;
}

export const analyticsApi = {
  summary: async (): Promise<AnalyticsSummary> => {
    if ((await resolveBackendMode()) === "local") return local.localAnalyticsApi.summary();
    return request<AnalyticsSummary>("/api/analytics/summary");
  },
};

/* ---------------- QR ---------------- */

export async function fetchQrDataUrl(data: string, size = 300): Promise<string> {
  // The QR route is pure computation — it works on every host, including
  // read-only serverless deployments.
  const res = await fetch(`/api/qr?data=${encodeURIComponent(data)}&size=${size}`);
  if (!res.ok) throw new Error("QR generation failed");
  const json = (await res.json()) as { dataUrl: string };
  return json.dataUrl;
}

/* ---------------- Settings / branding / dark mode ---------------- */

export interface SettingsInput {
  organizationName?: string;
  autoBackupEnabled?: boolean;
  backupFrequency?: "weekly" | "daily";
  driveClientId?: string;
  driveClientSecret?: string;
  driveRefreshToken?: string;
  driveFolderId?: string;
  clearDriveConfig?: boolean;
  /** Write-only security PINs (never echoed back by GET) */
  filingPin?: string;
  automationPin?: string;
  settingsPin?: string;
}

/* ---- Settings page password (server-enforced on every settings change) ---- */

const SETTINGS_PIN_KEY = "direcscore:settingsPin";

/** In-memory password cache — attached to every settings change request */
let settingsPinMemory = "";

/** Store the verified settings password for this tab session (survives reloads) */
export function setSettingsPin(pin: string): void {
  settingsPinMemory = pin;
  try {
    if (pin) window.sessionStorage.setItem(SETTINGS_PIN_KEY, pin);
    else window.sessionStorage.removeItem(SETTINGS_PIN_KEY);
  } catch {
    /* sessionStorage unavailable — memory cache still works */
  }
}

/** Retrieve the previously verified settings password (empty when locked) */
export function getSettingsPin(): string {
  if (settingsPinMemory) return settingsPinMemory;
  try {
    settingsPinMemory = window.sessionStorage.getItem(SETTINGS_PIN_KEY) ?? "";
  } catch {
    settingsPinMemory = "";
  }
  return settingsPinMemory;
}

/** Clear the stored password — locks the Settings page again */
export function clearSettingsPin(): void {
  setSettingsPin("");
}

export const settingsApi = {
  get: async (): Promise<{ settings: AppSettingsDTO }> => {
    if ((await resolveBackendMode()) === "local") return local.localSettingsApi.get();
    return request<{ settings: AppSettingsDTO }>("/api/settings");
  },
  /** Verify the settings password (unlocks the page) */
  verify: async (pin: string) => {
    if ((await resolveBackendMode()) === "local") return local.localSettingsApi.verify(pin);
    return request<{ ok: true }>("/api/settings/verify", {
      method: "POST",
      body: JSON.stringify({ pin }),
    });
  },
  update: async (data: SettingsInput) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localSettingsApi.update(data as unknown as Record<string, unknown>);
    }
    return request<{ settings: AppSettingsDTO }>("/api/settings", {
      method: "PUT",
      body: JSON.stringify(data),
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  /** Fetch the bureau logo as a data URL (custom upload or built-in Harari logo) */
  getLogo: async (): Promise<{ logoDataUrl: string; custom: boolean }> => {
    if ((await resolveBackendMode()) === "local") return local.localSettingsApi.getLogo();
    return request<{ logoDataUrl: string; custom: boolean }>("/api/settings/logo");
  },
  uploadLogo: async (file: File) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localSettingsApi.uploadLogo(file, pin);
    }
    const form = new FormData();
    form.append("file", file);
    return request<{ logoDataUrl: string; custom: boolean }>("/api/settings/logo", {
      method: "POST",
      body: form,
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  removeLogo: async () => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localSettingsApi.removeLogo(pin);
    }
    return request<{ logoDataUrl: string; custom: boolean }>("/api/settings/logo", {
      method: "DELETE",
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
};

/* ---------------- Backup (Google Drive on servers / download-restore locally) ---------------- */

export const backupApi = {
  status: async (): Promise<BackupStatusDTO> => {
    if ((await resolveBackendMode()) === "local") return local.localBackupApi.status();
    return request<BackupStatusDTO>("/api/backup/drive");
  },
  /** Run a backup now — Drive on servers, a JSON download in local mode */
  run: async (): Promise<BackupResultDTO> => {
    if ((await resolveBackendMode()) === "local") {
      const result = await local.localBackupApi.run();
      const { _settings: _omit, ...dto } = result;
      return dto;
    }
    return request<BackupResultDTO & { counts?: Record<string, number> }>("/api/backup/drive", {
      method: "POST",
    });
  },
  /** Server JSON export URL (server mode only) */
  exportUrl: "/api/backup/export",
  /** Restore a previously downloaded backup (local mode) */
  restore: async (file: File): Promise<{ files: number; collections: number }> => {
    const { importLocalBackup } = await import("@/lib/local-db");
    const text = await file.text();
    const payload = JSON.parse(text) as Parameters<typeof importLocalBackup>[0];
    return importLocalBackup(payload);
  },
};

/* ---------------- Quality report documents (per directorate) ---------------- */

export interface QualityReportMeta {
  directorateKey: string;
  quarter?: string;
  title?: string;
  note?: string;
}

export const qualityApi = {
  list: async (directorateKey?: string) => {
    if ((await resolveBackendMode()) === "local") return local.localQualityApi.list(directorateKey);
    const qs = directorateKey ? `?directorateKey=${encodeURIComponent(directorateKey)}` : "";
    return request<{ reports: QualityReportDTO[] }>(`/api/quality-reports${qs}`);
  },
  /**
   * Upload a quality report document under a directorate — ANY file type is
   * accepted (PDF, Word, Excel, PowerPoint, images, etc., ≤ 10 MB). On
   * success the unique share link is immediately automated to every enabled
   * WhatsApp / Telegram / Email channel.
   */
  upload: async (file: File, meta: QualityReportMeta) => {
    if ((await resolveBackendMode()) === "local") {
      const result = await local.localQualityApi.upload(file, meta);
      return { report: result.report, deliveries: result.deliveries };
    }
    const form = new FormData();
    form.append("file", file);
    form.append("directorateKey", meta.directorateKey);
    if (meta.quarter) form.append("quarter", meta.quarter);
    if (meta.title) form.append("title", meta.title);
    if (meta.note) form.append("note", meta.note);
    return request<{ report: QualityReportDTO; deliveries: DeliveryLogDTO[] }>(
      "/api/quality-reports",
      { method: "POST", body: form }
    );
  },
  remove: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localQualityApi.remove(id);
    return request<{ ok: true }>(`/api/quality-reports?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
  },
  /** Download URL for an uploaded document (works in both modes) */
  fileUrl: (id: string) => {
    if (peekBackendMode() === "local") return `/share/report?id=${encodeURIComponent(id)}`;
    return `/api/quality-reports/file?id=${encodeURIComponent(id)}`;
  },
};

/* ---------------- Public portal (directorate shareable link) ---------------- */

export const portalApi = {
  upload: async (
    file: File,
    meta: { directorateKey: string; quarter?: string; title?: string; note?: string }
  ) => {
    if ((await resolveBackendMode()) === "local") {
      const result = await local.localPortalApi.upload(file, meta);
      return {
        report: result.report,
        shareUrl: result.shareUrl,
        deliveries: result.deliveries,
        handoffs: result._handoffs,
      };
    }
    const form = new FormData();
    form.append("file", file);
    form.append("directorateKey", meta.directorateKey);
    if (meta.quarter) form.append("quarter", meta.quarter);
    if (meta.title) form.append("title", meta.title);
    if (meta.note) form.append("note", meta.note);
    return request<{
      report: QualityReportDTO;
      shareUrl: string;
      deliveries: DeliveryLogDTO[];
    }>("/api/portal/upload", { method: "POST", body: form });
  },
  /** The directorate's own uploaded documents (metadata, newest first) */
  listUploads: async (directorateKey: string) => {
    return qualityApi.list(directorateKey);
  },
};

/* ---------------- Unique shareable links ---------------- */

/** Public unique link for an uploaded quality report document */
export function reportShareUrl(shareToken: string): string {
  if (typeof window === "undefined") return `/api/share/report?token=${shareToken}`;
  const base = `${window.location.origin}`;
  if (peekBackendMode() === "local") {
    return `${base}/share/report?token=${encodeURIComponent(shareToken)}`;
  }
  return `${base}/api/share/report?token=${encodeURIComponent(shareToken)}`;
}

/** Build WhatsApp / Telegram / Email share compose URLs for any link */
export function buildShareLinks(link: string, text: string) {
  const encodedText = encodeURIComponent(text);
  const encodedLink = encodeURIComponent(link);
  const combined = encodeURIComponent(`${text}\n${link}`);
  return {
    copy: link,
    whatsapp: `https://wa.me/?text=${combined}`,
    telegram: `https://t.me/share/url?url=${encodedLink}&text=${encodedText}`,
    email: `mailto:?subject=${encodedText}&body=${combined}`,
  };
}

/* ---------------- Directorate feedback (comments & suggestions) ---------------- */

export const feedbackApi = {
  /** Public — submit from a directorate's own portal */
  submit: async (data: {
    directorateKey: string;
    directorateName?: string;
    quarter?: string;
    kind?: "comment" | "suggestion";
    message: string;
    contact?: string;
  }) => {
    if ((await resolveBackendMode()) === "local") return local.localFeedbackApi.submit(data);
    return request<{ feedback: FeedbackDTO; deliveries?: DeliveryLogDTO[] }>("/api/feedback", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  list: async (params?: { directorateKey?: string; unreadOnly?: boolean }) => {
    if ((await resolveBackendMode()) === "local") return local.localFeedbackApi.list(params);
    const search = new URLSearchParams();
    if (params?.directorateKey) search.set("directorateKey", params.directorateKey);
    if (params?.unreadOnly) search.set("unread", "1");
    const qs = search.toString();
    return request<{ feedback: FeedbackDTO[]; unreadCount: number }>(
      `/api/feedback${qs ? `?${qs}` : ""}`
    );
  },
  markRead: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localFeedbackApi.markRead(id);
    return request<{ feedback: FeedbackDTO }>(`/api/feedback?id=${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ isRead: true }),
    });
  },
};

/* ---------------- Secure document filing room (PIN 3472) ---------------- */

const FILING_PIN_KEY = "direcscore:filingPin";

/** In-memory PIN cache — attached to every /api/filing/* request */
let filingPinMemory = "";

/** Store the verified filing PIN for this tab session (survives reloads) */
export function setFilingPin(pin: string): void {
  filingPinMemory = pin;
  try {
    if (pin) window.sessionStorage.setItem(FILING_PIN_KEY, pin);
    else window.sessionStorage.removeItem(FILING_PIN_KEY);
  } catch {
    /* sessionStorage unavailable — memory cache still works */
  }
}

/** Retrieve the previously verified filing PIN (empty when locked) */
export function getFilingPin(): string {
  if (filingPinMemory) return filingPinMemory;
  try {
    filingPinMemory = window.sessionStorage.getItem(FILING_PIN_KEY) ?? "";
  } catch {
    filingPinMemory = "";
  }
  return filingPinMemory;
}

/** Clear the stored PIN — locks the filing room again */
export function clearFilingPin(): void {
  setFilingPin("");
}

export interface FiledDocumentMeta {
  title?: string;
  category?: string;
  note?: string;
}

export const filingApi = {
  /** Verify the filing-room password */
  verify: async (pin: string) => {
    if ((await resolveBackendMode()) === "local") return local.localFilingApi.verify(pin);
    return request<{ ok: true }>("/api/filing/verify", {
      method: "POST",
      body: JSON.stringify({ pin }),
    });
  },
  /** List filed documents (metadata only) */
  list: async () => {
    if ((await resolveBackendMode()) === "local") return local.localFilingApi.list();
    const pin = getFilingPin();
    return request<{ documents: FiledDocumentDTO[] }>("/api/filing/documents", {
      headers: pin ? { "x-filing-pin": pin } : {},
    });
  },
  /** Upload + scan + file a document (any type ≤ 10 MB) */
  upload: async (file: File, meta: FiledDocumentMeta = {}) => {
    if ((await resolveBackendMode()) === "local") {
      return local.localFilingApi.upload(file, meta);
    }
    const form = new FormData();
    form.append("file", file);
    if (meta.title) form.append("title", meta.title);
    if (meta.category) form.append("category", meta.category);
    if (meta.note) form.append("note", meta.note);
    const pin = getFilingPin();
    return request<{ document: FiledDocumentDTO; scan: FileScanReport }>(
      "/api/filing/documents",
      { method: "POST", body: form, headers: pin ? { "x-filing-pin": pin } : {} }
    );
  },
  remove: async (id: string) => {
    if ((await resolveBackendMode()) === "local") return local.localFilingApi.remove(id);
    const pin = getFilingPin();
    return request<{ ok: true }>(`/api/filing/documents?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: pin ? { "x-filing-pin": pin } : {},
    });
  },
};

/** Public unique share link for a filed document */
export function filingShareUrl(shareToken: string, download = false): string {
  const qs = `token=${encodeURIComponent(shareToken)}${download ? "&download=1" : ""}`;
  if (typeof window === "undefined") return `/api/share/file?${qs}`;
  if (peekBackendMode() === "local") {
    return `${window.location.origin}/share/file?${qs}`;
  }
  return `${window.location.origin}/api/share/file?${qs}`;
}

/* ---------------- Link attachment library (similar apps / learning / other) ---------------- */

export const linksApi = {
  list: async (category?: string) => {
    if ((await resolveBackendMode()) === "local") return local.localLinksApi.list(category);
    const qs = category ? `?category=${encodeURIComponent(category)}` : "";
    return request<{ links: LinkItemDTO[] }>(`/api/links${qs}`);
  },
  create: async (data: { title: string; url: string; category?: string; description?: string }) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localLinksApi.create(data, pin);
    return request<{ link: LinkItemDTO }>("/api/links", {
      method: "POST",
      body: JSON.stringify(data),
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  update: async (
    id: string,
    data: { title?: string; url?: string; category?: string; description?: string }
  ) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localLinksApi.update(id, data, pin);
    return request<{ link: LinkItemDTO }>(`/api/links?id=${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  remove: async (id: string) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localLinksApi.remove(id, pin);
    return request<{ ok: true }>(`/api/links?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
};

/* ---------------- Quarterly report submission deadline ---------------- */

export const deadlineApi = {
  /** Public — the dashboard banner and the portal countdown both read it */
  get: async (): Promise<DeadlineStateDTO> => {
    if ((await resolveBackendMode()) === "local") return local.localDeadlineApi.get();
    return request<DeadlineStateDTO>("/api/deadline");
  },
  /** Settings-password protected */
  set: async (quarter: string, date: string) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localDeadlineApi.set(quarter, date, pin);
    return request<{ deadline: { quarter: string; date: string } }>("/api/deadline", {
      method: "PUT",
      body: JSON.stringify({ quarter, date }),
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  /** Settings-password protected */
  clear: async () => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localDeadlineApi.clear(pin);
    return request<{ ok: true }>("/api/deadline", {
      method: "DELETE",
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  /** Send the "submit before the deadline" reminder now (Settings password) */
  remindNow: async () => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localDeadlineApi.remindNow(pin);
    return request<{ deliveries: DeliveryLogDTO[] }>("/api/deadline/remind", {
      method: "POST",
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
};

/* ---------------- Directorate contacts (one-go sending) ---------------- */

export interface ContactInput {
  directorateKey: string;
  email?: string;
  whatsapp?: string;
  telegram?: string;
}

export const contactsApi = {
  list: async () => {
    if ((await resolveBackendMode()) === "local") return local.localContactsApi.list();
    return request<{ contacts: ContactDTO[] }>("/api/contacts");
  },
  /** Insert or update one directorate's email / WhatsApp / Telegram (settings PIN) */
  save: async (data: ContactInput) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") return local.localContactsApi.save(data, pin);
    return request<{ contact: ContactDTO }>("/api/contacts", {
      method: "PUT",
      body: JSON.stringify(data),
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  /** Delete a directorate's saved contacts (settings PIN) */
  remove: async (directorateKey: string) => {
    const pin = getSettingsPin();
    if ((await resolveBackendMode()) === "local") {
      return local.localContactsApi.remove(directorateKey, pin);
    }
    return request<{ ok: true }>(`/api/contacts?key=${encodeURIComponent(directorateKey)}`, {
      method: "DELETE",
      headers: pin ? { "x-settings-pin": pin } : {},
    });
  },
  /**
   * Send everything in one go — quarterly score reports to each evaluated
   * directorate, or a submit-before-deadline reminder to every directorate.
   */
  sendAll: async (data: {
    mode: "scores" | "reminder";
    quarter?: string;
    directorateKeys?: string[];
  }): Promise<ContactSendAllDTO> => {
    if ((await resolveBackendMode()) === "local") return local.localContactsApi.sendAll(data);
    return request<ContactSendAllDTO>("/api/contacts/send", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
};

/* ---------------- Mode helpers for the UI ---------------- */

/** Resolves to true when the browser data engine is backing this session */
export async function isLocalMode(): Promise<boolean> {
  return (await resolveBackendMode()) === "local";
}

/** Synchronous best-effort read of the resolved mode (null before first probe) */
export function peekMode(): "server" | "local" | null {
  return peekBackendMode();
}

/** Ask the browser to re-run backend detection (Settings → Storage card) */
export async function recheckBackendMode(): Promise<"server" | "local"> {
  const { resetBackendMode, resolveBackendMode } = await import("@/lib/backend-mode");
  resetBackendMode();
  return resolveBackendMode();
}

export { local };
