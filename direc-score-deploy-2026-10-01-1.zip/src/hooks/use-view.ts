"use client";

import { useCallback, useEffect, useState } from "react";

export type ViewName =
  | "home"
  | "evaluate"
  | "review"
  | "analytics"
  | "qrcodes"
  | "portal"
  | "submit"
  | "ai-studio"
  | "document-history"
  | "compare"
  | "automation"
  | "filing"
  | "links"
  | "contacts"
  | "about"
  | "settings";

export type NavigateFn = (
  view: ViewName,
  params?: Record<string, string>,
  replace?: boolean
) => void;

interface ViewState {
  view: ViewName;
  params: Record<string, string>;
}

function parseViewFromUrl(): ViewState {
  if (typeof window === "undefined") return { view: "home", params: {} };
  const search = new URLSearchParams(window.location.search);
  const raw = search.get("view");
  const known: ViewName[] = [
    "home", "evaluate", "review", "analytics", "qrcodes", "portal",
    "submit", "ai-studio", "document-history", "compare", "automation", "filing", "links",
    "contacts", "about", "settings",
  ];
  const view = known.includes(raw as ViewName) ? (raw as ViewName) : "home";
  const params: Record<string, string> = {};
  search.forEach((value, key) => {
    if (key !== "view") params[key] = value;
  });
  return { view, params };
}

/** Hash-free single-route navigation: /?view=x&key=val */
export function useViewNavigation() {
  const [state, setState] = useState<ViewState>(parseViewFromUrl);

  useEffect(() => {
    const onPop = () => setState(parseViewFromUrl());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const navigate = useCallback(
    (view: ViewName, params?: Record<string, string>, replace = false) => {
      const search = new URLSearchParams();
      if (view !== "home") search.set("view", view);
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== "") search.set(k, v);
        });
      }
      const qs = search.toString();
      const url = `/${qs ? `?${qs}` : ""}`;
      if (replace) window.history.replaceState({}, "", url);
      else window.history.pushState({}, "", url);
      window.scrollTo({ top: 0 });
      setState({ view, params: params ?? {} });
    },
    []
  );

  const refresh = useCallback(() => setState(parseViewFromUrl()), []);

  return { view: state.view, params: state.params, navigate, refresh };
}

/** Build an absolute URL for QR codes / external links (stays on single route) */
export function buildAbsoluteUrl(view: ViewName, params?: Record<string, string>): string {
  if (typeof window === "undefined") return "/";
  const search = new URLSearchParams();
  if (view !== "home") search.set("view", view);
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      if (v) search.set(k, v);
    });
  }
  const qs = search.toString();
  return `${window.location.origin}/${qs ? `?${qs}` : ""}`;
}
